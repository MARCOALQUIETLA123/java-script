<?php
    $servername = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "library_management_system";

    try {
        // utf8mb4 so names with accents or other non-English characters save correctly.
        $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8mb4", $dbusername, $dbpassword);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Keep MySQL's NOW() on Philippine time (UTC+8) so created_at / reserved_at
        // agree with the "today" PHP uses for due dates and overdue checks.
        $conn->exec("SET time_zone = '+08:00'");

        // Older databases get the fine / lost-damaged columns added automatically (see api/schema_updates.php).
        try {
            require_once __DIR__ . "/../api/schema_updates.php";
            lms_ensure_schema($conn);
        } catch (Throwable $e) {
            error_log("schema update failed: " . $e->getMessage());
        }
    } catch(PDOException $e) {
        error_log("DB connection failed: " . $e->getMessage());
        $local = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true);
        echo json_encode(["status" => "error", "message" => "Database connection failed." . ($local ? " " . $e->getMessage() : "")]);
        exit;
    }