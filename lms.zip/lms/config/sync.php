<?php
// Live-update counter shared by every device.
//
// One row in `sync_state` holds a number that goes up by 1 every time anyone changes
// data. Each open page asks api/sync.php for that number every few seconds and reloads
// its own data when the number differs from the one it saw last. The table is created
// automatically the first time a change is saved.

class Sync {
    // Own connection helper: connection-pdo.php prints JSON and exits when the database is
    // down, so anything it prints is swallowed here (this runs after the response is sent).
    private static function db() {
        ob_start(function () { return ''; });
        include __DIR__ . '/connection-pdo.php';
        ob_end_clean();
        return $conn ?? null;
    }

    static function version() {
        $conn = self::db();
        if (!$conn) return 0;

        try {
            $v = $conn->query("SELECT version FROM sync_state WHERE id = 1")->fetchColumn();
            return $v === false ? 0 : (int) $v;
        } catch (PDOException $e) {
            return 0; // table not created yet: nothing has changed
        }
    }

    // Called once, after the request finishes, for every request that may have changed data.
    static function bump() {
        $conn = self::db();
        if (!$conn) return;

        $sql = "INSERT INTO sync_state (id, version, updated_at) VALUES (1, 1, NOW())
                ON DUPLICATE KEY UPDATE version = version + 1, updated_at = NOW()";

        try {
            $conn->exec($sql);
        } catch (PDOException $e) {
            try {
                $conn->exec("CREATE TABLE IF NOT EXISTS sync_state (
                                id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
                                version BIGINT UNSIGNED NOT NULL DEFAULT 0,
                                updated_at DATETIME NULL
                             )");
                $conn->exec($sql);
            } catch (PDOException $e2) {
                error_log("sync bump failed: " . $e2->getMessage());
            }
        }
    }
}
