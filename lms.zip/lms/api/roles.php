<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));   // not in STAFF_OPS, so only the Technical Services Librarian

// Roles are fixed. Only these six exist and they can't be added, renamed or deleted.
// Loan periods and borrowing limits are not stored on roles: they are edited on the Loan Rules page.
class Roles {
    const DEFAULT_ROLES = ['Technical Services Librarian', 'Library Staff', 'Student Assistant', 'Student', 'Faculty', 'Dean'];

    // Older databases call these roles "Admin" and "Staff". They are renamed the first time this runs.
    const OLD_NAMES = ['Admin' => 'Technical Services Librarian', 'Staff' => 'Library Staff'];

    private function ensureDefaults($conn) {
        $find = $conn->prepare("SELECT role_id FROM roles WHERE LOWER(TRIM(role_name)) = LOWER(:n) LIMIT 1");

        foreach (self::OLD_NAMES as $old => $new) {
            $find->execute([":n" => $new]);
            if ($find->fetchColumn() !== false) continue;   // already renamed

            $conn->prepare("UPDATE roles SET role_name = :new WHERE LOWER(TRIM(role_name)) = LOWER(:old)")
                 ->execute([":new" => $new, ":old" => $old]);
        }

        foreach (self::DEFAULT_ROLES as $name) {
            $find->execute([":n" => $name]);
            if ($find->fetchColumn() !== false) continue;

            lms_lock_ids($conn);
            $next = (int) $conn->query("SELECT COALESCE(MAX(role_id), 0) + 1 FROM roles")->fetchColumn();
            $conn->prepare("INSERT INTO roles (role_id, role_name, default_loan_days) VALUES (:id, :n, 0)")
                 ->execute([":id" => $next, ":n" => $name]);
        }
    }

    function getAll() {
        include "../config/connection-pdo.php";

        $this->ensureDefaults($conn);

        $rows = $conn->query("SELECT r.role_id, r.role_name, COUNT(u.user_id) AS user_count
                              FROM roles r
                              LEFT JOIN users u ON u.role_id = r.role_id
                              GROUP BY r.role_id, r.role_name")->fetchAll(PDO::FETCH_ASSOC);

        $order = array_map('strtolower', self::DEFAULT_ROLES);

        foreach ($rows as &$r) {
            $pos = array_search(strtolower(trim($r['role_name'])), $order, true);
            $r['role_id']    = (int) $r['role_id'];
            $r['user_count'] = (int) $r['user_count'];
            $r['_sort']      = $pos === false ? 99 : $pos;
        }
        unset($r);

        usort($rows, function ($a, $b) {
            return [$a['_sort'], $a['role_name']] <=> [$b['_sort'], $b['role_name']];
        });
        foreach ($rows as &$r) unset($r['_sort']);

        echo json_encode($rows);
    }

    function locked() {
        echo json_encode([
            "status"  => "error",
            "message" => "Roles are fixed (Technical Services Librarian, Library Staff, Student Assistant, Student, Faculty and Dean) and can't be added, changed or deleted."
        ]);
    }
}

$operation = $_GET['operation'] ?? $_POST['operation'] ?? '';

$obj = new Roles();

switch ($operation) {
    case "getAll":
        $obj->getAll();
        break;
    case "add":
    case "update":
    case "delete":
        $obj->locked();
        break;
}
?>
