<?php
// Answers "has anything changed since I last looked?" for the live-update script.
header('Content-Type: application/json');
header('Cache-Control: no-store');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));

if (($_GET['operation'] ?? '') !== 'version') {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Unknown operation."]);
    exit;
}

echo json_encode(["status" => "success", "version" => Sync::version()]);
