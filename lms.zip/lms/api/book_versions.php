<?php
// Finds the newest edition of a book.
// "Same book, newer version" means: the same title (ignoring capitals and extra spaces) and exactly the same
// authors, but a later published year. Used when a borrower has to replace a lost or damaged book.

class BookVersions {

    private static function authorKey($conn, $book_id) {
        $stmt = $conn->prepare("SELECT author_id FROM book_author WHERE book_id = :b ORDER BY author_id");
        $stmt->execute([':b' => $book_id]);
        return implode(',', $stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    // "First Last, First Last" for a book (empty string when it has no authors).
    static function authorNames($conn, $book_id) {
        $stmt = $conn->prepare("SELECT CONCAT_WS(' ', a.first_name, a.last_name)
                                FROM book_author ba INNER JOIN author a ON ba.author_id = a.author_id
                                WHERE ba.book_id = :b ORDER BY a.first_name, a.last_name");
        $stmt->execute([':b' => $book_id]);
        return implode(', ', $stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    // The book to buy or replace with: ['book_id', 'title', 'published_year', 'price', 'is_newer' => bool].
    // is_newer is true when a later edition than $book_id exists. Returns null if the book is not found.
    static function newest($conn, $book_id) {
        $stmt = $conn->prepare("SELECT book_id, title, published_year, price FROM book WHERE book_id = :b");
        $stmt->execute([':b' => $book_id]);
        $book = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$book) return null;

        $best = $book;
        $mine = self::authorKey($conn, $book_id);

        $same = $conn->prepare("SELECT book_id, title, published_year, price FROM book
                                WHERE LOWER(TRIM(title)) = LOWER(TRIM(:t)) AND book_id <> :b AND published_year > :y
                                ORDER BY published_year DESC, book_id DESC");
        $same->execute([':t' => $book['title'], ':b' => $book_id, ':y' => (int) $book['published_year']]);

        foreach ($same->fetchAll(PDO::FETCH_ASSOC) as $cand) {
            // Same authors, and no authors at all on one side but not the other, are both handled by comparing the lists.
            if (self::authorKey($conn, $cand['book_id']) === $mine) { $best = $cand; break; }
        }

        return [
            'book_id'        => (int) $best['book_id'],
            'title'          => $best['title'],
            'published_year' => $best['published_year'] !== null ? (int) $best['published_year'] : null,
            'price'          => $best['price'] !== null ? (float) $best['price'] : null,
            'is_newer'       => (int) $best['book_id'] !== (int) $book_id,
        ];
    }
}