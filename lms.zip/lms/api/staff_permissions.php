<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));   // not in Auth::PERMISSIONS, so only the Technical Services Librarian can reach it

// Permissions for each Library Staff / Student Assistant account. Only the Technical Services Librarian can read
// or change them, so a staff account can never change its own. Nothing is granted until it is switched on here.
class StaffPermissions {

    private function reply($status, $message) {
        echo json_encode(["status" => $status, "message" => $message]);
    }

    private function staffRoleSql() {
        return "LOWER(TRIM(r.role_name)) IN ('" . implode("','", array_merge(Auth::STAFF_NAMES, Auth::SA_NAMES)) . "')";
    }

    // The permission list, the staff / SA accounts, and what each account has been granted.
    function getAll() {
        include "../config/connection-pdo.php";
        Auth::grants($conn, 0);   // makes sure the table exists

        $perms = [];
        foreach (Auth::PERMISSIONS as $key => $p) {
            $perms[] = ["key" => $key, "label" => $p['label'], "desc" => $p['desc']];
        }

        $users = $conn->query("SELECT u.user_id, u.first_name, u.last_name, u.username, u.account_status, r.role_name
                               FROM users u INNER JOIN roles r ON u.role_id = r.role_id
                               WHERE " . $this->staffRoleSql() . " AND u.account_status IN ('active', 'disabled')
                               ORDER BY u.first_name, u.last_name")->fetchAll(PDO::FETCH_ASSOC);

        $granted = [];
        foreach ($conn->query("SELECT user_id, perm_key FROM staff_user_permission WHERE granted = 1") as $row) {
            $granted[(int) $row['user_id']][] = $row['perm_key'];
        }

        foreach ($users as &$u) {
            $u['user_id'] = (int) $u['user_id'];
            $u['is_sa'] = Auth::roleKey($u['role_name']) === 'sa' ? 1 : 0;
            $u['granted'] = array_values(array_intersect($granted[$u['user_id']] ?? [], array_keys(Auth::PERMISSIONS)));
        }

        echo json_encode(["permissions" => $perms, "users" => $users]);
    }

    function save($json) {
        include "../config/connection-pdo.php";
        $data = json_decode($json, true) ?: [];
        $user_id = (int) ($data['user_id'] ?? 0);
        $granted = isset($data['granted']) && is_array($data['granted']) ? $data['granted'] : [];

        foreach ($granted as $key) {
            if (!is_string($key) || !isset(Auth::PERMISSIONS[$key])) {
                $this->reply("error", "Unknown permission.");
                return;
            }
        }

        Auth::grants($conn, 0);   // makes sure the table exists before the transaction starts

        $chk = $conn->prepare("SELECT 1 FROM users u INNER JOIN roles r ON u.role_id = r.role_id
                               WHERE u.user_id = :u AND " . $this->staffRoleSql());
        $chk->execute([":u" => $user_id]);
        if (!$chk->fetchColumn()) {
            $this->reply("error", "Choose a Library Staff or Student Assistant account.");
            return;
        }

        try {
            $conn->beginTransaction();
            $up = $conn->prepare("INSERT INTO staff_user_permission (user_id, perm_key, granted, updated_by_user_id, updated_at)
                                  VALUES (:uid, :k, :g, :by, NOW())
                                  ON DUPLICATE KEY UPDATE granted = VALUES(granted),
                                                          updated_by_user_id = VALUES(updated_by_user_id),
                                                          updated_at = NOW()");
            foreach (array_keys(Auth::PERMISSIONS) as $key) {
                $up->execute([":uid" => $user_id, ":k" => $key, ":g" => in_array($key, $granted, true) ? 1 : 0, ":by" => Auth::id()]);
            }
            $conn->commit();
            $this->reply("success", "Permissions saved for this account.");
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("permission save failed: " . $e->getMessage());
            $this->reply("error", "Failed to save the permissions.");
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = $_GET['json'] ?? "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = $_POST['json'] ?? "";
}

$obj = new StaffPermissions();

switch ($operation) {
    case "getAll": $obj->getAll(); break;
    case "save":   $obj->save($json); break;
}
?>
