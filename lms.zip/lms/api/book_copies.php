<?php
require_once __DIR__ . "/schema_updates.php";

header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));

class BookCopies {

    // The status of a copy that stays in the library and can't be borrowed or reserved.
    private function libraryStatusId($conn) {
        $id = $conn->query("SELECT status_id FROM status WHERE status_desc = 'Library Use Only' LIMIT 1")->fetchColumn();
        return $id === false ? null : (int) $id;
    }

    // Every book needs at least one library-use-only copy. Returns an error message if changing or disposing
    // this copy would leave its book without one, otherwise null. $allowLastCopy lets the book's only remaining
    // copy go (a book with no copies left has nothing to protect).
    private function libraryCopyBlock($conn, $copy_id, $allowLastCopy) {
        $luo = $this->libraryStatusId($conn);
        if ($luo === null) return null;

        $row = $conn->prepare("SELECT book_id, status_id, accession_number FROM book_copies WHERE copy_id = :c");
        $row->execute([":c" => $copy_id]);
        $copy = $row->fetch(PDO::FETCH_ASSOC);
        if (!$copy || (int) $copy['status_id'] !== $luo) return null;

        $others = $conn->prepare("SELECT COUNT(*) FROM book_copies WHERE book_id = :b AND status_id = :s AND copy_id <> :c AND archived_at IS NULL");
        $others->execute([":b" => $copy['book_id'], ":s" => $luo, ":c" => $copy_id]);
        if ((int) $others->fetchColumn() > 0) return null;

        if ($allowLastCopy) {
            $rest = $conn->prepare("SELECT COUNT(*) FROM book_copies WHERE book_id = :b AND copy_id <> :c AND archived_at IS NULL");
            $rest->execute([":b" => $copy['book_id'], ":c" => $copy_id]);
            if ((int) $rest->fetchColumn() === 0) return null;
        }

        return "ACC-" . $copy['accession_number'] . " is the library-use-only copy of this book. Every book needs at least one, so mark another copy as Library Use Only first.";
    }

    // Statuses that the borrowing flow manages itself. Setting them by hand would make the
    // shelf and the borrow records disagree, so the copy form may not change them.
    private function statusGuard($conn, $new_status_id, $copy_id = null) {
        $stmt = $conn->prepare("SELECT status_desc FROM status WHERE status_id = :id");
        $stmt->bindParam(":id", $new_status_id);
        $stmt->execute();
        $newDesc = $stmt->fetchColumn();

        if ($newDesc === false) {
            return "The selected status was not found.";
        }

        $currentId = null;
        if ($copy_id !== null) {
            $cur = $conn->prepare("SELECT status_id FROM book_copies WHERE copy_id = :id");
            $cur->bindParam(":id", $copy_id);
            $cur->execute();
            $currentId = $cur->fetchColumn();
        }

        $unchanged = $currentId !== null && $currentId !== false && (int) $currentId === (int) $new_status_id;
        if ($unchanged) {
            return null; // editing other fields (e.g. condition) of a copy is always fine
        }

        if (in_array(strtolower($newDesc), ['borrowed', 'reserved', 'returned'], true)) {
            return "'$newDesc' is set automatically: use Borrow Transactions to lend a book, Reservations to hold one and Book Returns to take it back.";
        }

        if ($copy_id !== null) {
            $active = $conn->prepare("SELECT item_id FROM borrow_items WHERE copy_id = :id AND (is_returned IS NULL OR is_returned = 0) LIMIT 1");
            $active->bindParam(":id", $copy_id);
            $active->execute();

            if ($active->rowCount() > 0) {
                return "This copy is currently borrowed. Record its return on the Book Returns page before changing its status.";
            }

            try {
                $held = $conn->prepare("SELECT reservation_id FROM reservation WHERE copy_id = :id AND status IN ('Waiting', 'Ready') LIMIT 1");
                $held->bindParam(":id", $copy_id);
                $held->execute();

                if ($held->rowCount() > 0) {
                    return "This copy is being held for a reservation. Cancel the reservation first.";
                }
            } catch (PDOException $e) {
                // reservation table not created yet
            }
        }

        return null;
    }

    // The archive table is created on first use (DDL commits, so call this BEFORE beginTransaction).
    private function ensureArchive($conn) {
        $conn->exec("CREATE TABLE IF NOT EXISTS book_copies_archive (
                        archive_id INT NOT NULL PRIMARY KEY,
                        copy_id INT NOT NULL,
                        book_id INT NULL,
                        book_title VARCHAR(255) NULL,
                        accession_number VARCHAR(50) NOT NULL,
                        `condition` VARCHAR(50) NULL,
                        added_at DATETIME NULL,
                        disposed_at DATETIME NOT NULL,
                        disposed_by_user_id INT NULL
                     )");
        lms_ensure_schema($conn, true);   // adds the 'reason' column and book_copies.archived_at to older databases
    }

    private function currentUser() {
        return class_exists('Auth') ? Auth::current() : null;
    }

    // Moves one copy into the archive (copy it, then remove it from the shelf list).
    // Call inside a transaction. Returns the accession number, or null when the copy no longer exists.
    private function archiveOne($conn, $copy_id, $user_id) {
        $sel = $conn->prepare("SELECT bc.copy_id, bc.book_id, bc.accession_number, bc.`condition`, bc.added_at, b.title
                               FROM book_copies bc
                               LEFT JOIN book b ON bc.book_id = b.book_id
                               WHERE bc.copy_id = :id");
        $sel->execute([":id" => $copy_id]);
        $row = $sel->fetch(PDO::FETCH_ASSOC);
        if (!$row) return null;

        $next = (int) $conn->query("SELECT IFNULL(MAX(archive_id), 0) + 1 FROM book_copies_archive")->fetchColumn();

        $conn->prepare("INSERT INTO book_copies_archive
                            (archive_id, copy_id, book_id, book_title, accession_number, `condition`, added_at, disposed_at, disposed_by_user_id, reason)
                        VALUES (:aid, :cid, :bid, :title, :acc, :cond, :added, NOW(), :uid, 'Disposed')")
             ->execute([
                 ":aid" => $next, ":cid" => $row['copy_id'], ":bid" => $row['book_id'], ":title" => $row['title'],
                 ":acc" => $row['accession_number'], ":cond" => $row['condition'], ":added" => $row['added_at'], ":uid" => $user_id
             ]);

        $conn->prepare("DELETE FROM book_copies WHERE copy_id = :id")->execute([":id" => $copy_id]);

        return $row['accession_number'];
    }

    function getAll() {
        include "../config/connection-pdo.php";
        lms_ensure_schema($conn);

        // Lost and damaged copies are archived automatically, so they no longer show on the shelf list.
        $sql = "SELECT bc.copy_id, bc.book_id, bc.status_id,
                       bc.accession_number, bc.`condition`, bc.added_at,
                       b.title, s.status_desc
                FROM book_copies bc
                LEFT JOIN book b ON bc.book_id = b.book_id
                LEFT JOIN status s ON bc.status_id = s.status_id
                WHERE bc.archived_at IS NULL
                ORDER BY b.title ASC, CAST(bc.accession_number AS UNSIGNED) ASC, bc.accession_number ASC";

        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rs);
    }

    // Only copies currently marked "Available" — used to populate the
    // Available Book Copy dropdown on the Borrow Transaction form.
    function getAvailable() {
        include "../config/connection-pdo.php";

        $sql = "SELECT bc.copy_id, bc.book_id, bc.accession_number, bc.`condition`,
                       b.title, b.book_type
                FROM book_copies bc
                INNER JOIN book b ON bc.book_id = b.book_id
                INNER JOIN status s ON bc.status_id = s.status_id
                WHERE s.status_desc = 'Available'
                ORDER BY b.title ASC, CAST(bc.accession_number AS UNSIGNED) ASC, bc.accession_number ASC";

        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rs);
    }

    function add($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $book_id = $json['book_id'];
        $status_id = $json['status_id'];
        $condition = trim($json['condition']);
        $quantity = isset($json['quantity']) && $json['quantity'] !== '' ? $json['quantity'] : 1;

        if (empty($book_id) || empty($status_id) || empty($condition)) {
            echo json_encode([
                "status" => "error",
                "message" => "All fields are required."
            ]);
            return;
        }

        if (strlen($condition) < 2 || preg_match('/^\d+$/', $condition)) {
            echo json_encode([
                "status" => "error",
                "message" => "Condition must be meaningful text (e.g. Good, Fair), not just numbers."
            ]);
            return;
        }

        $guard = $this->statusGuard($conn, $status_id);
        if ($guard) {
            echo json_encode(["status" => "error", "message" => $guard]);
            return;
        }

        if (!is_numeric($quantity) || intval($quantity) != $quantity || intval($quantity) < 1 || intval($quantity) > 100) {
            echo json_encode([
                "status" => "error",
                "message" => "Number of copies must be a whole number from 1 to 100."
            ]);
            return;
        }

        $quantity = (int) $quantity;

        $this->ensureArchive($conn);

        // A book with no library-use-only copy yet gets one: the first copy added becomes it.
        $luo = $this->libraryStatusId($conn);
        $needLibrary = false;
        if ($luo !== null) {
            $has = $conn->prepare("SELECT COUNT(*) FROM book_copies WHERE book_id = :b AND status_id = :s AND archived_at IS NULL");
            $has->execute([":b" => $book_id, ":s" => $luo]);
            $needLibrary = (int) $has->fetchColumn() === 0;
        }

        try {
            $conn->beginTransaction();

            // Auto-generate accession numbers (MAX()+1 pattern, starting at 1001) and copy ids.
            // Archived copies count too, so a disposed copy's number is never handed out again.
            lms_lock_ids($conn);
            $nextAcc = max(
                (int) $conn->query("SELECT IFNULL(MAX(CAST(accession_number AS UNSIGNED)), 1000) + 1 FROM book_copies FOR UPDATE")->fetchColumn(),
                (int) $conn->query("SELECT IFNULL(MAX(CAST(accession_number AS UNSIGNED)), 1000) + 1 FROM book_copies_archive")->fetchColumn()
            );

            $nextId = max(
                (int) $conn->query("SELECT IFNULL(MAX(copy_id), 0) + 1 FROM book_copies")->fetchColumn(),
                (int) $conn->query("SELECT IFNULL(MAX(copy_id), 0) + 1 FROM book_copies_archive")->fetchColumn()
            );

            $sql = "INSERT INTO book_copies
                        (copy_id, book_id, accession_number, status_id, `condition`, added_at)
                    VALUES
                        (:copy_id, :book_id, :accession_number, :status_id, :condition, NOW())";

            $stmt = $conn->prepare($sql);

            $first = $nextAcc;
            for ($i = 0; $i < $quantity; $i++) {
                $accession_number = (string) ($nextAcc + $i);
                $stmt->execute([
                    ":copy_id" => $nextId + $i,
                    ":book_id" => $book_id,
                    ":accession_number" => $accession_number,
                    ":status_id" => ($i === 0 && $needLibrary) ? $luo : $status_id,
                    ":condition" => $condition
                ]);
            }

            $conn->commit();

            $last = $nextAcc + $quantity - 1;
            $range = $quantity === 1 ? "$first" : "$first - $last";

            $libraryNote = $needLibrary ? " ACC-$first is kept for library use only: it stays in the library and can't be borrowed." : "";

            echo json_encode([
                "status" => "success",
                "message" => ($quantity === 1
                    ? "Book copy added successfully. Accession number: $range"
                    : "$quantity book copies added successfully. Accession numbers: $range") . $libraryNote,
                "accession_number" => (string) $first,
                "quantity" => $quantity
            ]);
        } catch (Exception $e) {
            if ($conn->inTransaction()) {
                $conn->rollBack();
            }
            error_log("book copy add failed: " . $e->getMessage());
            echo json_encode([
                "status" => "error",
                "message" => "Failed to add book copies."
            ]);
        }
    }

    function update($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $copy_id = $json['copy_id'];
        $book_id = $json['book_id'];
        $status_id = $json['status_id'];
        $accession_number = trim($json['accession_number']);
        $condition = trim($json['condition']);

        if (empty($copy_id) || empty($book_id) || empty($status_id) || empty($accession_number) || empty($condition)) {
            echo json_encode([
                "status" => "error",
                "message" => "All fields are required."
            ]);
            return;
        }

        if (strlen($accession_number) < 3) {
            echo json_encode([
                "status" => "error",
                "message" => "Accession number is too short. Please enter a valid accession number."
            ]);
            return;
        }

        if (strlen($condition) < 2 || preg_match('/^\d+$/', $condition)) {
            echo json_encode([
                "status" => "error",
                "message" => "Condition must be meaningful text (e.g. Good, Fair), not just numbers."
            ]);
            return;
        }

        // Library Staff can never assign or change an accession number: only the Technical Services Librarian can.
        $me = Auth::current();
        if (!$me || $me['role'] !== 'admin') {
            $was = $conn->prepare("SELECT accession_number FROM book_copies WHERE copy_id = :c");
            $was->execute([":c" => $copy_id]);
            $current = $was->fetchColumn();
            if ($current === false || (string) $current !== (string) $accession_number) {
                echo json_encode(["status" => "error", "message" => "Only the Technical Services Librarian can change accession numbers."]);
                return;
            }
        }

        $guard = $this->statusGuard($conn, $status_id, $copy_id);
        if ($guard) {
            echo json_encode(["status" => "error", "message" => $guard]);
            return;
        }

        // The last library-use-only copy of a book can't be changed to another status or moved to another book.
        $luo = $this->libraryStatusId($conn);
        if ($luo !== null && (int) $status_id !== $luo) {
            $block = $this->libraryCopyBlock($conn, $copy_id, false);
            if ($block) { echo json_encode(["status" => "error", "message" => $block]); return; }
        }
        if ($luo !== null && (int) $status_id === $luo) {
            $cur = $conn->prepare("SELECT book_id, status_id FROM book_copies WHERE copy_id = :c");
            $cur->execute([":c" => $copy_id]);
            $was = $cur->fetch(PDO::FETCH_ASSOC);
            if ($was && (int) $was['status_id'] === $luo && (int) $was['book_id'] !== (int) $book_id) {
                $block = $this->libraryCopyBlock($conn, $copy_id, false);
                if ($block) { echo json_encode(["status" => "error", "message" => $block]); return; }
            }
        }

        $sql = "UPDATE book_copies
                SET book_id = :book_id,
                    accession_number = :accession_number,
                    status_id = :status_id,
                    `condition` = :condition
                WHERE copy_id = :copy_id";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":book_id", $book_id);
        $stmt->bindParam(":accession_number", $accession_number);
        $stmt->bindParam(":status_id", $status_id);
        $stmt->bindParam(":condition", $condition);
        $stmt->bindParam(":copy_id", $copy_id);
        $stmt->execute();

        echo json_encode([
            "status" => "success",
            "message" => "Book copy updated successfully."
        ]);
    }

    // "Dispose": the copy leaves the shelf list and is kept in the archive (it can be restored).
    function delete($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);
        $copy_id = $json['copy_id'];

        $check = $conn->prepare(
            "SELECT item_id FROM borrow_items WHERE copy_id = :copy_id LIMIT 1"
        );
        $check->bindParam(":copy_id", $copy_id);
        $check->execute();

        if ($check->rowCount() > 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Cannot dispose: this book copy is referenced in borrow transactions."
            ]);
            return;
        }

        try {
            $held = $conn->prepare("SELECT reservation_id FROM reservation WHERE copy_id = :copy_id AND status IN ('Waiting', 'Ready') LIMIT 1");
            $held->bindParam(":copy_id", $copy_id);
            $held->execute();

            if ($held->rowCount() > 0) {
                echo json_encode([
                    "status" => "error",
                    "message" => "Cannot dispose: this copy is being held for a reservation."
                ]);
                return;
            }
        } catch (PDOException $e) {
            // reservation table not created yet - nothing to check
        }

        $this->ensureArchive($conn);

        $block = $this->libraryCopyBlock($conn, $copy_id, true);
        if ($block) {
            echo json_encode(["status" => "error", "message" => "Cannot dispose: " . $block]);
            return;
        }

        $me = $this->currentUser();

        try {
            $conn->beginTransaction();
            lms_lock_ids($conn);
            $acc = $this->archiveOne($conn, $copy_id, $me['user_id'] ?? null);
            $conn->commit();
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("book copy dispose failed: " . $e->getMessage());
            echo json_encode(["status" => "error", "message" => "Failed to dispose of the book copy."]);
            return;
        }

        if ($acc !== null) {
            echo json_encode([
                "status" => "success",
                "message" => "Book copy ACC-$acc disposed of and moved to the archive."
            ]);
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "Failed to dispose of the book copy."
            ]);
        }
    }

    // Disposes of many copies at once. Copies that appear in borrow history or are held for a
    // reservation are skipped (same rule as disposing of one copy) and reported back.
    function deleteMultiple($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);
        $ids = isset($json['copy_ids']) && is_array($json['copy_ids']) ? $json['copy_ids'] : [];
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), function ($v) { return $v > 0; })));

        if (count($ids) === 0) {
            echo json_encode(["status" => "error", "message" => "Select at least one book copy to dispose of."]);
            return;
        }

        $refStmt = $conn->prepare("SELECT item_id FROM borrow_items WHERE copy_id = :copy_id LIMIT 1");
        $accStmt = $conn->prepare("SELECT accession_number FROM book_copies WHERE copy_id = :copy_id");

        $disposed = 0;
        $skipped = [];
        $keptLibrary = [];

        $heldIds = [];
        try {
            $heldStmt = $conn->query("SELECT copy_id FROM reservation WHERE copy_id IS NOT NULL AND status IN ('Waiting', 'Ready')");
            $heldIds = array_map('intval', $heldStmt->fetchAll(PDO::FETCH_COLUMN));
        } catch (PDOException $e) {
            // reservation table not created yet
        }

        $this->ensureArchive($conn);
        $me = $this->currentUser();
        $uid = $me['user_id'] ?? null;

        try {
            $conn->beginTransaction();
            lms_lock_ids($conn);

            // Library-use-only copies go last, so disposing of a whole book's copies in one go still works.
            $luoId = $this->libraryStatusId($conn);
            $libraryCopies = $luoId === null ? [] : array_map('intval', $conn->query("SELECT copy_id FROM book_copies WHERE status_id = $luoId")->fetchAll(PDO::FETCH_COLUMN));
            usort($ids, function ($a, $b) use ($libraryCopies) {
                return (int) in_array($a, $libraryCopies, true) <=> (int) in_array($b, $libraryCopies, true);
            });

            foreach ($ids as $id) {
                $refStmt->execute([":copy_id" => $id]);

                if ($this->libraryCopyBlock($conn, $id, true)) {
                    $accStmt->execute([":copy_id" => $id]);
                    $acc = $accStmt->fetchColumn();
                    $keptLibrary[] = "ACC-" . ($acc !== false ? $acc : $id);
                    continue;
                }

                if ($refStmt->rowCount() > 0 || in_array($id, $heldIds, true)) {
                    $accStmt->execute([":copy_id" => $id]);
                    $acc = $accStmt->fetchColumn();
                    $skipped[] = "ACC-" . ($acc !== false ? $acc : $id);
                    continue;
                }

                if ($this->archiveOne($conn, $id, $uid) !== null) $disposed++;
            }

            $conn->commit();
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("book copy bulk dispose failed: " . $e->getMessage());
            echo json_encode(["status" => "error", "message" => "Failed to dispose of the selected book copies."]);
            return;
        }

        if ($disposed === 0) {
            echo json_encode([
                "status" => "error",
                "message" => count($keptLibrary) > 0 && count($skipped) === 0
                    ? "Nothing was disposed of: " . implode(", ", $keptLibrary) . " is the library-use-only copy of its book. Every book needs at least one."
                    : "Nothing was disposed of: the selected copies are referenced in borrow transactions or held for a reservation (" . implode(", ", $skipped) . ")."
            ]);
            return;
        }

        $message = "$disposed book " . ($disposed === 1 ? "copy" : "copies") . " disposed of and moved to the archive.";
        if (count($keptLibrary) > 0) {
            $message .= " Kept " . implode(", ", $keptLibrary) . ": every book needs at least one library-use-only copy.";
        }
        if (count($skipped) > 0) {
            $message .= " Skipped " . count($skipped) . " referenced in borrow transactions or held for a reservation: " . implode(", ", $skipped) . ".";
        }

        echo json_encode(["status" => "success", "message" => $message, "disposed" => $disposed, "skipped" => count($skipped)]);
    }

    // Every disposed copy, newest first.
    function getArchive() {
        include "../config/connection-pdo.php";
        $this->ensureArchive($conn);

        $stmt = $conn->prepare("SELECT a.archive_id, a.copy_id, a.book_id,
                                       COALESCE(b.title, a.book_title) AS title,
                                       a.accession_number, a.`condition`, a.added_at, a.disposed_at,
                                       COALESCE(a.reason, 'Disposed') AS reason,
                                       CONCAT_WS(' ', u.first_name, u.last_name) AS disposed_by
                                FROM book_copies_archive a
                                LEFT JOIN book b ON a.book_id = b.book_id
                                LEFT JOIN users u ON a.disposed_by_user_id = u.user_id
                                ORDER BY a.disposed_at DESC, a.archive_id DESC");
        $stmt->execute();
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Puts an archived copy back on the shelf as "Available". Technical Services Librarian only.
    function restore($json) {
        include "../config/connection-pdo.php";

        $me = $this->currentUser();
        if (!$me || ($me['role'] ?? '') !== 'admin') {
            echo json_encode(["status" => "error", "message" => "Only the Technical Services Librarian can restore archived copies."]);
            return;
        }

        $json = json_decode($json, true);
        $archive_id = isset($json['archive_id']) ? (int) $json['archive_id'] : 0;
        if ($archive_id < 1) {
            echo json_encode(["status" => "error", "message" => "Archived copy is required."]);
            return;
        }

        $this->ensureArchive($conn);

        try {
            $conn->beginTransaction();
            lms_lock_ids($conn);

            $sel = $conn->prepare("SELECT * FROM book_copies_archive WHERE archive_id = :id FOR UPDATE");
            $sel->execute([":id" => $archive_id]);
            $row = $sel->fetch(PDO::FETCH_ASSOC);

            if (!$row) {
                $conn->rollBack();
                echo json_encode(["status" => "error", "message" => "That copy is no longer in the archive."]);
                return;
            }

            // Copies archived automatically (lost or damaged) still have their row: put it back on the shelf.
            $kept = $conn->prepare("SELECT copy_id FROM book_copies WHERE copy_id = :id AND archived_at IS NOT NULL FOR UPDATE");
            $kept->execute([":id" => $row['copy_id']]);
            if ($kept->fetchColumn() !== false) {
                $avail = $conn->query("SELECT status_id FROM status WHERE LOWER(TRIM(status_desc)) = 'available' LIMIT 1")->fetchColumn();
                // A found book is as good as before; a repaired one is only Fair.
                $cond = ($row['reason'] ?? '') === 'Damaged' ? 'Fair' : 'Good';
                $conn->prepare("UPDATE book_copies SET status_id = :s, `condition` = :c, archived_at = NULL WHERE copy_id = :id")
                     ->execute([":s" => $avail, ":c" => $cond, ":id" => $row['copy_id']]);
                $conn->prepare("DELETE FROM book_copies_archive WHERE archive_id = :id")->execute([":id" => $archive_id]);
                $conn->commit();
                echo json_encode(["status" => "success", "message" => "ACC-" . $row['accession_number'] . " restored to the library as Available."]);
                return;
            }

            $book = $conn->prepare("SELECT 1 FROM book WHERE book_id = :id");
            $book->execute([":id" => $row['book_id']]);
            if (!$book->fetchColumn()) {
                $conn->rollBack();
                echo json_encode(["status" => "error", "message" => "Cannot restore: the book \"" . $row['book_title'] . "\" no longer exists. Add the book again first."]);
                return;
            }

            $dup = $conn->prepare("SELECT 1 FROM book_copies WHERE accession_number = :acc");
            $dup->execute([":acc" => $row['accession_number']]);
            if ($dup->fetchColumn()) {
                $conn->rollBack();
                echo json_encode(["status" => "error", "message" => "Cannot restore: accession number ACC-" . $row['accession_number'] . " is already in use."]);
                return;
            }

            $status = $conn->query("SELECT status_id FROM status WHERE LOWER(TRIM(status_desc)) = 'available' LIMIT 1")->fetchColumn();
            if ($status === false) {
                $conn->rollBack();
                echo json_encode(["status" => "error", "message" => "The 'Available' status was not found."]);
                return;
            }

            // Keep the old copy id unless something else has taken it in the meantime.
            $copy_id = (int) $row['copy_id'];
            $taken = $conn->prepare("SELECT 1 FROM book_copies WHERE copy_id = :id");
            $taken->execute([":id" => $copy_id]);
            if ($taken->fetchColumn()) {
                $copy_id = (int) $conn->query("SELECT IFNULL(MAX(copy_id), 0) + 1 FROM book_copies")->fetchColumn();
            }

            $conn->prepare("INSERT INTO book_copies (copy_id, book_id, accession_number, status_id, `condition`, added_at)
                            VALUES (:cid, :bid, :acc, :sid, :cond, COALESCE(:added, NOW()))")
                 ->execute([
                     ":cid" => $copy_id, ":bid" => $row['book_id'], ":acc" => $row['accession_number'],
                     ":sid" => $status, ":cond" => $row['condition'] ?: 'Good', ":added" => $row['added_at']
                 ]);

            $conn->prepare("DELETE FROM book_copies_archive WHERE archive_id = :id")->execute([":id" => $archive_id]);
            $conn->commit();

            echo json_encode(["status" => "success", "message" => "ACC-" . $row['accession_number'] . " restored to the library as Available."]);
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("book copy restore failed: " . $e->getMessage());
            echo json_encode(["status" => "error", "message" => "Failed to restore the book copy."]);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$obj = new BookCopies();

switch ($operation) {
    case "getAll":
        $obj->getAll();
        break;
    case "getAvailable":
        $obj->getAvailable();
        break;
    case "add":
        $obj->add($json);
        break;
    case "update":
        $obj->update($json);
        break;
    case "delete":
        $obj->delete($json);
        break;
    case "deleteMultiple":
        $obj->deleteMultiple($json);
        break;
    case "getArchive":
        $obj->getArchive();
        break;
    case "restore":
        $obj->restore($json);
        break;
}

?>