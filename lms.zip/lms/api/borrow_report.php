<?php

header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));
require_once __DIR__ . "/loan_rules.php";
require_once __DIR__ . "/fine_payments.php";

// Two lists that never overlap:
//   getBorrowing - books out right now (not returned yet). This is the Borrowing Report.
//   getHistory   - books that came back, i.e. finished transactions. This is the Transaction History.
class BorrowReport {

    // One row per borrowed book (borrow item), with who has it and who handled it.
    private function baseSelect() {
        return "SELECT bi.item_id,
                       bt.transaction_id,
                       bt.student_id,
                       CONCAT(s.first_name, ' ', s.last_name) AS borrower,
                       COALESCE(sr.role_name, 'Student') AS borrower_role,
                       b.title,
                       bc.accession_number,
                       bt.borrow_date,
                       COALESCE(bi.due_date, bt.due_date) AS due_date,
                       CONCAT_WS(' ', bu.first_name, bu.last_name) AS borrow_processed_by";
    }

    private function baseFrom() {
        return "FROM borrow_items bi
                INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                LEFT JOIN student s ON bt.student_id = s.student_id
                LEFT JOIN users su ON s.user_id = su.user_id
                LEFT JOIN roles sr ON su.role_id = sr.role_id
                LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                LEFT JOIN book b ON bc.book_id = b.book_id
                LEFT JOIN book_return br ON br.item_id = bi.item_id
                LEFT JOIN users bu ON bt.processed_by_user_id = bu.user_id";
    }

    // Books that have not come back yet: Borrowed, or Overdue once the due date has passed.
    function getBorrowing() {
        include "../config/connection-pdo.php";

        $sql = $this->baseSelect() . ",
                       DATEDIFF(CURDATE(), COALESCE(bi.due_date, bt.due_date)) AS days_overdue,
                       CASE
                           WHEN COALESCE(bi.due_date, bt.due_date) < CURDATE() THEN 'Overdue'
                           ELSE 'Borrowed'
                       END AS status
                " . $this->baseFrom() . "
                WHERE br.return_id IS NULL AND (bi.is_returned IS NULL OR bi.is_returned = 0)
                ORDER BY COALESCE(bi.due_date, bt.due_date) ASC, bt.transaction_id DESC, bi.item_id ASC";

        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Overdue books keep earning a fine every day until they come back.
        $rate = (int) LoanRules::all($conn)['fine_per_day']['value'];
        foreach ($rows as &$r) {
            $r['fine_so_far'] = $r['status'] === 'Overdue' ? max(0, (int) $r['days_overdue']) * $rate : 0;
        }
        unset($r);

        echo json_encode($rows);
    }

    // Books that were returned, newest return first.
    function getHistory() {
        include "../config/connection-pdo.php";

        $sql = $this->baseSelect() . ",
                       COALESCE(br.return_date, DATE(bi.returned_at)) AS return_date,
                       br.condition_on_return,
                       br.fine_amount, br.settlement, br.book_price, br.processing_fee,
                       br.fine_amount + IF(br.settlement = 'Paid', IFNULL(br.book_price, 0) + br.processing_fee, 0) AS charges_total,
                       (SELECT IFNULL(SUM(fp.amount), 0) FROM fine_payment fp WHERE fp.return_id = br.return_id AND fp.kind = 'return') AS fine_cash,
                       (SELECT IFNULL(-SUM(fp.amount), 0) FROM fine_payment fp WHERE fp.return_id = br.return_id AND fp.kind = 'applied') AS fine_credit,
                       CONCAT_WS(' ', ru.first_name, ru.last_name) AS return_processed_by,
                       GREATEST(0, DATEDIFF(COALESCE(br.return_date, DATE(bi.returned_at)), COALESCE(bi.due_date, bt.due_date))) AS days_late,
                       CASE
                           WHEN COALESCE(br.return_date, DATE(bi.returned_at)) > COALESCE(bi.due_date, bt.due_date) THEN 'Late'
                           ELSE 'On time'
                       END AS status
                " . $this->baseFrom() . "
                LEFT JOIN users ru ON br.processed_by_user_id = ru.user_id
                WHERE br.return_id IS NOT NULL OR bi.is_returned = 1
                ORDER BY COALESCE(br.return_date, DATE(bi.returned_at)) DESC, bi.item_id DESC";

        $stmt = $conn->prepare($sql);
        $stmt->execute();

        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Money collected for overdue fines: today, this month, all time.
    function getFinesCollected() {
        include "../config/connection-pdo.php";
        echo json_encode(FinePayments::totals($conn));
    }
}

$operation = $_GET['operation'] ?? $_POST['operation'] ?? '';

$obj = new BorrowReport();

switch ($operation) {
    case "getBorrowing":
        $obj->getBorrowing();
        break;
    case "getHistory":
        $obj->getHistory();
        break;
    case "getFinesCollected":
        $obj->getFinesCollected();
        break;
}

?>
