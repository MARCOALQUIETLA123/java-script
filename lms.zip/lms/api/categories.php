<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));

class Categories {
    function getAll() {
        include "../config/connection-pdo.php";

        $sql = "SELECT category_id, category_type
                FROM categories
                ORDER BY category_type ASC";

        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rs);
    }

    function add($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);
        $category_type = isset($json['category_type']) ? trim($json['category_type']) : "";

        if (empty($category_type)) {
            echo json_encode(["status" => "error", "message" => "Category type is required."]);
            return;
        }

        if (preg_match('/^[\d\s]+$/', $category_type)) {
            echo json_encode(["status" => "error", "message" => "Invalid category type."]);
            return;
        }

        $check = $conn->prepare("SELECT category_id FROM categories WHERE category_type = :category_type");
        $check->bindParam(":category_type", $category_type);
        $check->execute();

        if ($check->rowCount() > 0) {
            echo json_encode(["status" => "error", "message" => "Category already exists."]);
            return;
        }

        lms_lock_ids($conn);

        $maxStmt = $conn->prepare("SELECT IFNULL(MAX(category_id), 0) + 1 AS nextId FROM categories");
        $maxStmt->execute();
        $category_id = $maxStmt->fetch(PDO::FETCH_ASSOC)['nextId'];

        $sql = "INSERT INTO categories (category_id, category_type)
                VALUES (:category_id, :category_type)";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":category_id", $category_id);
        $stmt->bindParam(":category_type", $category_type);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode(["status" => "success", "message" => "Category added successfully."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to add category."]);
        }
    }

    function update($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $category_id = (isset($json['category_id']) && $json['category_id'] !== '' && $json['category_id'] !== null)
            ? $json['category_id']
            : null;

        $category_type = isset($json['category_type']) ? trim($json['category_type']) : "";

        if ($category_id === null) {
            echo json_encode(["status" => "error", "message" => "Category ID is required."]);
            return;
        }

        if (empty($category_type)) {
            echo json_encode(["status" => "error", "message" => "Category type is required."]);
            return;
        }

        if (preg_match('/^[\d\s]+$/', $category_type)) {
            echo json_encode(["status" => "error", "message" => "Invalid category type."]);
            return;
        }

        $check = $conn->prepare("
            SELECT category_id
            FROM categories
            WHERE category_type = :category_type
            AND category_id != :category_id
        ");

        $check->bindParam(":category_type", $category_type);
        $check->bindParam(":category_id", $category_id);
        $check->execute();

        if ($check->rowCount() > 0) {
            echo json_encode(["status" => "error", "message" => "Category already exists."]);
            return;
        }

        $sql = "UPDATE categories
                SET category_type = :category_type
                WHERE category_id = :category_id";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":category_type", $category_type);
        $stmt->bindParam(":category_id", $category_id);
        $stmt->execute();

        echo json_encode(["status" => "success", "message" => "Category updated successfully."]);
    }

    function delete($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $category_id = (isset($json['category_id']) && $json['category_id'] !== '' && $json['category_id'] !== null)
            ? $json['category_id']
            : null;

        if ($category_id === null) {
            echo json_encode(["status" => "error", "message" => "Category ID is required."]);
            return;
        }

        $check = $conn->prepare("
            SELECT book_id
            FROM book
            WHERE category_id = :category_id
            LIMIT 1
        ");

        $check->bindParam(":category_id", $category_id);
        $check->execute();

        if ($check->rowCount() > 0) {
            echo json_encode(["status" => "error", "message" => "Cannot delete: this category is used by one or more books."]);
            return;
        }

        $sql = "DELETE FROM categories WHERE category_id = :category_id";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":category_id", $category_id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode(["status" => "success", "message" => "Category deleted successfully."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to delete category."]);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$obj = new Categories();

switch ($operation) {
    case "getAll":
        $obj->getAll();
        break;
    case "add":
        $obj->add($json);
        break;
    case "update":
        $obj->update($json);
        break;
    case "delete":
        $obj->delete($json);
        break;
}
?>