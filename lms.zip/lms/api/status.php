<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));

// The Status page is gone. The statuses already in the database stay as they are and are only read here
// (book copies, borrowing and reservations match them by name: Available, Borrowed, Reserved).
// Nothing can be added, renamed or deleted any more.
class Status {
    const REQUIRED = ['Available', 'Borrowed', 'Reserved'];

    // With no Status page to fix it, make sure the three statuses the system needs exist.
    // Existing rows are never touched.
    private function ensureRequired($conn) {
        $find = $conn->prepare("SELECT 1 FROM status WHERE LOWER(TRIM(status_desc)) = LOWER(:d) LIMIT 1");

        foreach (self::REQUIRED as $desc) {
            $find->execute([":d" => $desc]);
            if ($find->fetchColumn()) continue;

            lms_lock_ids($conn);
            $next = (int) $conn->query("SELECT IFNULL(MAX(status_id), 0) + 1 FROM status")->fetchColumn();
            $conn->prepare("INSERT INTO status (status_id, status_desc) VALUES (:id, :d)")
                 ->execute([":id" => $next, ":d" => $desc]);
        }
    }

    function getAll() {
        include "../config/connection-pdo.php";

        $this->ensureRequired($conn);

        $stmt = $conn->prepare("SELECT status_id, status_desc FROM status ORDER BY status_desc ASC");
        $stmt->execute();

        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    function locked() {
        echo json_encode([
            "status"  => "error",
            "message" => "Statuses can't be added, changed or deleted."
        ]);
    }
}

$operation = $_GET['operation'] ?? $_POST['operation'] ?? '';

$obj = new Status();

switch ($operation) {
    case "getAll":
        $obj->getAll();
        break;
    case "add":
    case "update":
    case "delete":
        $obj->locked();
        break;
}
?>
