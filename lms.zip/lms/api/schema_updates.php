<?php
// Adds the columns used by overdue fines and lost/damaged book charges.
// Runs only when something is missing, so an older database upgrades itself the first time it is used.
// (Importing migration_overdue_fines_and_lost_damaged.sql does the same thing up front.)
// ALTER TABLE commits on its own, so call this BEFORE beginTransaction().

// $force skips the 'already checked' shortcuts. Used right after a table is created mid-request.
function lms_ensure_schema($conn, $force = false) {
    static $done = false;
    if ($done && !$force) return;

    lms_rename_default_admin($conn);

    // The loan rules table is created here, at connection time, so reading the rules never has to run DDL
    // in the middle of a transaction (DDL silently commits it).
    $hasRules = $conn->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'loan_settings'")->fetchColumn();
    if ((int) $hasRules === 0) {
        $conn->exec("CREATE TABLE IF NOT EXISTS loan_settings (
                        setting_key VARCHAR(50) NOT NULL PRIMARY KEY,
                        setting_value INT NOT NULL,
                        setting_unit VARCHAR(10) DEFAULT NULL,
                        updated_by_user_id INT DEFAULT NULL,
                        updated_at DATETIME DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }


    $wanted = [
        'book'               => ['price'              => "DECIMAL(10,2) NULL"],
        'book_copies'        => ['archived_at'        => "DATETIME NULL"],
        'book_copies_archive'=> ['reason'             => "VARCHAR(20) NULL"],
        'book_return'        => [
            'overdue_days'       => "INT NOT NULL DEFAULT 0",
            'fine_amount'        => "DECIMAL(10,2) NOT NULL DEFAULT 0",
            'settlement'         => "VARCHAR(20) NULL",
            'book_price'         => "DECIMAL(10,2) NULL",
            'processing_fee'     => "DECIMAL(10,2) NOT NULL DEFAULT 0",
            'replacement_book_id'=> "INT NULL",
            'replacement_copy_id'=> "INT NULL",
            'case_status'        => "VARCHAR(20) NULL",
            'receipt_no'         => "VARCHAR(20) NULL",
            'or_number'          => "VARCHAR(40) NULL",
            'settled_at'         => "DATETIME NULL",
            'settled_by_user_id' => "INT NULL",
            'case_note'          => "VARCHAR(255) NULL",
        ],
        'student'            => [
            'blacklisted_at'         => "DATETIME NULL",
            'blacklist_reason'       => "VARCHAR(255) NULL",
            'blacklisted_by_user_id' => "INT NULL",
        ],
        'student_message'    => [
            // A borrower can send the library a message with a photo or PDF (proof that a fine was paid).
            'from_borrower'      => "TINYINT(1) NOT NULL DEFAULT 0",
            'attachment_path'    => "VARCHAR(120) NULL",
            'attachment_name'    => "VARCHAR(190) NULL",
            'attachment_mime'    => "VARCHAR(60) NULL",
            'proof_amount'       => "DECIMAL(10,2) NULL",
            'proof_ref'          => "VARCHAR(60) NULL",
        ],
        'reservation'        => [
            'reject_reason'      => "VARCHAR(255) NULL",
            'decided_at'         => "DATETIME NULL",
        ],
    ];

    // Every book keeps at least one copy that can't be borrowed: the "Library Use Only" status.
    // Borrower inbox (reminders, warnings and messages from the librarian). Created here, at connection time,
    // so nothing has to run DDL in the middle of a transaction.
    $hasMessages = $conn->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'student_message'")->fetchColumn();
    if ((int) $hasMessages === 0) {
        $conn->exec("CREATE TABLE IF NOT EXISTS student_message (
                        message_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                        student_id INT NOT NULL,
                        sender_user_id INT NULL,
                        kind VARCHAR(20) NOT NULL DEFAULT 'message',
                        subject VARCHAR(120) NOT NULL,
                        body TEXT NOT NULL,
                        reminder_date DATE NULL,
                        created_at DATETIME NOT NULL,
                        read_at DATETIME NULL,
                        INDEX idx_student_message_student (student_id, created_at)
                     ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }

    // Money the library received for overdue fines (see api/fine_payments.php). Created here, at connection time,
    // so nothing has to run DDL in the middle of a transaction.
    $hasPayments = $conn->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fine_payment'")->fetchColumn();
    if ((int) $hasPayments === 0) {
        $conn->exec("CREATE TABLE IF NOT EXISTS fine_payment (
                        payment_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                        student_id INT NOT NULL,
                        amount DECIMAL(10,2) NOT NULL,
                        kind VARCHAR(10) NOT NULL,
                        receipt_no VARCHAR(40) NULL,
                        reference VARCHAR(60) NULL,
                        return_id INT NULL,
                        message_id INT NULL,
                        note VARCHAR(255) NULL,
                        received_by_user_id INT NULL,
                        paid_at DATETIME NOT NULL,
                        INDEX idx_fine_payment_student (student_id),
                        INDEX idx_fine_payment_return (return_id),
                        INDEX idx_fine_payment_message (message_id)
                     ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }

    $needLibraryStatus = $conn->query("SELECT COUNT(*) FROM status WHERE status_desc = 'Library Use Only'")->fetchColumn() == 0;

    // Quick path: one query tells us whether everything is already in place.
    $total = 0; $clauses = [];
    foreach ($wanted as $table => $columns) {
        $total += count($columns);
        $clauses[] = "(TABLE_NAME = '$table' AND COLUMN_NAME IN ('" . implode("','", array_keys($columns)) . "'))";
    }
    $quick = $conn->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND (" . implode(" OR ", $clauses) . ")")->fetchColumn();
    $archiveExists = $conn->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'book_copies_archive'")->fetchColumn();
    if (!$force && !$needLibraryStatus && (int) $quick >= $total - ($archiveExists ? 0 : 1)) { $done = true; return; }

    $have = $conn->prepare("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
                            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :t");
    $exists = $conn->prepare("SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :t");

    foreach ($wanted as $table => $columns) {
        $exists->execute([':t' => $table]);
        if (!$exists->fetchColumn()) continue;      // e.g. the archive table is created on first use

        $have->execute([':t' => $table]);
        $present = array_map('strtolower', $have->fetchAll(PDO::FETCH_COLUMN));

        foreach ($columns as $name => $ddl) {
            if (!in_array(strtolower($name), $present, true)) {
                $conn->exec("ALTER TABLE `$table` ADD COLUMN `$name` $ddl");
            }
        }
    }

    if ($needLibraryStatus) lms_add_library_use_status($conn);

    $done = true;
}

// Adds the "Library Use Only" status and marks one free copy of every book with it (once).
// Copies of books that already have one, copies out on loan and archived copies are left alone.
function lms_add_library_use_status($conn) {
    $id = (int) $conn->query("SELECT IFNULL(MAX(status_id), 0) + 1 FROM status")->fetchColumn();
    $conn->prepare("INSERT INTO status (status_id, status_desc) VALUES (:i, 'Library Use Only')")->execute([":i" => $id]);

    $available = $conn->query("SELECT status_id FROM status WHERE status_desc = 'Available' LIMIT 1")->fetchColumn();
    if (!$available) return;

    $books = $conn->query("SELECT DISTINCT book_id FROM book_copies WHERE archived_at IS NULL")->fetchAll(PDO::FETCH_COLUMN);
    $pick = $conn->prepare("SELECT MAX(copy_id) FROM book_copies WHERE book_id = :b AND status_id = :a AND archived_at IS NULL");
    $set = $conn->prepare("UPDATE book_copies SET status_id = :s WHERE copy_id = :c");

    foreach ($books as $book_id) {
        $pick->execute([":b" => $book_id, ":a" => $available]);
        $copy = $pick->fetchColumn();
        if ($copy) $set->execute([":s" => $id, ":c" => $copy]);
    }
}

// The built-in account that used to be called "System Administrator" is now the "Technical Services Librarian".
// Its name is stored on the user row, so every dashboard (Processed by, Received by, Disposed by, messages...) shows the new name.
function lms_rename_default_admin($conn) {
    static $checked = false;
    if ($checked) return;
    $checked = true;

    $conn->exec("UPDATE users SET first_name = 'Technical Services', last_name = 'Librarian'
                 WHERE LOWER(TRIM(first_name)) = 'system' AND LOWER(TRIM(last_name)) = 'administrator'");
}
