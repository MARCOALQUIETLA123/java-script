<?php

header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));

class BorrowItems {

    // Only unreturned items — this feeds the Borrowed Book Item dropdown
    // on the Book Returns page, so already-returned items drop off automatically.
    function getAll() {
        include "../config/connection-pdo.php";

        $sql = "SELECT bi.item_id,
                       bi.transaction_id,
                       bi.copy_id,
                       bi.is_returned,
                       bi.returned_at,
                       bt.student_id,
                       bt.borrow_date,
                       bc.accession_number,
                       b.title,
                       CONCAT(s.first_name, ' ', s.last_name) AS student_name
                FROM borrow_items bi
                LEFT JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                LEFT JOIN book b ON bc.book_id = b.book_id
                LEFT JOIN student s ON bt.student_id = s.student_id
                WHERE bi.is_returned IS NULL OR bi.is_returned = 0
                ORDER BY b.title ASC, s.first_name ASC, s.last_name ASC";

        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rs);
    }

    // Links a book copy to a borrow transaction and flips that copy's
    // status to "Borrowed". Called right after a borrow_transaction is created.
    function add($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $transaction_id = (isset($json['transaction_id']) && $json['transaction_id'] !== '' && $json['transaction_id'] !== null)
            ? $json['transaction_id']
            : null;

        $copy_id = (isset($json['copy_id']) && $json['copy_id'] !== '' && $json['copy_id'] !== null)
            ? $json['copy_id']
            : null;

        if ($transaction_id === null || $copy_id === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Transaction and book copy are required."
            ]);
            return;
        }

        // A copy can only be lent while it is Available. Reserved copies are held for a
        // reservation and are checked out from the Reservations page instead.
        $guard = $conn->prepare("SELECT s.status_desc
                                 FROM book_copies bc
                                 INNER JOIN status s ON bc.status_id = s.status_id
                                 WHERE bc.copy_id = :copy_id");
        $guard->bindParam(":copy_id", $copy_id);
        $guard->execute();
        $copyStatus = $guard->fetchColumn();

        if ($copyStatus === false) {
            echo json_encode(["status" => "error", "message" => "Book copy not found."]);
            return;
        }

        if ($copyStatus === 'Reserved') {
            echo json_encode([
                "status" => "error",
                "message" => "This copy is Reserved and can't be borrowed. Check it out from the Reservations page."
            ]);
            return;
        }

        if ($copyStatus !== 'Available') {
            echo json_encode(["status" => "error", "message" => "This copy is not available to borrow."]);
            return;
        }

        lms_lock_ids($conn);

        $sqlMax = "SELECT IFNULL(MAX(item_id), 0) + 1 AS nextId FROM borrow_items";
        $stmtMax = $conn->prepare($sqlMax);
        $stmtMax->execute();
        $nextId = $stmtMax->fetch(PDO::FETCH_ASSOC)['nextId'];

        $sql = "INSERT INTO borrow_items (item_id, transaction_id, copy_id, is_returned)
                VALUES (:item_id, :transaction_id, :copy_id, 0)";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":item_id", $nextId);
        $stmt->bindParam(":transaction_id", $transaction_id);
        $stmt->bindParam(":copy_id", $copy_id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $sqlStatus = "UPDATE book_copies
                          SET status_id = (SELECT status_id FROM status WHERE status_desc = 'Borrowed' LIMIT 1)
                          WHERE copy_id = :copy_id";
            $stmtStatus = $conn->prepare($sqlStatus);
            $stmtStatus->bindParam(":copy_id", $copy_id);
            $stmtStatus->execute();

            echo json_encode([
                "status" => "success",
                "message" => "Borrow item recorded successfully."
            ]);
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "Failed to record borrow item."
            ]);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$obj = new BorrowItems();

switch ($operation) {
    case "getAll":
        $obj->getAll();
        break;
    case "add":
        $obj->add($json);
        break;
}

?>