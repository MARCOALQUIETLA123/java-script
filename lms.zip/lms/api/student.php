<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));

class Student {

    private function clean($json, $key) {
        return isset($json[$key]) ? trim($json[$key]) : "";
    }

    private function idOrNull($json, $key) {
        return (isset($json[$key]) && $json[$key] !== '' && $json[$key] !== null) ? $json[$key] : null;
    }

    private function fail($message) {
        echo json_encode(["status" => "error", "message" => $message]);
    }

    // Finds the Faculty role (any role whose name contains "faculty").
    // If none exists yet it is created, so adding faculty works on a fresh database.
    private function facultyRoleId($conn) {
        $stmt = $conn->prepare("SELECT role_id FROM roles WHERE LOWER(role_name) LIKE '%faculty%' ORDER BY role_id ASC LIMIT 1");
        $stmt->execute();
        $id = $stmt->fetchColumn();

        if ($id) {
            return (int) $id;
        }

        $nextId = (int) $conn->query("SELECT COALESCE(MAX(role_id), 0) + 1 FROM roles")->fetchColumn();
        $ins = $conn->prepare("INSERT INTO roles (role_id, role_name, default_loan_days) VALUES (:id, 'Faculty', 0)");
        $ins->bindParam(":id", $nextId);
        $ins->execute();
        return $nextId;
    }

    // Role for a borrower type. Student and Dean are created on first use, like Faculty.
    private function roleIdFor($conn, $type) {
        if ($type === 'faculty') return $this->facultyRoleId($conn);

        $name = $type === 'dean' ? 'Dean' : 'Student';
        $stmt = $conn->prepare("SELECT role_id FROM roles WHERE LOWER(TRIM(role_name)) = LOWER(:n) LIMIT 1");
        $stmt->execute([":n" => $name]);
        $id = $stmt->fetchColumn();
        if ($id) return (int) $id;

        $next = (int) $conn->query("SELECT COALESCE(MAX(role_id), 0) + 1 FROM roles")->fetchColumn();
        $conn->prepare("INSERT INTO roles (role_id, role_name, default_loan_days) VALUES (:id, :n, 0)")
             ->execute([":id" => $next, ":n" => $name]);
        return $next;
    }

    private function isFacultyUser($conn, $user_id) {
        $stmt = $conn->prepare("
            SELECT r.role_name
            FROM users u
            INNER JOIN roles r ON u.role_id = r.role_id
            WHERE u.user_id = :user_id
            LIMIT 1
        ");
        $stmt->bindParam(":user_id", $user_id);
        $stmt->execute();
        $name = $stmt->fetchColumn();
        return $name !== false && Auth::roleKey($name) === 'borrower';
    }

    private function departmentName($conn, $department_id) {
        $stmt = $conn->prepare("SELECT department_name FROM department WHERE department_id = :id LIMIT 1");
        $stmt->bindParam(":id", $department_id);
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    // Creating, editing and deleting borrowers now happens on the Users page (api/users.php).
    // This endpoint stays read-only because the borrow, return and reservation pages pick borrowers from it.
    function locked() {
        echo json_encode(["status" => "error", "message" => "Borrowers are managed on the Users page."]);
    }

    function getAll() {
        include "../config/connection-pdo.php";

        $sql = "SELECT s.student_id, s.user_id, s.first_name, s.last_name, s.email,
                       s.phone, s.address, s.course,
                       u.username, u.department_id,
                       CASE WHEN LOWER(IFNULL(r.role_name, '')) LIKE '%faculty%' OR LOWER(IFNULL(r.role_name, '')) LIKE '%dean%' THEN 1 ELSE 0 END AS is_faculty,
                       CASE WHEN LOWER(IFNULL(r.role_name, '')) LIKE '%dean%' THEN 'dean'
                            WHEN LOWER(IFNULL(r.role_name, '')) LIKE '%faculty%' THEN 'faculty'
                            ELSE 'student' END AS borrower_type
                FROM student s
                LEFT JOIN users u ON s.user_id = u.user_id
                LEFT JOIN roles r ON u.role_id = r.role_id
                ORDER BY s.first_name ASC, s.last_name ASC";

        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rs);
    }

    function add($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $typeIn = $this->clean($json, 'borrower_type');
        $borrower_type = in_array($typeIn, ['faculty', 'dean'], true) ? $typeIn : 'student';
        $first_name = $this->clean($json, 'first_name');
        $last_name = $this->clean($json, 'last_name');
        $email = $this->clean($json, 'email');
        $phone = $this->clean($json, 'phone');
        $address = $this->clean($json, 'address');
        $course = $this->clean($json, 'course');
        $user_id = $this->idOrNull($json, 'user_id');

        $department_id = $this->idOrNull($json, 'department_id');
        $username = $this->clean($json, 'username');
        $password = $this->clean($json, 'password');

        if (empty($first_name) || empty($last_name) || empty($email) || empty($phone) || empty($address)) {
            $this->fail("All fields are required.");
            return;
        }

        if ($borrower_type === 'student' && empty($course)) {
            $this->fail("All fields are required.");
            return;
        }

        if ($department_id === null || empty($username) || empty($password) || strlen($password) < 8) {
            $this->fail("Department, username and a password of at least 8 characters are required so they can log in.");
            return;
        }

        $check = $conn->prepare("SELECT student_id FROM student WHERE email = :email");
        $check->bindParam(":email", $email);
        $check->execute();

        if ($check->rowCount() > 0) {
            $this->fail("A student or faculty member with this email already exists.");
            return;
        }

        try {
            $conn->beginTransaction();

            if ($username !== '') {
                $dupe = $conn->prepare("SELECT user_id FROM users WHERE username = :username");
                $dupe->bindParam(":username", $username);
                $dupe->execute();

                if ($dupe->rowCount() > 0) {
                    $conn->rollBack();
                    $this->fail("Username already exists.");
                    return;
                }

                $deptName = $this->departmentName($conn, $department_id);
                if ($deptName === false) {
                    $conn->rollBack();
                    $this->fail("The selected department was not found.");
                    return;
                }

                $role_id = $this->roleIdFor($conn, $borrower_type);

                // Same storage as users.php so both pages stay consistent.
                $u = $conn->prepare("
                    INSERT INTO users (role_id, department_id, first_name, last_name,
                                       contact_number, email, username, password, account_status, created_at, updated_at)
                    VALUES (:role_id, :department_id, :first_name, :last_name,
                            :contact_number, :email, :username, :password, 'active', NOW(), NOW())
                ");
                $u->bindParam(":role_id", $role_id);
                $u->bindParam(":department_id", $department_id);
                $u->bindParam(":first_name", $first_name);
                $u->bindParam(":last_name", $last_name);
                $u->bindParam(":contact_number", $phone);
                $u->bindParam(":email", $email);
                $u->bindParam(":username", $username);
                $u->bindValue(":password", password_hash($password, PASSWORD_DEFAULT));
                $u->execute();

                $user_id = (int) $conn->lastInsertId();
                if ($borrower_type !== 'student') $course = $deptName;
            }

            $nextId = (int) $conn->query("SELECT IFNULL(MAX(student_id), 0) + 1 FROM student")->fetchColumn();

            $sql = "INSERT INTO student (
                        student_id, user_id, first_name, last_name,
                        email, phone, address, course, created_at, updated_at
                    ) VALUES (
                        :student_id, :user_id, :first_name, :last_name,
                        :email, :phone, :address, :course, NOW(), NOW()
                    )";

            $stmt = $conn->prepare($sql);
            $stmt->bindParam(":student_id", $nextId);
            $stmt->bindParam(":first_name", $first_name);
            $stmt->bindParam(":last_name", $last_name);
            $stmt->bindParam(":email", $email);
            $stmt->bindParam(":phone", $phone);
            $stmt->bindParam(":address", $address);
            $stmt->bindParam(":course", $course);

            if ($user_id === null) {
                $stmt->bindValue(":user_id", null, PDO::PARAM_NULL);
            } else {
                $stmt->bindValue(":user_id", $user_id, PDO::PARAM_INT);
            }

            $stmt->execute();
            $conn->commit();

            echo json_encode([
                "status" => "success",
                "message" => ucfirst($borrower_type) . " added successfully."
            ]);
        } catch (Exception $e) {
            if ($conn->inTransaction()) {
                $conn->rollBack();
            }
            error_log("student add failed: " . $e->getMessage());
            $this->fail("Failed to save. Please try again.");
        }
    }

    function update($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $student_id = $this->idOrNull($json, 'student_id');
        $user_id = $this->idOrNull($json, 'user_id');

        $first_name = $this->clean($json, 'first_name');
        $last_name = $this->clean($json, 'last_name');
        $email = $this->clean($json, 'email');
        $phone = $this->clean($json, 'phone');
        $address = $this->clean($json, 'address');
        $course = $this->clean($json, 'course');

        $department_id = $this->idOrNull($json, 'department_id');
        $username = $this->clean($json, 'username');
        $password = $this->clean($json, 'password');

        if ($student_id === null) {
            $this->fail("Student ID is required.");
            return;
        }

        $faculty = in_array($this->clean($json, 'borrower_type'), ['faculty', 'dean'], true);
        $borrower_type = $faculty ? $this->clean($json, 'borrower_type') : 'student';
        $hasAccount = $user_id !== null;
        $creating = !$hasAccount && $username !== '' && $password !== '';

        if (empty($first_name) || empty($last_name) || empty($email) || empty($phone) || empty($address)) {
            $this->fail("All fields are required.");
            return;
        }

        if (!$faculty && empty($course)) {
            $this->fail("All fields are required.");
            return;
        }

        if (($hasAccount || $creating) && ($department_id === null || empty($username))) {
            $this->fail("Department and username are required for the login.");
            return;
        }

        $check = $conn->prepare("
            SELECT student_id
            FROM student
            WHERE email = :email AND student_id != :student_id
        ");

        $check->bindParam(":email", $email);
        $check->bindParam(":student_id", $student_id);
        $check->execute();

        if ($check->rowCount() > 0) {
            $this->fail("Another student or faculty member with this email already exists.");
            return;
        }

        try {
            $conn->beginTransaction();

            if ($hasAccount) {
                $dupe = $conn->prepare("SELECT user_id FROM users WHERE username = :username AND user_id != :user_id");
                $dupe->bindParam(":username", $username);
                $dupe->bindParam(":user_id", $user_id);
                $dupe->execute();

                if ($dupe->rowCount() > 0) {
                    $conn->rollBack();
                    $this->fail("Username already taken by another user.");
                    return;
                }

                $deptName = $this->departmentName($conn, $department_id);
                if ($deptName === false) {
                    $conn->rollBack();
                    $this->fail("The selected department was not found.");
                    return;
                }

                if ($faculty) $course = $deptName;

                $sqlUser = "UPDATE users SET
                                department_id = :department_id,
                                first_name = :first_name,
                                last_name = :last_name,
                                contact_number = :contact_number,
                                email = :email,
                                username = :username,
                                updated_at = NOW()";
                if ($password !== '') {
                    $sqlUser .= ", password = :password";
                }
                $sqlUser .= " WHERE user_id = :user_id";

                $u = $conn->prepare($sqlUser);
                $u->bindParam(":department_id", $department_id);
                $u->bindParam(":first_name", $first_name);
                $u->bindParam(":last_name", $last_name);
                $u->bindParam(":contact_number", $phone);
                $u->bindParam(":email", $email);
                $u->bindParam(":username", $username);
                if ($password !== '') {
                    $u->bindValue(":password", password_hash($password, PASSWORD_DEFAULT));
                }
                $u->bindParam(":user_id", $user_id);
                $u->execute();
            }

            // An existing student who has no login yet can be given one here.
            if ($creating) {
                if (strlen($password) < 8) {
                    $conn->rollBack();
                    $this->fail("Password must be at least 8 characters.");
                    return;
                }

                $dupe = $conn->prepare("SELECT user_id FROM users WHERE username = :username");
                $dupe->execute([":username" => $username]);
                if ($dupe->fetchColumn()) {
                    $conn->rollBack();
                    $this->fail("Username already exists.");
                    return;
                }

                $deptName = $this->departmentName($conn, $department_id);
                if ($deptName === false) {
                    $conn->rollBack();
                    $this->fail("The selected department was not found.");
                    return;
                }

                $conn->prepare("INSERT INTO users (role_id, department_id, first_name, last_name, contact_number, email,
                                                   username, password, account_status, created_at, updated_at)
                                VALUES (:r, :d, :f, :l, :c, :e, :u, :p, 'active', NOW(), NOW())")
                     ->execute([":r" => $this->roleIdFor($conn, $borrower_type), ":d" => $department_id, ":f" => $first_name,
                                ":l" => $last_name, ":c" => $phone, ":e" => $email, ":u" => $username,
                                ":p" => password_hash($password, PASSWORD_DEFAULT)]);

                $user_id = (int) $conn->lastInsertId();
                if ($faculty) $course = $deptName;
            }

            $sql = "UPDATE student SET
                        user_id = :user_id,
                        first_name = :first_name,
                        last_name = :last_name,
                        email = :email,
                        phone = :phone,
                        address = :address,
                        course = :course,
                        updated_at = NOW()
                    WHERE student_id = :student_id";

            $stmt = $conn->prepare($sql);

            if ($user_id === null) {
                $stmt->bindValue(":user_id", null, PDO::PARAM_NULL);
            } else {
                $stmt->bindValue(":user_id", $user_id, PDO::PARAM_INT);
            }

            $stmt->bindParam(":first_name", $first_name);
            $stmt->bindParam(":last_name", $last_name);
            $stmt->bindParam(":email", $email);
            $stmt->bindParam(":phone", $phone);
            $stmt->bindParam(":address", $address);
            $stmt->bindParam(":course", $course);
            $stmt->bindParam(":student_id", $student_id);
            $stmt->execute();

            $conn->commit();

            echo json_encode(["status" => "success", "message" => "Record updated successfully."]);
        } catch (Exception $e) {
            if ($conn->inTransaction()) {
                $conn->rollBack();
            }
            error_log("student update failed: " . $e->getMessage());
            $this->fail("Failed to update. Please try again.");
        }
    }

    function delete($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $student_id = $this->idOrNull($json, 'student_id');

        if ($student_id === null) {
            $this->fail("Student ID is required.");
            return;
        }

        $check = $conn->prepare("
            SELECT transaction_id
            FROM borrow_transaction
            WHERE student_id = :student_id
            LIMIT 1
        ");

        $check->bindParam(":student_id", $student_id);
        $check->execute();

        if ($check->rowCount() > 0) {
            $this->fail("Cannot delete: this person has existing borrow transactions.");
            return;
        }

        try {
            $res = $conn->prepare("SELECT reservation_id FROM reservation WHERE student_id = :student_id AND status IN ('Pending', 'Waiting', 'Ready') LIMIT 1");
            $res->bindParam(":student_id", $student_id);
            $res->execute();

            if ($res->rowCount() > 0) {
                $this->fail("Cannot delete: this person has an active book reservation. Cancel it first.");
                return;
            }
        } catch (PDOException $e) {
            // reservation table not created yet - nothing to check
        }

        $rowStmt = $conn->prepare("SELECT user_id FROM student WHERE student_id = :student_id");
        $rowStmt->bindParam(":student_id", $student_id);
        $rowStmt->execute();
        $user_id = $rowStmt->fetchColumn();

        $sql = "DELETE FROM student WHERE student_id = :student_id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":student_id", $student_id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            // A faculty member's user account was created together with this record, so it
            // goes too (otherwise they would keep showing up as a borrower). It is kept if
            // the account processed any transactions or is shared by another record.
            if ($user_id && $this->isFacultyUser($conn, $user_id)) {
                $used = $conn->prepare("SELECT transaction_id FROM borrow_transaction WHERE processed_by_user_id = :u LIMIT 1");
                $used->bindParam(":u", $user_id);
                $used->execute();

                $shared = $conn->prepare("SELECT student_id FROM student WHERE user_id = :u LIMIT 1");
                $shared->bindParam(":u", $user_id);
                $shared->execute();

                if ($used->rowCount() === 0 && $shared->rowCount() === 0) {
                    $del = $conn->prepare("DELETE FROM users WHERE user_id = :u");
                    $del->bindParam(":u", $user_id);
                    $del->execute();
                }
            }

            echo json_encode(["status" => "success", "message" => "Record deleted successfully."]);
        } else {
            $this->fail("Failed to delete record.");
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$obj = new Student();

switch ($operation) {
    case "getAll":
        $obj->getAll();
        break;
    case "add":
        $obj->locked();
        break;
    case "update":
        $obj->locked();
        break;
    case "delete":
        $obj->locked();
        break;
}
?>