<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));

require_once __DIR__ . "/loan_rules.php";
require_once __DIR__ . "/account_standing.php";

// How it works
//  - A reservation is for a BOOK (title), not a specific copy.
//  - If a copy is Available it is held for the borrower: the copy's status becomes "Reserved"
//    (so it disappears from the Borrow Transactions picker) and the reservation is "Ready".
//  - If no copy is free the reservation is "Waiting" (first come, first served) and gets a copy
//    as soon as one is returned. This is checked every time the list is loaded.
//  - A reservation not picked up by its "pick up by" date becomes "Expired" and frees the copy.
//  - "Fulfill" turns a Ready reservation into a real borrow transaction.
class Reservation {

    const MAX_HOLD_DAYS = 14; // furthest pick-up date that can be chosen

    private function blank($value) {
        return !isset($value) || $value === '' || $value === null;
    }

    private function out($status, $message, $extra = []) {
        echo json_encode(array_merge(["status" => $status, "message" => $message], $extra));
    }

    private function validDate($value) {
        return is_string($value) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) && strtotime($value) !== false;
    }

    private function statusId($conn, $desc, $create = false) {
        $stmt = $conn->prepare("SELECT status_id FROM status WHERE status_desc = :d LIMIT 1");
        $stmt->bindParam(":d", $desc);
        $stmt->execute();
        $id = $stmt->fetchColumn();

        if ($id || !$create) {
            return $id ? (int) $id : null;
        }

        $next = (int) $conn->query("SELECT IFNULL(MAX(status_id), 0) + 1 FROM status")->fetchColumn();
        $ins = $conn->prepare("INSERT INTO status (status_id, status_desc) VALUES (:id, :d)");
        $ins->bindParam(":id", $next);
        $ins->bindParam(":d", $desc);
        $ins->execute();
        return $next;
    }

    // Puts a held copy back to Available (only if it is still marked Reserved).
    private function releaseCopy($conn, $copy_id) {
        if (!$copy_id) return;

        $reserved = $this->statusId($conn, 'Reserved');
        $available = $this->statusId($conn, 'Available');
        if (!$reserved || !$available) return;

        $stmt = $conn->prepare("UPDATE book_copies SET status_id = :a WHERE copy_id = :c AND status_id = :r");
        $stmt->execute([":a" => $available, ":c" => $copy_id, ":r" => $reserved]);
    }

    // Gives a Waiting reservation an Available copy of its book, if there is one.
    private function tryAllocate($conn, $reservation_id, $book_id) {
        $reservedId = $this->statusId($conn, 'Reserved', true);

        try {
            $conn->beginTransaction();

            $find = $conn->prepare("
                SELECT bc.copy_id
                FROM book_copies bc
                INNER JOIN status s ON bc.status_id = s.status_id
                WHERE bc.book_id = :book_id AND s.status_desc = 'Available'
                ORDER BY CAST(bc.accession_number AS UNSIGNED) ASC, bc.accession_number ASC
                LIMIT 1
                FOR UPDATE
            ");
            $find->bindParam(":book_id", $book_id);
            $find->execute();
            $copy_id = $find->fetchColumn();

            if (!$copy_id) {
                $conn->rollBack();
                return null;
            }

            $conn->prepare("UPDATE book_copies SET status_id = :r WHERE copy_id = :c")
                 ->execute([":r" => $reservedId, ":c" => $copy_id]);

            $conn->prepare("UPDATE reservation SET copy_id = :c, status = 'Ready', updated_at = NOW()
                            WHERE reservation_id = :id AND status = 'Waiting'")
                 ->execute([":c" => $copy_id, ":id" => $reservation_id]);

            $conn->commit();
            return (int) $copy_id;
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("reservation allocate failed: " . $e->getMessage());
            return null;
        }
    }

    // Expire late reservations, then hand free copies to the people waiting.
    private function maintain($conn) {
        $today = date('Y-m-d');

        // Make sure the "Reserved" status exists .
        $this->statusId($conn, 'Reserved', true);

        $exp = $conn->prepare("SELECT reservation_id, copy_id FROM reservation
                               WHERE status IN ('Pending', 'Waiting', 'Ready') AND expires_on < :today");
        $exp->bindParam(":today", $today);
        $exp->execute();

        foreach ($exp->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $conn->prepare("UPDATE reservation SET status = 'Expired', copy_id = NULL, updated_at = NOW()
                            WHERE reservation_id = :id")->execute([":id" => $r['reservation_id']]);
            $this->releaseCopy($conn, $r['copy_id']);
        }

        $wait = $conn->query("SELECT reservation_id, book_id FROM reservation
                              WHERE status = 'Waiting' ORDER BY reserved_at ASC, reservation_id ASC");

        foreach ($wait->fetchAll(PDO::FETCH_ASSOC) as $w) {
            $this->tryAllocate($conn, $w['reservation_id'], $w['book_id']);
        }
    }

    function getAll() {
        include "../config/connection-pdo.php";

        try {
            $this->maintain($conn);

            $sql = "SELECT r.reservation_id, r.student_id, r.book_id, r.copy_id, r.transaction_id,
                           r.reserved_at, r.expires_on, r.status, r.reject_reason, r.decided_at,
                           CONCAT(s.first_name, ' ', s.last_name) AS borrower,
                           CASE WHEN (LOWER(IFNULL(sr.role_name, '')) LIKE '%faculty%' OR LOWER(IFNULL(sr.role_name, '')) LIKE '%dean%') THEN 'Faculty' ELSE 'Student' END AS borrower_type,
                           b.title, b.book_type,
                           bc.accession_number,
                           (SELECT COUNT(*) FROM book_copies c INNER JOIN status st ON c.status_id = st.status_id
                            WHERE c.book_id = r.book_id AND c.archived_at IS NULL AND st.status_desc = 'Available') AS available_now,
                           (SELECT COUNT(*) FROM book_copies c INNER JOIN status st ON c.status_id = st.status_id
                            WHERE c.book_id = r.book_id AND c.archived_at IS NULL AND st.status_desc <> 'Library Use Only') AS borrowable_copies,
                           CONCAT(u.first_name, ' ', u.last_name) AS processed_by
                    FROM reservation r
                    LEFT JOIN student s ON r.student_id = s.student_id
                    LEFT JOIN users su ON s.user_id = su.user_id
                    LEFT JOIN roles sr ON su.role_id = sr.role_id
                    LEFT JOIN book b ON r.book_id = b.book_id
                    LEFT JOIN book_copies bc ON r.copy_id = bc.copy_id
                    LEFT JOIN users u ON r.processed_by_user_id = u.user_id
                    ORDER BY FIELD(r.status, 'Pending', 'Ready', 'Waiting', 'Fulfilled', 'Rejected', 'Cancelled', 'Expired'),
                             r.expires_on ASC, r.reservation_id DESC";

            $stmt = $conn->prepare($sql);
            $stmt->execute();
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        } catch (PDOException $e) {
            error_log("reservation getAll failed: " . $e->getMessage());
            $this->out("error", "Could not load reservations.");
        }
    }

    // Books with how many copies exist / are free right now (for the Book dropdown).
    function getBooks() {
        include "../config/connection-pdo.php";

        $this->maintain($conn);

        $sql = "SELECT b.book_id, b.title, b.book_type,
                       SUM(CASE WHEN bc.copy_id IS NOT NULL AND bc.archived_at IS NULL AND s.status_desc <> 'Library Use Only' THEN 1 ELSE 0 END) AS total_copies,
                       SUM(CASE WHEN s.status_desc = 'Available' THEN 1 ELSE 0 END) AS available,
                       SUM(CASE WHEN s.status_desc = 'Reserved' THEN 1 ELSE 0 END) AS reserved
                FROM book b
                LEFT JOIN book_copies bc ON bc.book_id = b.book_id
                LEFT JOIN status s ON bc.status_id = s.status_id
                GROUP BY b.book_id, b.title, b.book_type
                ORDER BY b.title ASC";

        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as &$row) {
            $row['total_copies'] = (int) $row['total_copies'];
            $row['available'] = (int) $row['available'];
            $row['reserved'] = (int) $row['reserved'];
        }

        echo json_encode($rows);
    }

    function add($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $student_id = $data['student_id'] ?? null;
        $book_id = $data['book_id'] ?? null;
        $expires_on = $data['expires_on'] ?? null;
        $processed_by = Auth::id(); // the signed-in user, never the request

        if ($this->blank($student_id) || $this->blank($book_id) || $this->blank($expires_on)) {
            $this->out("error", "Borrower, book and pick-up date are required.");
            return;
        }

        $student_id = (int) $student_id;
        $book_id = (int) $book_id;
        $today = date('Y-m-d');
        $latest = date('Y-m-d', strtotime("+" . self::MAX_HOLD_DAYS . " days"));

        if (!$this->validDate($expires_on)) {
            $this->out("error", "Please enter a valid pick-up date.");
            return;
        }

        if ($expires_on < $today) {
            $this->out("error", "Pick-up date can't be in the past.");
            return;
        }

        if ($expires_on > $latest) {
            $this->out("error", "Pick-up date can't be later than $latest (" . self::MAX_HOLD_DAYS . " days from today).");
            return;
        }

        try {
            $this->maintain($conn);

            $s = $conn->prepare("SELECT student_id FROM student WHERE student_id = :id");
            $s->execute([":id" => $student_id]);
            if (!$s->fetchColumn()) {
                $this->out("error", "Borrower not found.");
                return;
            }

            $hold = AccountStanding::guard($conn, (int) $student_id);
            if ($hold) { $this->out("error", $hold); return; }

            $b = $conn->prepare("SELECT b.title, (SELECT COUNT(*) FROM book_copies c INNER JOIN status st ON c.status_id = st.status_id
                                                  WHERE c.book_id = b.book_id AND c.archived_at IS NULL AND st.status_desc <> 'Library Use Only') AS copies
                                 FROM book b WHERE b.book_id = :id");
            $b->execute([":id" => $book_id]);
            $book = $b->fetch(PDO::FETCH_ASSOC);

            if (!$book) {
                $this->out("error", "Book not found.");
                return;
            }

            if ((int) $book['copies'] === 0) {
                $this->out("error", "This book has no copies in the library yet, so it can't be reserved.");
                return;
            }

            $dupe = $conn->prepare("SELECT reservation_id FROM reservation
                                    WHERE student_id = :s AND book_id = :b AND status IN ('Pending', 'Waiting', 'Ready') LIMIT 1");
            $dupe->execute([":s" => $student_id, ":b" => $book_id]);
            if ($dupe->fetchColumn()) {
                $this->out("error", "This borrower already has an active reservation for this book.");
                return;
            }

            // Unreturned loans plus active reservations count toward the borrower's limit.
            $faculty = LoanRules::isFaculty($conn, $student_id);
            $limit = LoanRules::limit($conn, $faculty);
            $active = LoanRules::activeCount($conn, $student_id);

            $resCount = $conn->prepare("SELECT COUNT(*) FROM reservation WHERE student_id = :s AND status IN ('Pending', 'Waiting', 'Ready')");
            $resCount->execute([":s" => $student_id]);
            $reserved = (int) $resCount->fetchColumn();

            if ($active + $reserved + 1 > $limit) {
                $this->out("error", sprintf(
                    "%s limit reached: at most %d books at a time, counting borrowed (%d) and reserved (%d) books.",
                    $faculty ? "Faculty" : "Student", $limit, $active, $reserved
                ));
                return;
            }

            $nextId = (int) $conn->query("SELECT IFNULL(MAX(reservation_id), 0) + 1 FROM reservation")->fetchColumn();

            $ins = $conn->prepare("
                INSERT INTO reservation
                    (reservation_id, student_id, book_id, copy_id, processed_by_user_id, reserved_at, expires_on, status, updated_at)
                VALUES
                    (:id, :student_id, :book_id, NULL, :processed_by, NOW(), :expires_on, 'Waiting', NOW())
            ");
            $ins->bindParam(":id", $nextId);
            $ins->bindParam(":student_id", $student_id);
            $ins->bindParam(":book_id", $book_id);
            $ins->bindValue(":processed_by", $processed_by, $processed_by === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
            $ins->bindParam(":expires_on", $expires_on);
            $ins->execute();

            // First-come-first-served: older waiting reservations get a free copy before this one.
            $this->maintain($conn);

            $chk = $conn->prepare("SELECT r.status, bc.accession_number
                                   FROM reservation r LEFT JOIN book_copies bc ON r.copy_id = bc.copy_id
                                   WHERE r.reservation_id = :id");
            $chk->execute([":id" => $nextId]);
            $row = $chk->fetch(PDO::FETCH_ASSOC);

            if ($row && $row['status'] === 'Ready') {
                $this->out("success", "Reserved. Copy ACC-" . $row['accession_number'] . " is being held for pick-up until $expires_on.", ["reservation_status" => "Ready"]);
            } else {
                $this->out("success", "Reserved. No copy is free right now, so this reservation is on the waiting list. It becomes Ready when a copy is returned.", ["reservation_status" => "Waiting"]);
            }
        } catch (Exception $e) {
            error_log("reservation add failed: " . $e->getMessage());
            $this->out("error", "Failed to save reservation.");
        }
    }

    function cancel($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $id = $data['reservation_id'] ?? null;

        if ($this->blank($id)) {
            $this->out("error", "Reservation ID is required.");
            return;
        }

        try {
            $stmt = $conn->prepare("SELECT status, copy_id FROM reservation WHERE reservation_id = :id");
            $stmt->execute([":id" => $id]);
            $r = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$r || !in_array($r['status'], ['Pending', 'Waiting', 'Ready'], true)) {
                $this->out("error", "Only Waiting or Ready reservations can be cancelled.");
                return;
            }

            $conn->prepare("UPDATE reservation SET status = 'Cancelled', copy_id = NULL, updated_at = NOW() WHERE reservation_id = :id")
                 ->execute([":id" => $id]);
            $this->releaseCopy($conn, $r['copy_id']);

            // The freed copy may go straight to the next person in line.
            $this->maintain($conn);

            $this->out("success", "Reservation cancelled.");
        } catch (Exception $e) {
            error_log("reservation cancel failed: " . $e->getMessage());
            $this->out("error", "Failed to cancel reservation.");
        }
    }

    // Turns a Ready reservation into a borrow transaction (borrow date = today).
    function fulfill($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $id = $data['reservation_id'] ?? null;
        $processed_by = Auth::id();
        $requested_due = $data['due_date'] ?? null;

        if ($this->blank($id) || $this->blank($processed_by)) {
            $this->out("error", "Reservation and processed-by user are required.");
            return;
        }

        try {
            $this->maintain($conn);
            $conn->beginTransaction();

            $stmt = $conn->prepare("SELECT * FROM reservation WHERE reservation_id = :id FOR UPDATE");
            $stmt->execute([":id" => $id]);
            $r = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$r) {
                $this->abort($conn, "Reservation not found.");
                return;
            }

            if ($r['status'] !== 'Ready' || !$r['copy_id']) {
                $this->abort($conn, $r['status'] === 'Pending'
                    ? "This reservation has not been approved yet. Approve it first."
                    : ($r['status'] === 'Waiting'
                        ? "This reservation is still waiting for a copy to be returned."
                        : "Only Ready reservations can be checked out (this one is {$r['status']})."));
                return;
            }

            $student_id = (int) $r['student_id'];
            $copy_id = (int) $r['copy_id'];

            $lock = $conn->prepare("SELECT student_id FROM student WHERE student_id = :s FOR UPDATE");
            $lock->execute([":s" => $student_id]);

            // The held copy must still be the one marked Reserved.
            $c = $conn->prepare("SELECT s.status_desc FROM book_copies bc INNER JOIN status s ON bc.status_id = s.status_id
                                 WHERE bc.copy_id = :c FOR UPDATE");
            $c->execute([":c" => $copy_id]);
            if ($c->fetchColumn() !== 'Reserved') {
                $this->abort($conn, "The held copy is no longer marked Reserved. Please cancel and reserve again.");
                return;
            }

            // Same loan rules as the Borrow Transactions page.
            $plan = LoanRules::plan($conn, $student_id, [$copy_id]);

            if ($plan['hold']) {
                $this->abort($conn, $plan['hold']);
                return;
            }

            if ($plan['active'] + 1 > $plan['limit']) {
                $this->abort($conn, sprintf(
                    "%s limit reached: at most %d books at a time and %d are unreturned.",
                    $plan['borrower_type'], $plan['limit'], $plan['active']
                ));
                return;
            }

            $borrow_date = $plan['borrow_date'];
            $due_date = $plan['due_date'];

            if (!$this->blank($requested_due)) {
                if (!$this->validDate($requested_due) || $requested_due < $borrow_date) {
                    $this->abort($conn, "Please enter a valid due date (not before today).");
                    return;
                }
                if ($requested_due > $plan['due_date']) {
                    $this->abort($conn, "Due date cannot be later than {$plan['due_date']}, the longest loan allowed for a "
                        . strtolower($plan['borrower_type']) . " with this book type ({$plan['period_label']}).");
                    return;
                }
                $due_date = $requested_due;
            }

            $borrowedId = $this->statusId($conn, 'Borrowed');
            if (!$borrowedId) {
                $this->abort($conn, "The 'Borrowed' status is missing. Ask the Technical Services Librarian to restore it.");
                return;
            }

            $txId = (int) $conn->query("SELECT IFNULL(MAX(transaction_id), 0) + 1 FROM borrow_transaction")->fetchColumn();

            $conn->prepare("INSERT INTO borrow_transaction
                                (transaction_id, student_id, processed_by_user_id, borrow_date, due_date, status_id, created_at)
                            VALUES (:t, :s, :u, :bd, :dd, :st, NOW())")
                 ->execute([":t" => $txId, ":s" => $student_id, ":u" => $processed_by,
                            ":bd" => $borrow_date, ":dd" => $due_date, ":st" => $borrowedId]);

            $itemId = (int) $conn->query("SELECT IFNULL(MAX(item_id), 0) + 1 FROM borrow_items")->fetchColumn();

            $conn->prepare("INSERT INTO borrow_items (item_id, transaction_id, copy_id, due_date, is_returned) VALUES (:i, :t, :c, :d, 0)")
                 ->execute([":i" => $itemId, ":t" => $txId, ":c" => $copy_id, ":d" => $due_date]);

            $conn->prepare("UPDATE book_copies SET status_id = :st WHERE copy_id = :c")
                 ->execute([":st" => $borrowedId, ":c" => $copy_id]);

            $conn->prepare("UPDATE reservation SET status = 'Fulfilled', transaction_id = :t,
                                processed_by_user_id = :u, updated_at = NOW()
                            WHERE reservation_id = :id")
                 ->execute([":t" => $txId, ":u" => $processed_by, ":id" => $id]);

            $conn->commit();

            $this->out("success", "Reservation checked out. Due date: $due_date.", ["transaction_id" => $txId, "due_date" => $due_date]);
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("reservation fulfill failed: " . $e->getMessage());
            $this->out("error", "Failed to check out the reservation.");
        }
    }

    private function abort($conn, $message) {
        if ($conn->inTransaction()) $conn->rollBack();
        $this->out("error", $message);
    }

    // Only finished reservations can be removed from the list.
    // Staff decision on a reservation a student asked for in the portal.
    // Approve: it joins the normal queue (Waiting) and gets a copy straight away if one is free (Ready).
    // Returns ["ok" => bool, "message" => string, "status" => string|null]; nothing is echoed.
    private function approveOne($conn, $id) {
        $fail = function ($msg) use ($conn) {
            if ($conn->inTransaction()) $conn->rollBack();
            return ["ok" => false, "message" => $msg, "status" => null];
        };

        try {
            $this->maintain($conn);          // anything past its pick-up date expires before it can be approved
            $conn->beginTransaction();

            $stmt = $conn->prepare("SELECT * FROM reservation WHERE reservation_id = :id FOR UPDATE");
            $stmt->execute([":id" => $id]);
            $r = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$r) return $fail("Reservation not found.");

            // The student may have gone overdue since asking.
            if ($r['status'] === 'Pending') {
                $hold = AccountStanding::guard($conn, (int) $r['student_id']);
                if ($hold) return $fail("Can't approve: " . $hold);
            }

            if ($r['status'] !== 'Pending') {
                return $fail($r['status'] === 'Expired'
                    ? "The pick-up date passed before this request was approved, so it expired. Ask the student to reserve again."
                    : "Only a Pending request can be approved (this one is {$r['status']}).");
            }

            $copies = $conn->prepare("SELECT COUNT(*) FROM book_copies c INNER JOIN status st ON c.status_id = st.status_id
                                      WHERE c.book_id = :b AND c.archived_at IS NULL AND st.status_desc <> 'Library Use Only'");
            $copies->execute([":b" => $r['book_id']]);
            if ((int) $copies->fetchColumn() === 0) return $fail("This book has no copies that can be borrowed, so the request can't be approved.");

            $conn->prepare("UPDATE reservation SET status = 'Waiting', processed_by_user_id = :u, decided_at = NOW(), updated_at = NOW()
                            WHERE reservation_id = :id")
                 ->execute([":u" => Auth::id(), ":id" => $id]);
            $conn->commit();

            // Join the queue in order of request, and take a free copy if there is one.
            $this->maintain($conn);

            $now = $conn->prepare("SELECT status, expires_on FROM reservation WHERE reservation_id = :id");
            $now->execute([":id" => $id]);
            $after = $now->fetch(PDO::FETCH_ASSOC);
            $ready = $after && $after['status'] === 'Ready';

            return [
                "ok" => true,
                "status" => $after ? $after['status'] : "Waiting",
                "message" => $ready
                    ? "Approved. A copy is now held for the student until " . $after['expires_on'] . "."
                    : "Approved. No copy is free right now, so the student is on the waiting list."
            ];
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("reservation approve failed: " . $e->getMessage());
            return ["ok" => false, "message" => "Failed to approve the reservation.", "status" => null];
        }
    }

    private function rejectOne($conn, $id, $reason) {
        try {
            $stmt = $conn->prepare("UPDATE reservation
                                    SET status = 'Rejected', reject_reason = :reason, processed_by_user_id = :u, decided_at = NOW(), updated_at = NOW()
                                    WHERE reservation_id = :id AND status = 'Pending'");
            $stmt->execute([":reason" => $reason === '' ? null : $reason, ":u" => Auth::id(), ":id" => $id]);

            return $stmt->rowCount() > 0
                ? ["ok" => true, "message" => "Request rejected."]
                : ["ok" => false, "message" => "Only a Pending request can be rejected."];
        } catch (Exception $e) {
            error_log("reservation reject failed: " . $e->getMessage());
            return ["ok" => false, "message" => "Failed to reject the reservation."];
        }
    }

    function approve($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $id = (int) ($data['reservation_id'] ?? 0);
        if ($id <= 0) { $this->out("error", "Reservation ID is required."); return; }

        $res = $this->approveOne($conn, $id);
        $this->out($res['ok'] ? "success" : "error", $res['message'], $res['ok'] ? ["reservation_status" => $res['status']] : []);
    }

    function reject($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $id = (int) ($data['reservation_id'] ?? 0);
        $reason = trim((string) ($data['reason'] ?? ''));

        if ($id <= 0) { $this->out("error", "Reservation ID is required."); return; }
        if (strlen($reason) > 200) { $this->out("error", "The reason can be at most 200 characters."); return; }

        $res = $this->rejectOne($conn, $id, $reason);
        $this->out($res['ok'] ? "success" : "error", $res['message']);
    }

    // One decision for everything a student asked for at once: the books ticked are approved, the rest rejected
    // (e.g. because the book is unavailable). Each request is decided on its own, so one problem doesn't block the others.
    function review($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $clean = function ($list) {
            return array_values(array_unique(array_filter(array_map('intval', is_array($list) ? $list : []), function ($v) { return $v > 0; })));
        };
        $approve = $clean($data['approve'] ?? []);
        $reject = $clean($data['reject'] ?? []);
        $reason = trim((string) ($data['reason'] ?? ''));

        if (count($approve) + count($reject) === 0) { $this->out("error", "Choose at least one request to approve or reject."); return; }
        if (count($approve) + count($reject) > 50) { $this->out("error", "Too many requests at once."); return; }
        if (count(array_intersect($approve, $reject)) > 0) { $this->out("error", "A request can't be both approved and rejected."); return; }
        if (strlen($reason) > 200) { $this->out("error", "The reason can be at most 200 characters."); return; }

        $approved = 0; $rejected = 0; $problems = [];

        foreach ($approve as $id) {
            $res = $this->approveOne($conn, $id);
            if ($res['ok']) $approved++; else $problems[] = "#$id: " . $res['message'];
        }
        foreach ($reject as $id) {
            $res = $this->rejectOne($conn, $id, $reason);
            if ($res['ok']) $rejected++; else $problems[] = "#$id: " . $res['message'];
        }

        $parts = [];
        if ($approved > 0) $parts[] = "approved $approved";
        if ($rejected > 0) $parts[] = "rejected $rejected";
        $message = $parts ? ucfirst(implode(" and ", $parts)) . "." : "Nothing was changed.";
        if ($problems) $message .= " Could not process: " . implode(" ", $problems);

        $this->out($problems && !$approved && !$rejected ? "error" : "success", $message,
                   ["approved" => $approved, "rejected" => $rejected, "problems" => count($problems)]);
    }

    function delete($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $id = $data['reservation_id'] ?? null;

        if ($this->blank($id)) {
            $this->out("error", "Reservation ID is required.");
            return;
        }

        $stmt = $conn->prepare("DELETE FROM reservation WHERE reservation_id = :id AND status IN ('Fulfilled', 'Cancelled', 'Expired', 'Rejected')");
        $stmt->execute([":id" => $id]);

        if ($stmt->rowCount() > 0) {
            $this->out("success", "Reservation deleted.");
        } else {
            $this->out("error", "Only fulfilled, cancelled, rejected or expired reservations can be deleted. Cancel or reject it first.");
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$obj = new Reservation();

switch ($operation) {
    case "getAll":
        $obj->getAll();
        break;
    case "getBooks":
        $obj->getBooks();
        break;
    case "add":
        $obj->add($json);
        break;
    case "cancel":
        $obj->cancel($json);
        break;
    case "fulfill":
        $obj->fulfill($json);
        break;
    case "approve":
        $obj->approve($json);
        break;
    case "reject":
        $obj->reject($json);
        break;
    case "review":
        $obj->review($json);
        break;
    case "delete":
        $obj->delete($json);
        break;
}

?>