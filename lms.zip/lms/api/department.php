<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));

class Department {
    function getAll() {
        include "../config/connection-pdo.php";

        $sql = "SELECT department_id, department_name
                FROM department
                ORDER BY department_name ASC";

        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rs);
    }

    function add($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);
        $department_name = isset($json['department_name']) ? trim($json['department_name']) : "";

        if (empty($department_name)) {
            echo json_encode(["status" => "error", "message" => "Department name is required."]);
            return;
        }

        if (preg_match('/^[\d\s]+$/', $department_name)) {
            echo json_encode(["status" => "error", "message" => "Invalid department name."]);
            return;
        }

        $check = $conn->prepare("SELECT department_id FROM department WHERE department_name = :department_name");
        $check->bindParam(":department_name", $department_name);
        $check->execute();

        if ($check->rowCount() > 0) {
            echo json_encode(["status" => "error", "message" => "Department already exists."]);
            return;
        }

        lms_lock_ids($conn);

        $maxStmt = $conn->prepare("SELECT IFNULL(MAX(department_id), 0) + 1 AS nextId FROM department");
        $maxStmt->execute();
        $department_id = $maxStmt->fetch(PDO::FETCH_ASSOC)['nextId'];

        $sql = "INSERT INTO department (department_id, department_name)
                VALUES (:department_id, :department_name)";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":department_id", $department_id);
        $stmt->bindParam(":department_name", $department_name);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode(["status" => "success", "message" => "Department added successfully."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to add department."]);
        }
    }

    function update($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $department_id = (isset($json['department_id']) && $json['department_id'] !== '' && $json['department_id'] !== null)
            ? $json['department_id']
            : null;

        $department_name = isset($json['department_name']) ? trim($json['department_name']) : "";

        if ($department_id === null) {
            echo json_encode(["status" => "error", "message" => "Department ID is required."]);
            return;
        }

        if (empty($department_name)) {
            echo json_encode(["status" => "error", "message" => "Department name is required."]);
            return;
        }

        if (preg_match('/^[\d\s]+$/', $department_name)) {
            echo json_encode(["status" => "error", "message" => "Invalid department name."]);
            return;
        }

        $check = $conn->prepare("
            SELECT department_id
            FROM department
            WHERE department_name = :department_name
            AND department_id != :department_id
        ");

        $check->bindParam(":department_name", $department_name);
        $check->bindParam(":department_id", $department_id);
        $check->execute();

        if ($check->rowCount() > 0) {
            echo json_encode(["status" => "error", "message" => "Department already exists."]);
            return;
        }

        $sql = "UPDATE department
                SET department_name = :department_name
                WHERE department_id = :department_id";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":department_name", $department_name);
        $stmt->bindParam(":department_id", $department_id);
        $stmt->execute();

        echo json_encode(["status" => "success", "message" => "Department updated successfully."]);
    }

    function delete($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $department_id = (isset($json['department_id']) && $json['department_id'] !== '' && $json['department_id'] !== null)
            ? $json['department_id']
            : null;

        if ($department_id === null) {
            echo json_encode(["status" => "error", "message" => "Department ID is required."]);
            return;
        }

        $check = $conn->prepare("
            SELECT user_id
            FROM users
            WHERE department_id = :department_id
            LIMIT 1
        ");

        $check->bindParam(":department_id", $department_id);
        $check->execute();

        if ($check->rowCount() > 0) {
            echo json_encode(["status" => "error", "message" => "Cannot delete: this department is assigned to one or more users."]);
            return;
        }

        $sql = "DELETE FROM department WHERE department_id = :department_id";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":department_id", $department_id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode(["status" => "success", "message" => "Department deleted successfully."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to delete department."]);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$obj = new Department();

switch ($operation) {
    case "getAll":
        $obj->getAll();
        break;
    case "add":
        $obj->add($json);
        break;
    case "update":
        $obj->update($json);
        break;
    case "delete":
        $obj->delete($json);
        break;
}
?>