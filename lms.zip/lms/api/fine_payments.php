<?php
// Money the library has received for overdue fines.
//
// Every row of fine_payment is one movement of money for ONE borrower:
//   kind 'return'  (+)  collected at the library desk when the book was returned (return_id says which return)
//   kind 'desk'    (+)  collected at the desk without a return (an advance payment, for a book still out)
//   kind 'proof'   (+)  recorded from the proof of payment the borrower sent (message_id says which one)
//   kind 'assessment' (0)  marker only: the fine of this return was above the desk limit and is paid at Assessment
//   kind 'applied' (-)  advance payment used up against the fine of a return (return_id)
//
// A borrower's "credit" is what they paid in advance and has not been used yet: desk + proof + applied.
// The money the library collected is desk + proof + return.

class FinePayments {

    static function peso($n) { return "₱" . number_format((float) $n, 2); }

    // Paid in advance and not used yet.
    static function credit($conn, $sid) {
        $q = $conn->prepare("SELECT IFNULL(SUM(amount), 0) FROM fine_payment WHERE student_id = :s AND kind IN ('desk', 'proof', 'applied')");
        $q->execute([":s" => $sid]);
        return max(0.0, round((float) $q->fetchColumn(), 2));
    }

    // Credit of every borrower who has some: student_id => amount.
    static function credits($conn) {
        $out = [];
        $rows = $conn->query("SELECT student_id, SUM(amount) AS c FROM fine_payment WHERE kind IN ('desk', 'proof', 'applied') GROUP BY student_id")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $r) if ((float) $r['c'] > 0) $out[(int) $r['student_id']] = round((float) $r['c'], 2);
        return $out;
    }

    static function add($conn, $sid, $amount, $kind, $by, $o = []) {
        $conn->prepare("INSERT INTO fine_payment (student_id, amount, kind, receipt_no, reference, return_id, message_id, note, received_by_user_id, paid_at)
                        VALUES (:s, :a, :k, :rn, :ref, :r, :m, :n, :u, NOW())")
             ->execute([":s" => $sid, ":a" => round($amount, 2), ":k" => $kind,
                        ":rn" => $o['receipt_no'] ?? null, ":ref" => $o['reference'] ?? null,
                        ":r" => $o['return_id'] ?? null, ":m" => $o['message_id'] ?? null,
                        ":n" => $o['note'] ?? null, ":u" => $by]);
        $id = (int) $conn->lastInsertId();

        // A payment taken at the desk or from a proof gets its own library receipt number unless one was typed in.
        if (empty($o['receipt_no']) && in_array($kind, ['desk', 'proof'], true)) {
            $conn->prepare("UPDATE fine_payment SET receipt_no = :rn WHERE payment_id = :id")
                 ->execute([":rn" => "FP-" . str_pad((string) $id, 6, "0", STR_PAD_LEFT), ":id" => $id]);
        }
        return $id;
    }

    // The fine of one return is paid: first from the borrower's advance payment, then in cash at the desk.
    // $creditLeft is the borrower's unused credit and is reduced by what was used. Returns [used from credit, cash].
    static function payReturnFine($conn, $sid, $returnId, $fine, $by, &$creditLeft) {
        $fine = round((float) $fine, 2);
        if ($fine <= 0) return [0.0, 0.0];

        $use = round(min($creditLeft, $fine), 2);
        $cash = round($fine - $use, 2);
        $receipt = "R-" . str_pad((string) $returnId, 6, "0", STR_PAD_LEFT);

        if ($use > 0) {
            self::add($conn, $sid, -$use, 'applied', $by, ["return_id" => $returnId, "receipt_no" => $receipt, "note" => "Advance payment used"]);
            $creditLeft = round($creditLeft - $use, 2);
        }
        if ($cash > 0) {
            self::add($conn, $sid, $cash, 'return', $by, ["return_id" => $returnId, "receipt_no" => $receipt]);
        }
        return [$use, $cash];
    }

    // A return was deleted: the advance payment it used is given back, and what was collected stays as credit.
    static function releaseReturn($conn, $returnId) {
        $conn->prepare("DELETE FROM fine_payment WHERE return_id = :r AND kind IN ('applied', 'assessment')")->execute([":r" => $returnId]);
        $conn->prepare("UPDATE fine_payment SET kind = 'desk', return_id = NULL, note = 'Collected on a return that was deleted' WHERE return_id = :r AND kind = 'return'")
             ->execute([":r" => $returnId]);
    }

    // The return date was edited and the fine went down: whatever was paid above the new fine becomes credit again.
    static function reconcileReturn($conn, $returnId, $newFine, $by) {
        $q = $conn->prepare("SELECT student_id, kind, SUM(amount) AS a FROM fine_payment WHERE return_id = :r GROUP BY student_id, kind");
        $q->execute([":r" => $returnId]);
        $cash = 0.0; $applied = 0.0; $sid = 0;
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $sid = (int) $r['student_id'];
            if ($r['kind'] === 'return') $cash += (float) $r['a'];
            if ($r['kind'] === 'applied') $applied += -(float) $r['a'];
        }
        $extra = round($cash + $applied - (float) $newFine, 2);
        if ($sid === 0 || $extra <= 0) return;

        $fromCash = round(min($extra, $cash), 2);
        if ($fromCash > 0) {
            $conn->prepare("UPDATE fine_payment SET amount = amount - :x WHERE return_id = :r AND kind = 'return'")->execute([":x" => $fromCash, ":r" => $returnId]);
            self::add($conn, $sid, $fromCash, 'desk', $by, ["note" => "Fine went down when the return was edited"]);
        }
        $fromApplied = round($extra - $fromCash, 2);
        if ($fromApplied > 0) {
            $conn->prepare("UPDATE fine_payment SET amount = amount + :x WHERE return_id = :r AND kind = 'applied'")->execute([":x" => $fromApplied, ":r" => $returnId]);
        }
    }

    // Money collected: today, this month, all time.
    static function totals($conn) {
        $r = $conn->query("SELECT IFNULL(SUM(amount), 0) AS total,
                                  IFNULL(SUM(CASE WHEN DATE(paid_at) = CURDATE() THEN amount ELSE 0 END), 0) AS today,
                                  IFNULL(SUM(CASE WHEN YEAR(paid_at) = YEAR(CURDATE()) AND MONTH(paid_at) = MONTH(CURDATE()) THEN amount ELSE 0 END), 0) AS month
                           FROM fine_payment WHERE kind IN ('desk', 'proof', 'return')")->fetch(PDO::FETCH_ASSOC);
        return ["today" => round((float) $r['today'], 2), "month" => round((float) $r['month'], 2), "total" => round((float) $r['total'], 2)];
    }
}
