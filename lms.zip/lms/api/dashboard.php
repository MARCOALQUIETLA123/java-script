<?php

header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
require_once __DIR__ . "/account_standing.php";
Auth::guard(basename(__FILE__, '.php'));

// Everything the dashboard shows comes from one call: operation=getCounts (the name is kept so the
// Staff permission list in config/auth.php doesn't need to change). Optional ?days=7..90 sets the
// window used by the trend, "most borrowed" and "by category" sections.
class Dashboard {

    // Runs one section on its own. If it fails (for example a table or column that doesn't exist in
    // this database) that section is null and is named in "errors", and the rest still loads.
    private function section(&$out, &$errors, $name, $fn) {
        try {
            $out[$name] = $fn();
        } catch (Throwable $e) {
            $out[$name] = null;
            $errors[] = $name;
            error_log("dashboard section '$name' failed: " . $e->getMessage());
        }
    }

    function getCounts() {
        include "../config/connection-pdo.php";

        // Blacklists anyone overdue for too long and sends today's reminders (no scheduled job needed).
        try { AccountStanding::sweep($conn); } catch (Throwable $e) { error_log("standing sweep failed: " . $e->getMessage()); }

        $days = isset($_GET['days']) ? (int) $_GET['days'] : 14;
        $days = max(7, min(90, $days));
        $back = $days - 1; // the window includes today

        $out = [];
        $errors = [];

        $out['today'] = $conn->query("SELECT CURDATE()")->fetchColumn();
        $out['now']   = $conn->query("SELECT DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s')")->fetchColumn();
        $out['days']  = $days;

        // Books out right now, how many fall due soon, and how many are late.
        $this->section($out, $errors, 'loans', function () use ($conn) {
            $row = $conn->query("
                SELECT COUNT(*) AS borrowed_now,
                       SUM(CASE WHEN due < CURDATE() THEN 1 ELSE 0 END) AS overdue,
                       SUM(CASE WHEN due >= CURDATE() AND due <= DATE_ADD(CURDATE(), INTERVAL 3 DAY) THEN 1 ELSE 0 END) AS due_soon,
                       MAX(CASE WHEN due < CURDATE() THEN DATEDIFF(CURDATE(), due) END) AS oldest_overdue
                FROM (
                    SELECT COALESCE(bi.due_date, bt.due_date) AS due
                    FROM borrow_items bi
                    INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                    WHERE bi.is_returned IS NULL OR bi.is_returned = 0
                ) x
            ")->fetch(PDO::FETCH_ASSOC);

            return [
                "borrowed_now"   => (int) $row['borrowed_now'],
                "overdue"        => (int) $row['overdue'],
                "due_soon"       => (int) $row['due_soon'],
                "oldest_overdue" => $row['oldest_overdue'] === null ? null : (int) $row['oldest_overdue'],
            ];
        });

        // Shelf: totals and the status of every copy.
        $this->section($out, $errors, 'copies', function () use ($conn) {
            $rows = $conn->query("
                SELECT COALESCE(s.status_desc, 'Unknown') AS label, COUNT(*) AS c
                FROM book_copies bc
                LEFT JOIN status s ON bc.status_id = s.status_id
                GROUP BY COALESCE(s.status_desc, 'Unknown')
                ORDER BY c DESC, label ASC
            ")->fetchAll(PDO::FETCH_ASSOC);

            $mix = [];
            $total = 0;
            $available = 0;
            foreach ($rows as $r) {
                $mix[] = ["label" => $r['label'], "count" => (int) $r['c']];
                $total += (int) $r['c'];
                if (strtolower($r['label']) === 'available') $available = (int) $r['c'];
            }

            return [
                "total"     => $total,
                "available" => $available,
                "titles"    => (int) $conn->query("SELECT COUNT(*) FROM book")->fetchColumn(),
                "status"    => $mix,
            ];
        });

        // Reservations that are still alive (not picked up, cancelled or expired).
        $this->section($out, $errors, 'reservations', function () use ($conn) {
            $row = $conn->query("
                SELECT SUM(CASE WHEN status = 'Ready' THEN 1 ELSE 0 END) AS ready,
                       SUM(CASE WHEN status = 'Waiting' THEN 1 ELSE 0 END) AS waiting,
                       SUM(CASE WHEN status IN ('Ready', 'Waiting') AND expires_on <= DATE_ADD(CURDATE(), INTERVAL 1 DAY) THEN 1 ELSE 0 END) AS expiring,
                       SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) AS pending
                FROM reservation
                WHERE status IN ('Pending', 'Ready', 'Waiting') AND expires_on >= CURDATE()
            ")->fetch(PDO::FETCH_ASSOC);

            return [
                "ready"    => (int) $row['ready'],
                "waiting"  => (int) $row['waiting'],
                "expiring" => (int) $row['expiring'],
                "pending"  => (int) $row['pending'],   // student requests waiting for approval
            ];
        });

        // Books borrowed and returned per day. Days with no activity are filled in by the page.
        $this->section($out, $errors, 'trend', function () use ($conn, $back) {
            $borrowed = [];
            $stmt = $conn->query("
                SELECT DATE(bt.borrow_date) AS d, COUNT(*) AS c
                FROM borrow_items bi
                INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                WHERE DATE(bt.borrow_date) >= DATE_SUB(CURDATE(), INTERVAL $back DAY)
                GROUP BY DATE(bt.borrow_date)
            ");
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) $borrowed[$r['d']] = (int) $r['c'];

            $returned = [];
            $stmt = $conn->query("
                SELECT DATE(br.return_date) AS d, COUNT(*) AS c
                FROM book_return br
                WHERE DATE(br.return_date) >= DATE_SUB(CURDATE(), INTERVAL $back DAY)
                GROUP BY DATE(br.return_date)
            ");
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) $returned[$r['d']] = (int) $r['c'];

            return ["borrowed" => (object) $borrowed, "returned" => (object) $returned];
        });

        $this->section($out, $errors, 'top_titles', function () use ($conn, $back) {
            $rows = $conn->query("
                SELECT b.title AS label, COUNT(*) AS c
                FROM borrow_items bi
                INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                INNER JOIN book_copies bc ON bi.copy_id = bc.copy_id
                INNER JOIN book b ON bc.book_id = b.book_id
                WHERE DATE(bt.borrow_date) >= DATE_SUB(CURDATE(), INTERVAL $back DAY)
                GROUP BY b.book_id, b.title
                ORDER BY c DESC, b.title ASC
                LIMIT 5
            ")->fetchAll(PDO::FETCH_ASSOC);

            return array_map(function ($r) { return ["label" => $r['label'], "count" => (int) $r['c']]; }, $rows);
        });

        $this->section($out, $errors, 'categories', function () use ($conn, $back) {
            $rows = $conn->query("
                SELECT COALESCE(c.category_type, 'Uncategorized') AS label, COUNT(*) AS n
                FROM borrow_items bi
                INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                INNER JOIN book_copies bc ON bi.copy_id = bc.copy_id
                INNER JOIN book b ON bc.book_id = b.book_id
                LEFT JOIN categories c ON b.category_id = c.category_id
                WHERE DATE(bt.borrow_date) >= DATE_SUB(CURDATE(), INTERVAL $back DAY)
                GROUP BY COALESCE(c.category_type, 'Uncategorized')
                ORDER BY n DESC, label ASC
                LIMIT 6
            ")->fetchAll(PDO::FETCH_ASSOC);

            return array_map(function ($r) { return ["label" => $r['label'], "count" => (int) $r['n']]; }, $rows);
        });

        // Unreturned books that are late or due within 3 days, most urgent first.
        $this->section($out, $errors, 'attention', function () use ($conn) {
            $rows = $conn->query("
                SELECT CONCAT_WS(' ', s.first_name, s.last_name) AS borrower,
                       b.title, bc.accession_number,
                       COALESCE(bi.due_date, bt.due_date) AS due_date,
                       DATEDIFF(CURDATE(), COALESCE(bi.due_date, bt.due_date)) AS days_late
                FROM borrow_items bi
                INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                LEFT JOIN student s ON bt.student_id = s.student_id
                LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                LEFT JOIN book b ON bc.book_id = b.book_id
                WHERE (bi.is_returned IS NULL OR bi.is_returned = 0)
                  AND COALESCE(bi.due_date, bt.due_date) <= DATE_ADD(CURDATE(), INTERVAL 3 DAY)
                ORDER BY COALESCE(bi.due_date, bt.due_date) ASC, bi.item_id ASC
                LIMIT 6
            ")->fetchAll(PDO::FETCH_ASSOC);

            return array_map(function ($r) {
                $r['days_late'] = (int) $r['days_late'];
                return $r;
            }, $rows);
        });

        // Latest borrows, returns and reservations, newest first.
        $this->section($out, $errors, 'activity', function () use ($conn) {
            $borrows = $conn->query("
                SELECT 'borrow' AS type, bt.created_at AS ts,
                       CONCAT_WS(' ', s.first_name, s.last_name) AS who,
                       MIN(b.title) AS title, COUNT(bi.item_id) AS n,
                       CONCAT_WS(' ', u.first_name, u.last_name) AS by_user
                FROM borrow_transaction bt
                LEFT JOIN borrow_items bi ON bi.transaction_id = bt.transaction_id
                LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                LEFT JOIN book b ON bc.book_id = b.book_id
                LEFT JOIN student s ON bt.student_id = s.student_id
                LEFT JOIN users u ON bt.processed_by_user_id = u.user_id
                GROUP BY bt.transaction_id, bt.created_at, s.first_name, s.last_name, u.first_name, u.last_name
                ORDER BY bt.created_at DESC, bt.transaction_id DESC
                LIMIT 6
            ")->fetchAll(PDO::FETCH_ASSOC);

            $returns = $conn->query("
                SELECT 'return' AS type, br.return_date AS ts,
                       CONCAT_WS(' ', s.first_name, s.last_name) AS who,
                       b.title AS title, 1 AS n,
                       CONCAT_WS(' ', u.first_name, u.last_name) AS by_user
                FROM book_return br
                LEFT JOIN borrow_items bi ON br.item_id = bi.item_id
                LEFT JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                LEFT JOIN student s ON bt.student_id = s.student_id
                LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                LEFT JOIN book b ON bc.book_id = b.book_id
                LEFT JOIN users u ON br.processed_by_user_id = u.user_id
                ORDER BY br.return_date DESC, br.return_id DESC
                LIMIT 6
            ")->fetchAll(PDO::FETCH_ASSOC);

            $reserves = [];
            try {
                $reserves = $conn->query("
                    SELECT 'reserve' AS type, r.reserved_at AS ts,
                           CONCAT_WS(' ', s.first_name, s.last_name) AS who,
                           b.title AS title, 1 AS n,
                           CONCAT_WS(' ', u.first_name, u.last_name) AS by_user
                    FROM reservation r
                    LEFT JOIN student s ON r.student_id = s.student_id
                    LEFT JOIN book b ON r.book_id = b.book_id
                    LEFT JOIN users u ON r.processed_by_user_id = u.user_id
                    ORDER BY r.reserved_at DESC, r.reservation_id DESC
                    LIMIT 6
                ")->fetchAll(PDO::FETCH_ASSOC);
            } catch (Throwable $e) {
                // reservations are optional: show borrows and returns without them
            }

            $feed = array_merge($borrows, $returns, $reserves);
            usort($feed, function ($a, $b) { return strcmp((string) $b['ts'], (string) $a['ts']); });

            return array_map(function ($r) {
                $r['n'] = (int) $r['n'];
                return $r;
            }, array_slice($feed, 0, 8));
        });

        // Borrowers with an overdue book and blacklisted ones, for the dashboard banner.
        $this->section($out, $errors, 'accounts', function () use ($conn) {
            $hold = (int) $conn->query("SELECT COUNT(DISTINCT bt.student_id)
                                        FROM borrow_items bi
                                        INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                                        INNER JOIN student s ON s.student_id = bt.student_id
                                        LEFT JOIN book_return br ON br.item_id = bi.item_id
                                        WHERE br.return_id IS NULL AND (bi.is_returned IS NULL OR bi.is_returned = 0)
                                          AND COALESCE(bi.due_date, bt.due_date) < CURDATE() AND s.blacklisted_at IS NULL")->fetchColumn();
            $black = (int) $conn->query("SELECT COUNT(*) FROM student WHERE blacklisted_at IS NOT NULL")->fetchColumn();
            $proofs = 0;
            try {
                $proofs = (int) $conn->query("SELECT COUNT(*) FROM student_message WHERE from_borrower = 1 AND attachment_path IS NOT NULL AND read_at IS NULL")->fetchColumn();
            } catch (Throwable $e) { /* column not created yet */ }
            return ["overdue" => $hold, "blacklisted" => $black, "proofs" => $proofs];
        });

        $out['errors'] = $errors;
        echo json_encode($out);
    }
}

$operation = $_GET['operation'] ?? $_POST['operation'] ?? '';

$obj = new Dashboard();

switch ($operation) {
    case "getCounts":
        $obj->getCounts();
        break;
}

?>