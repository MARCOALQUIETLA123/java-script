<?php
// Central place for all borrowing rules.
//
// The rules are stored in the loan_settings table and are edited on the "Loan Rules" page by the
// Technical Services Librarian. The DEFAULTS below are only used to fill in a rule that has never been saved.

date_default_timezone_set('Asia/Manila');

class LoanRules {
    // 'key' => [number, unit]. The books-at-a-time limits and the semester length have no unit.
    const DEFAULTS = [
        'student_educational' => [3, 'day'],
        'student_fictional'   => [7, 'day'],
        'student_other'       => [7, 'day'],      // book type could not be determined
        'faculty_educational' => [7, 'day'],
        'faculty_fictional'   => [1, 'semester'],
        'faculty_other'       => [1, 'semester'],
        'faculty_max'         => [1, 'semester'], // longest a faculty loan can ever run
        'student_limit'       => [3, null],       // books at a time
        'faculty_limit'       => [10, null],
        'semester_months'     => [3, null],       // how long "1 semester" is
        'fine_per_day'        => [5, null],       // pesos per overdue day, for every book
        'processing_fee'      => [100, null],      // pesos added when a lost/damaged book is paid for in cash
        'blacklist_after_days'=> [30, null],      // days a book may stay overdue before the account is blacklisted
    ];

    const UNITS = ['day', 'week', 'month', 'semester'];

    private static $cache = null;

    // Creates the table on first use and fills in any rule that is missing.
    static function ensureTable($conn) {
        // CREATE TABLE commits any open transaction, even when the table already exists, so only run it when it is missing.
        // (config/connection-pdo.php creates the table at connection time, before any transaction starts.)
        $exists = $conn->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'loan_settings'")->fetchColumn();
        if ((int) $exists > 0) return;

        $conn->exec("CREATE TABLE IF NOT EXISTS loan_settings (
                        setting_key VARCHAR(50) NOT NULL PRIMARY KEY,
                        setting_value INT NOT NULL,
                        setting_unit VARCHAR(10) DEFAULT NULL,
                        updated_by_user_id INT DEFAULT NULL,
                        updated_at DATETIME DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }

    // Every rule as ['key' => ['value' => n, 'unit' => 'day'|null]]. Read once per request.
    static function all($conn) {
        if (self::$cache !== null) return self::$cache;

        self::ensureTable($conn);
        // The processing fee is 100 pesos. If nobody ever edited it and it was moved to 1000, put it back to 100.
        $conn->exec("UPDATE loan_settings SET setting_value = 100
                     WHERE setting_key = 'processing_fee' AND setting_value = 1000 AND updated_by_user_id IS NULL");

        $rows = $conn->query("SELECT setting_key, setting_value, setting_unit FROM loan_settings")->fetchAll(PDO::FETCH_ASSOC);

        $have = [];
        foreach ($rows as $r) $have[$r['setting_key']] = $r;

        $out = [];
        $missing = $conn->prepare("INSERT IGNORE INTO loan_settings (setting_key, setting_value, setting_unit) VALUES (:k, :v, :u)");
        foreach (self::DEFAULTS as $key => $def) {
            if (isset($have[$key])) {
                $out[$key] = ['value' => (int) $have[$key]['setting_value'], 'unit' => $have[$key]['setting_unit']];
            } else {
                $missing->execute([':k' => $key, ':v' => $def[0], ':u' => $def[1]]);
                $out[$key] = ['value' => $def[0], 'unit' => $def[1]];
            }
        }

        return self::$cache = $out;
    }

    // Forget what was read, e.g. right after the rules were saved.
    static function reset() { self::$cache = null; }

    static function semesterMonths($conn) {
        return max(1, self::all($conn)['semester_months']['value']);
    }

    // Books a borrower may have out at once.
    static function limit($conn, $faculty) {
        $rules = self::all($conn);
        return (int) $rules[$faculty ? 'faculty_limit' : 'student_limit']['value'];
    }

    // PHP date modifier for a period, e.g. '+3 days' or (1 semester of 3 months) '+3 months'.
    static function modifier($value, $unit, $semesterMonths) {
        $value = (int) $value;
        switch ($unit) {
            case 'week':     return "+$value weeks";
            case 'month':    return "+$value months";
            case 'semester': return '+' . ($value * $semesterMonths) . ' months';
            default:         return "+$value days";
        }
    }

    // "3 days", "2 weeks", "1 semester".
    static function label($value, $unit) {
        $value = (int) $value;
        $unit = in_array($unit, self::UNITS, true) ? $unit : 'day';
        return $value . ' ' . $unit . ($value === 1 ? '' : 's');
    }

    // Roughly how many days a period is. Used only to sanity-check what is typed on the Loan Rules page.
    static function approxDays($value, $unit, $semesterMonths) {
        $perUnit = ['day' => 1, 'week' => 7, 'month' => 30, 'semester' => 30 * $semesterMonths];
        return (int) $value * ($perUnit[$unit] ?? 1);
    }

    // A borrower is faculty when their student record is linked to a user
    // whose role name contains "faculty".
    static function isFaculty($conn, $student_id) {
        $stmt = $conn->prepare("
            SELECT r.role_name
            FROM student s
            INNER JOIN users u ON s.user_id = u.user_id
            INNER JOIN roles r ON u.role_id = r.role_id
            WHERE s.student_id = :student_id
            LIMIT 1
        ");
        $stmt->bindParam(":student_id", $student_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row && (stripos($row['role_name'], 'faculty') !== false || stripos($row['role_name'], 'dean') !== false);
    }

    // Books borrowed by this student that have not been returned yet.
    static function activeCount($conn, $student_id) {
        $stmt = $conn->prepare("
            SELECT COUNT(*)
            FROM borrow_items bi
            INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
            WHERE bt.student_id = :student_id
            AND (bi.is_returned IS NULL OR bi.is_returned = 0)
        ");
        $stmt->bindParam(":student_id", $student_id);
        $stmt->execute();
        return (int) $stmt->fetchColumn();
    }

    // 'educational', 'fictional' or null. Book type wins; the category name is a fallback
    // for older books that have no type yet.
    static function bookKind($bookType, $categoryType) {
        $t = strtolower((string) $bookType);
        if ($t === 'educational' || $t === 'fictional') {
            return $t;
        }

        $c = strtolower((string) $categoryType);
        if (strpos($c, 'educ') !== false) {
            return 'educational';
        }
        // "fiction" / "fictional", but not "non-fiction"
        if (strpos($c, 'fic') !== false && !preg_match('/non[\s-]?fic/', $c)) {
            return 'fictional';
        }
        return null;
    }

    // Due date + readable label for one book.
    static function periodFor($conn, $faculty, $kind, $borrow_date) {
        $rules = self::all($conn);
        $sem = self::semesterMonths($conn);
        $start = new DateTime($borrow_date);

        $key = ($faculty ? 'faculty_' : 'student_') . ($kind === 'educational' ? 'educational' : ($kind === 'fictional' ? 'fictional' : 'other'));
        $rule = $rules[$key];

        $due = (clone $start)->modify(self::modifier($rule['value'], $rule['unit'], $sem));

        // Faculty loans can never run past the longest possible loan.
        if ($faculty) {
            $cap = $rules['faculty_max'];
            $max = (clone $start)->modify(self::modifier($cap['value'], $cap['unit'], $sem));
            if ($due > $max) $due = $max;
        }

        return [$due->format('Y-m-d'), self::label($rule['value'], $rule['unit'])];
    }

    // Copy IDs of every book already on a transaction (used when editing one).
    static function copyIdsForTransaction($conn, $transaction_id) {
        $stmt = $conn->prepare("SELECT copy_id FROM borrow_items WHERE transaction_id = :transaction_id");
        $stmt->bindParam(":transaction_id", $transaction_id);
        $stmt->execute();
        return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    // Builds the full borrowing plan for a borrower and a list of copy IDs.
    // $student_id may be null for a faculty member who has no student record yet;
    // in that case pass $faculty_override = true.
    static function plan($conn, $student_id, $copy_ids, $borrow_date = null, $faculty_override = null) {
        // A blacklisted borrower can't start new loans. (A borrower who is only overdue can: the fine just piles up.)
        require_once __DIR__ . "/account_standing.php";
        $hold = $student_id === null ? null : AccountStanding::guard($conn, (int) $student_id);

        $borrow_date = $borrow_date ?: date('Y-m-d');

        $faculty = $faculty_override !== null ? (bool) $faculty_override : self::isFaculty($conn, $student_id);
        $limit = self::limit($conn, $faculty);
        $active = $student_id === null ? 0 : self::activeCount($conn, $student_id);

        $books = [];
        if (count($copy_ids) > 0) {
            $in = implode(',', array_fill(0, count($copy_ids), '?'));
            $stmt = $conn->prepare("
                SELECT bc.copy_id, b.title, b.book_type, c.category_type
                FROM book_copies bc
                INNER JOIN book b ON bc.book_id = b.book_id
                LEFT JOIN categories c ON b.category_id = c.category_id
                WHERE bc.copy_id IN ($in)
            ");
            $stmt->execute(array_values($copy_ids));

            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $kind = self::bookKind($row['book_type'], $row['category_type']);
                list($due, $label) = self::periodFor($conn, $faculty, $kind, $borrow_date);

                $books[] = [
                    "copy_id" => (int) $row['copy_id'],
                    "title" => $row['title'],
                    "book_type" => $row['book_type'],
                    "due_date" => $due,
                    "period" => $label
                ];
            }
        }

        // One due date per transaction: the earliest (strictest) book decides.
        $due_date = null;
        $period_label = null;
        foreach ($books as $b) {
            if ($due_date === null || $b['due_date'] < $due_date) {
                $due_date = $b['due_date'];
                $period_label = $b['period'];
            }
        }

        return [
            "borrower_type" => $faculty ? "Faculty" : "Student",
            "limit" => $limit,
            "active" => $active,
            "remaining" => max(0, $limit - $active),
            "selected" => count($copy_ids),
            "borrow_date" => $borrow_date,
            "due_date" => $due_date,
            "period_label" => $period_label,
            "hold" => $hold,
            "books" => $books
        ];
    }
}