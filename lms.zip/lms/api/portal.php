<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));   // borrowers may only call the operations in Auth::BORROWER_OPS
require_once __DIR__ . "/loan_rules.php";
require_once __DIR__ . "/account_standing.php";
require_once __DIR__ . "/book_versions.php";

// Self-service for Students, Faculty and Deans. Everything is scoped to the borrower record linked to the
// signed-in account (never taken from the request) and the same LoanRules as the staff pages apply.
// There is deliberately no return operation: books are returned at the desk by staff.
// Students can only RESERVE. A reservation is a request: the Technical Services Librarian or Library Staff approve it
// (reservation.php), and the book is recorded as borrowed only when staff check it out at the desk.
class Portal {
    const MAX_HOLD_DAYS = 14;

    private function out($status, $message, $extra = []) {
        echo json_encode(array_merge(["status" => $status, "message" => $message], $extra));
    }

    private function sid() {
        $u = Auth::current();
        return $u && !empty($u['student_id']) ? (int) $u['student_id'] : null;
    }

    private function noRecord() {
        http_response_code(403);
        $this->out("error", "No borrower record is linked to this account. Ask the library to check your account.");
    }

    private function statusId($conn, $desc) {
        $s = $conn->prepare("SELECT status_id FROM status WHERE status_desc = :d LIMIT 1");
        $s->execute([":d" => $desc]);
        $id = $s->fetchColumn();
        return $id ? (int) $id : null;
    }

    private function validDate($v) {
        return is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) && strtotime($v) !== false;
    }

    // Loan period (label + due date if borrowed today) for this borrower and book.
    private function period($conn, $faculty, $book_id) {
        $s = $conn->prepare("SELECT b.book_type, c.category_type FROM book b
                             LEFT JOIN categories c ON b.category_id = c.category_id WHERE b.book_id = :b");
        $s->execute([":b" => $book_id]);
        $r = $s->fetch(PDO::FETCH_ASSOC) ?: ['book_type' => null, 'category_type' => null];
        return LoanRules::periodFor($conn, $faculty, LoanRules::bookKind($r['book_type'], $r['category_type']), date('Y-m-d'));
    }

    private function reservedCount($conn, $sid, $exceptBook = null) {
        $sql = "SELECT COUNT(*) FROM reservation WHERE student_id = :s AND status IN ('Pending', 'Waiting', 'Ready')";
        $args = [":s" => $sid];
        if ($exceptBook !== null) { $sql .= " AND book_id != :b"; $args[":b"] = $exceptBook; }
        $s = $conn->prepare($sql);
        $s->execute($args);
        return (int) $s->fetchColumn();
    }

    function getBooks() {
        include "../config/connection-pdo.php";
        $sid = $this->sid();
        if (!$sid) { $this->noRecord(); return; }

        $faculty = LoanRules::isFaculty($conn, $sid);
        $today = date('Y-m-d');

        $rows = $conn->query("
            SELECT b.book_id, b.title, b.book_type, b.published_year, c.category_type, p.publisher_name,
                   (SELECT GROUP_CONCAT(CONCAT(a.first_name, ' ', a.last_name) ORDER BY a.first_name SEPARATOR ', ')
                    FROM book_author ba INNER JOIN author a ON ba.author_id = a.author_id
                    WHERE ba.book_id = b.book_id) AS authors,
                   SUM(CASE WHEN bc.copy_id IS NOT NULL AND bc.archived_at IS NULL AND s.status_desc <> 'Library Use Only' THEN 1 ELSE 0 END) AS total_copies,
                   SUM(CASE WHEN bc.archived_at IS NULL AND s.status_desc = 'Library Use Only' THEN 1 ELSE 0 END) AS library_only,
                   SUM(CASE WHEN s.status_desc = 'Available' THEN 1 ELSE 0 END) AS available
            FROM book b
            LEFT JOIN categories c ON b.category_id = c.category_id
            LEFT JOIN publisher p ON b.publisher_id = p.publisher_id
            LEFT JOIN book_copies bc ON bc.book_id = b.book_id
            LEFT JOIN status s ON bc.status_id = s.status_id
            GROUP BY b.book_id, b.title, b.book_type, b.published_year, c.category_type, p.publisher_name
            ORDER BY b.title ASC")->fetchAll(PDO::FETCH_ASSOC);

        $res = $conn->prepare("SELECT book_id, status FROM reservation WHERE student_id = :s AND status IN ('Pending', 'Waiting', 'Ready')");
        $res->execute([":s" => $sid]);
        $myRes = [];
        foreach ($res->fetchAll(PDO::FETCH_ASSOC) as $r) $myRes[(int) $r['book_id']] = $r['status'];

        $loan = $conn->prepare("SELECT DISTINCT bc.book_id FROM borrow_items bi
                                INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                                INNER JOIN book_copies bc ON bi.copy_id = bc.copy_id
                                WHERE bt.student_id = :s AND (bi.is_returned IS NULL OR bi.is_returned = 0)");
        $loan->execute([":s" => $sid]);
        $myLoans = array_flip(array_map('intval', $loan->fetchAll(PDO::FETCH_COLUMN)));

        foreach ($rows as &$r) {
            $id = (int) $r['book_id'];
            list($due, $label) = LoanRules::periodFor($conn, $faculty, LoanRules::bookKind($r['book_type'], $r['category_type']), $today);
            $r['total_copies'] = (int) $r['total_copies'];     // copies that can be borrowed (not library use only)
            $r['library_only'] = (int) $r['library_only'];
            $r['available'] = (int) $r['available'];
            $r['period'] = $label;
            $r['due_if_borrowed'] = $due;
            $r['my_reservation'] = $myRes[$id] ?? null;
            $r['i_have'] = isset($myLoans[$id]);
        }

        echo json_encode($rows);
    }

    function getMyLoans() {
        include "../config/connection-pdo.php";
        $sid = $this->sid();
        if (!$sid) { $this->noRecord(); return; }

        // Today's reminder (once a day) and the blacklist check happen when the borrower opens their account.
        $standing = AccountStanding::evaluate($conn, $sid);
        AccountStanding::dailyReminder($conn, $sid, $standing);
        $unread = $conn->prepare("SELECT COUNT(*) FROM student_message WHERE student_id = :s AND read_at IS NULL AND from_borrower = 0");
        $unread->execute([":s" => $sid]);

        $stmt = $conn->prepare("
            SELECT bi.item_id, b.title, bc.accession_number, bt.borrow_date,
                   COALESCE(bi.due_date, bt.due_date) AS due_date, br.return_date,
                   CASE WHEN br.return_id IS NOT NULL OR bi.is_returned = 1 THEN 'Returned'
                        WHEN COALESCE(bi.due_date, bt.due_date) < CURDATE() THEN 'Overdue'
                        ELSE 'Borrowed' END AS status,
                   DATEDIFF(COALESCE(bi.due_date, bt.due_date), CURDATE()) AS days_left
            FROM borrow_items bi
            INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
            LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
            LEFT JOIN book b ON bc.book_id = b.book_id
            LEFT JOIN book_return br ON br.item_id = bi.item_id
            WHERE bt.student_id = :s
            ORDER BY (br.return_id IS NOT NULL OR bi.is_returned = 1), due_date ASC, bi.item_id DESC");
        $stmt->execute([":s" => $sid]);
        $loans = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($loans as &$l) $l['days_left'] = (int) $l['days_left'];

        // Lost or damaged books that are not settled yet: they block the borrower's clearance.
        $cases = $conn->prepare("
            SELECT br.return_id, br.condition_on_return, br.return_date, br.book_price, br.processing_fee, br.receipt_no,
                   COALESCE(br.case_status, 'Settled') AS case_status, b.book_id, b.title
            FROM book_return br
            INNER JOIN borrow_items bi ON br.item_id = bi.item_id
            INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
            LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
            LEFT JOIN book b ON bc.book_id = b.book_id
            WHERE bt.student_id = :s AND br.condition_on_return IN ('Lost', 'Damaged')
              AND COALESCE(br.case_status, 'Settled') IN ('Pending', 'Awaiting payment', 'Awaiting replacement')
            ORDER BY br.return_date DESC, br.return_id DESC");
        $cases->execute([":s" => $sid]);
        $clearance = $cases->fetchAll(PDO::FETCH_ASSOC);
        foreach ($clearance as &$c) {
            $c['replacement'] = null;
            $newest = $c['book_id'] ? BookVersions::newest($conn, (int) $c['book_id']) : null;
            if ($newest) {
                $c['replacement'] = [
                    "title" => $newest['title'],
                    "year" => $newest['published_year'],
                    "authors" => BookVersions::authorNames($conn, (int) $newest['book_id'])
                ];
            }
            unset($c['book_id']);
        }
        unset($c);

        $faculty = LoanRules::isFaculty($conn, $sid);
        echo json_encode([
            "clearance" => $clearance,
            "summary" => [
                "borrower_type" => $faculty ? "Faculty" : "Student",
                "limit"    => LoanRules::limit($conn, $faculty),
                "active"   => LoanRules::activeCount($conn, $sid),
                "reserved" => $this->reservedCount($conn, $sid),
                "fine_per_day" => (int) LoanRules::all($conn)['fine_per_day']['value'],
                "processing_fee" => (int) LoanRules::all($conn)['processing_fee']['value'],
            ],
            "loans" => $loans,
            "standing" => [
                "state"          => $standing['state'],
                "message"        => AccountStanding::holdMessage($standing),
                "overdue"        => $standing['overdue'],
                "fine_total"     => $standing['fine_total'],
                "credit"         => $standing['credit'],
                "fine_due"       => $standing['fine_due'],
                "fine_per_day"   => $standing['fine_per_day'],
                "days_until_blacklist" => $standing['days_until_blacklist'],
                "blacklist_after" => $standing['blacklist_after'],
                "blacklist_reason" => $standing['blacklist_reason'],
            ],
            "unread_messages" => (int) $unread->fetchColumn(),
        ]);
    }

    // The borrower's inbox, newest first. Unread messages are marked read when the borrower opens them.
    function getMessages() {
        include "../config/connection-pdo.php";
        $sid = $this->sid();
        if (!$sid) { $this->noRecord(); return; }

        $stmt = $conn->prepare("SELECT m.message_id, m.kind, m.subject, m.body, m.created_at, m.read_at, m.from_borrower,
                                       (m.attachment_path IS NOT NULL) AS has_file, m.attachment_name, m.attachment_mime,
                                       CASE WHEN m.from_borrower = 1 THEN 'You'
                                            WHEN m.sender_user_id IS NULL THEN 'Library system'
                                            ELSE CONCAT_WS(' ', u.first_name, u.last_name) END AS sender
                                FROM student_message m
                                LEFT JOIN users u ON m.sender_user_id = u.user_id
                                WHERE m.student_id = :s
                                ORDER BY m.created_at DESC, m.message_id DESC
                                LIMIT 100");
        $stmt->execute([":s" => $sid]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    function markRead($json) {
        include "../config/connection-pdo.php";
        $sid = $this->sid();
        if (!$sid) { $this->noRecord(); return; }

        $conn->prepare("UPDATE student_message SET read_at = NOW() WHERE student_id = :s AND read_at IS NULL AND from_borrower = 0")
             ->execute([":s" => $sid]);
        $this->out("success", "Marked as read.");
    }

    // A borrower sends proof that they paid a fine (a photo or PDF of the receipt) so the librarian can check it and
    // lift the blacklist sooner. It lands in the same message thread the library uses, as a message FROM the borrower.
    // The file is stored in uploads/proofs (closed to the web) and only opened through api/proof_file.php.
    const MAX_PROOF_BYTES = 5242880;   // 5 MB
    const MAX_PROOFS_PER_DAY = 5;

    function sendProof() {
        include "../config/connection-pdo.php";
        $sid = $this->sid();
        if (!$sid) { $this->noRecord(); return; }

        // PHP drops the whole request when it is bigger than post_max_size, so nothing arrives at all.
        if (empty($_FILES) && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
            $this->out("error", "That file is too big for this server. Send a smaller photo (under 2 MB) or a screenshot.");
            return;
        }

        $f = $_FILES['proof'] ?? null;
        if (!$f || $f['error'] === UPLOAD_ERR_NO_FILE) { $this->out("error", "Attach a photo or PDF of your receipt."); return; }
        if ($f['error'] === UPLOAD_ERR_INI_SIZE || $f['error'] === UPLOAD_ERR_FORM_SIZE || $f['size'] > self::MAX_PROOF_BYTES) {
            $this->out("error", "That file is too big. Send a smaller photo (under 2 MB) or a screenshot.");
            return;
        }
        if ($f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) { $this->out("error", "The upload failed. Please try again."); return; }

        // Judge the file by what it really is, not by the name or type the browser claims.
        $types = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'application/pdf' => 'pdf'];
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
        if (!isset($types[$mime])) { $this->out("error", "Only a photo (JPG, PNG, WEBP) or a PDF can be sent."); return; }
        if ($mime !== 'application/pdf' && @getimagesize($f['tmp_name']) === false) { $this->out("error", "That image can't be read. Try another photo."); return; }

        $amount = trim((string) ($_POST['amount'] ?? ''));
        $ref    = trim((string) ($_POST['reference'] ?? ''));
        $note   = trim((string) ($_POST['note'] ?? ''));

        if (!is_numeric($amount) || (float) $amount <= 0 || (float) $amount > 1000000) { $this->out("error", "Enter the amount you paid."); return; }
        if (strlen($ref) > 60)   { $this->out("error", "The receipt or reference number can be at most 60 characters."); return; }
        if (strlen($note) > 500) { $this->out("error", "Your note can be at most 500 characters."); return; }

        $recent = $conn->prepare("SELECT COUNT(*) FROM student_message WHERE student_id = :s AND from_borrower = 1
                                  AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)");
        $recent->execute([":s" => $sid]);
        if ((int) $recent->fetchColumn() >= self::MAX_PROOFS_PER_DAY) {
            $this->out("error", "You have already sent " . self::MAX_PROOFS_PER_DAY . " proofs today. Please wait for the librarian to check them.");
            return;
        }

        $dir = __DIR__ . "/../uploads/proofs";
        if (!is_dir($dir) && !@mkdir($dir, 0775, true)) { $this->out("error", "The server can't store files right now. Please tell the library."); return; }
        if (!is_file("$dir/.htaccess")) {
            @file_put_contents("$dir/.htaccess", "<IfModule mod_authz_core.c>
    Require all denied
</IfModule>
<IfModule !mod_authz_core.c>
    Order allow,deny
    Deny from all
</IfModule>
");
        }

        $stored = bin2hex(random_bytes(16)) . "." . $types[$mime];
        if (!move_uploaded_file($f['tmp_name'], "$dir/$stored")) { $this->out("error", "The upload failed. Please try again."); return; }

        $shownName = substr(preg_replace('/[^A-Za-z0-9._ -]/', '_', basename((string) $f['name'])), 0, 150);
        $body = "Amount paid: ₱" . number_format((float) $amount, 2);
        if ($ref !== '')  $body .= "\nReceipt / reference no.: " . $ref;
        if ($note !== '') $body .= "\n\n" . $note;

        try {
            $conn->prepare("INSERT INTO student_message (student_id, sender_user_id, kind, subject, body, created_at, from_borrower,
                                                         attachment_path, attachment_name, attachment_mime, proof_amount, proof_ref)
                            VALUES (:s, NULL, 'proof', 'Proof of payment', :b, NOW(), 1, :p, :n, :m, :a, :r)")
                 ->execute([":s" => $sid, ":b" => $body, ":p" => $stored, ":n" => $shownName, ":m" => $mime,
                            ":a" => round((float) $amount, 2), ":r" => $ref === '' ? null : $ref]);
        } catch (Throwable $e) {
            @unlink("$dir/$stored");
            error_log("proof insert failed: " . $e->getMessage());
            $this->out("error", "Could not send your proof. Please try again.");
            return;
        }

        $this->out("success", "Your proof of payment was sent. The librarian will check it and lift your blacklist once everything is confirmed.");
    }

    function getMyReservations() {
        include "../config/connection-pdo.php";
        $sid = $this->sid();
        if (!$sid) { $this->noRecord(); return; }

        $faculty = LoanRules::isFaculty($conn, $sid);

        $stmt = $conn->prepare("
            SELECT r.reservation_id, r.book_id, b.title, r.expires_on, bc.accession_number,
                   CASE WHEN r.status IN ('Pending', 'Waiting', 'Ready') AND r.expires_on < CURDATE() THEN 'Expired' ELSE r.status END AS status, r.reject_reason
            FROM reservation r
            LEFT JOIN book b ON r.book_id = b.book_id
            LEFT JOIN book_copies bc ON r.copy_id = bc.copy_id
            WHERE r.student_id = :s
            ORDER BY FIELD(r.status, 'Ready', 'Waiting', 'Pending', 'Fulfilled', 'Rejected', 'Cancelled', 'Expired'), r.reservation_id DESC
            LIMIT 50");
        $stmt->execute([":s" => $sid]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$r) $r['period'] = $this->period($conn, $faculty, $r['book_id'])[1];

        echo json_encode($rows);
    }

    // Ask to borrow a book. This only creates a Pending request: the Technical Services Librarian or Library Staff must approve it
    // before the book is recorded as borrowed.
    function reserve($json) {
        include "../config/connection-pdo.php";
        $sid = $this->sid();
        if (!$sid) { $this->noRecord(); return; }

        // A blacklisted account can't reserve. (Overdue alone doesn't block: the fine piles up until the blacklist limit.)
        $hold = AccountStanding::guard($conn, $sid);
        if ($hold) { $this->out("error", $hold, ["hold" => true]); return; }

        $data = json_decode($json, true) ?: [];
        $book_id = (int) ($data['book_id'] ?? 0);
        $expires = $data['expires_on'] ?? date('Y-m-d', strtotime('+7 days'));
        $today = date('Y-m-d');
        $latest = date('Y-m-d', strtotime("+" . self::MAX_HOLD_DAYS . " days"));

        if ($book_id <= 0) { $this->out("error", "Choose a book to reserve."); return; }
        if (!$this->validDate($expires) || $expires < $today) { $this->out("error", "Pick a pick-up date from today onwards."); return; }
        if ($expires > $latest) { $this->out("error", "Pick-up date can't be later than $latest (" . self::MAX_HOLD_DAYS . " days from today)."); return; }

        try {
            $b = $conn->prepare("SELECT (SELECT COUNT(*) FROM book_copies c INNER JOIN status st ON c.status_id = st.status_id
                                         WHERE c.book_id = b.book_id AND c.archived_at IS NULL AND st.status_desc <> 'Library Use Only') AS copies,
                                        (SELECT COUNT(*) FROM book_copies c WHERE c.book_id = b.book_id AND c.archived_at IS NULL) AS all_copies
                                 FROM book b WHERE b.book_id = :b");
            $b->execute([":b" => $book_id]);
            $counts = $b->fetch(PDO::FETCH_ASSOC);
            if (!$counts) { $this->out("error", "Book not found."); return; }
            if ((int) $counts['copies'] === 0) {
                $this->out("error", (int) $counts['all_copies'] > 0
                    ? "This book is for library use only right now, so it can't be reserved."
                    : "This book has no copies in the library yet.");
                return;
            }

            $dupe = $conn->prepare("SELECT 1 FROM reservation WHERE student_id = :s AND book_id = :b AND status IN ('Pending', 'Waiting', 'Ready') LIMIT 1");
            $dupe->execute([":s" => $sid, ":b" => $book_id]);
            if ($dupe->fetchColumn()) { $this->out("error", "You already have an active reservation or a pending request for this book."); return; }

            $faculty = LoanRules::isFaculty($conn, $sid);
            $limit = LoanRules::limit($conn, $faculty);
            $active = LoanRules::activeCount($conn, $sid);
            $reserved = $this->reservedCount($conn, $sid);
            if ($active + $reserved + 1 > $limit) {
                $this->out("error", sprintf("%s limit reached: at most %d books at a time, counting borrowed (%d) and reserved (%d) books.",
                    $faculty ? "Faculty" : "Student", $limit, $active, $reserved));
                return;
            }

            lms_lock_ids($conn);
            $id = (int) $conn->query("SELECT IFNULL(MAX(reservation_id), 0) + 1 FROM reservation")->fetchColumn();
            $conn->prepare("INSERT INTO reservation (reservation_id, student_id, book_id, copy_id, processed_by_user_id, reserved_at, expires_on, status, updated_at)
                            VALUES (:id, :s, :b, NULL, NULL, NOW(), :e, 'Pending', NOW())")
                 ->execute([":id" => $id, ":s" => $sid, ":b" => $book_id, ":e" => $expires]);

            // A reservation is only a request until the Technical Services Librarian or Library Staff approves it.
            // No copy is held and no place in the waiting list is taken until then.
            $label = $this->period($conn, $faculty, $book_id)[1];

            $this->out("success",
                "Reservation request sent. The library must approve it before a copy is held for you. Check My reservations for the answer. Loan period: $label.",
                ["reservation_status" => "Pending"]);
        } catch (Exception $e) {
            error_log("portal reserve failed: " . $e->getMessage());
            $this->out("error", "Failed to save the reservation.");
        }
    }

    function cancelReservation($json) {
        include "../config/connection-pdo.php";
        $sid = $this->sid();
        if (!$sid) { $this->noRecord(); return; }

        $data = json_decode($json, true) ?: [];

        $id = (int) ($data['reservation_id'] ?? 0);

        try {
            $s = $conn->prepare("SELECT status, copy_id FROM reservation WHERE reservation_id = :id AND student_id = :s");
            $s->execute([":id" => $id, ":s" => $sid]);
            $r = $s->fetch(PDO::FETCH_ASSOC);

            if (!$r || !in_array($r['status'], ['Pending', 'Waiting', 'Ready'], true)) {
                $this->out("error", "Only your Pending, Waiting or Ready reservations can be cancelled.");
                return;
            }

            $conn->prepare("UPDATE reservation SET status = 'Cancelled', copy_id = NULL, updated_at = NOW() WHERE reservation_id = :id")->execute([":id" => $id]);

            // Give the held copy back (only if it is still marked Reserved).
            if ($r['copy_id']) {
                $conn->prepare("UPDATE book_copies SET status_id = (SELECT status_id FROM status WHERE status_desc = 'Available' LIMIT 1)
                                WHERE copy_id = :c AND status_id = (SELECT status_id FROM status WHERE status_desc = 'Reserved' LIMIT 1)")
                     ->execute([":c" => $r['copy_id']]);
            }

            $this->out("success", "Reservation cancelled.");
        } catch (Exception $e) {
            error_log("portal cancel failed: " . $e->getMessage());
            $this->out("error", "Failed to cancel the reservation.");
        }
    }

    private function abort($conn, $message) {
        if ($conn->inTransaction()) $conn->rollBack();
        $this->out("error", $message);
    }
}

$operation = $_GET['operation'] ?? $_POST['operation'] ?? '';
$json = $_POST['json'] ?? $_GET['json'] ?? '';

$obj = new Portal();

switch ($operation) {
    case "getBooks":           $obj->getBooks(); break;
    case "getMyLoans":         $obj->getMyLoans(); break;
    case "getMyReservations":  $obj->getMyReservations(); break;
    case "getMessages":        $obj->getMessages(); break;
    case "markRead":           $obj->markRead($json); break;
    case "sendProof":          $obj->sendProof(); break;
    case "reserve":            $obj->reserve($json); break;
    case "cancelReservation":  $obj->cancelReservation($json); break;
}
?>