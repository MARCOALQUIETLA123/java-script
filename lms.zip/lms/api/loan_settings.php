<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
require_once __DIR__ . "/loan_rules.php";
Auth::guard(basename(__FILE__, '.php'));   // not in STAFF_OPS, so only the Technical Services Librarian

// Reads and saves the borrowing rules shown on the Loan Rules page.
// Every borrow, reservation and portal request reads the same rules through the LoanRules class,
// so a change saved here applies to the next loan straight away. Books already borrowed keep their due date.
class LoanSettings {

    // Names used in error messages.
    const NAMES = [
        'student_educational' => 'Students: educational books',
        'student_fictional'   => 'Students: fiction books',
        'student_other'       => 'Students: other books',
        'faculty_educational' => 'Faculty and Dean: educational books',
        'faculty_fictional'   => 'Faculty and Dean: fiction books',
        'faculty_other'       => 'Faculty and Dean: other books',
        'faculty_max'         => 'Faculty and Dean: longest possible loan',
        'student_limit'       => 'Students: books at a time',
        'faculty_limit'       => 'Faculty and Dean: books at a time',
        'semester_months'     => 'Length of one semester',
        'fine_per_day'        => 'Overdue fine per day',
        'processing_fee'      => 'Processing fee for lost or damaged books',
        'blacklist_after_days'=> 'Days overdue before an account is blacklisted',
    ];

    private function reply($status, $message) {
        echo json_encode(["status" => $status, "message" => $message]);
    }

    function getRules() {
        include "../config/connection-pdo.php";

        $rules = LoanRules::all($conn);

        $last = $conn->query("SELECT ls.updated_at, CONCAT_WS(' ', u.first_name, u.last_name) AS updated_by
                              FROM loan_settings ls
                              LEFT JOIN users u ON ls.updated_by_user_id = u.user_id
                              WHERE ls.updated_at IS NOT NULL
                              ORDER BY ls.updated_at DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            "rules"      => $rules,
            "units"      => LoanRules::UNITS,
            "updated_at" => $last ? $last['updated_at'] : null,
            "updated_by" => $last ? trim((string) $last['updated_by']) : null,
        ]);
    }

    function update($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true);
        $in = is_array($data) && isset($data['rules']) && is_array($data['rules']) ? $data['rules'] : null;
        if ($in === null) { $this->reply("error", "Nothing to save."); return; }

        $clean = [];
        foreach (LoanRules::DEFAULTS as $key => $def) {
            $name = self::NAMES[$key];
            $row = $in[$key] ?? null;
            if (!is_array($row) || !isset($row['value']) || !preg_match('/^\d{1,4}$/', (string) $row['value'])) {
                $this->reply("error", "$name needs a whole number of 1 or more.");
                return;
            }
            $value = (int) $row['value'];
            if ($value < 1) { $this->reply("error", "$name needs a whole number of 1 or more."); return; }

            $unit = null;
            if ($def[1] !== null) {
                $unit = $row['unit'] ?? '';
                if (!in_array($unit, LoanRules::UNITS, true)) {
                    $this->reply("error", "Choose days, weeks, months or semesters for: $name.");
                    return;
                }
            }
            $clean[$key] = ['value' => $value, 'unit' => $unit];
        }

        $limitMax = 50;
        foreach (['student_limit', 'faculty_limit'] as $k) {
            if ($clean[$k]['value'] > $limitMax) { $this->reply("error", self::NAMES[$k] . " can be at most $limitMax."); return; }
        }
        if ($clean['blacklist_after_days']['value'] > 365) { $this->reply("error", self::NAMES['blacklist_after_days'] . " can be at most 365."); return; }
        foreach (['fine_per_day', 'processing_fee'] as $k) {
            if ($clean[$k]['value'] > 100000) { $this->reply("error", self::NAMES[$k] . " is too large."); return; }
        }
        if ($clean['semester_months']['value'] > 6) { $this->reply("error", "One semester can be at most 6 months."); return; }

        // No single loan longer than a year.
        $sem = $clean['semester_months']['value'];
        foreach ($clean as $k => $r) {
            if ($r['unit'] === null) continue;
            if (LoanRules::approxDays($r['value'], $r['unit'], $sem) > 366) {
                $this->reply("error", self::NAMES[$k] . " can't be longer than one year.");
                return;
            }
        }

        // A faculty loan can't be longer than the longest possible loan.
        $cap = LoanRules::approxDays($clean['faculty_max']['value'], $clean['faculty_max']['unit'], $sem);
        foreach (['faculty_educational', 'faculty_fictional', 'faculty_other'] as $k) {
            $days = LoanRules::approxDays($clean[$k]['value'], $clean[$k]['unit'], $sem);
            if ($days > $cap) {
                $this->reply("error", self::NAMES[$k] . " is longer than the longest possible loan. Shorten it or raise the longest possible loan.");
                return;
            }
        }

        LoanRules::ensureTable($conn);
        $by = Auth::id();
        $stmt = $conn->prepare("INSERT INTO loan_settings (setting_key, setting_value, setting_unit, updated_by_user_id, updated_at)
                                VALUES (:k, :v, :u, :by, NOW())
                                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), setting_unit = VALUES(setting_unit),
                                                        updated_by_user_id = VALUES(updated_by_user_id), updated_at = VALUES(updated_at)");

        $conn->beginTransaction();
        try {
            foreach ($clean as $k => $r) {
                $stmt->execute([':k' => $k, ':v' => $r['value'], ':u' => $r['unit'], ':by' => $by]);
            }
            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollBack();
            throw $e;
        }

        LoanRules::reset();
        $this->reply("success", "Loan rules saved. They apply to every new loan from now on.");
    }
}

$operation = $_GET['operation'] ?? $_POST['operation'] ?? '';
$json = $_POST['json'] ?? '';

$obj = new LoanSettings();

switch ($operation) {
    case "getRules":
        $obj->getRules();
        break;
    case "update":
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            http_response_code(405);
            echo json_encode(["status" => "error", "message" => "Use POST."]);
            break;
        }
        $obj->update($json);
        break;
}
?>
