<?php

header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));

// Also sets the app time zone (Asia/Manila) so "today" matches the borrow pages.
require_once __DIR__ . "/loan_rules.php";
require_once __DIR__ . "/book_versions.php";
require_once __DIR__ . "/fine_payments.php";

class BookReturn {

    // Overdue fines of up to this amount (pesos) are paid at the library desk. Above it, the borrower is given
    // a receipt and pays at Assessment.
    const DESK_FINE_LIMIT = 60;

    private function out($status, $message) {
        echo json_encode(["status" => $status, "message" => $message]);
    }

    private function statusId($conn, $desc, $create = false) {
        $stmt = $conn->prepare("SELECT status_id FROM status WHERE status_desc = :d LIMIT 1");
        $stmt->bindParam(":d", $desc);
        $stmt->execute();
        $id = $stmt->fetchColumn();

        if ($id || !$create) {
            return $id ? (int) $id : null;
        }

        $next = (int) $conn->query("SELECT IFNULL(MAX(status_id), 0) + 1 FROM status")->fetchColumn();
        $ins = $conn->prepare("INSERT INTO status (status_id, status_desc) VALUES (:id, :d)");
        $ins->execute([":id" => $next, ":d" => $desc]);
        return $next;
    }

    private function validDate($value) {
        return is_string($value) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) && strtotime($value) !== false;
    }

    // The borrow item with its borrow date, copy and current copy status.
    private function loadItem($conn, $item_id, $lock = false) {
        $stmt = $conn->prepare("
            SELECT bi.item_id, bi.transaction_id, bi.copy_id, bt.borrow_date, bt.student_id,
                   COALESCE(bi.due_date, bt.due_date) AS due_date, bc.book_id,
                   s.status_desc AS copy_status
            FROM borrow_items bi
            INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
            LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
            LEFT JOIN status s ON bc.status_id = s.status_id
            WHERE bi.item_id = :item_id
            " . ($lock ? "FOR UPDATE" : ""));
        $stmt->bindParam(":item_id", $item_id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // A return date must be a real date, not before the book was borrowed, and not in the future.
    private function dateError($return_date, $borrow_date) {
        if (!$this->validDate($return_date)) {
            return "Please enter a valid return date.";
        }
        if ($return_date < $borrow_date) {
            return "Return date can't be earlier than the borrow date ($borrow_date).";
        }
        if ($return_date > date('Y-m-d')) {
            return "Return date can't be in the future.";
        }
        return null;
    }

    // Marks the borrow item returned and frees the copy (only if it is still marked Borrowed).
    private function markReturned($conn, $item) {
        $conn->prepare("UPDATE borrow_items SET is_returned = 1, returned_at = NOW() WHERE item_id = :id")
             ->execute([":id" => $item['item_id']]);

        $available = $this->statusId($conn, 'Available');
        $borrowed = $this->statusId($conn, 'Borrowed');

        if ($available && $borrowed) {
            $conn->prepare("UPDATE book_copies SET status_id = :a WHERE copy_id = :c AND status_id = :b")
                 ->execute([":a" => $available, ":c" => $item['copy_id'], ":b" => $borrowed]);
        }

        $this->keepLibraryCopy($conn, $item['copy_id']);
    }

    // Every book keeps at least one copy that can't be borrowed ("Library Use Only"). If this copy's book has none
    // (for example every copy was out on loan when the rule was introduced), the copy that just came back becomes it.
    private $libraryAssigned = [];

    private function keepLibraryCopy($conn, $copy_id) {
        $luo = $this->statusId($conn, 'Library Use Only');
        $available = $this->statusId($conn, 'Available');
        if (!$luo || !$available) return;

        $row = $conn->prepare("SELECT book_id, accession_number, status_id FROM book_copies WHERE copy_id = :c");
        $row->execute([":c" => $copy_id]);
        $copy = $row->fetch(PDO::FETCH_ASSOC);
        if (!$copy || (int) $copy['status_id'] !== (int) $available) return;

        $has = $conn->prepare("SELECT COUNT(*) FROM book_copies WHERE book_id = :b AND status_id = :s AND archived_at IS NULL");
        $has->execute([":b" => $copy['book_id'], ":s" => $luo]);
        if ((int) $has->fetchColumn() > 0) return;

        $conn->prepare("UPDATE book_copies SET status_id = :s WHERE copy_id = :c")->execute([":s" => $luo, ":c" => $copy_id]);
        $this->libraryAssigned[] = "ACC-" . $copy['accession_number'];
    }

    // Undoes markReturned (used when a return is deleted or moved to another item).
    // Refuses if the copy has already gone out again, because it can't be in two places.
    private function markNotReturned($conn, $item) {
        $available = $this->statusId($conn, 'Available');
        $borrowed = $this->statusId($conn, 'Borrowed');

        $libraryStatus = $this->statusId($conn, 'Library Use Only');
        if ($item['copy_status'] === 'Library Use Only' && $libraryStatus) {
            $available = $libraryStatus;   // the returned copy became the library copy: put it back as Borrowed
        } elseif ($item['copy_status'] !== 'Available') {
            return "This return can't be undone: the book copy is currently '" . ($item['copy_status'] ?: 'unknown') . "' and no longer on the shelf.";
        }

        $conn->prepare("UPDATE borrow_items SET is_returned = 0, returned_at = NULL WHERE item_id = :id")
             ->execute([":id" => $item['item_id']]);

        if ($available && $borrowed) {
            $conn->prepare("UPDATE book_copies SET status_id = :b WHERE copy_id = :c AND status_id = :a")
                 ->execute([":b" => $borrowed, ":c" => $item['copy_id'], ":a" => $available]);
        }

        return null;
    }

    /* =====================================================================
       Overdue fines, and lost or damaged books
       ===================================================================== */

    // The only conditions a book can come back in.
    const CONDITIONS = ['Good', 'Fair', 'Poor', 'Damaged', 'Lost'];

    private function peso($n) {
        return "₱" . number_format((float) $n, 2);
    }

    // Whole days between the due date and the return date (0 when on time or early).
    private function daysLate($due, $returned) {
        if (!$due || !$returned) return 0;
        return max(0, (int) round((strtotime($returned) - strtotime($due)) / 86400));
    }

    // The archive table is normally created by the Book Copies page. Make sure it exists here too.
    // Call BEFORE beginTransaction (CREATE/ALTER commit on their own).
    private function ensureArchiveTable($conn) {
        $conn->exec("CREATE TABLE IF NOT EXISTS book_copies_archive (
                        archive_id INT NOT NULL PRIMARY KEY,
                        copy_id INT NOT NULL,
                        book_id INT NULL,
                        book_title VARCHAR(255) NULL,
                        accession_number VARCHAR(50) NOT NULL,
                        `condition` VARCHAR(50) NULL,
                        added_at DATETIME NULL,
                        disposed_at DATETIME NOT NULL,
                        disposed_by_user_id INT NULL,
                        reason VARCHAR(20) NULL
                     )");
        lms_ensure_schema($conn, true);
    }

    // Good / Fair / Poor: the copy goes back on the shelf and its condition is updated.
    private function returnToShelf($conn, $item, $condition) {
        $this->markReturned($conn, $item);
        $conn->prepare("UPDATE book_copies SET `condition` = :c WHERE copy_id = :id")
             ->execute([":c" => $condition, ":id" => $item['copy_id']]);
    }

    // Damaged / Lost: the loan is closed, the copy gets the Damaged or Lost status and condition,
    // and it is archived automatically so it can never be lent out again.
    // (The row stays in book_copies, hidden by archived_at, because old loans still point at it.)
    private function retireCopy($conn, $item, $condition) {
        $conn->prepare("UPDATE borrow_items SET is_returned = 1, returned_at = NOW() WHERE item_id = :id")
             ->execute([":id" => $item['item_id']]);

        $status = $this->statusId($conn, $condition, true);
        $conn->prepare("UPDATE book_copies SET status_id = :s, `condition` = :c, archived_at = NOW() WHERE copy_id = :id")
             ->execute([":s" => $status, ":c" => $condition, ":id" => $item['copy_id']]);

        $sel = $conn->prepare("SELECT bc.copy_id, bc.book_id, bc.accession_number, bc.added_at, b.title
                               FROM book_copies bc LEFT JOIN book b ON bc.book_id = b.book_id
                               WHERE bc.copy_id = :id");
        $sel->execute([":id" => $item['copy_id']]);
        $copy = $sel->fetch(PDO::FETCH_ASSOC);
        if (!$copy) return;

        lms_lock_ids($conn);
        $next = (int) $conn->query("SELECT IFNULL(MAX(archive_id), 0) + 1 FROM book_copies_archive")->fetchColumn();
        $conn->prepare("INSERT INTO book_copies_archive
                            (archive_id, copy_id, book_id, book_title, accession_number, `condition`, added_at, disposed_at, disposed_by_user_id, reason)
                        VALUES (:aid, :cid, :bid, :title, :acc, :cond, :added, NOW(), :uid, :reason)")
             ->execute([":aid" => $next, ":cid" => $copy['copy_id'], ":bid" => $copy['book_id'], ":title" => $copy['title'],
                        ":acc" => $copy['accession_number'], ":cond" => $condition, ":added" => $copy['added_at'],
                        ":uid" => Auth::id(), ":reason" => $condition]);
    }

    // The borrower brought a replacement: add it to the library as a new Available copy. Returns [copy_id, accession].
    private function addReplacementCopy($conn, $book_id) {
        lms_lock_ids($conn);

        $acc = max(
            (int) $conn->query("SELECT IFNULL(MAX(CAST(accession_number AS UNSIGNED)), 1000) FROM book_copies")->fetchColumn(),
            (int) $conn->query("SELECT IFNULL(MAX(CAST(accession_number AS UNSIGNED)), 1000) FROM book_copies_archive")->fetchColumn()
        ) + 1;
        $copy_id = max(
            (int) $conn->query("SELECT IFNULL(MAX(copy_id), 0) FROM book_copies")->fetchColumn(),
            (int) $conn->query("SELECT IFNULL(MAX(copy_id), 0) FROM book_copies_archive")->fetchColumn()
        ) + 1;

        $status = $this->statusId($conn, 'Available', true);
        $luo = $this->statusId($conn, 'Library Use Only');
        if ($luo) {
            $has = $conn->prepare("SELECT COUNT(*) FROM book_copies WHERE book_id = :b AND status_id = :s AND archived_at IS NULL");
            $has->execute([":b" => $book_id, ":s" => $luo]);
            if ((int) $has->fetchColumn() === 0) $status = $luo;   // the book has no library copy yet
        }

        $conn->prepare("INSERT INTO book_copies (copy_id, book_id, accession_number, status_id, `condition`, added_at)
                        VALUES (:c, :b, :a, :s, 'Good', NOW())")
             ->execute([":c" => $copy_id, ":b" => $book_id, ":a" => (string) $acc, ":s" => $status]);

        return [$copy_id, $acc];
    }

    // Keeps the transaction's own status in step: "Returned" once every book is back, otherwise "Borrowed".
    private function syncTransactionStatus($conn, $transaction_id) {
        $stmt = $conn->prepare("SELECT COUNT(*) AS total,
                                       SUM(CASE WHEN is_returned = 1 THEN 1 ELSE 0 END) AS done
                                FROM borrow_items WHERE transaction_id = :t");
        $stmt->execute([":t" => $transaction_id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row || (int) $row['total'] === 0) return;

        $allBack = (int) $row['done'] === (int) $row['total'];
        $target = $allBack ? $this->statusId($conn, 'Returned', true) : $this->statusId($conn, 'Borrowed');

        if ($target) {
            $conn->prepare("UPDATE borrow_transaction SET status_id = :s WHERE transaction_id = :t")
                 ->execute([":s" => $target, ":t" => $transaction_id]);
        }
    }

    /* =====================================================================
       Endpoints for the borrower-first Book Returns screen
       ===================================================================== */

    private function pageParams($defaultLimit, $maxLimit = 50) {
        $limit = max(1, min($maxLimit, (int) ($_GET['limit'] ?? $defaultLimit)));
        $page = max(1, (int) ($_GET['page'] ?? 1));
        return [$page, $limit, ($page - 1) * $limit];
    }

    private function searchTerms($raw) {
        $terms = preg_split('/\s+/', trim((string) $raw), -1, PREG_SPLIT_NO_EMPTY);
        return array_slice($terms ?: [], 0, 5);
    }

    private function like($term) {
        return '%' . addcslashes($term, '%_\\') . '%';
    }

    private function itemLabel($conn, $item_id) {
        $stmt = $conn->prepare("SELECT CONCAT(IFNULL(b.title, 'Unknown title'), ' [ACC-', IFNULL(bc.accession_number, '?'), ']')
                                FROM borrow_items bi
                                LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                                LEFT JOIN book b ON bc.book_id = b.book_id
                                WHERE bi.item_id = :id");
        $stmt->execute([":id" => $item_id]);
        $label = $stmt->fetchColumn();
        return $label !== false ? $label : "Item #$item_id";
    }

    // Borrowers who currently have at least one unreturned book, with their open-loan counts.
    // Search words must ALL match (name, email, phone, course, department, id, or the
    // title / accession number of a book they are holding).
    function getBorrowers() {
        include "../config/connection-pdo.php";

        $type = $_GET['type'] ?? 'all';
        $overdueOnly = !empty($_GET['overdue']) && $_GET['overdue'] !== '0';
        $sort = $_GET['sort'] ?? 'overdue';
        list($page, $limit, $offset) = $this->pageParams(8);
        $today = date('Y-m-d');

        $params = [];
        $n = 0;
        $bind = function ($value) use (&$params, &$n) {
            $key = ':p' . $n++;
            $params[$key] = $value;
            return $key;
        };

        $isFaculty = "(LOWER(IFNULL(r.role_name, '')) LIKE '%faculty%' OR LOWER(IFNULL(r.role_name, '')) LIKE '%dean%')";
        $where = [];

        if ($type === 'faculty') {
            $where[] = $isFaculty;
        } elseif ($type === 'student') {
            $where[] = "NOT ($isFaculty)";
        }

        foreach ($this->searchTerms($_GET['search'] ?? '') as $term) {
            $like1 = $bind($this->like($term));
            $like2 = $bind($this->like($term));
            $like3 = $bind($this->like($term));
            $like4 = $bind($this->like($term));
            $like5 = $bind($this->like($term));
            $like6 = $bind($this->like($term));
            $like7 = $bind($this->like($term));
            $idEq = $bind($term);

            $where[] = "(CONCAT_WS(' ', s.first_name, s.last_name) LIKE $like1
                         OR s.email LIKE $like2
                         OR s.phone LIKE $like3
                         OR s.course LIKE $like4
                         OR d.department_name LIKE $like5
                         OR CAST(s.student_id AS CHAR) = $idEq
                         OR EXISTS (
                              SELECT 1
                              FROM borrow_transaction bt2
                              INNER JOIN borrow_items bi2 ON bi2.transaction_id = bt2.transaction_id
                                   AND (bi2.is_returned IS NULL OR bi2.is_returned = 0)
                              INNER JOIN book_copies bc2 ON bi2.copy_id = bc2.copy_id
                              LEFT JOIN book b2 ON bc2.book_id = b2.book_id
                              WHERE bt2.student_id = s.student_id
                                AND (bc2.accession_number LIKE $like6 OR b2.title LIKE $like7)
                         ))";
        }

        // Only borrowers who still have a book from this category out.
        $categoryId = (int) ($_GET['category'] ?? 0);
        if ($categoryId > 0) {
            $catParam = $bind($categoryId);
            $where[] = "EXISTS (
                            SELECT 1
                            FROM borrow_transaction bt3
                            INNER JOIN borrow_items bi3 ON bi3.transaction_id = bt3.transaction_id
                                   AND (bi3.is_returned IS NULL OR bi3.is_returned = 0)
                            INNER JOIN book_copies bc3 ON bi3.copy_id = bc3.copy_id
                            INNER JOIN book b3 ON bc3.book_id = b3.book_id
                            WHERE bt3.student_id = s.student_id AND b3.category_id = $catParam
                        )";
        }

        $overdueSelect = "SUM(CASE WHEN bt.due_date < " . $bind($today) . " THEN 1 ELSE 0 END)";

        $orders = [
            'overdue' => "overdue_count DESC, earliest_due ASC, s.first_name ASC, s.last_name ASC",
            'name'    => "s.first_name ASC, s.last_name ASC",
            'books'   => "books_out DESC, s.first_name ASC, s.last_name ASC",
            'newest'  => "latest_borrow DESC, s.first_name ASC, s.last_name ASC",
            'oldest'  => "earliest_borrow ASC, s.first_name ASC, s.last_name ASC"
        ];
        $orderBy = $orders[$sort] ?? $orders['overdue'];

        $inner = "SELECT s.student_id, s.first_name, s.last_name, s.email, s.phone, s.course,
                         d.department_name,
                         CASE WHEN $isFaculty THEN 1 ELSE 0 END AS is_faculty,
                         COUNT(bi.item_id) AS books_out,
                         $overdueSelect AS overdue_count,
                         MIN(bt.due_date) AS earliest_due,
                         MAX(bt.borrow_date) AS latest_borrow,
                         MIN(bt.borrow_date) AS earliest_borrow
                  FROM student s
                  INNER JOIN borrow_transaction bt ON bt.student_id = s.student_id
                  INNER JOIN borrow_items bi ON bi.transaction_id = bt.transaction_id
                          AND (bi.is_returned IS NULL OR bi.is_returned = 0)
                  LEFT JOIN users u ON s.user_id = u.user_id
                  LEFT JOIN roles r ON u.role_id = r.role_id
                  LEFT JOIN department d ON u.department_id = d.department_id"
                . (count($where) ? " WHERE " . implode(" AND ", $where) : "")
                . " GROUP BY s.student_id, s.first_name, s.last_name, s.email, s.phone, s.course,
                             d.department_name, r.role_name"
                . ($overdueOnly ? " HAVING overdue_count > 0" : "");

        $countStmt = $conn->prepare("SELECT COUNT(*) FROM ($inner) counted");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn();

        $stmt = $conn->prepare("$inner ORDER BY $orderBy LIMIT " . (int) $limit . " OFFSET " . (int) $offset);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Whole-library numbers for the summary cards (not affected by the search box).
        $sum = $conn->prepare("SELECT COUNT(DISTINCT bt.student_id) AS borrowers,
                                      COUNT(bi.item_id) AS books_out,
                                      SUM(CASE WHEN bt.due_date < :today THEN 1 ELSE 0 END) AS overdue_books
                               FROM borrow_items bi
                               INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                               WHERE bi.is_returned IS NULL OR bi.is_returned = 0");
        $sum->execute([":today" => $today]);
        $summary = $sum->fetch(PDO::FETCH_ASSOC) ?: [];

        echo json_encode([
            "rows" => $rows,
            "total" => $total,
            "page" => $page,
            "pages" => max(1, (int) ceil($total / $limit)),
            "limit" => $limit,
            "summary" => [
                "borrowers" => (int) ($summary['borrowers'] ?? 0),
                "books_out" => (int) ($summary['books_out'] ?? 0),
                "overdue_books" => (int) ($summary['overdue_books'] ?? 0)
            ]
        ]);
    }

    // One borrower plus every book they still have out.
    function getBorrowerItems() {
        include "../config/connection-pdo.php";

        $student_id = (int) ($_GET['student_id'] ?? 0);
        $today = date('Y-m-d');

        if ($student_id > 0 && !Auth::mayHandleBorrower($conn, $student_id)) {
            http_response_code(403);
            $this->out("error", "Faculty and Dean returns are reserved to the Technical Services Librarian unless your account was authorized for them.");
            return;
        }

        if ($student_id <= 0) {
            $this->out("error", "Borrower is required.");
            return;
        }

        $b = $conn->prepare("SELECT s.student_id, s.first_name, s.last_name, s.email, s.phone, s.course, s.address,
                                    d.department_name,
                                    CASE WHEN (LOWER(IFNULL(r.role_name, '')) LIKE '%faculty%' OR LOWER(IFNULL(r.role_name, '')) LIKE '%dean%') THEN 1 ELSE 0 END AS is_faculty
                             FROM student s
                             LEFT JOIN users u ON s.user_id = u.user_id
                             LEFT JOIN roles r ON u.role_id = r.role_id
                             LEFT JOIN department d ON u.department_id = d.department_id
                             WHERE s.student_id = :id");
        $b->execute([":id" => $student_id]);
        $borrower = $b->fetch(PDO::FETCH_ASSOC);

        if (!$borrower) {
            $this->out("error", "Borrower not found.");
            return;
        }

        $stmt = $conn->prepare("SELECT bi.item_id, bi.transaction_id, bi.copy_id,
                                       b.book_id, b.title, b.book_type, b.price AS book_price,
                                       bc.accession_number, bc.`condition` AS copy_condition,
                                       bt.borrow_date, COALESCE(bi.due_date, bt.due_date) AS due_date
                                FROM borrow_items bi
                                INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                                LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                                LEFT JOIN book b ON bc.book_id = b.book_id
                                WHERE bt.student_id = :id
                                  AND (bi.is_returned IS NULL OR bi.is_returned = 0)
                                ORDER BY COALESCE(bi.due_date, bt.due_date) ASC, b.title ASC, bi.item_id ASC");
        $stmt->execute([":id" => $student_id]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $todayTs = strtotime($today);
        foreach ($items as &$item) {
            // Positive = days overdue, 0 = due today, negative = days left.
            $item['days_overdue'] = $item['due_date']
                ? (int) round(($todayTs - strtotime($item['due_date'])) / 86400)
                : null;

            // What the borrower would have to buy or bring if this copy were lost or damaged:
            // the newest edition of the same title and authors.
            $newest = $item['book_id'] ? BookVersions::newest($conn, (int) $item['book_id']) : null;
            $item['replacement'] = $newest;
            $item['charge_price'] = $newest ? $newest['price'] : null;
        }
        unset($item);

        $rules = LoanRules::all($conn);
        $faculty = (int) $borrower['is_faculty'] === 1;
        $borrower['limit'] = LoanRules::limit($conn, $faculty);
        $borrower['books_out'] = count($items);
        $borrower['credit'] = FinePayments::credit($conn, (int) $student_id);   // paid in advance, not used yet

        echo json_encode([
            "status" => "success",
            "today" => $today,
            "borrower" => $borrower,
            "items" => $items,
            "fees" => [
                "fine_per_day" => (int) $rules['fine_per_day']['value'],
                "processing_fee" => (int) $rules['processing_fee']['value']
            ]
        ]);
    }

    // Past returns, newest first, with search, date range and a "late only" filter.
    function getHistory() {
        include "../config/connection-pdo.php";

        list($page, $limit, $offset) = $this->pageParams(15);

        $params = [];
        $n = 0;
        $bind = function ($value) use (&$params, &$n) {
            $key = ':p' . $n++;
            $params[$key] = $value;
            return $key;
        };

        $where = [];

        foreach ($this->searchTerms($_GET['search'] ?? '') as $term) {
            $a = $bind($this->like($term));
            $b = $bind($this->like($term));
            $c = $bind($this->like($term));
            $d = $bind($this->like($term));
            $where[] = "(CONCAT_WS(' ', s.first_name, s.last_name) LIKE $a
                         OR b.title LIKE $b
                         OR bc.accession_number LIKE $c
                         OR br.condition_on_return LIKE $d)";
        }

        $from = $_GET['from'] ?? '';
        $to = $_GET['to'] ?? '';
        if ($this->validDate($from)) $where[] = "br.return_date >= " . $bind($from);
        if ($this->validDate($to)) $where[] = "br.return_date <= " . $bind($to);
        if (($_GET['late'] ?? '') === '1') $where[] = "br.return_date > COALESCE(bi.due_date, bt.due_date)";
        $categoryId = (int) ($_GET['category'] ?? 0);
        if ($categoryId > 0) $where[] = "b.category_id = " . $bind($categoryId);
        $historyOrder = ($_GET['sort'] ?? 'newest') === 'oldest'
            ? "br.return_date ASC, br.return_id ASC"
            : "br.return_date DESC, br.return_id DESC";

        $from_sql = "FROM book_return br
                     LEFT JOIN borrow_items bi ON br.item_id = bi.item_id
                     LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                     LEFT JOIN book b ON bc.book_id = b.book_id
                     LEFT JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                     LEFT JOIN student s ON bt.student_id = s.student_id
                     LEFT JOIN users pu ON br.processed_by_user_id = pu.user_id"
                  . (count($where) ? " WHERE " . implode(" AND ", $where) : "");

        $countStmt = $conn->prepare("SELECT COUNT(*) $from_sql");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn();

        $stmt = $conn->prepare("SELECT br.return_id, br.item_id, br.return_date, br.condition_on_return,
                                       b.title, bc.accession_number,
                                       bt.borrow_date, COALESCE(bi.due_date, bt.due_date) AS due_date,
                                       s.student_id,
                                       CONCAT_WS(' ', s.first_name, s.last_name) AS student_name,
                                       CONCAT_WS(' ', pu.first_name, pu.last_name) AS processed_by,
                                       CASE WHEN br.return_date > COALESCE(bi.due_date, bt.due_date)
                                            THEN DATEDIFF(br.return_date, COALESCE(bi.due_date, bt.due_date)) ELSE 0 END AS days_late,
                                       (SELECT COUNT(*) FROM fine_payment fp WHERE fp.return_id = br.return_id AND fp.kind = 'assessment') AS assessment_flag,
                                       (SELECT IFNULL(SUM(fp.amount), 0) FROM fine_payment fp WHERE fp.return_id = br.return_id AND fp.kind = 'return') AS fine_cash,
                                       (SELECT IFNULL(-SUM(fp.amount), 0) FROM fine_payment fp WHERE fp.return_id = br.return_id AND fp.kind = 'applied') AS fine_credit,
                                       (SELECT MAX(fp.receipt_no) FROM fine_payment fp WHERE fp.return_id = br.return_id AND fp.kind IN ('return', 'applied')) AS fine_receipt,
                                       br.fine_amount, br.settlement, br.book_price, br.processing_fee,
                                       br.fine_amount + IF(br.settlement = 'Paid', IFNULL(br.book_price, 0) + br.processing_fee, 0) AS charges_total
                                $from_sql
                                ORDER BY $historyOrder
                                LIMIT " . (int) $limit . " OFFSET " . (int) $offset);
        $stmt->execute($params);

        echo json_encode([
            "rows" => $stmt->fetchAll(PDO::FETCH_ASSOC),
            "total" => $total,
            "page" => $page,
            "pages" => max(1, (int) ceil($total / $limit)),
            "limit" => $limit
        ]);
    }

    // Returns several books in one go. All-or-nothing: if any book fails, none are saved.
    // Each book can come back Good / Fair / Poor, or be reported Damaged / Lost. A damaged or lost book must be
    // settled at the desk: paid for in cash (price + processing fee) or replaced with the newest edition.
    function addMultiple($json) {
        include "../config/connection-pdo.php";
        $this->ensureArchiveTable($conn);

        $json = json_decode($json, true) ?: [];

        $return_date = $json['return_date'] ?? null;
        $items = isset($json['items']) && is_array($json['items']) ? $json['items'] : [];
        $confirmed = !empty($json['payment_confirmed']);

        if (empty($return_date) || count($items) === 0) {
            $this->out("error", "Select at least one book and a return date.");
            return;
        }

        if (count($items) > 50) {
            $this->out("error", "You can return at most 50 books at a time.");
            return;
        }

        $rules = LoanRules::all($conn);
        $rate = (int) $rules['fine_per_day']['value'];
        $fee = (int) $rules['processing_fee']['value'];

        try {
            $conn->beginTransaction();

            $nextId = (int) $conn->query("SELECT IFNULL(MAX(return_id), 0) + 1 FROM book_return")->fetchColumn();
            $returnIds = [];

            $insert = $conn->prepare("INSERT INTO book_return
                                        (return_id, item_id, return_date, condition_on_return, processed_by_user_id,
                                         overdue_days, fine_amount, settlement, book_price, processing_fee, replacement_book_id)
                                      VALUES
                                        (:return_id, :item_id, :return_date, :condition_on_return, :processed_by,
                                         :overdue_days, :fine_amount, :settlement, :book_price, :processing_fee, :replacement_book_id)");

            $seen = [];
            $transactions = [];
            $deskDue = 0.0;       // overdue fines collected at the library desk (after any advance payment)
            $plainFines = [];     // overdue fines of books returned in a good enough state to go back on the shelf
            $assessmentOverdue = 0.0;   // overdue fines above the desk limit: the borrower pays them at Assessment
            $assessmentFine = 0.0;   // fines of lost / damaged books: paid at Assessment together with the case
            $creditUsed = 0.0;
            $credit = [];         // student_id => advance payment not used yet
            $replacements = 0;
            $retired = 0;

            foreach ($items as $entry) {
                $item_id = (int) ($entry['item_id'] ?? 0);

                $condition = null;
                foreach (self::CONDITIONS as $c) {
                    if (strcasecmp(trim($entry['condition_on_return'] ?? ""), $c) === 0) $condition = $c;
                }

                if ($item_id <= 0 || isset($seen[$item_id])) {
                    $conn->rollBack();
                    $this->out("error", "The list of books to return is not valid.");
                    return;
                }
                $seen[$item_id] = true;

                $loaded = $this->loadItem($conn, $item_id, true);

                if (!$loaded) {
                    $conn->rollBack();
                    $this->out("error", "Borrow item #$item_id was not found.");
                    return;
                }

                if (!Auth::mayHandleBorrower($conn, $loaded['student_id'])) {
                    $conn->rollBack();
                    $this->out("error", "Faculty and Dean returns are reserved to the Technical Services Librarian unless your account was authorized for them.");
                    return;
                }

                $label = $this->itemLabel($conn, $item_id);

                if ($condition === null) {
                    $conn->rollBack();
                    $this->out("error", "$label: choose Good, Fair, Poor, Damaged or Lost.");
                    return;
                }

                $err = $this->dateError($return_date, $loaded['borrow_date']);
                if ($err) {
                    $conn->rollBack();
                    $this->out("error", "$label: $err");
                    return;
                }

                $dupe = $conn->prepare("SELECT return_id FROM book_return WHERE item_id = :id LIMIT 1");
                $dupe->execute([":id" => $item_id]);
                $flag = $conn->prepare("SELECT is_returned FROM borrow_items WHERE item_id = :id");
                $flag->execute([":id" => $item_id]);

                if ($dupe->rowCount() > 0 || (int) $flag->fetchColumn() === 1) {
                    $conn->rollBack();
                    $this->out("error", "$label has already been returned. Refresh the page to see the latest list.");
                    return;
                }

                // Overdue fine: every day past the due date, for every book.
                $days = $this->daysLate($loaded['due_date'], $return_date);
                $fine = $days * $rate;

                $settlement = null;
                $price = null;
                $itemFee = 0;
                $replacementBook = null;
                $retire = in_array($condition, ['Damaged', 'Lost'], true);

                $autoPriced = false;
                if ($retire) {
                    // No price is typed in when the book already has one: price + processing fee are filled in
                    // automatically. Only a book with no price on record waits for the librarian to set it.
                    $settlement = 'Pending';
                    $known = $this->knownPrice($conn, $loaded['book_id']);
                    if ($known !== null) {
                        $price = $known;
                        $itemFee = $fee;
                        $autoPriced = true;
                    }
                }

                $insert->execute([
                    ":return_id" => $nextId,
                    ":item_id" => $item_id,
                    ":return_date" => $return_date,
                    ":condition_on_return" => $condition,
                    ":processed_by" => Auth::id(),
                    ":overdue_days" => $days,
                    ":fine_amount" => $fine,
                    ":settlement" => $settlement,
                    ":book_price" => $price,
                    ":processing_fee" => $itemFee,
                    ":replacement_book_id" => $replacementBook
                ]);

                if ($retire) {
                    $assessmentFine += $fine;
                } elseif ($fine > 0) {
                    // An overdue fine alone is settled once every book of this return is known (see below):
                    // up to the limit it is paid at the library desk, above it at Assessment.
                    $plainFines[] = ["sid" => (int) $loaded['student_id'], "return_id" => $nextId, "fine" => $fine];
                }

                if ($retire) {
                    $this->retireCopy($conn, $loaded, $condition);
                    if ($autoPriced) {
                        $conn->prepare("UPDATE book_return SET case_status = 'Awaiting payment', receipt_no = :rn WHERE return_id = :r")
                             ->execute([":rn" => "LD-" . str_pad((string) $nextId, 6, "0", STR_PAD_LEFT), ":r" => $nextId]);
                    } else {
                        $conn->prepare("UPDATE book_return SET case_status = 'Pending' WHERE return_id = :r")
                             ->execute([":r" => $nextId]);
                    }
                    $retired++;
                } else {
                    $this->returnToShelf($conn, $loaded, $condition);
                }

                if ($replacementBook !== null) {
                    list($newCopyId) = $this->addReplacementCopy($conn, $replacementBook);
                    $conn->prepare("UPDATE book_return SET replacement_copy_id = :c WHERE return_id = :r")
                         ->execute([":c" => $newCopyId, ":r" => $nextId]);
                }

                $returnIds[] = $nextId;
                $nextId++;
                $transactions[$loaded['transaction_id']] = true;
            }

            // Overdue fines: the total of this return decides where it is paid. Up to the limit at the library desk
            // (first from any advance payment, then in cash). Above the limit the borrower takes the receipt to Assessment.
            $plainTotal = 0.0;
            foreach ($plainFines as $pf) $plainTotal += $pf['fine'];

            if ($plainTotal > self::DESK_FINE_LIMIT) {
                $assessmentOverdue = round($plainTotal, 2);
                // A zero-peso marker says "this fine is paid at Assessment" (it is not money, so no total counts it).
                foreach ($plainFines as $pf) {
                    if ($pf['sid'] > 0) {
                        FinePayments::add($conn, $pf['sid'], 0, 'assessment', Auth::id(),
                                          ["return_id" => $pf['return_id'], "note" => "Fine above the desk limit: to be paid at Assessment"]);
                    }
                }
            } else {
                foreach ($plainFines as $pf) {
                    $sidKey = $pf['sid'];
                    if ($sidKey > 0) {
                        if (!isset($credit[$sidKey])) $credit[$sidKey] = FinePayments::credit($conn, $sidKey);
                        list($used, $cashPart) = FinePayments::payReturnFine($conn, $sidKey, $pf['return_id'], $pf['fine'], Auth::id(), $credit[$sidKey]);
                        $creditUsed += $used;
                        $deskDue += $cashPart;
                    } else {
                        $deskDue += $pf['fine'];
                    }
                }
            }

            // Money is collected (and replacement copies received) at the desk before the return is saved.
            if (($deskDue > 0 || $assessmentFine > 0 || $assessmentOverdue > 0 || $replacements > 0) && !$confirmed) {
                $conn->rollBack();
                $this->out("error", "Confirm that the fine was collected and any replacement copy received.");
                return;
            }

            foreach (array_keys($transactions) as $transaction_id) {
                $this->syncTransactionStatus($conn, $transaction_id);
            }

            $conn->commit();

            $count = count($items);
            $msg = $count === 1 ? "1 book returned successfully." : "$count books returned successfully.";
            if ($creditUsed > 0) $msg .= " " . $this->peso($creditUsed) . " of the fine was covered by the borrower's advance payment.";
            if ($deskDue > 0) $msg .= " Collected at the library desk: " . $this->peso($deskDue) . ".";
            if ($assessmentOverdue > 0) $msg .= " The overdue fine of " . $this->peso($assessmentOverdue) . " is more than " . $this->peso(self::DESK_FINE_LIMIT) . ", so the borrower takes the receipt and pays at Assessment.";
            if ($assessmentFine > 0) $msg .= " To pay at Assessment (lost or damaged book): " . $this->peso($assessmentFine) . ".";
            if ($replacements > 0) $msg .= " " . ($replacements === 1 ? "A replacement copy was added to the library." : "$replacements replacement copies were added to the library.");
            if ($retired > 0) $msg .= " " . ($retired === 1 ? "1 lost or damaged copy was archived and sent to the Lost & Damaged dashboard." : "$retired lost or damaged copies were archived and sent to the Lost & Damaged dashboard.");
            if ($this->libraryAssigned) $msg .= " " . implode(", ", $this->libraryAssigned) . " is now kept for library use only (every book needs one copy that can't be borrowed).";

            echo json_encode(["status" => "success", "message" => $msg, "cash_collected" => $deskDue, "assessment_due" => $assessmentFine + $assessmentOverdue, "desk_limit" => self::DESK_FINE_LIMIT, "credit_used" => $creditUsed, "return_ids" => $returnIds]);
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("book return addMultiple failed: " . $e->getMessage());
            $this->out("error", "Failed to save the returns. Nothing was changed.");
        }
    }


    // The borrower paid an overdue fine that was above the desk limit at Assessment. The Assessment receipt number is recorded
    // and the fine counts as paid. $json: {return_ids: [..], or_number: "..."}
    function payAssessmentFine($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $ids = array_values(array_filter(array_map('intval', (array) ($data['return_ids'] ?? [])), function ($v) { return $v > 0; }));
        $or = trim((string) ($data['or_number'] ?? ''));

        if (count($ids) === 0) { $this->out("error", "Choose the returns that were paid."); return; }
        if ($or === '' || mb_strlen($or) > 40) { $this->out("error", "Enter the Assessment receipt number."); return; }

        try {
            $conn->beginTransaction();
            $paidTotal = 0.0;

            $load = $conn->prepare("SELECT br.return_id, br.fine_amount, br.condition_on_return, bt.student_id,
                                           (SELECT IFNULL(SUM(fp.amount), 0) FROM fine_payment fp WHERE fp.return_id = br.return_id AND fp.kind = 'return') AS cash,
                                           (SELECT IFNULL(-SUM(fp.amount), 0) FROM fine_payment fp WHERE fp.return_id = br.return_id AND fp.kind = 'applied') AS credit
                                    FROM book_return br
                                    INNER JOIN borrow_items bi ON br.item_id = bi.item_id
                                    INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                                    WHERE br.return_id = :id FOR UPDATE");

            foreach ($ids as $id) {
                $load->execute([":id" => $id]);
                $r = $load->fetch(PDO::FETCH_ASSOC);
                if (!$r || in_array($r['condition_on_return'], ['Lost', 'Damaged'], true)) continue;   // those are closed on the Lost & Damaged dashboard

                $due = round((float) $r['fine_amount'] - (float) $r['cash'] - (float) $r['credit'], 2);
                if ($due <= 0 || (int) $r['student_id'] <= 0) continue;

                FinePayments::add($conn, (int) $r['student_id'], $due, 'return', Auth::id(),
                                  ["return_id" => (int) $id, "receipt_no" => $or, "note" => "Paid at Assessment"]);
                $paidTotal += $due;
            }

            if ($paidTotal <= 0) {
                $conn->rollBack();
                $this->out("error", "Nothing is owed on the chosen returns.");
                return;
            }

            $conn->commit();
            $this->out("success", "Payment of " . $this->peso($paidTotal) . " recorded with Assessment receipt no. " . $or . ".");
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("book return payAssessmentFine failed: " . $e->getMessage());
            $this->out("error", "Failed to record the payment.");
        }
    }

    // The rows for an Assessment receipt: the returns with the given ids (comma separated), with what is owed.
    function getReceipt() {
        include "../config/connection-pdo.php";

        $ids = array_values(array_filter(array_map('intval', explode(',', (string) ($_GET['ids'] ?? ''))), function ($v) { return $v > 0; }));
        $ids = array_slice($ids, 0, 50);

        if (count($ids) === 0) {
            $this->out("error", "No returns were chosen for the receipt.");
            return;
        }

        $marks = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $conn->prepare("SELECT br.return_id, br.return_date, br.condition_on_return,
                                       b.title, bc.accession_number,
                                       COALESCE(bi.due_date, bt.due_date) AS due_date,
                                       CONCAT_WS(' ', s.first_name, s.last_name) AS student_name,
                                       CONCAT_WS(' ', pu.first_name, pu.last_name) AS processed_by,
                                       CASE WHEN br.return_date > COALESCE(bi.due_date, bt.due_date)
                                            THEN DATEDIFF(br.return_date, COALESCE(bi.due_date, bt.due_date)) ELSE 0 END AS days_late,
                                       (SELECT COUNT(*) FROM fine_payment fp WHERE fp.return_id = br.return_id AND fp.kind = 'assessment') AS assessment_flag,
                                       (SELECT IFNULL(SUM(fp.amount), 0) FROM fine_payment fp WHERE fp.return_id = br.return_id AND fp.kind = 'return') AS fine_cash,
                                       (SELECT IFNULL(-SUM(fp.amount), 0) FROM fine_payment fp WHERE fp.return_id = br.return_id AND fp.kind = 'applied') AS fine_credit,
                                       (SELECT MAX(fp.receipt_no) FROM fine_payment fp WHERE fp.return_id = br.return_id AND fp.kind IN ('return', 'applied')) AS fine_receipt,
                                       br.fine_amount, br.settlement, br.book_price, br.processing_fee,
                                       br.fine_amount + IF(br.settlement = 'Paid', IFNULL(br.book_price, 0) + br.processing_fee, 0) AS charges_total
                                FROM book_return br
                                LEFT JOIN borrow_items bi ON br.item_id = bi.item_id
                                LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                                LEFT JOIN book b ON bc.book_id = b.book_id
                                LEFT JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                                LEFT JOIN student s ON bt.student_id = s.student_id
                                LEFT JOIN users pu ON br.processed_by_user_id = pu.user_id
                                WHERE br.return_id IN ($marks)
                                ORDER BY br.return_id ASC");
        $stmt->execute($ids);

        echo json_encode(["status" => "success", "rows" => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }

    /* =====================================================================
       Lost & Damaged dashboard
       ===================================================================== */

    const OPEN_CASES = "COALESCE(br.case_status, 'Settled') IN ('Pending', 'Awaiting payment', 'Awaiting replacement')";

    private function isAdmin() {
        $me = Auth::current();
        return $me && $me['role'] === 'admin';
    }

    // The price already tied to a book, or null when none is set. The newest edition's price is used when one
    // exists (that is what a borrower must pay or replace with); otherwise the book's own price.
    private function knownPrice($conn, $book_id) {
        $book_id = (int) $book_id;
        if ($book_id <= 0) return null;

        if (class_exists('BookVersions')) {
            $newest = BookVersions::newest($conn, $book_id);
            if ($newest && isset($newest['price']) && is_numeric($newest['price']) && (float) $newest['price'] > 0) {
                return round((float) $newest['price'], 2);
            }
        }

        $st = $conn->prepare("SELECT price FROM book WHERE book_id = :b");
        $st->execute([":b" => $book_id]);
        $price = $st->fetchColumn();
        return ($price !== false && is_numeric($price) && (float) $price > 0) ? round((float) $price, 2) : null;
    }

    // 'student', 'faculty' or 'dean' for a student-table id. Clearance only applies to students; a dean's lost or
    // damaged book is deducted from his or her salary instead.
    private function borrowerKind($conn, $student_id) {
        $st = $conn->prepare("SELECT r.role_name FROM student s
                              INNER JOIN users u ON s.user_id = u.user_id
                              INNER JOIN roles r ON u.role_id = r.role_id
                              WHERE s.student_id = :s LIMIT 1");
        $st->execute([":s" => (int) $student_id]);
        $name = strtolower(trim((string) $st->fetchColumn()));
        if ($name === 'dean') return 'dean';
        if (strpos($name, 'faculty') !== false) return 'faculty';
        return 'student';
    }

    // Cases (lost or damaged returns) with search, a status filter and paging, plus counts for the summary cards.
    function getCases() {
        include "../config/connection-pdo.php";

        list($page, $limit, $offset) = $this->pageParams(10);

        $params = [];
        $n = 0;
        $bind = function ($value) use (&$params, &$n) {
            $key = ':p' . $n++;
            $params[$key] = $value;
            return $key;
        };

        $where = ["br.condition_on_return IN ('Lost', 'Damaged')"];

        $status = $_GET['status'] ?? 'open';
        if ($status === 'open') {
            $where[] = self::OPEN_CASES;
        } elseif (in_array($status, ['Pending', 'Awaiting payment', 'Awaiting replacement', 'Settled', 'Waived'], true)) {
            $where[] = "COALESCE(br.case_status, 'Settled') = " . $bind($status);
        }

        if (in_array($_GET['condition'] ?? '', ['Lost', 'Damaged'], true)) {
            $where[] = "br.condition_on_return = " . $bind($_GET['condition']);
        }

        foreach ($this->searchTerms($_GET['search'] ?? '') as $term) {
            $a = $bind($this->like($term)); $b = $bind($this->like($term)); $c = $bind($this->like($term));
            $d = $bind($this->like($term)); $e = $bind($this->like($term));
            $where[] = "(CONCAT_WS(' ', s.first_name, s.last_name) LIKE $a OR b.title LIKE $b OR bc.accession_number LIKE $c
                         OR br.receipt_no LIKE $d OR br.or_number LIKE $e)";
        }

        $from = "FROM book_return br
                 INNER JOIN borrow_items bi ON br.item_id = bi.item_id
                 INNER JOIN book_copies bc ON bi.copy_id = bc.copy_id
                 LEFT JOIN book b ON bc.book_id = b.book_id
                 LEFT JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                 LEFT JOIN student s ON bt.student_id = s.student_id
                 LEFT JOIN users pu ON br.processed_by_user_id = pu.user_id
                 WHERE " . implode(" AND ", $where);

        $countStmt = $conn->prepare("SELECT COUNT(*) $from");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn();

        $stmt = $conn->prepare("SELECT br.return_id, br.return_date, br.condition_on_return, br.fine_amount, br.book_price,
                                       br.processing_fee, br.settlement, COALESCE(br.case_status, 'Settled') AS case_status,
                                       br.receipt_no, br.or_number, br.settled_at, br.case_note,
                                       b.book_id, b.title, bc.accession_number,
                                       s.student_id, CONCAT_WS(' ', s.first_name, s.last_name) AS student_name, s.course,
                                       CONCAT_WS(' ', pu.first_name, pu.last_name) AS processed_by,
                                       (SELECT r2.role_name FROM users u2 INNER JOIN roles r2 ON u2.role_id = r2.role_id
                                         WHERE u2.user_id = s.user_id LIMIT 1) AS borrower_role
                                $from
                                ORDER BY (COALESCE(br.case_status, 'Settled') IN ('Pending', 'Awaiting payment', 'Awaiting replacement')) DESC,
                                         br.return_date DESC, br.return_id DESC
                                LIMIT " . (int) $limit . " OFFSET " . (int) $offset);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // What the book would cost today (the newest edition) so the Technical Services Librarian has a starting point.
        foreach ($rows as &$row) {
            $row['suggested_price'] = null;
            $row['replacement_title'] = null;
            $row['replacement_year'] = null;
            $row['replacement_authors'] = null;
            $row['replacement_is_newer'] = false;
            $row['borrower_kind'] = (strtolower((string) $row['borrower_role']) === 'dean') ? 'dean'
                                  : ((strpos(strtolower((string) $row['borrower_role']), 'faculty') !== false) ? 'faculty' : 'student');
            $row['price_is_automatic'] = $row['book_id'] ? ($this->knownPrice($conn, (int) $row['book_id']) !== null) : false;
            if ($row['book_id'] && in_array($row['case_status'], ['Pending', 'Awaiting payment', 'Awaiting replacement'], true)) {
                $newest = BookVersions::newest($conn, (int) $row['book_id']);
                if ($newest) {
                    $row['suggested_price'] = $newest['price'];
                    $row['replacement_title'] = $newest['title'];
                    $row['replacement_year'] = $newest['published_year'];
                    $row['replacement_authors'] = BookVersions::authorNames($conn, (int) $newest['book_id']);
                    $row['replacement_is_newer'] = $newest['is_newer'];
                }
            }
        }
        unset($row);

        $sum = $conn->query("SELECT SUM(COALESCE(br.case_status, 'Settled') = 'Pending') AS pending,
                                    SUM(COALESCE(br.case_status, 'Settled') = 'Awaiting payment') AS awaiting,
                                    SUM(COALESCE(br.case_status, 'Settled') = 'Awaiting replacement') AS replacing,
                                    SUM(COALESCE(br.case_status, 'Settled') IN ('Settled', 'Waived')) AS closed,
                                    SUM(CASE WHEN br.case_status = 'Awaiting payment' THEN IFNULL(br.book_price, 0) + br.processing_fee ELSE 0 END) AS outstanding
                             FROM book_return br
                             WHERE br.condition_on_return IN ('Lost', 'Damaged')")->fetch(PDO::FETCH_ASSOC) ?: [];

        echo json_encode([
            "rows" => $rows,
            "total" => $total,
            "page" => $page,
            "pages" => max(1, (int) ceil($total / $limit)),
            "summary" => [
                "pending" => (int) ($sum['pending'] ?? 0),
                "awaiting" => (int) ($sum['awaiting'] ?? 0),
                "replacing" => (int) ($sum['replacing'] ?? 0),
                "closed" => (int) ($sum['closed'] ?? 0),
                "open" => (int) ($sum['pending'] ?? 0) + (int) ($sum['awaiting'] ?? 0) + (int) ($sum['replacing'] ?? 0),
                "outstanding" => (float) ($sum['outstanding'] ?? 0)
            ],
            "processing_fee" => (int) LoanRules::all($conn)['processing_fee']['value']
        ]);
    }

    private function loadCase($conn, $return_id, $lock = false) {
        $stmt = $conn->prepare("SELECT br.return_id, br.condition_on_return, COALESCE(br.case_status, 'Settled') AS case_status,
                                       br.receipt_no, bc.book_id
                                FROM book_return br
                                LEFT JOIN borrow_items bi ON br.item_id = bi.item_id
                                LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                                WHERE br.return_id = :id" . ($lock ? " FOR UPDATE" : ""));
        $stmt->execute([":id" => $return_id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return ($row && in_array($row['condition_on_return'], ['Lost', 'Damaged'], true)) ? $row : null;
    }

    // The Technical Services Librarian decides how the borrower settles: pay (the price is set, the processing fee is added and a receipt
    // number is created) or replace (the newest edition with the same title and authors).
    function saveCase($json) {
        include "../config/connection-pdo.php";

        if (!$this->isAdmin()) {
            $this->out("error", "Only the Technical Services Librarian can choose how a lost or damaged book is settled.");
            return;
        }

        $data = json_decode($json, true) ?: [];
        $return_id = (int) ($data['return_id'] ?? 0);
        $method = ($data['method'] ?? 'pay') === 'replace' ? 'replace' : 'pay';
        $note = mb_substr(trim((string) ($data['note'] ?? '')), 0, 255);

        $case = $this->loadCase($conn, $return_id);
        if (!$case || !in_array($case['case_status'], ['Pending', 'Awaiting payment', 'Awaiting replacement'], true)) {
            $this->out("error", "This case can no longer be changed.");
            return;
        }

        if ($method === 'replace') {
            $newest = $case['book_id'] ? BookVersions::newest($conn, (int) $case['book_id']) : null;
            if (!$newest) {
                $this->out("error", "The book record could not be found.");
                return;
            }

            $conn->prepare("UPDATE book_return
                            SET book_price = NULL, processing_fee = 0, case_status = 'Awaiting replacement',
                                replacement_book_id = :b, case_note = :n
                            WHERE return_id = :id")
                 ->execute([":b" => $newest['book_id'], ":n" => $note, ":id" => $return_id]);

            $this->out("success", "The borrower must bring: " . $newest['title']
                . (!empty($newest['published_year']) ? " (" . $newest['published_year'] . ")" : "")
                . ", the newest edition with the same title and author.");
            return;
        }

        $price = $data['price'] ?? '';
        if (($price === '' || $price === null) && $case['book_id']) {
            // Nothing typed: use the price that is already tied to the book.
            $known = $this->knownPrice($conn, (int) $case['book_id']);
            if ($known !== null) $price = $known;
        }
        if (!is_numeric($price) || (float) $price <= 0 || (float) $price > 1000000) {
            $this->out("error", "This book has no price on record. Enter a valid price.");
            return;
        }

        $fee = (int) LoanRules::all($conn)['processing_fee']['value'];
        $receipt = $case['receipt_no'] ?: "LD-" . str_pad((string) $return_id, 6, "0", STR_PAD_LEFT);

        $conn->prepare("UPDATE book_return
                        SET book_price = :p, processing_fee = :f, receipt_no = :r, case_status = 'Awaiting payment',
                            replacement_book_id = NULL, case_note = :n
                        WHERE return_id = :id")
             ->execute([":p" => round((float) $price, 2), ":f" => $fee, ":r" => $receipt, ":n" => $note, ":id" => $return_id]);

        $this->out("success", "Price saved. The receipt " . $receipt . " is ready to print.");
    }

    // Closes a case: paid at Assessment (needs the Assessment receipt number), replaced with a new copy, or waived.
    function settleCase($json) {
        include "../config/connection-pdo.php";

        // Library Staff and Student Assistants can monitor cases and message borrowers, but they cannot close one.
        if (!$this->isAdmin()) {
            $this->out("error", "Only the Technical Services Librarian can close a lost or damaged case. You can monitor it and send the borrower a message.");
            return;
        }

        $data = json_decode($json, true) ?: [];
        $return_id = (int) ($data['return_id'] ?? 0);
        $method = $data['method'] ?? '';
        $note = mb_substr(trim((string) ($data['note'] ?? '')), 0, 255);

        try {
            $conn->beginTransaction();

            $case = $this->loadCase($conn, $return_id, true);
            if (!$case || !in_array($case['case_status'], ['Pending', 'Awaiting payment', 'Awaiting replacement'], true)) {
                $conn->rollBack();
                $this->out("error", "This case is already closed.");
                return;
            }

            $sid = $conn->prepare("SELECT bt.student_id FROM book_return br
                                   INNER JOIN borrow_items bi ON br.item_id = bi.item_id
                                   INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                                   WHERE br.return_id = :id");
            $sid->execute([":id" => $return_id]);
            $kind = $this->borrowerKind($conn, (int) $sid->fetchColumn());
            // Clearance only exists for students. Faculty and deans are never told their clearance is affected.
            $clear = $kind === 'student' ? " The borrower's clearance for this book is cleared." : "";

            if ($method === 'paid') {
                $or = trim((string) ($data['or_number'] ?? ''));
                if ($case['case_status'] !== 'Awaiting payment') {
                    $conn->rollBack();
                    $this->out("error", "Set the price and print the receipt first.");
                    return;
                }
                if ($or === '' || mb_strlen($or) > 40) {
                    $conn->rollBack();
                    $this->out("error", "Enter the Assessment receipt number.");
                    return;
                }
                $conn->prepare("UPDATE book_return SET settlement = 'Paid', case_status = 'Settled', or_number = :o,
                                       settled_at = NOW(), settled_by_user_id = :u WHERE return_id = :id")
                     ->execute([":o" => $or, ":u" => Auth::id(), ":id" => $return_id]);
                // The late fine on this book was part of what Assessment received.
                $fp = $conn->prepare("SELECT br.fine_amount, bt.student_id FROM book_return br
                                      INNER JOIN borrow_items bi ON br.item_id = bi.item_id
                                      INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                                      WHERE br.return_id = :id");
                $fp->execute([":id" => $return_id]);
                $fr = $fp->fetch(PDO::FETCH_ASSOC);
                if ($fr && (float) $fr['fine_amount'] > 0 && (int) $fr['student_id'] > 0) {
                    FinePayments::add($conn, (int) $fr['student_id'], (float) $fr['fine_amount'], 'return', Auth::id(),
                                      ["return_id" => (int) $return_id, "receipt_no" => $or, "note" => "Paid at Assessment with the lost / damaged case"]);
                }
                $msg = "Payment recorded." . $clear;
            } elseif ($method === 'replaced') {
                if ($case['case_status'] !== 'Awaiting replacement') {
                    $conn->rollBack();
                    $this->out("error", "Choose \"replace with the newest edition\" for this case first.");
                    return;
                }
                if (empty($data['verified'])) {
                    $conn->rollBack();
                    $this->out("error", "Confirm that the copy is the newest edition with the same title and author.");
                    return;
                }
                $newest = $case['book_id'] ? BookVersions::newest($conn, (int) $case['book_id']) : null;
                if (!$newest) {
                    $conn->rollBack();
                    $this->out("error", "The book record could not be found.");
                    return;
                }
                list($newCopyId) = $this->addReplacementCopy($conn, $newest['book_id']);
                $conn->prepare("UPDATE book_return SET settlement = 'Replaced', book_price = NULL, processing_fee = 0, case_status = 'Settled',
                                       replacement_book_id = :b, replacement_copy_id = :c, settled_at = NOW(), settled_by_user_id = :u, case_note = :n
                                WHERE return_id = :id")
                     ->execute([":b" => $newest['book_id'], ":c" => $newCopyId, ":u" => Auth::id(), ":n" => $note, ":id" => $return_id]);
                $msg = "Replacement copy received and added to the library." . ($kind === 'student' ? " The borrower's clearance is cleared." : "");
            } elseif ($method === 'waived') {
                if (!$this->isAdmin()) {
                    $conn->rollBack();
                    $this->out("error", "Only the Technical Services Librarian can waive a charge.");
                    return;
                }
                if ($note === '') {
                    $conn->rollBack();
                    $this->out("error", "Write the reason for waiving the charge.");
                    return;
                }
                $conn->prepare("UPDATE book_return SET settlement = 'Waived', book_price = NULL, processing_fee = 0, case_status = 'Waived',
                                       settled_at = NOW(), settled_by_user_id = :u, case_note = :n WHERE return_id = :id")
                     ->execute([":u" => Auth::id(), ":n" => $note, ":id" => $return_id]);
                $msg = "Charge waived." . ($kind === 'student' ? " The borrower's clearance is cleared." : "");
            } elseif ($method === 'salary') {
                // A dean does not pay at Assessment and has no clearance to sign: the price and the processing
                // fee are deducted from his or her salary.
                if ($kind !== 'dean') {
                    $conn->rollBack();
                    $this->out("error", "Salary deduction applies to deans only.");
                    return;
                }
                if ($case['case_status'] !== 'Awaiting payment') {
                    $conn->rollBack();
                    $this->out("error", "Set the price first (it is filled in automatically when the book has one).");
                    return;
                }
                $conn->prepare("UPDATE book_return SET settlement = 'Salary deduction', case_status = 'Settled',
                                       settled_at = NOW(), settled_by_user_id = :u,
                                       case_note = CONCAT_WS(' ', NULLIF(case_note, ''), 'Deducted from salary.') WHERE return_id = :id")
                     ->execute([":u" => Auth::id(), ":id" => $return_id]);
                $msg = "Recorded as a salary deduction.";
            } else {
                $conn->rollBack();
                $this->out("error", "Choose how this case is settled.");
                return;
            }

            $conn->commit();
            $this->out("success", $msg);
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("book return settleCase failed: " . $e->getMessage());
            $this->out("error", "Failed to save. Nothing was changed.");
        }
    }

    function getAll() {
        include "../config/connection-pdo.php";

        $sql = "SELECT br.return_id,
                       br.item_id,
                       br.return_date,
                       br.condition_on_return,
                       b.title,
                       bc.accession_number,
                       bt.borrow_date,
                       CONCAT(s.first_name, ' ', s.last_name) AS student_name
                FROM book_return br
                LEFT JOIN borrow_items bi ON br.item_id = bi.item_id
                LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                LEFT JOIN book b ON bc.book_id = b.book_id
                LEFT JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                LEFT JOIN student s ON bt.student_id = s.student_id
                ORDER BY br.return_date DESC, br.return_id DESC";

        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rs);
    }

    // Single-book version of addMultiple, kept so older callers still get the same fine and lost/damaged rules.
    function add($json) {
        $data = json_decode($json, true) ?: [];
        $this->addMultiple(json_encode([
            "return_date" => $data['return_date'] ?? null,
            "payment_confirmed" => !empty($data['payment_confirmed']),
            "items" => [[
                "item_id" => $data['item_id'] ?? null,
                "condition_on_return" => $data['condition_on_return'] ?? "",
                "settlement" => $data['settlement'] ?? null
            ]]
        ]));
    }

    function update($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true) ?: [];

        $return_id = $json['return_id'] ?? null;
        $item_id = $json['item_id'] ?? null;
        $return_date = $json['return_date'] ?? null;
        $condition_on_return = trim($json['condition_on_return'] ?? "");

        if (empty($return_id) || empty($item_id) || empty($return_date) || empty($condition_on_return)) {
            $this->out("error", "All fields are required.");
            return;
        }

        $okCondition = null;
        foreach (['Good', 'Fair', 'Poor'] as $c) {
            if (strcasecmp($condition_on_return, $c) === 0) $okCondition = $c;
        }
        if ($okCondition === null) {
            $this->out("error", "Condition must be Good, Fair or Poor. A damaged or lost book is reported when it is returned, not edited afterwards.");
            return;
        }
        $condition_on_return = $okCondition;

        try {
            $conn->beginTransaction();

            $cur = $conn->prepare("SELECT item_id, condition_on_return, settlement, overdue_days, fine_amount
                                   FROM book_return WHERE return_id = :id FOR UPDATE");
            $cur->execute([":id" => $return_id]);
            $existing = $cur->fetch(PDO::FETCH_ASSOC);
            $old_item_id = $existing ? $existing['item_id'] : false;

            if ($old_item_id === false) {
                $conn->rollBack();
                $this->out("error", "Return record not found.");
                return;
            }

            if ($existing['settlement'] !== null || in_array($existing['condition_on_return'], ['Damaged', 'Lost'], true)) {
                $conn->rollBack();
                $this->out("error", "This book was reported damaged or lost and its charges are already recorded, so it can't be edited here.");
                return;
            }

            $item = $this->loadItem($conn, $item_id, true);

            if (!$item) {
                $conn->rollBack();
                $this->out("error", "Borrow item not found.");
                return;
            }

            $err = $this->dateError($return_date, $item['borrow_date']);
            if ($err) {
                $conn->rollBack();
                $this->out("error", $err);
                return;
            }

            if ((int) $old_item_id !== (int) $item_id) {
                $dupe = $conn->prepare("SELECT return_id FROM book_return WHERE item_id = :item_id AND return_id != :return_id LIMIT 1");
                $dupe->execute([":item_id" => $item_id, ":return_id" => $return_id]);

                if ($dupe->rowCount() > 0) {
                    $conn->rollBack();
                    $this->out("error", "This borrow item has already been returned.");
                    return;
                }

                // The return is moving to a different book: the old one goes back out, the new one comes in.
                $oldItem = $this->loadItem($conn, $old_item_id, true);
                if ($oldItem) {
                    $err = $this->markNotReturned($conn, $oldItem);
                    if ($err) {
                        $conn->rollBack();
                        $this->out("error", $err);
                        return;
                    }
                    $this->syncTransactionStatus($conn, $oldItem['transaction_id']);
                }

                $this->markReturned($conn, $item);
                $this->syncTransactionStatus($conn, $item['transaction_id']);
            }

            // The overdue fine follows the new return date, at the rate it was charged at.
            $rate = (int) $existing['overdue_days'] > 0
                ? (float) $existing['fine_amount'] / (int) $existing['overdue_days']
                : (float) LoanRules::all($conn)['fine_per_day']['value'];
            $days = $this->daysLate($item['due_date'], $return_date);
            $fine = round($days * $rate, 2);

            $stmt = $conn->prepare("UPDATE book_return
                                    SET item_id = :item_id, return_date = :return_date, condition_on_return = :condition_on_return,
                                        overdue_days = :days, fine_amount = :fine
                                    WHERE return_id = :return_id");
            $stmt->bindParam(":item_id", $item_id);
            $stmt->bindParam(":return_date", $return_date);
            $stmt->bindParam(":condition_on_return", $condition_on_return);
            $stmt->bindParam(":days", $days);
            $stmt->bindParam(":fine", $fine);
            $stmt->bindParam(":return_id", $return_id);
            $stmt->execute();

            // If the fine went down, whatever was already paid above it goes back to the borrower as advance payment.
            FinePayments::reconcileReturn($conn, (int) $return_id, $fine, Auth::id());

            $conn->prepare("UPDATE book_copies SET `condition` = :c WHERE copy_id = :id")
                 ->execute([":c" => $condition_on_return, ":id" => $item['copy_id']]);

            $conn->commit();
            $this->out("success", "Book return updated successfully.");
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("book return update failed: " . $e->getMessage());
            $this->out("error", "Failed to update book return.");
        }
    }

    function delete($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true) ?: [];
        $return_id = $json['return_id'] ?? null;

        if (empty($return_id)) {
            $this->out("error", "Return ID is required.");
            return;
        }

        try {
            $conn->beginTransaction();

            $cur = $conn->prepare("SELECT item_id, condition_on_return, settlement FROM book_return WHERE return_id = :id FOR UPDATE");
            $cur->execute([":id" => $return_id]);
            $row = $cur->fetch(PDO::FETCH_ASSOC);
            $item_id = $row ? $row['item_id'] : false;

            if ($item_id === false) {
                $conn->rollBack();
                $this->out("error", "Failed to delete book return.");
                return;
            }

            if ($row['settlement'] !== null || in_array($row['condition_on_return'], ['Damaged', 'Lost'], true)) {
                $conn->rollBack();
                $this->out("error", "A damaged or lost book can't be undone here: its charges are recorded and the copy is archived. If the book turns up, restore the copy from the Archive on the Book Copies page.");
                return;
            }

            // Deleting a return means the book is still out, so put the loan and copy back.
            $item = $this->loadItem($conn, $item_id, true);
            if ($item) {
                $err = $this->markNotReturned($conn, $item);
                if ($err) {
                    $conn->rollBack();
                    $this->out("error", $err);
                    return;
                }
            }

            FinePayments::releaseReturn($conn, (int) $return_id);
            $conn->prepare("DELETE FROM book_return WHERE return_id = :id")->execute([":id" => $return_id]);

            if ($item) {
                $this->syncTransactionStatus($conn, $item['transaction_id']);
            }

            $conn->commit();
            $this->out("success", "Book return deleted. The book is marked as borrowed again.");
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("book return delete failed: " . $e->getMessage());
            $this->out("error", "Failed to delete book return.");
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$obj = new BookReturn();

try {
    switch ($operation) {
        case "getAll":
            $obj->getAll();
            break;
        case "getBorrowers":
            $obj->getBorrowers();
            break;
        case "getBorrowerItems":
            $obj->getBorrowerItems();
            break;
        case "getCases":
            $obj->getCases();
            break;
        case "saveCase":
            $obj->saveCase($json);
            break;
        case "settleCase":
            $obj->settleCase($json);
            break;
        case "payAssessmentFine":
            $obj->payAssessmentFine($json);
            break;
        case "getReceipt":
            $obj->getReceipt();
            break;
        case "getHistory":
            $obj->getHistory();
            break;
        case "addMultiple":
            $obj->addMultiple($json);
            break;
        case "add":
            $obj->add($json);
            break;
        case "update":
            $obj->update($json);
            break;
        case "delete":
            $obj->delete($json);
            break;
    }
} catch (PDOException $e) {
    error_log("book_return.php: " . $e->getMessage());
    echo json_encode(["status" => "error", "message" => "Database error. Please try again."]);
}

?>