<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));

class Publisher {
    function getAll() {
        include "../config/connection-pdo.php";

        $sql = "SELECT publisher_id, publisher_name
                FROM publisher
                ORDER BY publisher_name ASC";

        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rs);
    }

    function add($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);
        $publisher_name = isset($json['publisher_name']) ? trim($json['publisher_name']) : "";

        if (empty($publisher_name)) {
            echo json_encode(["status" => "error", "message" => "Publisher name is required."]);
            return;
        }

        if (preg_match('/^[\d\s]+$/', $publisher_name)) {
            echo json_encode(["status" => "error", "message" => "Invalid publisher name."]);
            return;
        }

        $check = $conn->prepare("SELECT publisher_id FROM publisher WHERE publisher_name = :publisher_name");
        $check->bindParam(":publisher_name", $publisher_name);
        $check->execute();

        if ($check->rowCount() > 0) {
            echo json_encode(["status" => "error", "message" => "Publisher already exists."]);
            return;
        }

        lms_lock_ids($conn);

        $maxStmt = $conn->prepare("SELECT IFNULL(MAX(publisher_id), 0) + 1 AS nextId FROM publisher");
        $maxStmt->execute();
        $publisher_id = $maxStmt->fetch(PDO::FETCH_ASSOC)['nextId'];

        $sql = "INSERT INTO publisher (publisher_id, publisher_name)
                VALUES (:publisher_id, :publisher_name)";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":publisher_id", $publisher_id);
        $stmt->bindParam(":publisher_name", $publisher_name);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode(["status" => "success", "message" => "Publisher added successfully."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to add publisher."]);
        }
    }

    function update($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $publisher_id = (isset($json['publisher_id']) && $json['publisher_id'] !== '' && $json['publisher_id'] !== null)
            ? $json['publisher_id']
            : null;

        $publisher_name = isset($json['publisher_name']) ? trim($json['publisher_name']) : "";

        if ($publisher_id === null) {
            echo json_encode(["status" => "error", "message" => "Publisher ID is required."]);
            return;
        }

        if (empty($publisher_name)) {
            echo json_encode(["status" => "error", "message" => "Publisher name is required."]);
            return;
        }

        if (preg_match('/^[\d\s]+$/', $publisher_name)) {
            echo json_encode(["status" => "error", "message" => "Invalid publisher name."]);
            return;
        }

        $check = $conn->prepare("
            SELECT publisher_id
            FROM publisher
            WHERE publisher_name = :publisher_name
            AND publisher_id != :publisher_id
        ");

        $check->bindParam(":publisher_name", $publisher_name);
        $check->bindParam(":publisher_id", $publisher_id);
        $check->execute();

        if ($check->rowCount() > 0) {
            echo json_encode(["status" => "error", "message" => "Publisher already exists."]);
            return;
        }

        $sql = "UPDATE publisher
                SET publisher_name = :publisher_name
                WHERE publisher_id = :publisher_id";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":publisher_name", $publisher_name);
        $stmt->bindParam(":publisher_id", $publisher_id);
        $stmt->execute();

        echo json_encode(["status" => "success", "message" => "Publisher updated successfully."]);
    }

    function delete($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $publisher_id = (isset($json['publisher_id']) && $json['publisher_id'] !== '' && $json['publisher_id'] !== null)
            ? $json['publisher_id']
            : null;

        if ($publisher_id === null) {
            echo json_encode(["status" => "error", "message" => "Publisher ID is required."]);
            return;
        }

        $check = $conn->prepare("
            SELECT book_id
            FROM book
            WHERE publisher_id = :publisher_id
            LIMIT 1
        ");

        $check->bindParam(":publisher_id", $publisher_id);
        $check->execute();

        if ($check->rowCount() > 0) {
            echo json_encode(["status" => "error", "message" => "Cannot delete: this publisher is used by one or more books."]);
            return;
        }

        $sql = "DELETE FROM publisher WHERE publisher_id = :publisher_id";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":publisher_id", $publisher_id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode(["status" => "success", "message" => "Publisher deleted successfully."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to delete publisher."]);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$obj = new Publisher();

switch ($operation) {
    case "getAll":
        $obj->getAll();
        break;
    case "add":
        $obj->add($json);
        break;
    case "update":
        $obj->update($json);
        break;
    case "delete":
        $obj->delete($json);
        break;
}
?>