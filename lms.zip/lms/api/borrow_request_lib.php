<?php
// Shared by portal.php (a borrower asks to borrow) and borrow_request.php (the Technical Services Librarian or Library Staff approve or reject).
// A book is only ever recorded as borrowed by fulfil(), which only runs when the Technical Services Librarian or Library Staff approves.
require_once __DIR__ . "/loan_rules.php";

class BorrowRequests {

    // Created on first use. DDL commits, so call this before beginTransaction().
    static function ensureTable($conn) {
        $conn->exec("CREATE TABLE IF NOT EXISTS borrow_request (
                        request_id INT NOT NULL PRIMARY KEY,
                        student_id INT NOT NULL,
                        book_id INT NOT NULL,
                        requested_at DATETIME NOT NULL,
                        status VARCHAR(20) NOT NULL DEFAULT 'Pending',
                        decided_by_user_id INT NULL,
                        decided_at DATETIME NULL,
                        reason VARCHAR(255) NULL,
                        transaction_id INT NULL
                     )");
    }

    static function statusId($conn, $desc) {
        $s = $conn->prepare("SELECT status_id FROM status WHERE status_desc = :d LIMIT 1");
        $s->execute([":d" => $desc]);
        $id = $s->fetchColumn();
        return $id ? (int) $id : null;
    }

    static function pendingCount($conn, $sid, $exceptBook = null) {
        $sql = "SELECT COUNT(*) FROM borrow_request WHERE student_id = :s AND status = 'Pending'";
        $args = [":s" => $sid];
        if ($exceptBook !== null) { $sql .= " AND book_id != :b"; $args[":b"] = $exceptBook; }
        $s = $conn->prepare($sql);
        $s->execute($args);
        return (int) $s->fetchColumn();
    }

    static function reservedCount($conn, $sid, $exceptBook = null) {
        $sql = "SELECT COUNT(*) FROM reservation WHERE student_id = :s AND status IN ('Waiting', 'Ready')";
        $args = [":s" => $sid];
        if ($exceptBook !== null) { $sql .= " AND book_id != :b"; $args[":b"] = $exceptBook; }
        $s = $conn->prepare($sql);
        $s->execute($args);
        return (int) $s->fetchColumn();
    }

    // Records the borrow for an approved request: picks the copy (the borrower's own held copy first),
    // creates the transaction under the APPROVER's account, marks the copy Borrowed and the request Approved.
    // Returns ["ok" => bool, "message" => string, "due_date" => ?, "period" => ?].
    static function fulfil($conn, $sid, $book_id, $request_id, $approver_id) {
        $fail = function ($msg) use ($conn) {
            if ($conn->inTransaction()) $conn->rollBack();
            return ["ok" => false, "message" => $msg];
        };

        self::ensureTable($conn);
        lms_lock_ids($conn);

        try {
            $conn->beginTransaction();

            $req = $conn->prepare("SELECT status FROM borrow_request WHERE request_id = :id FOR UPDATE");
            $req->execute([":id" => $request_id]);
            if ($req->fetchColumn() !== 'Pending') return $fail("This request has already been handled.");

            $dupe = $conn->prepare("SELECT 1 FROM borrow_items bi
                                    INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                                    INNER JOIN book_copies bc ON bi.copy_id = bc.copy_id
                                    WHERE bt.student_id = :s AND bc.book_id = :b AND (bi.is_returned IS NULL OR bi.is_returned = 0) LIMIT 1");
            $dupe->execute([":s" => $sid, ":b" => $book_id]);
            if ($dupe->fetchColumn()) return $fail("This borrower already has this book borrowed.");

            $borrowedId = self::statusId($conn, 'Borrowed');
            if (!$borrowedId) return $fail("Borrowing isn't set up yet: the 'Borrowed' status is missing.");

            $myRes = $conn->prepare("SELECT reservation_id, copy_id FROM reservation
                                     WHERE student_id = :s AND book_id = :b AND status = 'Ready' AND copy_id IS NOT NULL
                                       AND expires_on >= CURDATE() LIMIT 1 FOR UPDATE");
            $myRes->execute([":s" => $sid, ":b" => $book_id]);
            $held = $myRes->fetch(PDO::FETCH_ASSOC);

            if ($held) {
                $copy_id = (int) $held['copy_id'];
            } else {
                $find = $conn->prepare("SELECT bc.copy_id FROM book_copies bc INNER JOIN status s ON bc.status_id = s.status_id
                                        WHERE bc.book_id = :b AND s.status_desc = 'Available'
                                        ORDER BY CAST(bc.accession_number AS UNSIGNED) ASC LIMIT 1 FOR UPDATE");
                $find->execute([":b" => $book_id]);
                $copy_id = (int) $find->fetchColumn();
                if (!$copy_id) return $fail("No copy is free right now, so this can't be approved yet. Reject it or try again when a copy is returned.");
            }

            // Limit: unreturned loans plus the borrower's other active reservations.
            $plan = LoanRules::plan($conn, $sid, [$copy_id]);
            $others = self::reservedCount($conn, $sid, $book_id);
            if ($plan['active'] + $others + 1 > $plan['limit']) {
                return $fail(sprintf("%s limit reached: at most %d books at a time, counting borrowed (%d) and reserved (%d) books.",
                    $plan['borrower_type'], $plan['limit'], $plan['active'], $others));
            }

            $txId = (int) $conn->query("SELECT IFNULL(MAX(transaction_id), 0) + 1 FROM borrow_transaction")->fetchColumn();
            $conn->prepare("INSERT INTO borrow_transaction (transaction_id, student_id, processed_by_user_id, borrow_date, due_date, status_id, created_at)
                            VALUES (:t, :s, :u, :bd, :dd, :st, NOW())")
                 ->execute([":t" => $txId, ":s" => $sid, ":u" => $approver_id, ":bd" => $plan['borrow_date'], ":dd" => $plan['due_date'], ":st" => $borrowedId]);

            $itemId = (int) $conn->query("SELECT IFNULL(MAX(item_id), 0) + 1 FROM borrow_items")->fetchColumn();
            $conn->prepare("INSERT INTO borrow_items (item_id, transaction_id, copy_id, due_date, is_returned) VALUES (:i, :t, :c, :d, 0)")
                 ->execute([":i" => $itemId, ":t" => $txId, ":c" => $copy_id, ":d" => $plan['due_date']]);

            $conn->prepare("UPDATE book_copies SET status_id = :st WHERE copy_id = :c")->execute([":st" => $borrowedId, ":c" => $copy_id]);

            // Their own reservations for this book are used up by borrowing it.
            $conn->prepare("UPDATE reservation SET status = :st, transaction_id = :t, updated_at = NOW()
                            WHERE student_id = :s AND book_id = :b AND status IN ('Waiting', 'Ready')")
                 ->execute([":st" => $held ? 'Fulfilled' : 'Cancelled', ":t" => $held ? $txId : null, ":s" => $sid, ":b" => $book_id]);

            $conn->prepare("UPDATE borrow_request SET status = 'Approved', decided_by_user_id = :u, decided_at = NOW(), transaction_id = :t
                            WHERE request_id = :id")
                 ->execute([":u" => $approver_id, ":t" => $txId, ":id" => $request_id]);

            $conn->commit();
            return ["ok" => true, "message" => "Approved.", "due_date" => $plan['due_date'], "period" => $plan['period_label']];
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("borrow request approve failed: " . $e->getMessage());
            return ["ok" => false, "message" => "Failed to approve the request."];
        }
    }
}
