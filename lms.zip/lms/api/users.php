<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
require_once __DIR__ . "/account_standing.php";
Auth::guard(basename(__FILE__, '.php'));

// People page: login accounts AND the borrower record (address, course) of Students, Faculty and Deans.
// Creating a user with a Student, Faculty or Dean role also creates the linked borrower record, so there is
// one place to manage everyone. Borrowers without a login (older records) are listed too, with "No login".
class Users {

    private function reply($status, $message) {
        echo json_encode(["status" => $status, "message" => $message]);
    }

    private function str($json, $key) {
        return isset($json[$key]) ? trim((string) $json[$key]) : "";
    }

    private function idOrNull($json, $key) {
        return (isset($json[$key]) && $json[$key] !== '' && $json[$key] !== null) ? $json[$key] : null;
    }

    // student | faculty | dean for a borrower role; null for the Technical Services Librarian, Library Staff, Student Assistant and anything else.
    private function borrowerKind($roleName) {
        $r = strtolower(trim((string) $roleName));
        if ($r === '') return null;
        if (strpos($r, 'faculty') !== false) return 'faculty';
        if ($r === 'dean') return 'dean';
        if ($r === 'student') return 'student';
        return null;
    }

    // Server-side checks. The form checks the same things, but the API must not trust the browser.
    private function problem($first, $last, $contact, $email, $username, $password, $checkUsername) {
        $name = "/^[\p{L}\p{M}][\p{L}\p{M}' .-]{0,49}$/u";

        if (!preg_match($name, $first)) return "First name can only contain letters, spaces, apostrophes, dots and hyphens.";
        if (!preg_match($name, $last))  return "Last name can only contain letters, spaces, apostrophes, dots and hyphens.";
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return "Please enter a valid email address.";
        if (!preg_match('/^0\d{10}$/', $contact) && !preg_match('/^[1-9]\d{9}$/', $contact)) {
            return "Contact number must be 11 digits (e.g. 09171234567) or 10 digits without the leading 0.";
        }
        if ($checkUsername && !preg_match('/^[A-Za-z0-9._-]{3,30}$/', $username)) {
            return "Username must be 3-30 characters: letters, numbers, dot, dash or underscore.";
        }
        if ($password !== '' && strlen($password) < 8) return "Password must be at least 8 characters.";

        return null;
    }

    private function borrowerProblem($kind, $address, $course) {
        if (!preg_match('/[A-Za-z]/', $address)) return "Address is required for students, faculty and deans.";
        if ($kind === 'student' && !preg_match('/[A-Za-z]/', $course)) return "Course is required for students (e.g. BSIT).";
        return null;
    }

    private function roleName($conn, $role_id) {
        $s = $conn->prepare("SELECT role_name FROM roles WHERE role_id = :id");
        $s->execute([":id" => $role_id]);
        return $s->fetchColumn();
    }

    private function deptName($conn, $department_id) {
        $s = $conn->prepare("SELECT department_name FROM department WHERE department_id = :id");
        $s->execute([":id" => $department_id]);
        return $s->fetchColumn();
    }

    private function emailTaken($conn, $email, $exceptStudentId = null) {
        $s = $conn->prepare("SELECT student_id FROM student WHERE email = :e AND student_id != :id LIMIT 1");
        $s->execute([":e" => $email, ":id" => $exceptStudentId ?? 0]);
        return $s->fetchColumn() !== false;
    }

    private function insertStudent($conn, $user_id, $first, $last, $email, $phone, $address, $course) {
        lms_lock_ids($conn);
        $id = (int) $conn->query("SELECT IFNULL(MAX(student_id), 0) + 1 FROM student")->fetchColumn();

        $conn->prepare("INSERT INTO student (student_id, user_id, first_name, last_name, email, phone, address, course, created_at, updated_at)
                        VALUES (:id, :u, :f, :l, :e, :p, :a, :c, NOW(), NOW())")
             ->execute([":id" => $id, ":u" => $user_id, ":f" => $first, ":l" => $last, ":e" => $email,
                        ":p" => $phone, ":a" => $address, ":c" => $course]);
        return $id;
    }

    // Why a borrower can't be deleted (null when they can).
    private function deleteBlock($conn, $student_id) {
        $t = $conn->prepare("SELECT transaction_id FROM borrow_transaction WHERE student_id = :s LIMIT 1");
        $t->execute([":s" => $student_id]);
        if ($t->fetchColumn() !== false) return "Cannot delete: this person has existing borrow transactions.";

        try {
            $r = $conn->prepare("SELECT reservation_id FROM reservation WHERE student_id = :s AND status IN ('Pending', 'Waiting', 'Ready') LIMIT 1");
            $r->execute([":s" => $student_id]);
            if ($r->fetchColumn() !== false) return "Cannot delete: this person has an active book reservation. Cancel it first.";
        } catch (PDOException $e) {
            // reservation table not created yet
        }

        return null;
    }

    function getAll() {
        include "../config/connection-pdo.php";

        $rows = $conn->query("SELECT u.user_id, u.role_id, u.department_id,
                                     u.first_name, u.last_name, u.contact_number,
                                     u.email, u.username, u.account_status, r.role_name, d.department_name,
                                     s.student_id, s.address, s.course
                              FROM users u
                              LEFT JOIN roles r ON u.role_id = r.role_id
                              LEFT JOIN department d ON u.department_id = d.department_id
                              LEFT JOIN student s ON s.user_id = u.user_id")->fetchAll(PDO::FETCH_ASSOC);

        // Borrowers that have no login account yet.
        $studentRole = $conn->query("SELECT role_id FROM roles WHERE LOWER(TRIM(role_name)) = 'student' LIMIT 1")->fetchColumn();
        $orphans = $conn->query("SELECT student_id, first_name, last_name, email, phone, address, course
                                 FROM student WHERE user_id IS NULL")->fetchAll(PDO::FETCH_ASSOC);

        foreach ($orphans as $o) {
            $rows[] = [
                "user_id" => null, "role_id" => $studentRole === false ? null : (int) $studentRole, "department_id" => null,
                "first_name" => $o['first_name'], "last_name" => $o['last_name'], "contact_number" => $o['phone'],
                "email" => $o['email'], "username" => "", "account_status" => "no_login", "role_name" => "Student",
                "department_name" => "", "student_id" => $o['student_id'], "address" => $o['address'], "course" => $o['course'],
            ];
        }

        // What each borrower owes in fines and charges (0 for everyone else).
        $owed = AccountStanding::balances($conn);
        foreach ($rows as &$r) {
            $r['fine_balance'] = !empty($r['student_id']) ? (float) ($owed[(int) $r['student_id']] ?? 0) : 0.0;
        }
        unset($r);

        usort($rows, function ($a, $b) {
            return strcasecmp($a['first_name'] . ' ' . $a['last_name'], $b['first_name'] . ' ' . $b['last_name']);
        });

        echo json_encode($rows);
    }

    function add($json) {
        include "../config/connection-pdo.php";
        $json = json_decode($json, true) ?: [];

        $role_id = $this->idOrNull($json, 'role_id');
        $department_id = $this->idOrNull($json, 'department_id');
        $first = $this->str($json, 'first_name');
        $last = $this->str($json, 'last_name');
        $contact = $this->str($json, 'contact_number');
        $email = $this->str($json, 'email');
        $username = $this->str($json, 'username');
        $password = $this->str($json, 'password');
        $address = $this->str($json, 'address');
        $course = $this->str($json, 'course');

        if ($role_id === null || $first === '' || $last === '' || $contact === '' ||
            $email === '' || $username === '' || $password === '') {
            $this->reply("error", "All fields are required.");
            return;
        }

        $problem = $this->problem($first, $last, $contact, $email, $username, $password, true);
        if ($problem) { $this->reply("error", $problem); return; }

        $roleName = $this->roleName($conn, $role_id);
        if ($roleName === false) { $this->reply("error", "The selected role was not found."); return; }
        $kind = $this->borrowerKind($roleName);

        // Only borrowers must have a department. Librarian, Library Staff and Student Assistant accounts may have none.
        if ($kind && $department_id === null) { $this->reply("error", "Department is required for students, faculty and deans."); return; }

        if ($kind) {
            $problem = $this->borrowerProblem($kind, $address, $course);
            if ($problem) { $this->reply("error", $problem); return; }
            if ($this->emailTaken($conn, $email)) { $this->reply("error", "That email is already used by another borrower."); return; }
        }

        $check = $conn->prepare("SELECT user_id FROM users WHERE username = :u");
        $check->execute([":u" => $username]);
        if ($check->fetchColumn() !== false) { $this->reply("error", "Username already exists."); return; }

        try {
            $conn->beginTransaction();

            $conn->prepare("INSERT INTO users (role_id, department_id, first_name, last_name, contact_number, email,
                                               username, password, account_status, created_at, updated_at)
                            VALUES (:r, :d, :f, :l, :c, :e, :u, :p, 'active', NOW(), NOW())")
                 ->execute([":r" => $role_id, ":d" => $department_id, ":f" => $first, ":l" => $last, ":c" => $contact,
                            ":e" => $email, ":u" => $username, ":p" => password_hash($password, PASSWORD_DEFAULT)]);
            $user_id = (int) $conn->lastInsertId();

            if ($kind) {
                // Faculty and deans have no course: their department is shown there instead.
                if ($kind !== 'student') $course = (string) $this->deptName($conn, $department_id);
                $this->insertStudent($conn, $user_id, $first, $last, $email, $contact, $address, $course);
            }

            $conn->commit();
            $this->reply("success", "User added successfully.");
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("user add failed: " . $e->getMessage());
            $this->reply("error", "Failed to add the user.");
        }
    }

    function update($json) {
        include "../config/connection-pdo.php";
        $json = json_decode($json, true) ?: [];

        $user_id = $this->idOrNull($json, 'user_id');
        $role_id = $this->idOrNull($json, 'role_id');
        $department_id = $this->idOrNull($json, 'department_id');
        $first = $this->str($json, 'first_name');
        $last = $this->str($json, 'last_name');
        $contact = $this->str($json, 'contact_number');
        $email = $this->str($json, 'email');
        $username = $this->str($json, 'username');
        $password = $this->str($json, 'password');
        $address = $this->str($json, 'address');
        $course = $this->str($json, 'course');

        if ($user_id === null) { $this->reply("error", "User ID is required."); return; }

        if ($role_id === null || $first === '' || $last === '' || $contact === '' ||
            $email === '' || $username === '') {
            $this->reply("error", "All fields are required.");
            return;
        }

        $cur = $conn->prepare("SELECT u.username, r.role_name FROM users u LEFT JOIN roles r ON u.role_id = r.role_id WHERE u.user_id = :id");
        $cur->execute([":id" => $user_id]);
        $current = $cur->fetch(PDO::FETCH_ASSOC);
        if (!$current) { $this->reply("error", "User not found."); return; }

        $problem = $this->problem($first, $last, $contact, $email, $username, $password, $username !== $current['username']);
        if ($problem) { $this->reply("error", $problem); return; }

        $newRoleName = $this->roleName($conn, $role_id);
        if ($newRoleName === false) { $this->reply("error", "The selected role was not found."); return; }

        // Changing an Admin to another role must never leave the system without an active Admin.
        $wasAdmin = Auth::roleKey($current['role_name']) === 'admin';
        $staysAdmin = Auth::roleKey($newRoleName) === 'admin';

        if ($wasAdmin && !$staysAdmin) {
            if ((int) $user_id === Auth::id()) { $this->reply("error", "You can't remove the Technical Services Librarian role from your own account."); return; }

            $others = $conn->prepare("SELECT COUNT(*) FROM users u INNER JOIN roles r ON u.role_id = r.role_id
                                      WHERE " . Auth::adminSql('r.role_name') . " AND u.account_status = 'active' AND u.user_id != :id");
            $others->execute([":id" => $user_id]);
            if ((int) $others->fetchColumn() === 0) { $this->reply("error", "This is the last active Technical Services Librarian. Make another user a Technical Services Librarian first."); return; }
        }

        // Borrower record linked to this account, if any.
        $st = $conn->prepare("SELECT student_id FROM student WHERE user_id = :id LIMIT 1");
        $st->execute([":id" => $user_id]);
        $student_id = $st->fetchColumn();

        $kind = $this->borrowerKind($newRoleName);

        if ($kind && $department_id === null) { $this->reply("error", "Department is required for students, faculty and deans."); return; }

        if ($student_id !== false && !$kind) {
            $this->reply("error", "This person is a borrower. Keep the role as Student, Faculty or Dean, or delete the person instead.");
            return;
        }

        if ($kind) {
            $problem = $this->borrowerProblem($kind, $address, $course);
            if ($problem) { $this->reply("error", $problem); return; }
            if ($this->emailTaken($conn, $email, $student_id === false ? null : $student_id)) {
                $this->reply("error", "That email is already used by another borrower.");
                return;
            }
        }

        $dupe = $conn->prepare("SELECT user_id FROM users WHERE username = :u AND user_id != :id");
        $dupe->execute([":u" => $username, ":id" => $user_id]);
        if ($dupe->fetchColumn() !== false) { $this->reply("error", "Username already taken by another user."); return; }

        try {
            $conn->beginTransaction();

            $sql = "UPDATE users SET role_id = :r, department_id = :d, first_name = :f, last_name = :l,
                        contact_number = :c, email = :e, username = :u, updated_at = NOW()";
            $args = [":r" => $role_id, ":d" => $department_id, ":f" => $first, ":l" => $last, ":c" => $contact,
                     ":e" => $email, ":u" => $username, ":id" => $user_id];
            if ($password !== '') {
                $sql .= ", password = :p";
                $args[":p"] = password_hash($password, PASSWORD_DEFAULT);
            }
            $conn->prepare($sql . " WHERE user_id = :id")->execute($args);

            if ($kind) {
                if ($kind !== 'student') $course = (string) $this->deptName($conn, $department_id);

                if ($student_id !== false) {
                    $conn->prepare("UPDATE student SET first_name = :f, last_name = :l, email = :e, phone = :p,
                                    address = :a, course = :c, updated_at = NOW() WHERE student_id = :id")
                         ->execute([":f" => $first, ":l" => $last, ":e" => $email, ":p" => $contact,
                                    ":a" => $address, ":c" => $course, ":id" => $student_id]);
                } else {
                    $this->insertStudent($conn, $user_id, $first, $last, $email, $contact, $address, $course);
                }
            }

            $conn->commit();
            $this->reply("success", "User updated successfully.");
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("user update failed: " . $e->getMessage());
            $this->reply("error", "Failed to update the user.");
        }
    }

    // Edit a borrower who has no login. Filling in a username and password gives them one.
    function updateBorrower($json) {
        include "../config/connection-pdo.php";
        $json = json_decode($json, true) ?: [];

        $student_id = $this->idOrNull($json, 'student_id');
        $first = $this->str($json, 'first_name');
        $last = $this->str($json, 'last_name');
        $contact = $this->str($json, 'contact_number');
        $email = $this->str($json, 'email');
        $address = $this->str($json, 'address');
        $course = $this->str($json, 'course');
        $username = $this->str($json, 'username');
        $password = $this->str($json, 'password');
        $role_id = $this->idOrNull($json, 'role_id');
        $department_id = $this->idOrNull($json, 'department_id');

        if ($student_id === null) { $this->reply("error", "Borrower ID is required."); return; }
        if ($first === '' || $last === '' || $contact === '' || $email === '') { $this->reply("error", "All fields are required."); return; }

        $creating = $username !== '' || $password !== '';
        $kind = 'student';
        $roleName = false;

        if ($creating) {
            if ($username === '' || $password === '' || $role_id === null || $department_id === null) {
                $this->reply("error", "To give them a login, fill in the role, department, username and password.");
                return;
            }
            $roleName = $this->roleName($conn, $role_id);
            $kind = $roleName === false ? null : $this->borrowerKind($roleName);
            if (!$kind) { $this->reply("error", "A borrower's role must be Student, Faculty or Dean."); return; }
        }

        $problem = $this->problem($first, $last, $contact, $email, $username, $password, $creating);
        if ($problem) { $this->reply("error", $problem); return; }

        $problem = $this->borrowerProblem($kind, $address, $course);
        if ($problem) { $this->reply("error", $problem); return; }

        if ($this->emailTaken($conn, $email, $student_id)) { $this->reply("error", "That email is already used by another borrower."); return; }

        if ($creating) {
            $dupe = $conn->prepare("SELECT user_id FROM users WHERE username = :u");
            $dupe->execute([":u" => $username]);
            if ($dupe->fetchColumn() !== false) { $this->reply("error", "Username already exists."); return; }
        }

        try {
            $conn->beginTransaction();
            $user_id = null;

            if ($creating) {
                if ($kind !== 'student') $course = (string) $this->deptName($conn, $department_id);

                $conn->prepare("INSERT INTO users (role_id, department_id, first_name, last_name, contact_number, email,
                                                   username, password, account_status, created_at, updated_at)
                                VALUES (:r, :d, :f, :l, :c, :e, :u, :p, 'active', NOW(), NOW())")
                     ->execute([":r" => $role_id, ":d" => $department_id, ":f" => $first, ":l" => $last, ":c" => $contact,
                                ":e" => $email, ":u" => $username, ":p" => password_hash($password, PASSWORD_DEFAULT)]);
                $user_id = (int) $conn->lastInsertId();
            }

            $conn->prepare("UPDATE student SET first_name = :f, last_name = :l, email = :e, phone = :p, address = :a, course = :c,
                                   user_id = IFNULL(:u, user_id), updated_at = NOW() WHERE student_id = :id")
                 ->execute([":f" => $first, ":l" => $last, ":e" => $email, ":p" => $contact, ":a" => $address,
                            ":c" => $course, ":u" => $user_id, ":id" => $student_id]);

            $conn->commit();
            $this->reply("success", $creating ? "Login created for this borrower." : "Borrower updated successfully.");
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("borrower update failed: " . $e->getMessage());
            $this->reply("error", "Failed to update the borrower.");
        }
    }

    // Sends a borrower an itemised statement of what they owe to their account inbox in the portal,
    // with an optional photo or PDF of the Assessment receipt attached. The amounts are worked out here, never taken from the browser.
    function sendStatement($json) {
        include "../config/connection-pdo.php";
        $json = json_decode($json, true) ?: [];

        $student_id = (int) ($json['student_id'] ?? 0);
        $note = mb_substr(trim((string) ($json['note'] ?? '')), 0, 500);

        $st = $conn->prepare("SELECT student_id, first_name FROM student WHERE student_id = :s");
        $st->execute([":s" => $student_id]);
        $student = $st->fetch(PDO::FETCH_ASSOC);
        if (!$student) { $this->reply("error", "Borrower not found."); return; }

        $bal = AccountStanding::balance($conn, $student_id);
        if ($bal['total'] <= 0) { $this->reply("error", "This borrower has no balance to send."); return; }

        // Optional attachment: judged by what the file really is, stored where only api/proof_file.php can serve it.
        $stored = null; $shownName = null; $mime = null;
        $f = $_FILES['receipt'] ?? null;
        if (empty($_FILES) && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) { $this->reply("error", "That file is too big for this server. Send a smaller photo (under 2 MB)."); return; }
        if ($f && $f['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($f['error'] !== UPLOAD_ERR_OK || $f['size'] > 2 * 1024 * 1024 || !is_uploaded_file($f['tmp_name'])) { $this->reply("error", "The file is too big (2 MB max) or the upload failed."); return; }
            $types = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'application/pdf' => 'pdf'];
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
            if (!isset($types[$mime])) { $this->reply("error", "Only a photo (JPG, PNG, WEBP) or a PDF can be attached."); return; }
            if ($mime !== 'application/pdf' && @getimagesize($f['tmp_name']) === false) { $this->reply("error", "That image can't be read. Try another photo."); return; }

            $dir = __DIR__ . "/../uploads/proofs";
            if (!is_dir($dir) && !@mkdir($dir, 0775, true)) { $this->reply("error", "The server can't store files right now."); return; }
            $stored = bin2hex(random_bytes(16)) . "." . $types[$mime];
            if (!move_uploaded_file($f['tmp_name'], "$dir/$stored")) { $this->reply("error", "The upload failed. Please try again."); return; }
            $shownName = substr(preg_replace('/[^A-Za-z0-9._ -]/', '_', basename((string) $f['name'])), 0, 150);
        }

        $lines = [];
        foreach ($bal['lines'] as $l) {
            $lines[] = "• " . $l['label'] . ($l['amount'] != 0 ? ": " . ($l['amount'] < 0 ? "-" : "") . "₱" . number_format(abs($l['amount']), 2) : "");
        }
        $body = "Hello " . $student['first_name'] . ",\n\nThis is your statement of fines and charges as of " . date('F j, Y') . ":\n"
              . implode("\n", $lines) . "\n\nTotal balance: ₱" . number_format($bal['total'], 2)
              . "\n\nOverdue fines keep growing every day until the book is returned. Please pay at the library desk and keep your receipt."
              . " You can send us a photo of your receipt from your account once you have paid."
              . ($note !== '' ? "\n\nNote from the librarian: " . $note : "");

        $conn->prepare("INSERT INTO student_message (student_id, sender_user_id, kind, subject, body, created_at, attachment_path, attachment_name, attachment_mime)
                        VALUES (:s, :u, 'statement', :subj, :body, NOW(), :p, :n, :m)")
             ->execute([":s" => $student_id, ":u" => Auth::id(), ":subj" => "Statement of fines and charges: ₱" . number_format($bal['total'], 2),
                        ":body" => $body, ":p" => $stored, ":n" => $shownName, ":m" => $mime]);

        $this->reply("success", "Statement sent. The borrower will see it in their account.");
    }

    // Sign-ups waiting for the Technical Services Librarian to approve them, oldest first.
    function getPending() {
        include "../config/connection-pdo.php";

        $stmt = $conn->prepare("SELECT u.user_id, u.first_name, u.last_name, u.username, u.email,
                                       u.contact_number, u.created_at, d.department_name, r.role_name
                                FROM users u
                                LEFT JOIN department d ON u.department_id = d.department_id
                                LEFT JOIN roles r ON u.role_id = r.role_id
                                WHERE u.account_status = 'pending'
                                ORDER BY u.created_at ASC, u.user_id ASC");
        $stmt->execute();
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Approve a pending sign-up, or deactivate / activate an account.
    function setStatus($json) {
        include "../config/connection-pdo.php";
        $json = json_decode($json, true) ?: [];
        $user_id = $json['user_id'] ?? null;
        $status = $json['account_status'] ?? '';

        if ($user_id === null || $user_id === '' || !in_array($status, ['active', 'disabled'], true)) {
            $this->reply("error", "User and a valid status are required.");
            return;
        }

        if ((int) $user_id === Auth::id()) { $this->reply("error", "You can't change the status of your own account."); return; }

        $conn->prepare("UPDATE users SET account_status = :s, updated_at = NOW() WHERE user_id = :id")
             ->execute([":s" => $status, ":id" => $user_id]);

        $isSa = false;
        $rn = $conn->prepare("SELECT r.role_name FROM users u LEFT JOIN roles r ON u.role_id = r.role_id WHERE u.user_id = :id");
        $rn->execute([":id" => $user_id]);
        $isSa = Auth::roleKey($rn->fetchColumn()) === 'sa';

        $who = $isSa ? "Student Assistant account" : "Account";
        $this->reply("success", $status === 'active' ? "$who activated." : "$who deactivated. They are signed out and can't log in until you activate it again.");
    }

    function delete($json) {
        include "../config/connection-pdo.php";
        $json = json_decode($json, true) ?: [];

        $user_id = $this->idOrNull($json, 'user_id');
        if ($user_id === null) { $this->reply("error", "User ID is required."); return; }

        if ((int) $user_id === Auth::id()) { $this->reply("error", "You can't delete the account you are signed in with."); return; }

        // Keep the record of who processed what: a user who appears in any borrow,
        // reservation or return can't be deleted.
        foreach (["borrow_transaction", "reservation", "book_return"] as $table) {
            try {
                $check = $conn->prepare("SELECT 1 FROM $table WHERE processed_by_user_id = :u LIMIT 1");
                $check->execute([":u" => $user_id]);

                if ($check->fetchColumn() !== false) {
                    $this->reply("error", "Cannot delete: this user has processed borrow transactions, reservations or returns.");
                    return;
                }
            } catch (PDOException $e) {
                // table or column not created yet - nothing to protect
            }
        }

        // A borrower's record goes together with their account, under the same rules as deleting a borrower.
        $st = $conn->prepare("SELECT student_id FROM student WHERE user_id = :u");
        $st->execute([":u" => $user_id]);
        $studentIds = $st->fetchAll(PDO::FETCH_COLUMN);

        foreach ($studentIds as $sid) {
            $block = $this->deleteBlock($conn, $sid);
            if ($block) { $this->reply("error", $block); return; }
        }

        try {
            $conn->beginTransaction();
            foreach ($studentIds as $sid) {
                $conn->prepare("DELETE FROM student WHERE student_id = :s")->execute([":s" => $sid]);
            }
            $del = $conn->prepare("DELETE FROM users WHERE user_id = :u");
            $del->execute([":u" => $user_id]);
            $conn->commit();

            $this->reply($del->rowCount() > 0 ? "success" : "error",
                         $del->rowCount() > 0 ? "User deleted successfully." : "Failed to delete user.");
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("user delete failed: " . $e->getMessage());
            $this->reply("error", "Failed to delete the user.");
        }
    }

    // Delete a borrower who has no login.
    function deleteBorrower($json) {
        include "../config/connection-pdo.php";
        $json = json_decode($json, true) ?: [];

        $student_id = $this->idOrNull($json, 'student_id');
        if ($student_id === null) { $this->reply("error", "Borrower ID is required."); return; }

        $link = $conn->prepare("SELECT user_id FROM student WHERE student_id = :s");
        $link->execute([":s" => $student_id]);
        if ($link->fetchColumn()) { $this->reply("error", "This person has a login. Delete them as a user instead."); return; }

        $block = $this->deleteBlock($conn, $student_id);
        if ($block) { $this->reply("error", $block); return; }

        $del = $conn->prepare("DELETE FROM student WHERE student_id = :s");
        $del->execute([":s" => $student_id]);

        $this->reply($del->rowCount() > 0 ? "success" : "error",
                     $del->rowCount() > 0 ? "Borrower deleted successfully." : "Failed to delete the borrower.");
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$obj = new Users();

switch ($operation) {
    case "getAll":         $obj->getAll(); break;
    case "add":            $obj->add($json); break;
    case "update":         $obj->update($json); break;
    case "updateBorrower": $obj->updateBorrower($json); break;
    case "getPending":     $obj->getPending(); break;
    case "sendStatement":  $obj->sendStatement($json); break;
    case "setStatus":      $obj->setStatus($json); break;
    case "delete":         $obj->delete($json); break;
    case "deleteBorrower": $obj->deleteBorrower($json); break;
}
?>
