<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));

class BookAuthor {
    function getAll() {
        include "../config/connection-pdo.php";

        $sql = "SELECT ba.book_id,
                       b.title AS book_title,
                       ba.author_id,
                       CONCAT(a.first_name, ' ', a.last_name) AS author_name
                FROM book_author ba
                INNER JOIN book b ON ba.book_id = b.book_id
                INNER JOIN author a ON ba.author_id = a.author_id
                ORDER BY b.title ASC, a.first_name ASC, a.last_name ASC";

        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rs);
    }

    function add($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $book_id = (isset($json['book_id']) && $json['book_id'] !== '' && $json['book_id'] !== null)
            ? $json['book_id']
            : null;

        $author_id = (isset($json['author_id']) && $json['author_id'] !== '' && $json['author_id'] !== null)
            ? $json['author_id']
            : null;

        if ($book_id === null || $author_id === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Book and author are required."
            ]);
            return;
        }

        $check = $conn->prepare("
            SELECT book_id
            FROM book_author
            WHERE book_id = :book_id
            AND author_id = :author_id
        ");

        $check->bindParam(":book_id", $book_id);
        $check->bindParam(":author_id", $author_id);
        $check->execute();

        if ($check->rowCount() > 0) {
            echo json_encode([
                "status" => "error",
                "message" => "This book and author are already linked."
            ]);
            return;
        }

        $sql = "INSERT INTO book_author (book_id, author_id)
                VALUES (:book_id, :author_id)";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":book_id", $book_id);
        $stmt->bindParam(":author_id", $author_id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode([
                "status" => "success",
                "message" => "Book author added successfully."
            ]);
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "Failed to add book author."
            ]);
        }
    }

    function update($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $old_book_id = (isset($json['old_book_id']) && $json['old_book_id'] !== '' && $json['old_book_id'] !== null)
            ? $json['old_book_id']
            : null;

        $old_author_id = (isset($json['old_author_id']) && $json['old_author_id'] !== '' && $json['old_author_id'] !== null)
            ? $json['old_author_id']
            : null;

        $book_id = (isset($json['book_id']) && $json['book_id'] !== '' && $json['book_id'] !== null)
            ? $json['book_id']
            : null;

        $author_id = (isset($json['author_id']) && $json['author_id'] !== '' && $json['author_id'] !== null)
            ? $json['author_id']
            : null;

        if ($old_book_id === null || $old_author_id === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Original book and author are required."
            ]);
            return;
        }

        if ($book_id === null || $author_id === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Book and author are required."
            ]);
            return;
        }

        if ($old_book_id != $book_id || $old_author_id != $author_id) {
            $check = $conn->prepare("
                SELECT book_id
                FROM book_author
                WHERE book_id = :book_id
                AND author_id = :author_id
            ");

            $check->bindParam(":book_id", $book_id);
            $check->bindParam(":author_id", $author_id);
            $check->execute();

            if ($check->rowCount() > 0) {
                echo json_encode([
                    "status" => "error",
                    "message" => "This book and author are already linked."
                ]);
                return;
            }
        }

        $sql = "UPDATE book_author
                SET book_id = :book_id,
                    author_id = :author_id
                WHERE book_id = :old_book_id
                AND author_id = :old_author_id";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":book_id", $book_id);
        $stmt->bindParam(":author_id", $author_id);
        $stmt->bindParam(":old_book_id", $old_book_id);
        $stmt->bindParam(":old_author_id", $old_author_id);
        $stmt->execute();

        echo json_encode([
            "status" => "success",
            "message" => "Book author updated successfully."
        ]);
    }

    function delete($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $book_id = (isset($json['book_id']) && $json['book_id'] !== '' && $json['book_id'] !== null)
            ? $json['book_id']
            : null;

        $author_id = (isset($json['author_id']) && $json['author_id'] !== '' && $json['author_id'] !== null)
            ? $json['author_id']
            : null;

        if ($book_id === null || $author_id === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Book and author are required."
            ]);
            return;
        }

        $sql = "DELETE FROM book_author
                WHERE book_id = :book_id
                AND author_id = :author_id";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":book_id", $book_id);
        $stmt->bindParam(":author_id", $author_id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode([
                "status" => "success",
                "message" => "Book author deleted successfully."
            ]);
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "Failed to delete book author."
            ]);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$obj = new BookAuthor();

try {
    switch ($operation) {
        case "getAll":
            $obj->getAll();
            break;
        case "add":
            $obj->add($json);
            break;
        case "update":
            $obj->update($json);
            break;
        case "delete":
            $obj->delete($json);
            break;
    }
} catch (PDOException $e) {
    // Always answer with JSON so the page can show what the database rejected.
    echo json_encode([
        "status" => "error",
        "message" => "Database error: " . $e->getMessage()
    ]);
}
?>