<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
require_once __DIR__ . "/account_standing.php";
require_once __DIR__ . "/fine_payments.php";
Auth::guard(basename(__FILE__, '.php'));

// Borrowers who need attention (overdue or blacklisted) and messages to borrowers.
// Library Staff can see the list and send messages. Blacklisting and lifting a blacklist are for the
// Technical Services Librarian only (those operations are not in Auth::STAFF_OPS).
class AccountHolds {

    private function reply($status, $message, $extra = []) {
        echo json_encode(array_merge(["status" => $status, "message" => $message], $extra));
    }

    private function borrowerSql() {
        return "SELECT s.student_id, CONCAT_WS(' ', s.first_name, s.last_name) AS name,
                       CASE WHEN (LOWER(IFNULL(r.role_name, '')) LIKE '%faculty%' OR LOWER(IFNULL(r.role_name, '')) LIKE '%dean%')
                            THEN IFNULL(r.role_name, 'Faculty') ELSE 'Student' END AS borrower_type
                FROM student s
                LEFT JOIN users u ON s.user_id = u.user_id
                LEFT JOIN roles r ON u.role_id = r.role_id";
    }

    // Everyone who is overdue or blacklisted, worst first.
    function getAll() {
        include "../config/connection-pdo.php";

        AccountStanding::sweep($conn);   // blacklists anyone past the limit and sends today's reminders

        $ids = $conn->query("SELECT DISTINCT bt.student_id
                             FROM borrow_items bi
                             INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                             LEFT JOIN book_return br ON br.item_id = bi.item_id
                             WHERE br.return_id IS NULL AND (bi.is_returned IS NULL OR bi.is_returned = 0)
                               AND COALESCE(bi.due_date, bt.due_date) < CURDATE() AND bt.student_id IS NOT NULL
                             UNION
                             SELECT student_id FROM student WHERE blacklisted_at IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);

        $people = $conn->prepare($this->borrowerSql() . " WHERE s.student_id = :id");
        $last = $conn->prepare("SELECT created_at, kind FROM student_message WHERE student_id = :id ORDER BY created_at DESC, message_id DESC LIMIT 1");
        $unread = $conn->prepare("SELECT COUNT(*) FROM student_message WHERE student_id = :id AND read_at IS NULL AND from_borrower = 0");
        // Proofs of payment the borrower sent: how many in all, and how many nobody has looked at yet.
        $proofs = $conn->prepare("SELECT COUNT(*) AS total, SUM(read_at IS NULL) AS fresh FROM student_message
                                  WHERE student_id = :id AND from_borrower = 1 AND attachment_path IS NOT NULL");

        $out = [];
        foreach ($ids as $id) {
            $people->execute([":id" => $id]);
            $p = $people->fetch(PDO::FETCH_ASSOC);
            if (!$p) continue;

            $st = AccountStanding::status($conn, (int) $id);
            $last->execute([":id" => $id]);
            $lm = $last->fetch(PDO::FETCH_ASSOC);
            $unread->execute([":id" => $id]);
            $proofs->execute([":id" => $id]);
            $pf = $proofs->fetch(PDO::FETCH_ASSOC) ?: ['total' => 0, 'fresh' => 0];

            $out[] = [
                "student_id"       => (int) $id,
                "name"             => $p['name'],
                "borrower_type"    => $p['borrower_type'],
                "state"            => $st['state'],
                "overdue"          => $st['overdue'],
                "overdue_count"    => $st['overdue_count'],
                "max_days_overdue" => $st['max_days_overdue'],
                "fine_total"       => $st['fine_total'],
                "credit"           => $st['credit'],
                "fine_due"         => $st['fine_due'],
                "days_until_blacklist" => $st['days_until_blacklist'],
                "blacklisted_at"   => $st['blacklisted_at'],
                "blacklist_reason" => $st['blacklist_reason'],
                "last_message_at"  => $lm ? $lm['created_at'] : null,
                "unread"           => (int) $unread->fetchColumn(),
                "proofs_total"     => (int) $pf['total'],
                "proofs_new"       => (int) $pf['fresh'],
            ];
        }

        usort($out, function ($a, $b) {
            $rank = ['blacklisted' => 0, 'overdue' => 1, 'good' => 2];
            return [$rank[$a['state']], -$a['max_days_overdue']] <=> [$rank[$b['state']], -$b['max_days_overdue']];
        });

        echo json_encode(["borrowers" => $out, "fine_per_day" => (int) LoanRules::all($conn)['fine_per_day']['value'],
                          "blacklist_after" => AccountStanding::threshold($conn)]);
    }

    // Every borrower, for the "message anyone" picker.
    function getBorrowers() {
        include "../config/connection-pdo.php";
        echo json_encode($conn->query($this->borrowerSql() . " ORDER BY s.first_name, s.last_name")->fetchAll(PDO::FETCH_ASSOC));
    }

    // What this borrower has been sent so far.
    function getMessages() {
        include "../config/connection-pdo.php";

        $sid = (int) ($_GET['student_id'] ?? 0);
        if ($sid <= 0) { echo json_encode([]); return; }

        $stmt = $conn->prepare("SELECT m.message_id, m.kind, m.subject, m.body, m.created_at, m.read_at, m.from_borrower,
                                       (m.attachment_path IS NOT NULL) AS has_file, m.attachment_name, m.attachment_mime,
                                       m.proof_amount, m.proof_ref,
                                       CASE WHEN m.from_borrower = 1 THEN CONCAT_WS(' ', s.first_name, s.last_name)
                                            WHEN m.sender_user_id IS NULL THEN 'Library system'
                                            ELSE CONCAT_WS(' ', u.first_name, u.last_name) END AS sender
                                FROM student_message m
                                LEFT JOIN users u ON m.sender_user_id = u.user_id
                                LEFT JOIN student s ON m.student_id = s.student_id
                                WHERE m.student_id = :s ORDER BY m.created_at DESC, m.message_id DESC LIMIT 50");
        $stmt->execute([":s" => $sid]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Every proof of payment any borrower has sent (not only overdue or blacklisted ones), new ones first.
    function getProofs() {
        include "../config/connection-pdo.php";

        $stmt = $conn->query("SELECT m.message_id, m.student_id, m.subject, m.body, m.created_at, m.read_at,
                                     m.attachment_name, m.attachment_mime, m.proof_amount, m.proof_ref,
                                     CONCAT_WS(' ', s.first_name, s.last_name) AS name,
                                     CASE WHEN (LOWER(IFNULL(r.role_name, '')) LIKE '%faculty%' OR LOWER(IFNULL(r.role_name, '')) LIKE '%dean%')
                                          THEN IFNULL(r.role_name, 'Faculty') ELSE 'Student' END AS borrower_type,
                                     (s.blacklisted_at IS NOT NULL) AS blacklisted,
                                     fp.amount AS recorded_amount, fp.receipt_no AS recorded_receipt, fp.paid_at AS recorded_at
                              FROM student_message m
                              LEFT JOIN fine_payment fp ON fp.message_id = m.message_id AND fp.kind = 'proof'
                              INNER JOIN student s ON m.student_id = s.student_id
                              LEFT JOIN users u ON s.user_id = u.user_id
                              LEFT JOIN roles r ON u.role_id = r.role_id
                              WHERE m.from_borrower = 1 AND m.attachment_path IS NOT NULL
                              ORDER BY (m.read_at IS NULL) DESC, m.created_at DESC, m.message_id DESC
                              LIMIT 100");
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // What a borrower owes right now, for the "Record payment" form.
    function getBalance() {
        include "../config/connection-pdo.php";

        $sid = (int) ($_GET['student_id'] ?? 0);
        if ($sid <= 0) { echo json_encode(["total" => 0, "lines" => [], "credit" => 0]); return; }
        echo json_encode(AccountStanding::balance($conn, $sid));
    }

    // Recent fine payments and the totals collected.
    function getPayments() {
        include "../config/connection-pdo.php";

        $rows = $conn->query("SELECT fp.payment_id, fp.student_id, fp.amount, fp.kind, fp.receipt_no, fp.reference, fp.note, fp.paid_at,
                                     CONCAT_WS(' ', s.first_name, s.last_name) AS name,
                                     CONCAT_WS(' ', u.first_name, u.last_name) AS received_by
                              FROM fine_payment fp
                              INNER JOIN student s ON fp.student_id = s.student_id
                              LEFT JOIN users u ON fp.received_by_user_id = u.user_id
                              WHERE fp.kind IN ('desk', 'proof', 'return')
                              ORDER BY fp.paid_at DESC, fp.payment_id DESC
                              LIMIT 30")->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(["totals" => FinePayments::totals($conn), "rows" => $rows]);
    }

    // The librarian received a payment for a borrower's fine: at the library desk, or confirmed from the proof the
    // borrower sent (message_id). It is kept as credit and comes off the fine when the book is returned.
    function recordPayment($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $sid = (int) ($data['student_id'] ?? 0);
        $mid = (int) ($data['message_id'] ?? 0);
        $amount = round((float) ($data['amount'] ?? 0), 2);
        $reference = mb_substr(trim((string) ($data['reference'] ?? '')), 0, 60);
        $note = mb_substr(trim((string) ($data['note'] ?? '')), 0, 200);
        $lift = !empty($data['lift']);

        if ($sid <= 0) { $this->reply("error", "Choose a borrower."); return; }
        if ($amount <= 0 || $amount > 100000) { $this->reply("error", "Enter the amount received (more than 0 and not more than 100,000)."); return; }

        $exists = $conn->prepare("SELECT 1 FROM student WHERE student_id = :s");
        $exists->execute([":s" => $sid]);
        if (!$exists->fetchColumn()) { $this->reply("error", "Borrower not found."); return; }

        if ($mid > 0) {
            $m = $conn->prepare("SELECT 1 FROM student_message WHERE message_id = :m AND student_id = :s AND from_borrower = 1 AND attachment_path IS NOT NULL");
            $m->execute([":m" => $mid, ":s" => $sid]);
            if (!$m->fetchColumn()) { $this->reply("error", "That proof of payment was not found."); return; }

            $dupe = $conn->prepare("SELECT receipt_no FROM fine_payment WHERE message_id = :m AND kind = 'proof' LIMIT 1");
            $dupe->execute([":m" => $mid]);
            $already = $dupe->fetchColumn();
            if ($already !== false) { $this->reply("error", "This proof was already recorded as paid (receipt " . $already . ")."); return; }
        }

        try {
            $conn->beginTransaction();

            $id = FinePayments::add($conn, $sid, $amount, $mid > 0 ? 'proof' : 'desk', Auth::id(), [
                "reference" => $reference === '' ? null : $reference,
                "message_id" => $mid > 0 ? $mid : null,
                "note" => $note === '' ? null : $note,
            ]);
            $rn = $conn->prepare("SELECT receipt_no FROM fine_payment WHERE payment_id = :id");
            $rn->execute([":id" => $id]);
            $receipt = (string) $rn->fetchColumn();

            // Dealing with a proof counts as seen.
            if ($mid > 0) {
                $conn->prepare("UPDATE student_message SET read_at = NOW() WHERE message_id = :m AND read_at IS NULL")->execute([":m" => $mid]);
            }

            $st = AccountStanding::status($conn, $sid);
            $bal = AccountStanding::balance($conn, $sid);

            $body = "Hello " . AccountStanding::firstName($conn, $sid) . ",\n\nThe library received your payment of " . FinePayments::peso($amount)
                  . " on " . date('F j, Y') . ". Receipt no.: " . $receipt . "."
                  . ($reference !== '' ? " Your reference no.: " . $reference . "." : "") . "\n\n"
                  . ($bal['total'] > 0
                        ? "You still owe " . FinePayments::peso($bal['total']) . "."
                        : "You have nothing left to pay right now.")
                  . ($st['overdue_count'] > 0 ? " The fine on a book that is still overdue keeps growing every day until the book is returned." : "")
                  . ($note !== '' ? "\n\nNote from the librarian: " . $note : "");
            AccountStanding::addMessage($conn, $sid, 'notice', "Payment received: " . FinePayments::peso($amount), $body, Auth::id());

            $msg = "Payment of " . FinePayments::peso($amount) . " recorded. Receipt no. " . $receipt . ".";
            if ($lift) {
                $me = Auth::current();
                if ($me && $me['role'] === 'admin') {
                    $msg .= AccountStanding::lift($conn, $sid, Auth::id(), $note) ? " The blacklist was lifted." : " The account was not blacklisted.";
                } else {
                    $msg .= " Only the Technical Services Librarian can lift a blacklist.";
                }
            }

            $conn->commit();
            $this->reply("success", $msg, ["receipt_no" => $receipt, "balance" => $bal['total']]);
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("account holds recordPayment failed: " . $e->getMessage());
            $this->reply("error", "Could not record the payment.");
        }
    }

    // The librarian opened a proof (message_id) or all of a borrower's proofs (student_id): they are no longer "new".
    function markSeen($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $sid = (int) ($data['student_id'] ?? 0);
        $mid = (int) ($data['message_id'] ?? 0);

        if ($mid > 0) {
            $conn->prepare("UPDATE student_message SET read_at = NOW() WHERE message_id = :m AND from_borrower = 1 AND read_at IS NULL")
                 ->execute([":m" => $mid]);
        } elseif ($sid > 0) {
            $conn->prepare("UPDATE student_message SET read_at = NOW() WHERE student_id = :s AND from_borrower = 1 AND read_at IS NULL")
                 ->execute([":s" => $sid]);
        } else { $this->reply("error", "Choose a borrower."); return; }
        $this->reply("success", "Marked as seen.");
    }

    function sendMessage($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $sid = (int) ($data['student_id'] ?? 0);
        $subject = trim((string) ($data['subject'] ?? ''));
        $body = trim((string) ($data['body'] ?? ''));

        if ($sid <= 0) { $this->reply("error", "Choose who the message is for."); return; }
        if ($subject === '' || strlen($subject) > 120) { $this->reply("error", "Add a subject (up to 120 characters)."); return; }
        if ($body === '' || strlen($body) > 2000) { $this->reply("error", "Write a message (up to 2000 characters)."); return; }

        $exists = $conn->prepare("SELECT 1 FROM student WHERE student_id = :s");
        $exists->execute([":s" => $sid]);
        if (!$exists->fetchColumn()) { $this->reply("error", "Borrower not found."); return; }

        AccountStanding::addMessage($conn, $sid, 'message', $subject, $body, Auth::id());
        $this->reply("success", "Message sent. The borrower will see it in their account.");
    }

    function blacklist($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $sid = (int) ($data['student_id'] ?? 0);
        $reason = trim((string) ($data['reason'] ?? ''));
        if ($sid <= 0) { $this->reply("error", "Choose a borrower."); return; }
        if (strlen($reason) > 200) { $this->reply("error", "The reason can be at most 200 characters."); return; }

        $ok = AccountStanding::blacklist($conn, $sid, Auth::id(), $reason === '' ? "Blacklisted by the librarian." : $reason);
        $this->reply($ok ? "success" : "error", $ok ? "The account is blacklisted." : "This account is already blacklisted.");
    }

    function lift($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $sid = (int) ($data['student_id'] ?? 0);
        $note = trim((string) ($data['note'] ?? ''));
        if ($sid <= 0) { $this->reply("error", "Choose a borrower."); return; }
        if (strlen($note) > 200) { $this->reply("error", "The note can be at most 200 characters."); return; }

        // A blacklist is lifted once the books are back and everything is paid. If a book is still overdue the fine
        // keeps piling up and the account is blacklisted again when the limit passes, so say so.
        $st = AccountStanding::status($conn, $sid);
        $ok = AccountStanding::lift($conn, $sid, Auth::id(), $note);
        if ($ok) {
            // Their proofs of payment have been dealt with.
            $conn->prepare("UPDATE student_message SET read_at = NOW() WHERE student_id = :s AND from_borrower = 1 AND read_at IS NULL")
                 ->execute([":s" => $sid]);
        }

        $msg = $ok ? "The blacklist was lifted." : "This account is not blacklisted.";
        if ($ok && $st['overdue_count'] > 0) {
            $msg .= " The borrower still has " . $st['overdue_count'] . " overdue book(s), so the fine keeps growing.";
        }
        $this->reply($ok ? "success" : "error", $msg);
    }
}

$operation = $_GET['operation'] ?? $_POST['operation'] ?? '';
$json = $_POST['json'] ?? '';
$obj = new AccountHolds();

switch ($operation) {
    case "getAll":       $obj->getAll(); break;
    case "getBorrowers": $obj->getBorrowers(); break;
    case "getMessages":  $obj->getMessages(); break;
    case "getProofs":    $obj->getProofs(); break;
    case "getBalance":   $obj->getBalance(); break;
    case "getPayments":  $obj->getPayments(); break;
    case "recordPayment": $obj->recordPayment($json); break;
    case "sendMessage":  $obj->sendMessage($json); break;
    case "markSeen":     $obj->markSeen($json); break;
    case "blacklist":    $obj->blacklist($json); break;
    case "lift":         $obj->lift($json); break;
}
?>
