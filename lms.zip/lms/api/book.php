<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));

// Books (the title level). Physical copies live in book_copies.php, authors in book_author.php.
class Book {
    private function out($status, $message, $extra = []) {
        echo json_encode(array_merge(["status" => $status, "message" => $message], $extra));
    }

    // One row per book, with publisher / category names and the copy counts the Books page shows.
    // Archived copies (lost or damaged and removed from the shelf) are not counted.
    function getAll() {
        include "../config/connection-pdo.php";

        $stmt = $conn->query("
            SELECT b.book_id, b.publisher_id, b.category_id, b.book_type, b.title, b.published_year, b.price,
                   b.created_at, b.updated_at,
                   p.publisher_name, c.category_type,
                   (SELECT GROUP_CONCAT(CONCAT_WS(' ', a.first_name, a.last_name) ORDER BY a.first_name, a.last_name SEPARATOR ', ')
                      FROM book_author ba INNER JOIN author a ON ba.author_id = a.author_id
                     WHERE ba.book_id = b.book_id) AS authors,
                   COALESCE(SUM(CASE WHEN bc.copy_id IS NOT NULL AND bc.archived_at IS NULL THEN 1 ELSE 0 END), 0) AS total_copies,
                   COALESCE(SUM(CASE WHEN bc.archived_at IS NULL AND s.status_desc = 'Available' THEN 1 ELSE 0 END), 0) AS available_copies,
                   COALESCE(SUM(CASE WHEN bc.archived_at IS NULL AND s.status_desc = 'Borrowed' THEN 1 ELSE 0 END), 0) AS borrowed_copies,
                   COALESCE(SUM(CASE WHEN bc.archived_at IS NULL AND s.status_desc = 'Library Use Only' THEN 1 ELSE 0 END), 0) AS library_copies
            FROM book b
            LEFT JOIN publisher p ON b.publisher_id = p.publisher_id
            LEFT JOIN categories c ON b.category_id = c.category_id
            LEFT JOIN book_copies bc ON bc.book_id = b.book_id
            LEFT JOIN status s ON bc.status_id = s.status_id
            GROUP BY b.book_id, b.publisher_id, b.category_id, b.book_type, b.title, b.published_year, b.price,
                     b.created_at, b.updated_at, p.publisher_name, c.category_type
            ORDER BY b.title ASC, b.published_year DESC, b.book_id ASC");

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$r) {
            foreach (['total_copies', 'available_copies', 'borrowed_copies', 'library_copies'] as $k) $r[$k] = (int) $r[$k];
        }
        unset($r);

        echo json_encode($rows);
    }

    // Checks the fields shared by add and update. Returns [error|null, cleaned values].
    private function clean($conn, $data, $ignoreId = 0) {
        $publisher_id = (int) ($data['publisher_id'] ?? 0);
        $category_id  = (int) ($data['category_id'] ?? 0);
        $book_type    = trim((string) ($data['book_type'] ?? ''));
        $title        = trim(preg_replace('/\s+/', ' ', (string) ($data['title'] ?? '')));
        $year         = trim((string) ($data['published_year'] ?? ''));
        $price        = trim((string) ($data['price'] ?? ''));

        if ($publisher_id <= 0 || $category_id <= 0 || $book_type === '' || $title === '' || $year === '') {
            return ["Please fill in all required book fields.", null];
        }
        if (!in_array($book_type, ['Educational', 'Fictional'], true)) {
            return ["Book type must be Educational or Fictional.", null];
        }
        if (mb_strlen($title) < 2 || mb_strlen($title) > 255) {
            return ["Please enter a valid book title.", null];
        }
        if (!preg_match('/^\d{4}$/', $year) || (int) $year < 1000 || (int) $year > (int) date('Y') + 1) {
            return ["A valid 4-digit published year is required.", null];
        }
        if ($price !== '' && (!is_numeric($price) || (float) $price < 0 || (float) $price > 1000000)) {
            return ["Enter a valid price, or leave it empty.", null];
        }

        $p = $conn->prepare("SELECT 1 FROM publisher WHERE publisher_id = :i");
        $p->execute([":i" => $publisher_id]);
        if (!$p->fetchColumn()) return ["The chosen publisher does not exist.", null];

        $c = $conn->prepare("SELECT 1 FROM categories WHERE category_id = :i");
        $c->execute([":i" => $category_id]);
        if (!$c->fetchColumn()) return ["The chosen category does not exist.", null];

        // The same title may exist in another edition (a different year), but not twice in the same year.
        $d = $conn->prepare("SELECT book_id FROM book WHERE LOWER(TRIM(title)) = LOWER(:t) AND published_year = :y AND book_id <> :id LIMIT 1");
        $d->execute([":t" => $title, ":y" => (int) $year, ":id" => $ignoreId]);
        if ($d->fetchColumn()) return ["This book ($title, $year) already exists.", null];

        return [null, [
            "publisher_id" => $publisher_id,
            "category_id"  => $category_id,
            "book_type"    => $book_type,
            "title"        => $title,
            "year"         => (int) $year,
            "price"        => $price === '' ? null : round((float) $price, 2),
        ]];
    }

    function add($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        list($err, $v) = $this->clean($conn, $data);
        if ($err) { $this->out("error", $err); return; }

        lms_lock_ids($conn);
        $book_id = (int) $conn->query("SELECT IFNULL(MAX(book_id), 0) + 1 FROM book")->fetchColumn();

        $conn->prepare("INSERT INTO book (book_id, publisher_id, category_id, book_type, title, published_year, price, created_at, updated_at)
                        VALUES (:id, :p, :c, :t, :title, :y, :price, NOW(), NOW())")
             ->execute([":id" => $book_id, ":p" => $v['publisher_id'], ":c" => $v['category_id'], ":t" => $v['book_type'],
                        ":title" => $v['title'], ":y" => $v['year'], ":price" => $v['price']]);

        $this->out("success", "Book added successfully.", ["book_id" => $book_id]);
    }

    function update($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $book_id = (int) ($data['book_id'] ?? 0);
        if ($book_id <= 0) { $this->out("error", "Book ID is required."); return; }

        $exists = $conn->prepare("SELECT 1 FROM book WHERE book_id = :id");
        $exists->execute([":id" => $book_id]);
        if (!$exists->fetchColumn()) { $this->out("error", "The book could not be found."); return; }

        list($err, $v) = $this->clean($conn, $data, $book_id);
        if ($err) { $this->out("error", $err); return; }

        $conn->prepare("UPDATE book SET publisher_id = :p, category_id = :c, book_type = :t, title = :title,
                               published_year = :y, price = :price, updated_at = NOW()
                        WHERE book_id = :id")
             ->execute([":p" => $v['publisher_id'], ":c" => $v['category_id'], ":t" => $v['book_type'], ":title" => $v['title'],
                        ":y" => $v['year'], ":price" => $v['price'], ":id" => $book_id]);

        $this->out("success", "Book updated successfully.");
    }

    // Permanent delete (Technical Services Librarian only, see config/auth.php). A book that was ever borrowed,
    // or is reserved, is kept so the history stays correct.
    function delete($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $book_id = (int) ($data['book_id'] ?? 0);
        if ($book_id <= 0) { $this->out("error", "Book ID is required."); return; }

        $used = $conn->prepare("SELECT COUNT(*) FROM borrow_items bi INNER JOIN book_copies bc ON bi.copy_id = bc.copy_id WHERE bc.book_id = :b");
        $used->execute([":b" => $book_id]);
        if ((int) $used->fetchColumn() > 0) {
            $this->out("error", "Cannot delete: this book has borrowing history.");
            return;
        }

        $res = $conn->prepare("SELECT COUNT(*) FROM reservation WHERE book_id = :b AND status IN ('Pending', 'Waiting', 'Ready')");
        $res->execute([":b" => $book_id]);
        if ((int) $res->fetchColumn() > 0) {
            $this->out("error", "Cannot delete: this book has active reservations.");
            return;
        }

        try {
            $conn->beginTransaction();
            $conn->prepare("DELETE FROM book_author WHERE book_id = :b")->execute([":b" => $book_id]);
            $conn->prepare("DELETE FROM book_copies WHERE book_id = :b")->execute([":b" => $book_id]);
            $del = $conn->prepare("DELETE FROM book WHERE book_id = :b");
            $del->execute([":b" => $book_id]);
            $conn->commit();
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            error_log("book delete failed: " . $e->getMessage());
            $this->out("error", "Cannot delete this book because other records still use it.");
            return;
        }

        if ($del->rowCount() > 0) $this->out("success", "Book deleted successfully.");
        else $this->out("error", "The book could not be found.");
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$obj = new Book();

switch ($operation) {
    case "getAll":
        $obj->getAll();
        break;
    case "add":
        $obj->add($json);
        break;
    case "update":
        $obj->update($json);
        break;
    case "delete":
        $obj->delete($json);
        break;
}
?>
