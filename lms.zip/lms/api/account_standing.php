<?php
// A borrower's standing in the library.
//
//   good        - nothing overdue.
//   overdue     - at least one book is overdue. Nothing is restricted: the borrower can still reserve and borrow,
//                 the fine just keeps piling up (5 pesos a day) and a reminder is sent every day.
//   blacklisted - a book stayed overdue for the "blacklist after" number of days (Loan Rules page), or the
//                 Technical Services Librarian blacklisted the borrower. The account can't reserve or borrow,
//                 and only the Technical Services Librarian can lift it.
//
// Fines are 5 pesos (editable) for every overdue day. Messages go to the borrower's inbox in the portal.

require_once __DIR__ . "/loan_rules.php";
require_once __DIR__ . "/fine_payments.php";

class AccountStanding {

    // Books that are overdue and still not returned.
    static function overdue($conn, $sid) {
        $rate = (int) LoanRules::all($conn)['fine_per_day']['value'];

        $stmt = $conn->prepare("SELECT bi.item_id, b.title, bc.accession_number,
                                       COALESCE(bi.due_date, bt.due_date) AS due_date,
                                       DATEDIFF(CURDATE(), COALESCE(bi.due_date, bt.due_date)) AS days_overdue
                                FROM borrow_items bi
                                INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                                LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                                LEFT JOIN book b ON bc.book_id = b.book_id
                                LEFT JOIN book_return br ON br.item_id = bi.item_id
                                WHERE bt.student_id = :s
                                  AND br.return_id IS NULL AND (bi.is_returned IS NULL OR bi.is_returned = 0)
                                  AND COALESCE(bi.due_date, bt.due_date) < CURDATE()
                                ORDER BY due_date ASC");
        $stmt->execute([":s" => $sid]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as &$r) {
            $r['days_overdue'] = (int) $r['days_overdue'];
            $r['fine'] = $r['days_overdue'] * $rate;
        }
        unset($r);

        return $rows;
    }

    // What a borrower owes right now:
    //   - the fine that is still growing on books that are overdue and not yet returned, and
    //   - every open lost / damaged case: its late fine, plus the book price and processing fee once the price is set.
    // Paid, replaced and waived cases owe nothing. Returns ["total" => float, "lines" => [["label", "amount"], ...]].
    static function balance($conn, $sid) {
        $lines = []; $total = 0.0;

        foreach (self::overdue($conn, $sid) as $o) {
            if ($o['fine'] <= 0) continue;
            $lines[] = ["label" => ($o['title'] ?: "A book") . " - overdue " . $o['days_overdue'] . ($o['days_overdue'] === 1 ? " day" : " days") . " (not yet returned)",
                        "amount" => (float) $o['fine']];
            $total += $o['fine'];
        }

        $q = $conn->prepare("SELECT br.condition_on_return, COALESCE(br.case_status, 'Settled') AS case_status,
                                    br.fine_amount, br.book_price, br.processing_fee, b.title
                             FROM book_return br
                             INNER JOIN borrow_items bi ON br.item_id = bi.item_id
                             INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                             LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                             LEFT JOIN book b ON bc.book_id = b.book_id
                             WHERE bt.student_id = :s AND br.condition_on_return IN ('Lost', 'Damaged')
                               AND COALESCE(br.case_status, 'Settled') IN ('Pending', 'Awaiting payment', 'Awaiting replacement')
                             ORDER BY br.return_id");
        $q->execute([":s" => $sid]);
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $c) {
            $title = $c['title'] ?: "A book";
            $fine = (float) $c['fine_amount'];
            if ($fine > 0) { $lines[] = ["label" => "$title - late fine", "amount" => $fine]; $total += $fine; }

            if ($c['case_status'] === 'Awaiting payment') {
                $price = (float) $c['book_price']; $fee = (float) $c['processing_fee'];
                $lines[] = ["label" => "$title - " . strtolower($c['condition_on_return']) . " book price", "amount" => $price];
                if ($fee > 0) $lines[] = ["label" => "$title - processing fee", "amount" => $fee];
                $total += $price + $fee;
            } elseif ($c['case_status'] === 'Awaiting replacement') {
                $lines[] = ["label" => "$title - " . strtolower($c['condition_on_return']) . ": bring a replacement copy", "amount" => 0.0];
            } else {
                $lines[] = ["label" => "$title - " . strtolower($c['condition_on_return']) . ": price still to be set by the librarian", "amount" => 0.0];
            }
        }

        // Money the borrower already paid in advance comes off what they owe.
        $credit = FinePayments::credit($conn, $sid);
        $use = round(min($credit, $total), 2);
        if ($use > 0) {
            $lines[] = ["label" => "Advance payments received", "amount" => -$use];
            $total -= $use;
        }

        return ["total" => round(max(0, $total), 2), "lines" => $lines, "credit" => $credit];
    }

    // The same totals for everyone at once: [student_id => total]. Only borrowers who owe something appear.
    static function balances($conn) {
        $rate = (int) LoanRules::all($conn)['fine_per_day']['value'];
        $out = [];

        $late = $conn->query("SELECT bt.student_id, SUM(DATEDIFF(CURDATE(), COALESCE(bi.due_date, bt.due_date))) AS days
                              FROM borrow_items bi
                              INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                              LEFT JOIN book_return br ON br.item_id = bi.item_id
                              WHERE br.return_id IS NULL AND (bi.is_returned IS NULL OR bi.is_returned = 0)
                                AND COALESCE(bi.due_date, bt.due_date) < CURDATE() AND bt.student_id IS NOT NULL
                              GROUP BY bt.student_id")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($late as $r) $out[(int) $r['student_id']] = (float) $r['days'] * $rate;

        $cases = $conn->query("SELECT bt.student_id,
                                      SUM(br.fine_amount + IF(br.case_status = 'Awaiting payment', IFNULL(br.book_price, 0) + br.processing_fee, 0)) AS owed
                               FROM book_return br
                               INNER JOIN borrow_items bi ON br.item_id = bi.item_id
                               INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                               WHERE br.condition_on_return IN ('Lost', 'Damaged')
                                 AND COALESCE(br.case_status, 'Settled') IN ('Pending', 'Awaiting payment', 'Awaiting replacement')
                                 AND bt.student_id IS NOT NULL
                               GROUP BY bt.student_id")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($cases as $r) $out[(int) $r['student_id']] = ($out[(int) $r['student_id']] ?? 0) + (float) $r['owed'];

        foreach (FinePayments::credits($conn) as $sid => $c) {
            if (isset($out[$sid])) $out[$sid] = max(0, $out[$sid] - $c);
        }

        return array_map(function ($v) { return round($v, 2); }, $out);
    }

    static function threshold($conn) {
        return max(1, (int) LoanRules::all($conn)['blacklist_after_days']['value']);
    }

    // Everything the portal and the staff pages need to know about one borrower.
    static function status($conn, $sid) {
        $over = self::overdue($conn, $sid);
        $rate = (int) LoanRules::all($conn)['fine_per_day']['value'];
        $threshold = self::threshold($conn);

        $row = $conn->prepare("SELECT blacklisted_at, blacklist_reason FROM student WHERE student_id = :s");
        $row->execute([":s" => $sid]);
        $s = $row->fetch(PDO::FETCH_ASSOC) ?: ['blacklisted_at' => null, 'blacklist_reason' => null];

        $maxDays = 0; $fine = 0;
        foreach ($over as $o) { $maxDays = max($maxDays, $o['days_overdue']); $fine += $o['fine']; }

        $state = $s['blacklisted_at'] ? 'blacklisted' : (count($over) > 0 ? 'overdue' : 'good');
        $credit = FinePayments::credit($conn, $sid);   // paid in advance, not used yet

        return [
            "state"             => $state,
            "overdue"           => $over,
            "overdue_count"     => count($over),
            "max_days_overdue"  => $maxDays,
            "fine_total"        => $fine,
            "credit"            => $credit,
            "fine_due"          => max(0, round($fine - $credit, 2)),
            "fine_per_day"      => $rate,
            "blacklist_after"   => $threshold,
            "days_until_blacklist" => $state === 'overdue' ? max(0, $threshold - $maxDays) : null,
            "blacklisted_at"    => $s['blacklisted_at'],
            "blacklist_reason"  => $s['blacklist_reason'],
        ];
    }

    private static function peso($n) { return "₱" . number_format((float) $n, 2); }

    // Blacklists automatically when a book has been overdue for too long. Returns the up-to-date status.
    static function evaluate($conn, $sid) {
        $st = self::status($conn, $sid);

        if ($st['state'] === 'overdue' && $st['max_days_overdue'] >= $st['blacklist_after']) {
            $reason = "A book has been overdue for " . $st['max_days_overdue'] . " days (limit: " . $st['blacklist_after'] . " days).";
            self::blacklist($conn, $sid, null, $reason);
            $st = self::status($conn, $sid);
        }

        return $st;
    }

    // Text shown to the borrower (and staff) when a new loan or reservation is refused.
    // Only a blacklisted account is refused. A borrower who is merely overdue can carry on; the fine piles up.
    static function holdMessage($st) {
        if ($st['state'] === 'blacklisted') {
            return "This account is blacklisted" . ($st['blacklist_reason'] ? " (" . $st['blacklist_reason'] . ")" : "")
                 . ". Reserving and borrowing are not allowed. Please see the librarian at the library desk to settle it.";
        }
        return null;
    }

    // null when the borrower may reserve or borrow, otherwise the reason why not.
    static function guard($conn, $sid) {
        if ($sid === null) return null;
        return self::holdMessage(self::evaluate($conn, $sid));
    }

    /* ---------------- Messages ---------------- */

    static function addMessage($conn, $sid, $kind, $subject, $body, $senderUserId = null, $reminderDate = null) {
        $conn->prepare("INSERT INTO student_message (student_id, sender_user_id, kind, subject, body, reminder_date, created_at)
                        VALUES (:s, :u, :k, :subj, :body, :d, NOW())")
             ->execute([":s" => $sid, ":u" => $senderUserId, ":k" => $kind, ":subj" => $subject, ":body" => $body, ":d" => $reminderDate]);
    }

    static function firstName($conn, $sid) {
        $q = $conn->prepare("SELECT first_name FROM student WHERE student_id = :s");
        $q->execute([":s" => $sid]);
        return (string) $q->fetchColumn();
    }

    // One reminder per borrower per day while a book is overdue. Safe to call as often as you like.
    static function dailyReminder($conn, $sid, $st = null) {
        $st = $st ?: self::status($conn, $sid);
        if ($st['overdue_count'] === 0) return false;

        $today = date('Y-m-d');
        $has = $conn->prepare("SELECT 1 FROM student_message WHERE student_id = :s AND kind = 'reminder' AND reminder_date = :d LIMIT 1");
        $has->execute([":s" => $sid, ":d" => $today]);
        if ($has->fetchColumn()) return false;

        $lines = [];
        foreach ($st['overdue'] as $o) {
            $lines[] = "• " . $o['title'] . " (due " . $o['due_date'] . ", " . $o['days_overdue'] . " "
                     . ($o['days_overdue'] === 1 ? "day" : "days") . " late, fine " . self::peso($o['fine']) . ")";
        }

        $body = "Hello " . self::firstName($conn, $sid) . ",\n\n"
              . "You have " . $st['overdue_count'] . " overdue " . ($st['overdue_count'] === 1 ? "book" : "books") . ":\n"
              . implode("\n", $lines) . "\n\n"
              . "A fine of " . self::peso($st['fine_per_day']) . " is added for every day a book is overdue. Your total so far is "
              . self::peso($st['fine_total']) . ", and it grows each day.\n\n"
              . "Please return the " . ($st['overdue_count'] === 1 ? "book" : "books") . ". A fine of ₱60 or less is paid at the library desk; a fine above ₱60 is paid at Assessment with the receipt the library gives you.\n\n"
              . "If you can't find a book, or it was lost or damaged, please come to the library in person to settle it: pay its full price plus the processing fee, or bring a replacement copy.\n\n"
              . "If a book stays overdue for " . $st['blacklist_after'] . " days your account will be blacklisted"
              . ($st['days_until_blacklist'] !== null ? " (" . $st['days_until_blacklist'] . " days left)" : "")
              . ", and you will not be able to reserve or borrow until the librarian lifts it.";

        self::addMessage($conn, $sid, 'reminder', "Overdue book reminder", $body, null, $today);
        return true;
    }

    // Blacklists anyone whose book has been overdue too long and sends today's reminders.
    // Called when staff open the dashboard and when a borrower opens the portal, so no scheduled job is needed.
    static function sweep($conn) {
        $ids = $conn->query("SELECT DISTINCT bt.student_id
                             FROM borrow_items bi
                             INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                             LEFT JOIN book_return br ON br.item_id = bi.item_id
                             WHERE br.return_id IS NULL AND (bi.is_returned IS NULL OR bi.is_returned = 0)
                               AND COALESCE(bi.due_date, bt.due_date) < CURDATE() AND bt.student_id IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);

        foreach ($ids as $sid) {
            $st = self::evaluate($conn, (int) $sid);
            self::dailyReminder($conn, (int) $sid, $st);
        }
    }

    /* ---------------- Blacklist ---------------- */

    static function blacklist($conn, $sid, $byUserId, $reason) {
        $q = $conn->prepare("UPDATE student SET blacklisted_at = NOW(), blacklist_reason = :r, blacklisted_by_user_id = :u
                             WHERE student_id = :s AND blacklisted_at IS NULL");
        $q->execute([":r" => $reason, ":u" => $byUserId, ":s" => $sid]);
        if ($q->rowCount() === 0) return false;

        self::addMessage($conn, $sid, 'warning', "Your account has been blacklisted",
            "Hello " . self::firstName($conn, $sid) . ",\n\nYour library account has been blacklisted." . ($reason ? " Reason: $reason" : "")
            . "\n\nYou can't reserve or borrow books until you settle this with the librarian. Please come to the library in person, "
            . "return any overdue books and pay what is owed.", $byUserId);
        return true;
    }

    static function lift($conn, $sid, $byUserId, $note) {
        $q = $conn->prepare("UPDATE student SET blacklisted_at = NULL, blacklist_reason = NULL, blacklisted_by_user_id = NULL
                             WHERE student_id = :s AND blacklisted_at IS NOT NULL");
        $q->execute([":s" => $sid]);
        if ($q->rowCount() === 0) return false;

        self::addMessage($conn, $sid, 'notice', "Your account is active again",
            "Hello " . self::firstName($conn, $sid) . ",\n\nThe blacklist on your library account has been lifted." . ($note ? " Note: $note" : "")
            . "\n\nYou can reserve books again, as long as you have nothing overdue. Please return books on time.", $byUserId);
        return true;
    }
}
