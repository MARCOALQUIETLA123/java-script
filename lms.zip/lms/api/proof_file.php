<?php
// Sends one proof-of-payment file to the browser. Files are stored outside public reach (uploads/proofs is
// closed by .htaccess), so this is the only way to open them. Who may open one:
//   - the Technical Services Librarian, Library Staff and Student Assistants: any proof
//   - a borrower: only the proofs they sent themselves
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));   // operation=view is listed in Auth::STAFF_OPS and Auth::BORROWER_OPS

include __DIR__ . "/../config/connection-pdo.php";

$id = (int) ($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT student_id, attachment_path, attachment_name, attachment_mime
                        FROM student_message WHERE message_id = :id AND attachment_path IS NOT NULL");
$stmt->execute([":id" => $id]);
$m = $stmt->fetch(PDO::FETCH_ASSOC);

$me = Auth::current();
$mine = $m && $me && $me['role'] === 'borrower' && (int) $m['student_id'] === (int) $me['student_id'];

if (!$m || ($me['role'] === 'borrower' && !$mine)) {
    http_response_code(404);
    header('Content-Type: text/plain');
    echo "File not found.";
    exit;
}

$file = __DIR__ . "/../uploads/proofs/" . basename($m['attachment_path']);
if (!is_file($file)) {
    http_response_code(404);
    header('Content-Type: text/plain');
    echo "File not found.";
    exit;
}

$allowed = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
$mime = in_array($m['attachment_mime'], $allowed, true) ? $m['attachment_mime'] : 'application/octet-stream';

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($file));
header('Content-Disposition: inline; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', (string) $m['attachment_name']) . '"');
header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'");
header('Cache-Control: private, no-store');
readfile($file);
