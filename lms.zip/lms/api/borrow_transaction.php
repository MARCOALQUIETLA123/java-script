<?php

header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));

require_once __DIR__ . "/loan_rules.php";

class BorrowTransaction {

    // Treats "", null, and missing keys as empty — but NOT the string "0",
    // which is a valid ID (e.g. user_id 0) that PHP's empty() would wrongly reject.
    private function blank($value) {
        return !isset($value) || $value === '' || $value === null;
    }

    function getAll() {
        include "../config/connection-pdo.php";

        $sql = "SELECT bt.transaction_id,
                       bt.student_id,
                       bt.processed_by_user_id,
                       bt.borrow_date,
                       bt.due_date,
                       bt.status_id,
                       bt.created_at,
                       CONCAT(s.first_name, ' ', s.last_name) AS student_name,
                       CONCAT(u.first_name, ' ', u.last_name) AS processed_by,
                       st.status_desc
                FROM borrow_transaction bt
                LEFT JOIN student s ON bt.student_id = s.student_id
                LEFT JOIN users u ON bt.processed_by_user_id = u.user_id
                LEFT JOIN status st ON bt.status_id = st.status_id
                ORDER BY s.first_name ASC, s.last_name ASC, bt.borrow_date DESC";

        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rs);
    }

    private function facultyMessage() {
        return "Faculty and Dean transactions are reserved to the Technical Services Librarian unless your account was authorized for them.";
    }

    private function abort($conn, $message) {
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        echo json_encode(["status" => "error", "message" => $message]);
    }

    // Faculty can be picked straight from the user list: their dropdown value is
    // "f" + user_id (e.g. "f12"). Students keep their plain student_id.
    // borrow_transaction.student_id points at the student table, so a faculty member
    // needs a student record. With $create = true it is found, linked or created here.
    // Returns [student_id|null, faculty_override|null, error_message|null].
    private function resolveBorrower($conn, $raw, $create) {
        $raw = trim((string) $raw);

        if (!preg_match('/^f(\d+)$/', $raw, $m)) {
            return [$raw, null, null];
        }

        $user_id = (int) $m[1];

        $u = $conn->prepare("
            SELECT u.user_id, u.first_name, u.last_name, u.email, u.contact_number,
                   r.role_name, d.department_name
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.role_id
            LEFT JOIN department d ON u.department_id = d.department_id
            WHERE u.user_id = :user_id
            LIMIT 1
        ");
        $u->bindParam(":user_id", $user_id);
        $u->execute();
        $user = $u->fetch(PDO::FETCH_ASSOC);

        if (!$user || stripos((string) $user['role_name'], 'faculty') === false) {
            return [null, null, "The selected faculty member was not found."];
        }

        // Already has a borrower record?
        $s = $conn->prepare("SELECT student_id FROM student WHERE user_id = :user_id LIMIT 1");
        $s->bindParam(":user_id", $user_id);
        $s->execute();
        $existing = $s->fetchColumn();

        if ($existing) {
            return [(int) $existing, true, null];
        }

        if (!$create) {
            return [null, true, null];
        }

        // A student record with the same email that is not linked yet: link it.
        $e = $conn->prepare("SELECT student_id, user_id FROM student WHERE email = :email LIMIT 1");
        $e->bindParam(":email", $user['email']);
        $e->execute();
        $sameEmail = $e->fetch(PDO::FETCH_ASSOC);

        if ($sameEmail) {
            if ($sameEmail['user_id'] !== null && (int) $sameEmail['user_id'] !== $user_id) {
                return [null, null, "A different borrower record already uses this faculty member's email."];
            }

            $link = $conn->prepare("UPDATE student SET user_id = :user_id, updated_at = NOW() WHERE student_id = :student_id");
            $link->bindParam(":user_id", $user_id);
            $link->bindParam(":student_id", $sameEmail['student_id']);
            $link->execute();

            return [(int) $sameEmail['student_id'], true, null];
        }

        // Otherwise create the borrower record from the user's own details.
        $nextId = (int) $conn->query("SELECT IFNULL(MAX(student_id), 0) + 1 FROM student")->fetchColumn();
        $address = "N/A";
        $course = $user['department_name'] ? $user['department_name'] : "Faculty";

        $ins = $conn->prepare("
            INSERT INTO student
                (student_id, user_id, first_name, last_name, email, phone, address, course, created_at, updated_at)
            VALUES
                (:student_id, :user_id, :first_name, :last_name, :email, :phone, :address, :course, NOW(), NOW())
        ");
        $ins->bindParam(":student_id", $nextId);
        $ins->bindParam(":user_id", $user_id);
        $ins->bindParam(":first_name", $user['first_name']);
        $ins->bindParam(":last_name", $user['last_name']);
        $ins->bindParam(":email", $user['email']);
        $ins->bindParam(":phone", $user['contact_number']);
        $ins->bindParam(":address", $address);
        $ins->bindParam(":course", $course);
        $ins->execute();

        return [$nextId, true, null];
    }

    private function validDate($value) {
        return is_string($value) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) && strtotime($value) !== false;
    }

    // Shows the borrower type, limit, current loans and the latest allowed due date
    // without saving anything. Used for the live preview on the form.
    // When "transaction_id" is sent (edit mode) the books already on that
    // transaction are used instead of "copy_ids", and "borrow_date" is respected.
    function preview($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $raw_student = $data['student_id'] ?? null;
        $transaction_id = $data['transaction_id'] ?? null;
        $borrow_date = $data['borrow_date'] ?? null;
        $copy_ids = array_values(array_unique(array_map('intval', $data['copy_ids'] ?? [])));

        if ($this->blank($raw_student)) {
            echo json_encode(["status" => "error", "message" => "Student is required."]);
            return;
        }

        try {
            list($student_id, $facultyOverride, $err) = $this->resolveBorrower($conn, $raw_student, false);

            if ($err) {
                echo json_encode(["status" => "error", "message" => $err]);
                return;
            }

            if (!Auth::mayHandleBorrower($conn, $raw_student)) {
                echo json_encode(["status" => "error", "message" => $this->facultyMessage()]);
                return;
            }

            if (!$this->blank($transaction_id)) {
                $copy_ids = LoanRules::copyIdsForTransaction($conn, $transaction_id);
            }

            if (!$this->validDate($borrow_date)) {
                $borrow_date = null;
            }

            echo json_encode([
                "status" => "success",
                "plan" => LoanRules::plan($conn, $student_id, $copy_ids, $borrow_date, $facultyOverride)
            ]);
        } catch (Exception $e) {
            error_log("preview failed: " . $e->getMessage());
            echo json_encode(["status" => "error", "message" => "Failed to check borrowing rules."]);
        }
    }

    // Creates the transaction and all its items in one DB transaction.
    // Borrow date = today, due date and limits come from LoanRules.
    function borrow($json) {
        include "../config/connection-pdo.php";

        $data = json_decode($json, true) ?: [];
        $raw_student = $data['student_id'] ?? null;
        $processed_by_user_id = Auth::id(); // the signed-in user, never the request
        $requested_due = $data['due_date'] ?? null;          // older clients: one date for every book
        $requested_dues = isset($data['due_dates']) && is_array($data['due_dates']) ? $data['due_dates'] : [];  // copy_id => date
        $copy_ids = array_values(array_unique(array_map('intval', $data['copy_ids'] ?? [])));

        if ($this->blank($raw_student) || $this->blank($processed_by_user_id)) {
            echo json_encode(["status" => "error", "message" => "Student and processed-by user are required."]);
            return;
        }

        if (count($copy_ids) === 0) {
            echo json_encode(["status" => "error", "message" => "Please select at least one book to borrow."]);
            return;
        }

        try {
            $conn->beginTransaction();

            // Faculty picked from the dropdown ("f12") are matched to / given a borrower record.
            list($student_id, $facultyOverride, $resolveError) = $this->resolveBorrower($conn, $raw_student, true);

            if ($resolveError) {
                $this->abort($conn, $resolveError);
                return;
            }

            if (!Auth::mayHandleBorrower($conn, $raw_student)) {
                $this->abort($conn, $this->facultyMessage());
                return;
            }

            // Lock the student so two simultaneous requests can't both slip under the limit.
            $lock = $conn->prepare("SELECT student_id FROM student WHERE student_id = :student_id FOR UPDATE");
            $lock->bindParam(":student_id", $student_id);
            $lock->execute();

            if ($lock->rowCount() === 0) {
                $this->abort($conn, "Student not found.");
                return;
            }

            // Lock the copies and make sure every one is still Available.
            $in = implode(',', array_fill(0, count($copy_ids), '?'));
            $copyStmt = $conn->prepare("
                SELECT bc.copy_id, s.status_desc
                FROM book_copies bc
                INNER JOIN status s ON bc.status_id = s.status_id
                WHERE bc.copy_id IN ($in)
                FOR UPDATE
            ");
            $copyStmt->execute($copy_ids);
            $copies = $copyStmt->fetchAll(PDO::FETCH_ASSOC);

            if (count($copies) !== count($copy_ids)) {
                $this->abort($conn, "One or more selected book copies no longer exist.");
                return;
            }

            foreach ($copies as $c) {
                if ($c['status_desc'] === 'Reserved') {
                    $this->abort($conn, "One or more selected copies are Reserved and can't be borrowed here. A reserved copy can only be checked out from the Reservations page.");
                    return;
                }

                if ($c['status_desc'] !== 'Available') {
                    $this->abort($conn, "One or more selected copies are no longer available. Please reload and pick again.");
                    return;
                }
            }

            // Apply the loan rules.
            $plan = LoanRules::plan($conn, $student_id, $copy_ids, null, $facultyOverride);

            if ($plan['hold']) {
                $this->abort($conn, $plan['hold']);
                return;
            }

            if ($plan['active'] + count($copy_ids) > $plan['limit']) {
                $this->abort($conn, sprintf(
                    "%s limit reached: %s can borrow at most %d books at a time and currently has %d unreturned. You can borrow %d more.",
                    $plan['borrower_type'], strtolower($plan['borrower_type']),
                    $plan['limit'], $plan['active'], $plan['remaining']
                ));
                return;
            }

            if ($plan['due_date'] === null) {
                $this->abort($conn, "Could not compute a due date.");
                return;
            }

            $st = $conn->prepare("SELECT status_id FROM status WHERE status_desc = 'Borrowed' LIMIT 1");
            $st->execute();
            $borrowedStatusId = $st->fetchColumn();

            if (!$borrowedStatusId) {
                $this->abort($conn, "The 'Borrowed' status is missing. Ask the Technical Services Librarian to restore it.");
                return;
            }

            $nextId = $conn->query("SELECT IFNULL(MAX(transaction_id), 0) + 1 FROM borrow_transaction")->fetchColumn();
            $borrow_date = $plan['borrow_date'];

            // Every book gets its OWN due date. The plan gives the LATEST date allowed for each
            // one (borrower type + that book's type). The librarian may choose an earlier date for
            // a book, never a later one. A mixed loan (educational + fictional) therefore keeps
            // a different return date per book.
            $dueByCopy = [];

            foreach ($plan['books'] as $bk) {
                $copyId = (int) $bk['copy_id'];
                $due = $bk['due_date'];

                $req = $requested_dues[$copyId] ?? $requested_dues[(string) $copyId] ?? $requested_due;

                if (!$this->blank($req)) {
                    if (!$this->validDate($req)) {
                        $this->abort($conn, "Please enter a valid due date for \"{$bk['title']}\".");
                        return;
                    }

                    if ($req < $borrow_date) {
                        $this->abort($conn, "The due date for \"{$bk['title']}\" cannot be earlier than the borrow date.");
                        return;
                    }

                    if ($req > $bk['due_date']) {
                        $this->abort($conn, sprintf(
                            "The due date for \"%s\" cannot be later than %s. That is the longest loan allowed for a %s with this book (%s).",
                            $bk['title'], $bk['due_date'], strtolower($plan['borrower_type']), $bk['period']
                        ));
                        return;
                    }

                    $due = $req;
                }

                $dueByCopy[$copyId] = $due;
            }

            if (count($dueByCopy) !== count($copy_ids)) {
                $this->abort($conn, "Could not compute a due date for every selected book.");
                return;
            }

            // The transaction itself keeps the EARLIEST due date as its summary date.
            $due_date = min($dueByCopy);

            $ins = $conn->prepare("
                INSERT INTO borrow_transaction
                    (transaction_id, student_id, processed_by_user_id, borrow_date, due_date, status_id, created_at)
                VALUES
                    (:transaction_id, :student_id, :processed_by_user_id, :borrow_date, :due_date, :status_id, NOW())
            ");
            $ins->bindParam(":transaction_id", $nextId);
            $ins->bindParam(":student_id", $student_id);
            $ins->bindParam(":processed_by_user_id", $processed_by_user_id);
            $ins->bindParam(":borrow_date", $borrow_date);
            $ins->bindParam(":due_date", $due_date);
            $ins->bindParam(":status_id", $borrowedStatusId);
            $ins->execute();

            $nextItemId = (int) $conn->query("SELECT IFNULL(MAX(item_id), 0) + 1 FROM borrow_items")->fetchColumn();

            $itemStmt = $conn->prepare("
                INSERT INTO borrow_items (item_id, transaction_id, copy_id, due_date, is_returned)
                VALUES (:item_id, :transaction_id, :copy_id, :due_date, 0)
            ");
            $copyUpd = $conn->prepare("UPDATE book_copies SET status_id = :status_id WHERE copy_id = :copy_id");

            foreach ($copy_ids as $copy_id) {
                $itemStmt->execute([
                    ":item_id" => $nextItemId++,
                    ":transaction_id" => $nextId,
                    ":copy_id" => $copy_id,
                    ":due_date" => $dueByCopy[$copy_id]
                ]);
                $copyUpd->execute([
                    ":status_id" => $borrowedStatusId,
                    ":copy_id" => $copy_id
                ]);
            }

            $conn->commit();

            $distinct = array_unique(array_values($dueByCopy));
            $when = count($distinct) === 1
                ? "Due date: " . $due_date . "."
                : "Each book has its own due date (earliest: " . $due_date . ").";

            echo json_encode([
                "status" => "success",
                "message" => "Borrowed " . count($copy_ids) . " book(s). " . $when,
                "transaction_id" => $nextId,
                "due_date" => $due_date,
                "due_dates" => $dueByCopy
            ]);
        } catch (Exception $e) {
            if ($conn->inTransaction()) {
                $conn->rollBack();
            }
            error_log("borrow failed: " . $e->getMessage());
            echo json_encode(["status" => "error", "message" => "Failed to save borrow transaction."]);
        }
    }

    /* =====================================================================
       Endpoints for the borrower-first Borrow Transactions screen
       ===================================================================== */

    private function pageParams($defaultLimit, $maxLimit = 50) {
        $limit = max(1, min($maxLimit, (int) ($_GET['limit'] ?? $defaultLimit)));
        $page = max(1, (int) ($_GET['page'] ?? 1));
        return [$page, $limit, ($page - 1) * $limit];
    }

    private function searchTerms($raw) {
        $terms = preg_split('/\s+/', trim((string) $raw), -1, PREG_SPLIT_NO_EMPTY);
        return array_slice($terms ?: [], 0, 5);
    }

    private function like($term) {
        return '%' . addcslashes($term, '%_\\') . '%';
    }

    // Every possible borrower in one list: all student records (students and faculty that
    // already have one) plus faculty users who have no student record yet. Those get the key
    // "f<user_id>", exactly what resolveBorrower() expects when borrowing.
    private function borrowerSql($conn, $bind) {
        $today = $bind(date('Y-m-d'));
        $flim = LoanRules::limit($conn, true);
        $slim = LoanRules::limit($conn, false);
        $open = "(bi.is_returned IS NULL OR bi.is_returned = 0)";

        $base = "SELECT CAST(s.student_id AS CHAR) AS borrower_key, s.student_id, s.user_id,
                        s.first_name, s.last_name, s.email, s.phone, s.course,
                        d.department_name,
                        CASE WHEN (LOWER(IFNULL(r.role_name, '')) LIKE '%faculty%' OR LOWER(IFNULL(r.role_name, '')) LIKE '%dean%') THEN 1 ELSE 0 END AS is_faculty
                 FROM student s
                 LEFT JOIN users u ON s.user_id = u.user_id
                 LEFT JOIN roles r ON u.role_id = r.role_id
                 LEFT JOIN department d ON u.department_id = d.department_id
                 UNION ALL
                 SELECT CONCAT('f', u.user_id), NULL, u.user_id,
                        u.first_name, u.last_name, u.email, u.contact_number, NULL,
                        d.department_name, 1
                 FROM users u
                 INNER JOIN roles r ON u.role_id = r.role_id
                 LEFT JOIN department d ON u.department_id = d.department_id
                 WHERE LOWER(r.role_name) LIKE '%faculty%'
                   AND NOT EXISTS (SELECT 1 FROM student s2 WHERE s2.user_id = u.user_id)";

        return "SELECT x.*,
                       (SELECT COUNT(*) FROM borrow_items bi
                        INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                        WHERE bt.student_id = x.student_id AND $open) AS books_out,
                       (SELECT COUNT(*) FROM borrow_items bi
                        INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                        WHERE bt.student_id = x.student_id AND $open AND COALESCE(bi.due_date, bt.due_date) < $today) AS overdue_count,
                       CASE WHEN x.is_faculty = 1 THEN $flim ELSE $slim END AS borrow_limit
                FROM ($base) x";
    }

    // Paged, searchable list of borrowers. Search words must ALL match
    // (name, email, phone, course, department or student id).
    function getBorrowers() {
        include "../config/connection-pdo.php";

        $type = $_GET['type'] ?? 'all';
        $sort = $_GET['sort'] ?? 'name';
        $canBorrow = !empty($_GET['available']) && $_GET['available'] !== '0';
        list($page, $limit, $offset) = $this->pageParams(8);

        $params = [];
        $n = 0;
        $bind = function ($value) use (&$params, &$n) {
            $key = ':p' . $n++;
            $params[$key] = $value;
            return $key;
        };

        $inner = $this->borrowerSql($conn, $bind);
        $where = [];

        if ($type === 'faculty') {
            $where[] = "y.is_faculty = 1";
        } elseif ($type === 'student') {
            $where[] = "y.is_faculty = 0";
        }

        if ($canBorrow) {
            $where[] = "y.books_out < y.borrow_limit";
        }

        foreach ($this->searchTerms($_GET['search'] ?? '') as $term) {
            $a = $bind($this->like($term));
            $b = $bind($this->like($term));
            $c = $bind($this->like($term));
            $d = $bind($this->like($term));
            $e = $bind($this->like($term));
            $f = $bind($term);

            $where[] = "(CONCAT_WS(' ', y.first_name, y.last_name) LIKE $a
                         OR y.email LIKE $b
                         OR y.phone LIKE $c
                         OR y.course LIKE $d
                         OR y.department_name LIKE $e
                         OR CAST(y.student_id AS CHAR) = $f)";
        }

        $orders = [
            'name'    => "y.first_name ASC, y.last_name ASC",
            'books'   => "y.books_out DESC, y.first_name ASC, y.last_name ASC",
            'overdue' => "y.overdue_count DESC, y.books_out DESC, y.first_name ASC, y.last_name ASC"
        ];
        $orderBy = $orders[$sort] ?? $orders['name'];

        $from = "FROM ($inner) y" . (count($where) ? " WHERE " . implode(" AND ", $where) : "");

        $countStmt = $conn->prepare("SELECT COUNT(*) $from");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn();

        $stmt = $conn->prepare("SELECT y.* $from ORDER BY $orderBy LIMIT " . (int) $limit . " OFFSET " . (int) $offset);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Whole-library numbers for the summary cards (not affected by the search box).
        $sum = $conn->prepare("SELECT COUNT(DISTINCT bt.student_id) AS borrowers,
                                      COUNT(bi.item_id) AS books_out,
                                      SUM(CASE WHEN COALESCE(bi.due_date, bt.due_date) < :today THEN 1 ELSE 0 END) AS overdue_books
                               FROM borrow_items bi
                               INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                               WHERE bi.is_returned IS NULL OR bi.is_returned = 0");
        $sum->execute([":today" => date('Y-m-d')]);
        $summary = $sum->fetch(PDO::FETCH_ASSOC) ?: [];

        $avail = (int) $conn->query("SELECT COUNT(*) FROM book_copies bc
                                     INNER JOIN status s ON bc.status_id = s.status_id
                                     WHERE s.status_desc = 'Available'")->fetchColumn();

        echo json_encode([
            "rows" => $rows,
            "total" => $total,
            "page" => $page,
            "pages" => max(1, (int) ceil($total / $limit)),
            "limit" => $limit,
            "summary" => [
                "borrowers" => (int) ($summary['borrowers'] ?? 0),
                "books_out" => (int) ($summary['books_out'] ?? 0),
                "overdue_books" => (int) ($summary['overdue_books'] ?? 0),
                "available_copies" => $avail
            ]
        ]);
    }

    // One borrower plus the books they currently have out.
    function getBorrower() {
        include "../config/connection-pdo.php";

        $key = trim((string) ($_GET['key'] ?? ''));

        if ($key === '') {
            echo json_encode(["status" => "error", "message" => "Borrower is required."]);
            return;
        }

        $fetch = function ($key) use ($conn) {
            $params = [];
            $n = 0;
            $bind = function ($value) use (&$params, &$n) {
                $k = ':p' . $n++;
                $params[$k] = $value;
                return $k;
            };
            $inner = $this->borrowerSql($conn, $bind);
            $k = $bind($key);
            $stmt = $conn->prepare("SELECT y.* FROM ($inner) y WHERE y.borrower_key = $k LIMIT 1");
            $stmt->execute($params);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        };

        $borrower = $fetch($key);

        // A faculty member picked as "f12" may have just been given a student record.
        if (!$borrower && preg_match('/^f(\d+)$/', $key, $m)) {
            $s = $conn->prepare("SELECT student_id FROM student WHERE user_id = :u LIMIT 1");
            $s->execute([":u" => (int) $m[1]]);
            $sid = $s->fetchColumn();
            if ($sid) {
                $borrower = $fetch((string) $sid);
            }
        }

        if (!$borrower) {
            echo json_encode(["status" => "error", "message" => "Borrower not found."]);
            return;
        }

        $today = date('Y-m-d');
        $items = [];

        if ($borrower['student_id'] !== null) {
            $stmt = $conn->prepare("SELECT bi.item_id, bi.transaction_id, b.title, b.book_type,
                                           bc.accession_number, bt.borrow_date,
                                           COALESCE(bi.due_date, bt.due_date) AS due_date
                                    FROM borrow_items bi
                                    INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                                    LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                                    LEFT JOIN book b ON bc.book_id = b.book_id
                                    WHERE bt.student_id = :id
                                      AND (bi.is_returned IS NULL OR bi.is_returned = 0)
                                    ORDER BY COALESCE(bi.due_date, bt.due_date) ASC, b.title ASC, bi.item_id ASC");
            $stmt->execute([":id" => $borrower['student_id']]);
            $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $todayTs = strtotime($today);
            foreach ($items as &$item) {
                $item['days_overdue'] = $item['due_date']
                    ? (int) round(($todayTs - strtotime($item['due_date'])) / 86400)
                    : null;
            }
            unset($item);
        }

        $borrower['books_out'] = count($items);

        echo json_encode([
            "status" => "success",
            "today" => $today,
            "borrower" => $borrower,
            "items" => $items
        ]);
    }

    // Paged, searchable list of copies that are on the shelf (status "Available").
    // Search words must ALL match (title, accession no., author, publisher or category).
    function getAvailableCopies() {
        include "../config/connection-pdo.php";

        $type = $_GET['type'] ?? 'all';
        list($page, $limit, $offset) = $this->pageParams(10);

        $params = [];
        $n = 0;
        $bind = function ($value) use (&$params, &$n) {
            $key = ':p' . $n++;
            $params[$key] = $value;
            return $key;
        };

        $where = ["s.status_desc = 'Available'"];

        if ($type === 'Educational' || $type === 'Fictional') {
            $where[] = "b.book_type = " . $bind($type);
        }

        foreach ($this->searchTerms($_GET['search'] ?? '') as $term) {
            $a = $bind($this->like($term));
            $b2 = $bind($this->like($term));
            $c = $bind($this->like($term));
            $d = $bind($this->like($term));
            $e = $bind($this->like($term));

            $where[] = "(b.title LIKE $a
                         OR bc.accession_number LIKE $b2
                         OR p.publisher_name LIKE $c
                         OR c.category_type LIKE $d
                         OR EXISTS (SELECT 1 FROM book_author ba
                                    INNER JOIN author a ON ba.author_id = a.author_id
                                    WHERE ba.book_id = b.book_id
                                      AND CONCAT_WS(' ', a.first_name, a.last_name) LIKE $e))";
        }

        $from = "FROM book_copies bc
                 INNER JOIN book b ON bc.book_id = b.book_id
                 INNER JOIN status s ON bc.status_id = s.status_id
                 LEFT JOIN categories c ON b.category_id = c.category_id
                 LEFT JOIN publisher p ON b.publisher_id = p.publisher_id
                 WHERE " . implode(" AND ", $where);

        // Pages are counted in BOOKS, so every copy of a book is always on the same page.
        $countStmt = $conn->prepare("SELECT COUNT(DISTINCT bc.book_id), COUNT(*) $from");
        $countStmt->execute($params);
        list($total, $totalCopies) = array_map('intval', $countStmt->fetch(PDO::FETCH_NUM));

        $idStmt = $conn->prepare("SELECT bc.book_id
                                  $from
                                  GROUP BY bc.book_id, b.title
                                  ORDER BY b.title ASC, bc.book_id ASC
                                  LIMIT " . (int) $limit . " OFFSET " . (int) $offset);
        $idStmt->execute($params);
        $bookIds = array_map('intval', $idStmt->fetchAll(PDO::FETCH_COLUMN));

        $rows = [];
        if (count($bookIds) > 0) {
            $stmt = $conn->prepare("SELECT bc.copy_id, bc.book_id, bc.accession_number, bc.`condition`,
                                           b.title, b.book_type, c.category_type,
                                           (SELECT GROUP_CONCAT(CONCAT_WS(' ', a2.first_name, a2.last_name) SEPARATOR ', ')
                                            FROM book_author ba2
                                            INNER JOIN author a2 ON ba2.author_id = a2.author_id
                                            WHERE ba2.book_id = b.book_id) AS authors
                                    $from
                                    AND bc.book_id IN (" . implode(',', $bookIds) . ")
                                    ORDER BY b.title ASC, bc.book_id ASC, CAST(bc.accession_number AS UNSIGNED) ASC, bc.accession_number ASC");
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        echo json_encode([
            "rows" => $rows,
            "total" => $total,
            "total_copies" => $totalCopies,
            "page" => $page,
            "pages" => max(1, (int) ceil($total / $limit)),
            "limit" => $limit
        ]);
    }

    // Past and current transactions with the books on each one.
    // state: open (books still out), overdue, completed (everything back).
    function getTransactions() {
        include "../config/connection-pdo.php";

        list($page, $limit, $offset) = $this->pageParams(10);
        $state = $_GET['state'] ?? '';

        $params = [];
        $n = 0;
        $bind = function ($value) use (&$params, &$n) {
            $key = ':p' . $n++;
            $params[$key] = $value;
            return $key;
        };

        $today = $bind(date('Y-m-d'));

        $inner = "SELECT bt.transaction_id, bt.student_id, bt.processed_by_user_id, bt.borrow_date,
                         bt.due_date, bt.status_id, bt.created_at,
                         CONCAT_WS(' ', s.first_name, s.last_name) AS student_name,
                         CONCAT_WS(' ', u.first_name, u.last_name) AS processed_by,
                         st.status_desc,
                         (SELECT COUNT(*) FROM borrow_items bi WHERE bi.transaction_id = bt.transaction_id) AS item_count,
                         (SELECT COUNT(*) FROM borrow_items bi WHERE bi.transaction_id = bt.transaction_id AND bi.is_returned = 1) AS returned_count,
                         (SELECT MIN(COALESCE(bi.due_date, bt.due_date)) FROM borrow_items bi
                          WHERE bi.transaction_id = bt.transaction_id AND (bi.is_returned IS NULL OR bi.is_returned = 0)) AS next_due,
                         (SELECT COUNT(*) FROM borrow_items bi
                          WHERE bi.transaction_id = bt.transaction_id AND (bi.is_returned IS NULL OR bi.is_returned = 0)
                            AND COALESCE(bi.due_date, bt.due_date) < $today) AS overdue_items
                  FROM borrow_transaction bt
                  LEFT JOIN student s ON bt.student_id = s.student_id
                  LEFT JOIN users u ON bt.processed_by_user_id = u.user_id
                  LEFT JOIN status st ON bt.status_id = st.status_id";

        $stateSql = "SELECT t.*,
                            CASE WHEN t.item_count = 0 THEN 'empty'
                                 WHEN t.returned_count >= t.item_count THEN 'completed'
                                 WHEN t.overdue_items > 0 THEN 'overdue'
                                 ELSE 'open' END AS state
                     FROM ($inner) t";

        $where = [];

        if (in_array($state, ['open', 'overdue', 'completed'], true)) {
            // "open" means "still has books out", so it includes the overdue ones.
            $where[] = $state === 'open' ? "z.state IN ('open', 'overdue')" : "z.state = " . $bind($state);
        }

        foreach ($this->searchTerms($_GET['search'] ?? '') as $term) {
            $a = $bind($this->like($term));
            $b = $bind($this->like($term));
            $c = $bind($this->like($term));
            $d = $bind($this->like($term));
            $idEq = $bind($term);

            $where[] = "(z.student_name LIKE $a
                         OR z.processed_by LIKE $b
                         OR CAST(z.transaction_id AS CHAR) = $idEq
                         OR EXISTS (SELECT 1 FROM borrow_items bi2
                                    INNER JOIN book_copies bc2 ON bi2.copy_id = bc2.copy_id
                                    LEFT JOIN book b2 ON bc2.book_id = b2.book_id
                                    WHERE bi2.transaction_id = z.transaction_id
                                      AND (b2.title LIKE $c OR bc2.accession_number LIKE $d)))";
        }

        $from = $_GET['from'] ?? '';
        $to = $_GET['to'] ?? '';
        if ($this->validDate($from)) $where[] = "z.borrow_date >= " . $bind($from);
        if ($this->validDate($to)) $where[] = "z.borrow_date <= " . $bind($to);

        $fromSql = "FROM ($stateSql) z" . (count($where) ? " WHERE " . implode(" AND ", $where) : "");

        $countStmt = $conn->prepare("SELECT COUNT(*) $fromSql");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn();

        $stmt = $conn->prepare("SELECT z.* $fromSql
                                ORDER BY z.borrow_date DESC, z.transaction_id DESC
                                LIMIT " . (int) $limit . " OFFSET " . (int) $offset);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // The books on the transactions of this page.
        if (count($rows) > 0) {
            $ids = array_map(function ($r) { return (int) $r['transaction_id']; }, $rows);
            $in = implode(',', array_fill(0, count($ids), '?'));

            $itemStmt = $conn->prepare("SELECT bi.transaction_id, bi.item_id, bi.copy_id, bi.is_returned,
                                               COALESCE(bi.due_date, bt.due_date) AS due_date,
                                               b.title, b.book_type, bc.accession_number
                                        FROM borrow_items bi
                                        INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                                        LEFT JOIN book_copies bc ON bi.copy_id = bc.copy_id
                                        LEFT JOIN book b ON bc.book_id = b.book_id
                                        WHERE bi.transaction_id IN ($in)
                                        ORDER BY bi.item_id ASC");
            $itemStmt->execute($ids);

            $byTx = [];
            foreach ($itemStmt->fetchAll(PDO::FETCH_ASSOC) as $it) {
                $byTx[$it['transaction_id']][] = $it;
            }

            foreach ($rows as &$row) {
                $row['items'] = $byTx[$row['transaction_id']] ?? [];
            }
            unset($row);
        }

        echo json_encode([
            "rows" => $rows,
            "total" => $total,
            "page" => $page,
            "pages" => max(1, (int) ceil($total / $limit)),
            "limit" => $limit
        ]);
    }

    function add($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $student_id = $json['student_id'] ?? null;
        $processed_by_user_id = Auth::id();
        $borrow_date = $json['borrow_date'] ?? null;
        $due_date = $json['due_date'] ?? null;
        $status_id = $json['status_id'] ?? null;

        if ($this->blank($student_id) || $this->blank($processed_by_user_id) ||
            $this->blank($borrow_date) || $this->blank($due_date) || $this->blank($status_id)) {
            echo json_encode([
                "status" => "error",
                "message" => "All fields are required."
            ]);
            return;
        }

        if ($due_date < $borrow_date) {
            echo json_encode([
                "status" => "error",
                "message" => "Due date cannot be earlier than borrow date."
            ]);
            return;
        }

        $sqlMax = "SELECT IFNULL(MAX(transaction_id), 0) + 1 AS nextId
                   FROM borrow_transaction";

        $stmtMax = $conn->prepare($sqlMax);
        $stmtMax->execute();

        $nextId = $stmtMax->fetch(PDO::FETCH_ASSOC)['nextId'];

        $sql = "INSERT INTO borrow_transaction
                    (transaction_id, student_id, processed_by_user_id,
                     borrow_date, due_date, status_id, created_at)
                VALUES
                    (:transaction_id, :student_id, :processed_by_user_id,
                     :borrow_date, :due_date, :status_id, NOW())";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":transaction_id", $nextId);
        $stmt->bindParam(":student_id", $student_id);
        $stmt->bindParam(":processed_by_user_id", $processed_by_user_id);
        $stmt->bindParam(":borrow_date", $borrow_date);
        $stmt->bindParam(":due_date", $due_date);
        $stmt->bindParam(":status_id", $status_id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode([
                "status" => "success",
                "message" => "Borrow transaction added successfully.",
                "transaction_id" => $nextId
            ]);
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "Failed to add borrow transaction."
            ]);
        }
    }

    // Edits a transaction. Due dates are kept per book: "items" is a list of
    // {item_id, due_date}. Each date must be within the limit for THAT book (borrower type +
    // book type, counted from the borrow date). Returned books keep the date they had.
    // Older clients may still send a single "due_date", which is applied to every book out.
    function update($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $transaction_id = $json['transaction_id'] ?? null;
        $student_id = $json['student_id'] ?? null;
        $processed_by_user_id = Auth::id();
        $borrow_date = $json['borrow_date'] ?? null;
        $due_date = $json['due_date'] ?? null;
        $status_id = $json['status_id'] ?? null;
        $itemsIn = isset($json['items']) && is_array($json['items']) ? $json['items'] : null;

        if ($this->blank($transaction_id) || $this->blank($student_id) ||
            $this->blank($processed_by_user_id) || $this->blank($borrow_date) ||
            $this->blank($status_id) || ($itemsIn === null && $this->blank($due_date))) {
            echo json_encode([
                "status" => "error",
                "message" => "All fields are required."
            ]);
            return;
        }

        if (!$this->validDate($borrow_date)) {
            echo json_encode(["status" => "error", "message" => "Please enter a valid borrow date."]);
            return;
        }

        try {
            $conn->beginTransaction();

            list($resolvedId, $facultyOverride, $resolveError) = $this->resolveBorrower($conn, $student_id, true);

            if ($resolveError) {
                $this->abort($conn, $resolveError);
                return;
            }

            $student_id = $resolvedId;

            $itemStmt = $conn->prepare("SELECT bi.item_id, bi.copy_id, bi.is_returned,
                                               COALESCE(bi.due_date, bt.due_date) AS due_date
                                        FROM borrow_items bi
                                        INNER JOIN borrow_transaction bt ON bi.transaction_id = bt.transaction_id
                                        WHERE bi.transaction_id = :t
                                        FOR UPDATE");
            $itemStmt->execute([":t" => $transaction_id]);
            $items = $itemStmt->fetchAll(PDO::FETCH_ASSOC);

            $requested = [];
            if ($itemsIn !== null) {
                foreach ($itemsIn as $row) {
                    if (isset($row['item_id'])) {
                        $requested[(int) $row['item_id']] = $row['due_date'] ?? null;
                    }
                }
            }

            // The longest loan allowed for each book on this transaction, from the borrow date.
            $maxByCopy = [];
            $titleByCopy = [];
            $plan = null;

            if (count($items) > 0) {
                $copy_ids = array_map(function ($i) { return (int) $i['copy_id']; }, $items);
                $plan = LoanRules::plan($conn, $student_id, $copy_ids, $borrow_date, $facultyOverride);

                foreach ($plan['books'] as $bk) {
                    $maxByCopy[$bk['copy_id']] = $bk['due_date'];
                    $titleByCopy[$bk['copy_id']] = $bk['title'];
                }
            }

            $newDue = [];

            foreach ($items as $it) {
                $itemId = (int) $it['item_id'];
                $copyId = (int) $it['copy_id'];
                $returned = (int) $it['is_returned'] === 1;
                $due = $it['due_date'];

                if (!$returned) {
                    $req = $itemsIn !== null ? ($requested[$itemId] ?? null) : $due_date;

                    if (!$this->blank($req)) {
                        $title = $titleByCopy[$copyId] ?? "this book";

                        if (!$this->validDate($req)) {
                            $this->abort($conn, "Please enter a valid due date for \"$title\".");
                            return;
                        }

                        if ($req < $borrow_date) {
                            $this->abort($conn, "The due date for \"$title\" cannot be earlier than the borrow date.");
                            return;
                        }

                        if (isset($maxByCopy[$copyId]) && $req > $maxByCopy[$copyId]) {
                            $this->abort($conn, sprintf(
                                "The due date for \"%s\" cannot be later than %s. That is the longest loan allowed for a %s with this book.",
                                $title, $maxByCopy[$copyId], strtolower($plan['borrower_type'])
                            ));
                            return;
                        }

                        $due = $req;
                    }
                }

                $newDue[$itemId] = $due;
            }

            // Summary date for the transaction: the earliest due date among its books.
            $summary = count($newDue) > 0 ? min($newDue) : $due_date;

            if ($this->blank($summary) || !$this->validDate($summary)) {
                $this->abort($conn, "Please enter a valid due date.");
                return;
            }

            $setItem = $conn->prepare("UPDATE borrow_items SET due_date = :d WHERE item_id = :i");
            foreach ($newDue as $itemId => $d) {
                $setItem->execute([":d" => $d, ":i" => $itemId]);
            }

            $stmt = $conn->prepare("UPDATE borrow_transaction
                                    SET student_id = :student_id,
                                        borrow_date = :borrow_date,
                                        due_date = :due_date,
                                        status_id = :status_id
                                    WHERE transaction_id = :transaction_id");
            $stmt->execute([
                ":student_id" => $student_id,
                ":borrow_date" => $borrow_date,
                ":due_date" => $summary,
                ":status_id" => $status_id,
                ":transaction_id" => $transaction_id
            ]);

            $conn->commit();

            echo json_encode([
                "status" => "success",
                "message" => "Borrow transaction updated successfully."
            ]);
        } catch (Exception $e) {
            if ($conn->inTransaction()) {
                $conn->rollBack();
            }
            error_log("update failed: " . $e->getMessage());
            echo json_encode(["status" => "error", "message" => "Failed to update the transaction."]);
        }
    }

    function delete($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);
        $transaction_id = $json['transaction_id'];

        $check = $conn->prepare(
            "SELECT item_id
             FROM borrow_items
             WHERE transaction_id = :transaction_id
             LIMIT 1"
        );
        $check->bindParam(":transaction_id", $transaction_id);
        $check->execute();

        if ($check->rowCount() > 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Cannot delete: this transaction has borrow items."
            ]);
            return;
        }

        $sql = "DELETE FROM borrow_transaction
                WHERE transaction_id = :transaction_id";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":transaction_id", $transaction_id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode([
                "status" => "success",
                "message" => "Borrow transaction deleted successfully."
            ]);
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "Failed to delete borrow transaction."
            ]);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$obj = new BorrowTransaction();

switch ($operation) {
    case "getAll":
        $obj->getAll();
        break;
    case "getBorrowers":
        $obj->getBorrowers();
        break;
    case "getBorrower":
        $obj->getBorrower();
        break;
    case "getAvailableCopies":
        $obj->getAvailableCopies();
        break;
    case "getTransactions":
        $obj->getTransactions();
        break;
    case "preview":
        $obj->preview($json);
        break;
    case "borrow":
        $obj->borrow($json);
        break;
    case "add":
        // Direct adds would bypass the loan rules; use "borrow" instead.
        echo json_encode(["status" => "error", "message" => "Use the borrow operation so loan rules are applied."]);
        break;
    case "update":
        $obj->update($json);
        break;
    case "delete":
        $obj->delete($json);
        break;
}

?>