<?php
header('Content-Type: application/json');
require_once __DIR__ . "/../config/auth.php";
Auth::guard(basename(__FILE__, '.php'));

class Author {
    private function isMeaningfulText($value) {
        $trimmed = trim($value);
        return strlen($trimmed) >= 2 && !preg_match('/^\d+$/', $trimmed);
    }

    function getAll() {
        include "../config/connection-pdo.php";

        $sql = "SELECT author_id, first_name, last_name, bio
                FROM author
                ORDER BY first_name ASC, last_name ASC";

        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rs);
    }

    function add($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $first_name = isset($json['first_name']) ? trim($json['first_name']) : "";
        $last_name = isset($json['last_name']) ? trim($json['last_name']) : "";
        $bio = isset($json['bio']) ? trim($json['bio']) : "";
        if ($bio === "") {
            $bio = null; // store blank bios as NULL, not an empty string
        }

        if (empty($first_name) || empty($last_name)) {
            echo json_encode([
                "status" => "error",
                "message" => "First name and last name are required."
            ]);
            return;
        }

        if (!$this->isMeaningfulText($first_name)) {
            echo json_encode([
                "status" => "error",
                "message" => "First name must be a meaningful name, not just numbers."
            ]);
            return;
        }

        if (!$this->isMeaningfulText($last_name)) {
            echo json_encode([
                "status" => "error",
                "message" => "Last name must be a meaningful name, not just numbers."
            ]);
            return;
        }

        lms_lock_ids($conn);

        $sqlMax = "SELECT IFNULL(MAX(author_id), 0) + 1 AS nextId FROM author";
        $stmtMax = $conn->prepare($sqlMax);
        $stmtMax->execute();
        $nextId = $stmtMax->fetch(PDO::FETCH_ASSOC)['nextId'];

        $sql = "INSERT INTO author (author_id, first_name, last_name, bio)
                VALUES (:author_id, :first_name, :last_name, :bio)";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":author_id", $nextId);
        $stmt->bindParam(":first_name", $first_name);
        $stmt->bindParam(":last_name", $last_name);
        $stmt->bindParam(":bio", $bio);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode([
                "status" => "success",
                "message" => "Author added successfully."
            ]);
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "Failed to add author."
            ]);
        }
    }

    function update($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $author_id = (isset($json['author_id']) && $json['author_id'] !== '' && $json['author_id'] !== null)
            ? $json['author_id']
            : null;

        $first_name = isset($json['first_name']) ? trim($json['first_name']) : "";
        $last_name = isset($json['last_name']) ? trim($json['last_name']) : "";
        $bio = isset($json['bio']) ? trim($json['bio']) : "";
        if ($bio === "") {
            $bio = null; // store blank bios as NULL, not an empty string
        }

        if ($author_id === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Author ID is required."
            ]);
            return;
        }

        if (empty($first_name) || empty($last_name)) {
            echo json_encode([
                "status" => "error",
                "message" => "First name and last name are required."
            ]);
            return;
        }

        if (!$this->isMeaningfulText($first_name)) {
            echo json_encode([
                "status" => "error",
                "message" => "First name must be a meaningful name, not just numbers."
            ]);
            return;
        }

        if (!$this->isMeaningfulText($last_name)) {
            echo json_encode([
                "status" => "error",
                "message" => "Last name must be a meaningful name, not just numbers."
            ]);
            return;
        }

        $sql = "UPDATE author
                SET first_name = :first_name,
                    last_name = :last_name,
                    bio = :bio
                WHERE author_id = :author_id";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":first_name", $first_name);
        $stmt->bindParam(":last_name", $last_name);
        $stmt->bindParam(":bio", $bio);
        $stmt->bindParam(":author_id", $author_id);
        $stmt->execute();

        echo json_encode([
            "status" => "success",
            "message" => "Author updated successfully."
        ]);
    }

    function delete($json) {
        include "../config/connection-pdo.php";

        $json = json_decode($json, true);

        $author_id = (isset($json['author_id']) && $json['author_id'] !== '' && $json['author_id'] !== null)
            ? $json['author_id']
            : null;

        if ($author_id === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Author ID is required."
            ]);
            return;
        }

        $check = $conn->prepare("
            SELECT book_id
            FROM book_author
            WHERE author_id = :author_id
            LIMIT 1
        ");

        $check->bindParam(":author_id", $author_id);
        $check->execute();

        if ($check->rowCount() > 0) {
            echo json_encode([
                "status" => "error",
                "message" => "Cannot delete: this author is linked to one or more books."
            ]);
            return;
        }

        $sql = "DELETE FROM author WHERE author_id = :author_id";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":author_id", $author_id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode([
                "status" => "success",
                "message" => "Author deleted successfully."
            ]);
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "Failed to delete author."
            ]);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$obj = new Author();

switch ($operation) {
    case "getAll":
        $obj->getAll();
        break;
    case "add":
        $obj->add($json);
        break;
    case "update":
        $obj->update($json);
        break;
    case "delete":
        $obj->delete($json);
        break;
}
?>