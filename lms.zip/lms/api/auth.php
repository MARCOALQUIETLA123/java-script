<?php
header('Content-Type: application/json');

require_once __DIR__ . "/../config/auth.php";

const MAX_FAILS_PER_USER = 5;    // within the window below
const MAX_FAILS_PER_IP   = 20;
const WINDOW_MINUTES     = 15;

function out($status, $message, $extra = [], $http = 200) {
    http_response_code($http);
    echo json_encode(array_merge(["status" => $status, "message" => $message], $extra));
    exit;
}

function publicUser($u) {
    return [
        "user_id" => $u['user_id'], "first_name" => $u['first_name'], "last_name" => $u['last_name'],
        "username" => $u['username'], "role" => $u['role'], "role_name" => $u['role_name'],
        "permissions" => $u['permissions'] ?? [],
    ];
}

function login() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') out("error", "Use POST.", [], 405);

    $username = trim($_POST['username'] ?? '');
    $password = (string) ($_POST['password'] ?? '');

    if ($username === '' || $password === '') {
        out("error", "Enter your username and password.", [], 422);
    }

    include __DIR__ . "/../config/connection-pdo.php";
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';

    try {
        // Brute-force guard.
        // Compare against the database clock: attempted_at is written with NOW(), so PHP's
        // timezone must not be involved.
        $window = "attempted_at > DATE_SUB(NOW(), INTERVAL " . (int) WINDOW_MINUTES . " MINUTE)";
        $byUser = $conn->prepare("SELECT COUNT(*) FROM login_attempts WHERE username = :u AND $window");
        $byUser->execute([":u" => strtolower($username)]);
        $byIp = $conn->prepare("SELECT COUNT(*) FROM login_attempts WHERE ip = :ip AND $window");
        $byIp->execute([":ip" => $ip]);

        if ((int) $byUser->fetchColumn() >= MAX_FAILS_PER_USER || (int) $byIp->fetchColumn() >= MAX_FAILS_PER_IP) {
            out("error", "Too many failed attempts. Try again in " . WINDOW_MINUTES . " minutes.", [], 429);
        }

        $stmt = $conn->prepare("SELECT u.user_id, u.password, u.account_status, r.role_name
                                FROM users u
                                INNER JOIN roles r ON u.role_id = r.role_id
                                WHERE u.username = :username LIMIT 1");
        $stmt->execute([":username" => $username]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        $ok = false;

        if ($row) {
            $stored = (string) $row['password'];
            $info = password_get_info($stored);

            if (!empty($info['algo'])) {
                $ok = password_verify($password, $stored);
            } else {
                // Account created before hashing was added: compare once, then upgrade it.
                $ok = $stored !== '' && hash_equals($stored, $password);
            }

            if ($ok && (empty($info['algo']) || password_needs_rehash($stored, PASSWORD_DEFAULT))) {
                $up = $conn->prepare("UPDATE users SET password = :p WHERE user_id = :id");
                $up->execute([":p" => password_hash($password, PASSWORD_DEFAULT), ":id" => $row['user_id']]);
            }

            // Faculty and other borrower-only roles are not allowed to sign in.
            if ($ok && Auth::roleKey($row['role_name']) === null) $ok = false;
        } else {
            password_hash($password, PASSWORD_DEFAULT); // keep timing similar for unknown usernames
        }

        if (!$ok) {
            $conn->prepare("INSERT INTO login_attempts (username, ip, attempted_at) VALUES (:u, :ip, NOW())")
                 ->execute([":u" => strtolower($username), ":ip" => $ip]);
            out("error", "Invalid username or password.", [], 401);
        }

        $conn->prepare("DELETE FROM login_attempts WHERE username = :u")->execute([":u" => strtolower($username)]);

        // Password was right, but the account may not be switched on yet.
        if ($row['account_status'] === 'pending') {
            out("error", "Your account is waiting for the Technical Services Librarian to approve it.", ["code" => "pending"], 403);
        }
        if ($row['account_status'] !== 'active') {
            out("error", "Your account is deactivated. Ask the Technical Services Librarian to activate it.", ["code" => "disabled"], 403);
        }
    } catch (PDOException $e) {
        error_log("login failed: " . $e->getMessage());
        out("error", "Login is unavailable. Have the database/auth_migration*.sql files been run?", [], 500);
    }

    Auth::begin($row['user_id']);
    $me = Auth::current();
    out("success", "Welcome, " . $me['first_name'] . ".", ["user" => publicUser($me)]);
}

// Public: departments for the sign-up form.
function departments() {
    include __DIR__ . "/../config/connection-pdo.php";
    $rows = $conn->query("SELECT department_id, department_name FROM department ORDER BY department_name")
                 ->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($rows);
    exit;
}

// Public sign-up. The account is Library Staff or Student Assistant (SA) and always starts as 'pending':
// it cannot log in until the Technical Services Librarian approves it on the Users page.
// Nobody can sign themselves up as the Technical Services Librarian.
function signup() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') out("error", "Use POST.", [], 405);

    $f = [];
    foreach (['first_name','last_name','contact_number','email','username'] as $k) $f[$k] = trim($_POST[$k] ?? '');
    $password = (string) ($_POST['password'] ?? '');
    $confirm  = (string) ($_POST['confirm_password'] ?? $password);
    $dept     = $_POST['department_id'] ?? '';
    $wantRole = strtolower(trim((string) ($_POST['role'] ?? 'staff')));   // 'staff' or 'sa'
    if (!in_array($wantRole, ['staff', 'sa'], true)) out("error", "Choose Library Staff or Student Assistant.", [], 422);

    foreach ($f as $v) if ($v === '') out("error", "All fields are required.", [], 422);
    if ($dept !== '' && !ctype_digit((string) $dept)) out("error", "Choose a department.", [], 422);   // department is optional for staff

    $namePattern = "/^[\p{L}\p{M}][\p{L}\p{M}' .-]{0,49}$/u";
    if (!preg_match($namePattern, $f['first_name'])) out("error", "First name can only contain letters, spaces, apostrophes, dots and hyphens.", [], 422);
    if (!preg_match($namePattern, $f['last_name']))  out("error", "Last name can only contain letters, spaces, apostrophes, dots and hyphens.", [], 422);
    if (!filter_var($f['email'], FILTER_VALIDATE_EMAIL)) out("error", "Please enter a valid email address.", [], 422);
    if (!preg_match('/^0\d{10}$/', $f['contact_number']) && !preg_match('/^[1-9]\d{9}$/', $f['contact_number'])) {
        out("error", "Contact number must be 11 digits (e.g. 09171234567) or 10 digits without the leading 0.", [], 422);
    }
    if (!preg_match('/^[A-Za-z0-9._-]{3,30}$/', $f['username'])) {
        out("error", "Username must be 3-30 characters: letters, numbers, dot, dash or underscore.", [], 422);
    }
    if (strlen($password) < 8) out("error", "Password must be at least 8 characters.", [], 422);
    if ($password !== $confirm) out("error", "The two passwords don't match.", [], 422);

    include __DIR__ . "/../config/connection-pdo.php";
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';

    try {
        // At most 5 sign-ups per IP per hour.
        $recent = $conn->prepare("SELECT COUNT(*) FROM login_attempts WHERE username = '__signup__' AND ip = :ip AND attempted_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
        $recent->execute([":ip" => $ip]);
        if ((int) $recent->fetchColumn() >= 5) out("error", "Too many sign-ups from this device. Try again later.", [], 429);

        if ($wantRole === 'sa') {
            $names = Auth::SA_NAMES;
            $best  = 'student assistant';
        } else {
            $names = Auth::STAFF_NAMES;
            $best  = 'library staff';
        }
        $role = $conn->prepare("SELECT role_id FROM roles WHERE LOWER(TRIM(role_name)) IN ('" . implode("','", $names) . "')
                                ORDER BY (LOWER(TRIM(role_name)) = '$best') DESC LIMIT 1");
        $role->execute();
        $roleId = $role->fetchColumn();
        if ($roleId === false && $wantRole === 'sa') {
            // Older database: the Student Assistant role has not been created yet. Create it.
            lms_lock_ids($conn);
            $next = (int) $conn->query("SELECT COALESCE(MAX(role_id), 0) + 1 FROM roles")->fetchColumn();
            $conn->prepare("INSERT INTO roles (role_id, role_name, default_loan_days) VALUES (:id, 'Student Assistant', 0)")
                 ->execute([":id" => $next]);
            $roleId = $next;
        }
        if ($roleId === false) out("error", "Sign-up isn't set up yet. Ask the Technical Services Librarian.", [], 503);

        if ($dept !== '') {
            $d = $conn->prepare("SELECT 1 FROM department WHERE department_id = :d");
            $d->execute([":d" => $dept]);
            if (!$d->fetchColumn()) out("error", "Choose a department.", [], 422);
        } else {
            $dept = null;
        }

        $taken = $conn->prepare("SELECT 1 FROM users WHERE username = :u");
        $taken->execute([":u" => $f['username']]);
        if ($taken->fetchColumn()) out("error", "That username is already taken.", [], 409);

        $conn->prepare("INSERT INTO users (role_id, department_id, first_name, last_name, contact_number, email,
                                           username, password, account_status, created_at, updated_at)
                        VALUES (:r, :d, :fn, :ln, :c, :e, :u, :p, 'pending', NOW(), NOW())")
             ->execute([":r" => $roleId, ":d" => $dept, ":fn" => $f['first_name'], ":ln" => $f['last_name'],
                        ":c" => $f['contact_number'], ":e" => $f['email'], ":u" => $f['username'],
                        ":p" => password_hash($password, PASSWORD_DEFAULT)]);

        $conn->prepare("INSERT INTO login_attempts (username, ip, attempted_at) VALUES ('__signup__', :ip, NOW())")
             ->execute([":ip" => $ip]);
    } catch (PDOException $e) {
        error_log("signup failed: " . $e->getMessage());
        out("error", "Sign-up is unavailable. Have the database/auth_migration*.sql files been run?", [], 500);
    }

    out("success", $wantRole === 'sa'
        ? "Student Assistant account created. The Technical Services Librarian must approve it before you can log in."
        : "Account created. The Technical Services Librarian must approve it before you can log in.");
}

$operation = $_GET['operation'] ?? $_POST['operation'] ?? '';

switch ($operation) {
    case "departments":
        departments();
        break;
    case "signup":
        signup();
        break;
    case "login":
        login();
        break;
    case "logout":
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') out("error", "Use POST.", [], 405);
        Auth::end();
        out("success", "Signed out.");
        break;
    case "me":
        $me = Auth::current();
        if (!$me) out("error", "Please log in to continue.", ["code" => "unauthenticated"], 401);
        out("success", "OK", ["user" => publicUser($me)]);
        break;
    default:
        out("error", "Unknown operation.", [], 400);
}