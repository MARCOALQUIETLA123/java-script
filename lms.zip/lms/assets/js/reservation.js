const baseApiUrl = "api"; // relative to the page, so it works from any folder

const MAX_HOLD_DAYS = 14;    // keep in step with Reservation::MAX_HOLD_DAYS in api/reservation.php
const DEFAULT_HOLD_DAYS = 7;

const STATUS_BADGE = {
    Pending: "bg-info text-dark",
    Ready: "bg-success",
    Waiting: "bg-warning text-dark",
    Fulfilled: "bg-primary",
    Rejected: "bg-danger",
    Cancelled: "bg-secondary",
    Expired: "bg-danger"
};

const FILTERS = [
    ["", "All"],
    ["Pending", "Needs approval"],
    ["Ready", "Ready"],
    ["Waiting", "Waiting"],
    ["Fulfilled", "Fulfilled"],
    ["Rejected", "Rejected"],
    ["Cancelled", "Cancelled"],
    ["Expired", "Expired"]
];

let activeFilter = "";
let pendingCheckoutId = null;
let pendingConfirm = null;

const escapeHtml = (value) => {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
};

const dateString = (offsetDays = 0) => {
    const d = new Date();
    d.setDate(d.getDate() + offsetDays);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

// Whole days from today until a YYYY-MM-DD date (negative = already past).
const daysUntil = (dateStr) => {
    if (!dateStr) return null;
    const target = new Date(String(dateStr).slice(0, 10) + "T00:00:00");
    const today = new Date(dateString(0) + "T00:00:00");
    return Math.round((target - today) / 86400000);
};

const fmtDate = (value) => {
    if (!value) return "—";
    const d = new Date(String(value).slice(0, 10) + "T00:00:00");
    if (isNaN(d)) return escapeHtml(value);
    return d.toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" });
};

const plural = (n, one, many) => `${n} ${Number(n) === 1 ? one : (many || one + "s")}`;

const isActive = (row) => ["Pending", "Ready", "Waiting"].includes(row.status);

const getModal = (id) => bootstrap.Modal.getOrCreateInstance(document.getElementById(id));

document.addEventListener("DOMContentLoaded", () => {
    setDateLimits();
    loadDropdowns();
    loadRecords();

    const panel = document.getElementById("review-panel");
    panel.addEventListener("change", (e) => {
        if (!e.target.classList.contains("review-check")) return;
        reviewTicks[e.target.dataset.id] = e.target.checked;
        updateReviewSummary(e.target.closest(".review-card"));
    });
    panel.addEventListener("click", (e) => {
        const btn = e.target.closest(".review-submit");
        if (btn) submitReview(btn.closest(".review-card"));
    });

    document.getElementById("btn-save").addEventListener("click", saveRecord);
    document.getElementById("btn-clear").addEventListener("click", clearForm);
    document.getElementById("book_id").addEventListener("change", showBookInfo);
    document.getElementById("res-search").addEventListener("input", renderRecords);
    document.getElementById("btn-confirm-checkout").addEventListener("click", confirmCheckout);
    document.getElementById("btn-confirm-ok").addEventListener("click", runConfirmed);

    document.getElementById("expires_on").addEventListener("change", (e) => {
        const min = dateString(0);
        const max = dateString(MAX_HOLD_DAYS);
        if (e.target.value && e.target.value < min) {
            e.target.value = min;
            showAlert("Pick-up date can't be in the past.", "danger");
        } else if (e.target.value > max) {
            e.target.value = max;
            showAlert(`Pick-up date can't be later than ${max}.`, "danger");
        }
    });
});

const setDateLimits = () => {
    const input = document.getElementById("expires_on");
    input.min = dateString(0);
    input.max = dateString(MAX_HOLD_DAYS);
    input.value = dateString(DEFAULT_HOLD_DAYS);
};

const setQuickDate = (days) => {
    document.getElementById("expires_on").value = dateString(Math.min(days, MAX_HOLD_DAYS));
};

/* ---------------- Toasts ---------------- */

const showAlert = (msg, type = "success") => {
    const container = document.getElementById("toast-container");
    const el = document.createElement("div");

    el.className = `toast align-items-center text-bg-${type} border-0`;
    el.setAttribute("role", "alert");
    el.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${escapeHtml(msg)}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>`;

    container.appendChild(el);
    el.addEventListener("hidden.bs.toast", () => el.remove());
    new bootstrap.Toast(el, { delay: type === "danger" ? 7000 : 4500 }).show();
};

/* ---------------- Dropdowns ---------------- */

const loadDropdowns = async () => {
    try {
        const [studentRes, me] = await Promise.all([
            axios.get(`${baseApiUrl}/student.php`, { params: { operation: "getAll" } }),
            window.authReady
        ]);

        const students = studentRes.data.filter((r) => Number(r.is_faculty) !== 1);
        const faculty = studentRes.data.filter((r) => Number(r.is_faculty) === 1);

        const optionsFor = (rows) => rows
            .map((r) => `<option value="${r.student_id}">${escapeHtml(r.first_name)} ${escapeHtml(r.last_name)}</option>`)
            .join("");

        let html = '<option value="">Select Borrower</option>';
        html += `<optgroup label="Students">${optionsFor(students)}</optgroup>`;
        if (faculty.length > 0) {
            html += `<optgroup label="Faculty">${optionsFor(faculty)}</optgroup>`;
        }
        document.getElementById("student_id").innerHTML = html;

        // Processed-by is always the signed-in user; the server fills it in from the session.
        const meOption = `<option value="${me.user_id}">${escapeHtml(me.first_name)} ${escapeHtml(me.last_name)}</option>`;
        ["processed_by_user_id", "co-processed-by"].forEach((id) => {
            const el = document.getElementById(id);
            el.innerHTML = meOption;
            el.disabled = true;
        });
    } catch (error) {
        showAlert("Failed to load borrowers and users.", "danger");
    }

    loadBooks();
};

const loadBooks = async () => {
    try {
        const response = await axios.get(`${baseApiUrl}/reservation.php`, { params: { operation: "getBooks" } });
        window._books = Array.isArray(response.data) ? response.data : [];

        const select = document.getElementById("book_id");
        const current = select.value;
        select.innerHTML = '<option value="">Select Book</option>';

        window._books.forEach((b) => {
            const note = b.total_copies === 0
                ? "no copies"
                : (b.available > 0 ? `${b.available} available` : "none available");
            select.innerHTML += `<option value="${b.book_id}">${escapeHtml(b.title)} (${note})</option>`;
        });

        select.value = current;
        showBookInfo();
    } catch (error) {
        showAlert("Failed to load books.", "danger");
    }
};

const showBookInfo = () => {
    const box = document.getElementById("book-info");
    const saveBtn = document.getElementById("btn-save");
    const id = document.getElementById("book_id").value;
    const book = (window._books || []).find((b) => String(b.book_id) === id);

    saveBtn.disabled = !!book && book.total_copies === 0;

    if (!book) {
        box.className = "alert alert-secondary small py-2 mt-2 mb-0";
        box.innerText = "Pick a book to see whether a copy is free.";
        return;
    }

    const held = book.reserved > 0
        ? ` ${book.reserved} ${book.reserved === 1 ? "copy is" : "copies are"} already reserved for others.`
        : "";

    if (book.total_copies === 0) {
        box.className = "alert alert-danger small py-2 mt-2 mb-0";
        box.innerText = "This book has no copies in the library yet, so it can't be reserved.";
    } else if (book.available > 0) {
        box.className = "alert alert-success small py-2 mt-2 mb-0";
        box.innerText = `${book.available} of ${book.total_copies} copies are free. One will be marked Reserved for the borrower until the pick-up date.${held}`;
    } else {
        box.className = "alert alert-warning small py-2 mt-2 mb-0";
        box.innerText = `All ${book.total_copies} copies are out or reserved. This reservation joins the waiting list and becomes Ready when one is returned.`;
    }
};

/* ---------------- List ---------------- */

const loadRecords = async () => {
    try {
        const response = await axios.get(`${baseApiUrl}/reservation.php`, { params: { operation: "getAll" } });

        if (!Array.isArray(response.data)) {
            showAlert(response.data.message || "Failed to load reservations.", "danger");
            return;
        }

        window._reservations = response.data;
        renderRecords();
    } catch (error) {
        showAlert("Failed to load reservations.", "danger");
    }
};

const setFilter = (status) => {
    activeFilter = status;
    renderRecords();
};

const renderRecords = () => {
    const tbody = document.getElementById("table-body");
    const all = window._reservations || [];
    const term = document.getElementById("res-search").value.trim().toLowerCase();

    // Counts for the filter tabs and the summary cards.
    const counts = {};
    all.forEach((r) => { counts[r.status] = (counts[r.status] || 0) + 1; });

    document.getElementById("status-tabs").innerHTML = FILTERS.map(([value, label]) => {
        const n = value === "" ? all.length : (counts[value] || 0);
        const on = value === activeFilter;
        return `<button type="button" class="btn btn-sm ${on ? "btn-success" : "btn-outline-secondary"}" onclick="setFilter('${value}')">
                    ${label} <span class="badge ${on ? "bg-light text-success" : "bg-secondary"} ms-1">${n}</span>
                </button>`;
    }).join("");

    document.getElementById("stat-pending").innerText = counts.Pending || 0;
    document.getElementById("stat-ready").innerText = counts.Ready || 0;
    document.getElementById("stat-waiting").innerText = counts.Waiting || 0;
    document.getElementById("stat-soon").innerText = all.filter((r) => {
        const d = daysUntil(r.expires_on);
        return isActive(r) && d !== null && d <= 1;
    }).length;

    const rows = all.filter((r) => {
        if (activeFilter && r.status !== activeFilter) return false;
        if (term) {
            const text = `${r.borrower} ${r.title} ${r.accession_number || ""}`.toLowerCase();
            if (!text.includes(term)) return false;
        }
        return true;
    });

    // "Needs approval" is a review screen: one card per student with all the books they asked for.
    const reviewOn = activeFilter === "Pending";
    document.getElementById("review-panel").classList.toggle("d-none", !reviewOn);
    document.getElementById("table-wrap").classList.toggle("d-none", reviewOn);
    if (reviewOn) { renderReview(rows); return; }

    if (rows.length === 0) {
        const msg = all.length === 0
            ? "No reservations yet. Use the form to reserve a book."
            : "No reservations match your filters.";
        tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-4">${msg}</td></tr>`;
        return;
    }

    tbody.innerHTML = rows.map((row) => {
        const badge = STATUS_BADGE[row.status] || "bg-secondary";
        const active = isActive(row);
        const days = daysUntil(row.expires_on);
        const urgent = active && days !== null && days <= 1;

        const type = row.borrower_type
            ? ` <span class="badge bg-light text-dark border ms-1">${escapeHtml(row.borrower_type)}</span>`
            : "";

        let copyCell = "—";
        if (row.status === "Ready") {
            copyCell = `<span class="copy-chip">ACC-${escapeHtml(row.accession_number)}</span>
                        <span class="badge bg-info text-dark" title="This copy is held and can't be borrowed by anyone else">Reserved</span>`;
        } else if (row.status === "Pending") {
            copyCell = `<span class="text-muted small">Not held yet. Approve to hold a copy.</span>`;
        } else if (row.status === "Waiting") {
            copyCell = `<span class="text-muted small">Waiting for a copy</span>`;
        } else if (row.accession_number) {
            copyCell = `<span class="copy-chip">ACC-${escapeHtml(row.accession_number)}</span>`;
        }

        let pickup = fmtDate(row.expires_on);
        if (active && days !== null) {
            const label = days < 0 ? "overdue" : days === 0 ? "today" : days === 1 ? "tomorrow" : `in ${days} days`;
            pickup += `<div class="small ${urgent ? "text-danger fw-semibold" : "text-muted"}">${label}</div>`;
        }

        let actions = "";
        if (row.status === "Pending") {
            actions += `<button class="btn btn-success btn-sm me-1" onclick="approveRecord(${row.reservation_id})">Approve</button>
                        <button class="btn btn-outline-danger btn-sm" onclick="rejectRecord(${row.reservation_id})">Reject</button>`;
        } else if (row.status === "Ready") {
            actions += `<button class="btn btn-success btn-sm me-1" onclick="openCheckout(${row.reservation_id})">Check Out</button>`;
        }
        if (active && row.status !== "Pending") {
            actions += `<button class="btn btn-outline-danger btn-sm" onclick="cancelRecord(${row.reservation_id})">Cancel</button>`;
        } else if (!active) {
            actions += `<button class="btn btn-outline-secondary btn-sm admin-only" onclick="deleteRecord(${row.reservation_id})">Delete</button>`;
        }

        return `
            <tr class="${urgent ? "row-urgent" : ""}">
                <td class="fw-semibold">${escapeHtml(row.borrower)}${type}</td>
                <td>
                    ${escapeHtml(row.title)}
                    <div class="small text-muted">Reserved ${fmtDate(row.reserved_at)}</div>
                </td>
                <td>${copyCell}</td>
                <td>${pickup}</td>
                <td><span class="badge ${badge}">${escapeHtml(row.status === "Pending" ? "Needs approval" : row.status)}</span>${row.status === "Rejected" && row.reject_reason ? `<div class="small text-muted mt-1">${escapeHtml(row.reject_reason)}</div>` : ""}</td>
                <td>${actions}</td>
            </tr>`;
    }).join("");
};

/* ---------------- Actions ---------------- */

/* ---------------- Review a student's requests together ---------------- */

const reviewTicks = {};     // reservation_id -> true (approve) / false (reject); kept while the page refreshes
const DEFAULT_REJECT_REASON = "Book is unavailable";

const canBorrow = (r) => Number(r.borrowable_copies) > 0;

// Free copies are pre-ticked. A book with no borrowable copy can only be rejected.
const isTicked = (r) => {
    if (!canBorrow(r)) return false;
    if (reviewTicks[r.reservation_id] !== undefined) return reviewTicks[r.reservation_id];
    return Number(r.available_now) > 0;
};

const availabilityBadge = (r) => {
    if (!canBorrow(r)) return '<span class="badge bg-danger">Library use only. Can\'t be borrowed</span>';
    const n = Number(r.available_now);
    if (n > 0) return `<span class="badge bg-success">${n} ${n === 1 ? "copy" : "copies"} free</span>`;
    return '<span class="badge bg-warning text-dark">None free right now</span>';
};

const renderReview = (rows) => {
    const panel = document.getElementById("review-panel");

    if (rows.length === 0) {
        panel.innerHTML = '<div class="text-center text-muted py-4">No requests are waiting for approval.</div>';
        return;
    }

    const groups = new Map();
    rows.forEach((r) => {
        if (!groups.has(r.student_id)) groups.set(r.student_id, { name: r.borrower, type: r.borrower_type, rows: [] });
        groups.get(r.student_id).rows.push(r);
    });

    panel.innerHTML = [...groups.entries()].map(([sid, g]) => `
        <div class="card mb-3 review-card" data-student="${escapeHtml(sid)}">
            <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
                <div><strong>${escapeHtml(g.name)}</strong> <span class="badge bg-secondary">${escapeHtml(g.type)}</span></div>
                <div class="small text-muted">${plural(g.rows.length, "book")} requested. Tick the books they may borrow.</div>
            </div>
            <ul class="list-group list-group-flush">
                ${g.rows.map((r) => `
                <li class="list-group-item d-flex flex-wrap align-items-center gap-3">
                    <div class="form-check mb-0">
                        <input class="form-check-input review-check" type="checkbox" id="rv-${r.reservation_id}"
                               data-id="${r.reservation_id}" ${isTicked(r) ? "checked" : ""} ${canBorrow(r) ? "" : "disabled"}>
                        <label class="form-check-label fw-semibold" for="rv-${r.reservation_id}">${escapeHtml(r.title)}</label>
                    </div>
                    <div>${availabilityBadge(r)}</div>
                    <div class="small text-muted ms-md-auto">Pick up by ${escapeHtml(fmtDate(r.expires_on))}</div>
                </li>`).join("")}
            </ul>
            <div class="card-footer d-flex flex-wrap align-items-center gap-2">
                <span class="small review-summary"></span>
                <input type="text" class="form-control form-control-sm review-reason ms-md-auto" style="max-width: 280px;"
                       maxlength="200" value="${escapeHtml(DEFAULT_REJECT_REASON)}" aria-label="Reason for books that are not approved">
                <button type="button" class="btn btn-success btn-sm review-submit">Confirm decision</button>
            </div>
        </div>`).join("");

    panel.querySelectorAll(".review-card").forEach(updateReviewSummary);
};

const updateReviewSummary = (card) => {
    const boxes = [...card.querySelectorAll(".review-check")];
    const yes = boxes.filter((b) => b.checked).length;
    const no = boxes.length - yes;

    card.querySelector(".review-summary").textContent =
        `Approve ${yes}${no ? ` · Reject ${no}` : ""}`;
    card.querySelector(".review-reason").classList.toggle("d-none", no === 0);
};

const submitReview = (card) => {
    const boxes = [...card.querySelectorAll(".review-check")];
    const approve = boxes.filter((b) => b.checked).map((b) => Number(b.dataset.id));
    const reject = boxes.filter((b) => !b.checked).map((b) => Number(b.dataset.id));
    const reason = card.querySelector(".review-reason").value.trim();
    const name = card.querySelector(".card-header strong").textContent;

    askConfirm({
        title: "Confirm this decision?",
        message: `${name}: approve ${approve.length} ${approve.length === 1 ? "book" : "books"}` +
            (reject.length ? ` and reject ${reject.length}. The student will see: "${reason || "no reason given"}".` : ".") +
            " Approved books are held for them if a copy is free, otherwise they join the waiting list.",
        okText: "Confirm",
        okClass: "btn-success",
        run: async () => {
            try {
                const result = await post("review", { approve, reject, reason });
                [...approve, ...reject].forEach((id) => delete reviewTicks[id]);
                showAlert(result.message, result.status === "success" ? "success" : "danger");
                refreshAll();
            } catch (error) {
                showAlert("Failed to save the decision.", "danger");
            }
        }
    });
};

const post = async (operation, payload) => {
    const formData = new FormData();
    formData.append("operation", operation);
    formData.append("json", JSON.stringify(payload));

    const response = await axios({
        url: `${baseApiUrl}/reservation.php`,
        method: "POST",
        data: formData
    });

    return response.data;
};

const refreshAll = () => {
    loadRecords();
    loadBooks();
};

const saveRecord = async () => {
    const student_id = document.getElementById("student_id").value;
    const book_id = document.getElementById("book_id").value;
    const expires_on = document.getElementById("expires_on").value;
    const processed_by_user_id = document.getElementById("processed_by_user_id").value;

    if (!student_id || !book_id || !expires_on) {
        showAlert("Borrower, book and pick-up date are required.", "danger");
        return;
    }

    if (expires_on < dateString(0) || expires_on > dateString(MAX_HOLD_DAYS)) {
        showAlert(`Pick-up date must be between today and ${dateString(MAX_HOLD_DAYS)}.`, "danger");
        return;
    }

    const btn = document.getElementById("btn-save");
    btn.disabled = true;

    try {
        const result = await post("add", { student_id, book_id, expires_on, processed_by_user_id });

        if (result.status === "success") {
            clearForm();
            showAlert(result.message, "success");
        } else {
            showAlert(result.message, "danger");
        }

        refreshAll();
    } catch (error) {
        showAlert("Failed to save reservation.", "danger");
    } finally {
        btn.disabled = false;
        showBookInfo();
    }
};

/* Check Out: a window that asks who is processing it, so there is no scrolling back to the form. */

const openCheckout = (id) => {
    const row = (window._reservations || []).find((r) => r.reservation_id == id);
    if (!row) return;

    pendingCheckoutId = id;

    document.getElementById("co-borrower").innerText = row.borrower;
    document.getElementById("co-book").innerText = row.title;
    document.getElementById("co-copy").innerText = row.accession_number ? `ACC-${row.accession_number}` : "—";
    document.getElementById("co-processed-by").value = document.getElementById("processed_by_user_id").value || "";
    document.getElementById("co-error").classList.add("d-none");

    getModal("checkoutModal").show();
};

const confirmCheckout = async () => {
    const processed_by_user_id = document.getElementById("co-processed-by").value;

    if (!processed_by_user_id) {
        document.getElementById("co-error").classList.remove("d-none");
        return;
    }

    const btn = document.getElementById("btn-confirm-checkout");
    btn.disabled = true;

    try {
        const result = await post("fulfill", { reservation_id: pendingCheckoutId, processed_by_user_id });

        getModal("checkoutModal").hide();
        document.getElementById("processed_by_user_id").value = processed_by_user_id;
        showAlert(result.message, result.status === "success" ? "success" : "danger");
        refreshAll();
    } catch (error) {
        showAlert("Failed to check out the reservation.", "danger");
    } finally {
        btn.disabled = false;
    }
};

/* Cancel / delete use one shared confirm window instead of the browser's confirm() box. */

const askConfirm = async ({ title, message, okText, okClass, run }) => {
    const ok = await lmsConfirm(message, {
        title,
        confirmText: okText,
        danger: String(okClass || "").includes("danger")
    });

    if (ok && run) await run();
};

const runConfirmed = async () => {
    const run = pendingConfirm;
    pendingConfirm = null;
    getModal("confirmModal").hide();
    if (run) await run();
};

// A student's request from the portal: staff decide before any copy is held.
const approveRecord = (id) => {
    askConfirm({
        title: "Approve this reservation?",
        message: "A free copy will be held for the student right away. If none is free, they join the waiting list.",
        okText: "Approve",
        okClass: "btn-success",
        run: async () => {
            try {
                const result = await post("approve", { reservation_id: id });
                showAlert(result.message, result.status === "success" ? "success" : "danger");
                refreshAll();
            } catch (error) {
                showAlert("Failed to approve the reservation.", "danger");
            }
        }
    });
};

const rejectRecord = async (id) => {
    const reason = await lmsPrompt("Reject this reservation? You can tell the student why (optional).", {
        title: "Reject reservation",
        confirmText: "Reject",
        placeholder: "e.g. This book is for in-library use only",
        danger: true
    });
    if (reason === null) return;          // cancelled

    try {
        const result = await post("reject", { reservation_id: id, reason });
        showAlert(result.message, result.status === "success" ? "success" : "danger");
        refreshAll();
    } catch (error) {
        showAlert("Failed to reject the reservation.", "danger");
    }
};

const cancelRecord = (id) => {
    askConfirm({
        title: "Cancel this reservation?",
        message: "A held copy will be released and may go straight to the next person in line.",
        okText: "Cancel Reservation",
        okClass: "btn-danger",
        run: async () => {
            try {
                const result = await post("cancel", { reservation_id: id });
                showAlert(result.message, result.status === "success" ? "success" : "danger");
                refreshAll();
            } catch (error) {
                showAlert("Failed to cancel the reservation.", "danger");
            }
        }
    });
};

const deleteRecord = (id) => {
    askConfirm({
        title: "Delete this record?",
        message: "This removes the reservation from the list. It can't be undone.",
        okText: "Delete",
        okClass: "btn-danger",
        run: async () => {
            try {
                const result = await post("delete", { reservation_id: id });
                showAlert(result.message, result.status === "success" ? "success" : "danger");
                loadRecords();
            } catch (error) {
                showAlert("Failed to delete the reservation.", "danger");
            }
        }
    });
};

const clearForm = () => {
    document.getElementById("student_id").value = "";
    document.getElementById("book_id").value = "";
    setDateLimits();
    showBookInfo();
};

window.setQuickDate = setQuickDate;
window.setFilter = setFilter;
window.openCheckout = openCheckout;
window.cancelRecord = cancelRecord;
window.deleteRecord = deleteRecord;