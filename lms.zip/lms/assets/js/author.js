const baseApiUrl = "api"; // relative to the page, so it works from any folder

let editingId = null;

document.addEventListener("DOMContentLoaded", () => {
    loadRecords();

    document.getElementById("btn-save").addEventListener("click", saveRecord);
    document.getElementById("btn-clear").addEventListener("click", clearForm);
});

const escapeHtml = (value) => {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
};

const loadRecords = async () => {
    try {
        const response = await axios.get(`${baseApiUrl}/author.php`, {
            params: { operation: "getAll" }
        });

        const tbody = document.getElementById("table-body");
        tbody.innerHTML = "";
        window._authorData = response.data;

        if (response.data.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center text-muted">No records found.</td>
                </tr>
            `;
            return;
        }

        response.data.forEach((row) => {
            tbody.innerHTML += `
                <tr>
                    <td>${escapeHtml(row.first_name)}</td>
                    <td>${escapeHtml(row.last_name)}</td>
                    <td>${escapeHtml(row.bio)}</td>
                    <td>
                        <button class="btn btn-success btn-sm me-1" onclick="editRecord(${row.author_id})">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deleteRecord(${row.author_id})">Delete</button>
                    </td>
                </tr>
            `;
        });
    } catch (error) {
        showAlert("Failed to load authors.", "danger");
    }
};

const isMeaningfulText = (value) => {
    const trimmed = value.trim();
    return trimmed.length >= 2 && !/^\d+$/.test(trimmed);
};

const saveRecord = async () => {
    const first_name = document.getElementById("first_name").value.trim();
    const last_name = document.getElementById("last_name").value.trim();
    const bio = document.getElementById("bio").value.trim();

    if (!first_name || !last_name) {
        showAlert("First name and last name are required.", "danger");
        return;
    }

    if (!isMeaningfulText(first_name)) {
        showAlert("First name must be a meaningful name, not just numbers.", "danger");
        return;
    }

    if (!isMeaningfulText(last_name)) {
        showAlert("Last name must be a meaningful name, not just numbers.", "danger");
        return;
    }

    const jsonData = { first_name, last_name, bio };
    let operation = "add";

    if (editingId !== null) {
        jsonData.author_id = editingId;
        operation = "update";
    }

    try {
        const formData = new FormData();
        formData.append("operation", operation);
        formData.append("json", JSON.stringify(jsonData));

        const response = await axios({
            url: `${baseApiUrl}/author.php`,
            method: "POST",
            data: formData
        });

        if (response.data.status === "success") {
            showAlert(response.data.message, "success");
            clearForm();
            loadRecords();
        } else {
            showAlert(response.data.message, "danger");
        }
    } catch (error) {
        showAlert("Failed to save author.", "danger");
    }
};

const editRecord = (id) => {
    const row = window._authorData.find((author) => author.author_id == id);

    if (!row) return;

    editingId = id;

    document.getElementById("first_name").value = row.first_name;
    document.getElementById("last_name").value = row.last_name;
    document.getElementById("bio").value = row.bio || "";

    document.getElementById("btn-save").innerText = "Update";
    document.getElementById("form-title").innerText = "Edit Author";

    window.scrollTo(0, 0);
};

const deleteRecord = async (id) => {
    if (!await lmsConfirm("Are you sure you want to delete this author?")) {
        return;
    }

    try {
        const formData = new FormData();
        formData.append("operation", "delete");
        formData.append("json", JSON.stringify({ author_id: id }));

        const response = await axios({
            url: `${baseApiUrl}/author.php`,
            method: "POST",
            data: formData
        });

        if (response.data.status === "success") {
            showAlert(response.data.message, "success");
            loadRecords();
        } else {
            showAlert(response.data.message, "danger");
        }
    } catch (error) {
        showAlert("Failed to delete author.", "danger");
    }
};

const clearForm = () => {
    editingId = null;

    ["first_name", "last_name", "bio"].forEach((id) => {
        document.getElementById(id).value = "";
    });

    document.getElementById("btn-save").innerText = "Save";
    document.getElementById("form-title").innerText = "Add Author";
    document.getElementById("alert-box").innerHTML = "";
};

const apiMessage = (error, fallback) =>
    (error.response && error.response.data && error.response.data.message) || fallback;

const showAlert = (msg, type) => {
    const box = document.getElementById("alert-box");
    box.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert"><span></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
    box.querySelector("span").textContent = msg; // plain text, never HTML
};

window.editRecord = editRecord;
window.deleteRecord = deleteRecord;