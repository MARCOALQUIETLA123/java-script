const baseApiUrl = "api"; // relative to the page, so it works from any folder

document.addEventListener("DOMContentLoaded", () => {
    loadDropdowns();
    loadRecords();

    document.getElementById("btn-save").addEventListener("click", saveRecord);
    document.getElementById("btn-clear").addEventListener("click", clearForm);
});

const loadDropdownsRaw = async () => {
    const [booksResponse, authorsResponse] = await Promise.all([
        axios.get(`${baseApiUrl}/book.php`, {
            params: { operation: "getAll" }
        }),
        axios.get(`${baseApiUrl}/author.php`, {
            params: { operation: "getAll" }
        })
    ]);

    const bookSelect = document.getElementById("book_id");
    const authorSelect = document.getElementById("author_id");

    bookSelect.innerHTML = `<option value="">Select Book</option>`;
    authorSelect.innerHTML = `<option value="">Select Author</option>`;

    booksResponse.data.forEach((book) => {
        bookSelect.innerHTML += `
            <option value="${book.book_id}">
                ${escapeHtml(book.title)}
            </option>
        `;
    });

    authorsResponse.data.forEach((author) => {
        authorSelect.innerHTML += `
            <option value="${author.author_id}">
                ${escapeHtml(author.first_name)} ${escapeHtml(author.last_name)}
            </option>
        `;
    });
};

const loadRecordsRaw = async () => {
    const response = await axios.get(`${baseApiUrl}/book_author.php`, {
        params: { operation: "getAll" }
    });

    const tbody = document.getElementById("table-body");
    tbody.innerHTML = "";
    window._baData = response.data;

    if (response.data.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="3" class="text-center text-muted">No records found.</td>
            </tr>
        `;
        return;
    }

    response.data.forEach((row) => {
        tbody.innerHTML += `
            <tr>
                <td>${escapeHtml(row.book_title)}</td>
                <td>${escapeHtml(row.author_name)}</td>
                <td>
                    <button class="btn btn-success btn-sm me-1" onclick="editRecord(${row.book_id}, ${row.author_id})">Edit</button>
                    <button class="btn btn-danger btn-sm" onclick="deleteRecord(${row.book_id}, ${row.author_id})">Delete</button>
                </td>
            </tr>
        `;
    });
};

const saveRecordRaw = async () => {
    const book_id = document.getElementById("book_id").value;
    const author_id = document.getElementById("author_id").value;

    if (!book_id || !author_id) {
        showAlert("Book and author are required.", "danger");
        return;
    }

    const jsonData = {
        book_id,
        author_id
    };

    const editingBookId = document.getElementById("book_id").dataset.editingBookId;
    const editingAuthorId = document.getElementById("book_id").dataset.editingAuthorId;

    let operation = "add";

    if (editingBookId && editingAuthorId) {
        jsonData.old_book_id = editingBookId;
        jsonData.old_author_id = editingAuthorId;
        operation = "update";
    }

    const formData = new FormData();
    formData.append("operation", operation);
    formData.append("json", JSON.stringify(jsonData));

    const response = await axios({
        url: `${baseApiUrl}/book_author.php`,
        method: "POST",
        data: formData
    });

    if (response.data.status === "success") {
        showAlert(response.data.message, "success");
        clearForm();
        loadRecords();
    } else {
        showAlert(response.data.message, "danger");
    }
};

const editRecord = (book_id, author_id) => {
    const row = window._baData.find(
        (item) => item.book_id == book_id && item.author_id == author_id
    );

    if (!row) return;

    document.getElementById("book_id").value = row.book_id;
    document.getElementById("author_id").value = row.author_id;

    document.getElementById("book_id").dataset.editingBookId = row.book_id;
    document.getElementById("book_id").dataset.editingAuthorId = row.author_id;

    document.getElementById("btn-save").innerText = "Update";
    document.getElementById("form-title").innerText = "Edit Book Author";

    window.scrollTo(0, 0);
};

const deleteRecordRaw = async (book_id, author_id) => {
    if (!await lmsConfirm("Are you sure you want to delete this book author link?")) {
        return;
    }

    const formData = new FormData();
    formData.append("operation", "delete");
    formData.append("json", JSON.stringify({
        book_id,
        author_id
    }));

    const response = await axios({
        url: `${baseApiUrl}/book_author.php`,
        method: "POST",
        data: formData
    });

    if (response.data.status === "success") {
        showAlert(response.data.message, "success");
        loadRecords();
    } else {
        showAlert(response.data.message, "danger");
    }
};

const clearForm = () => {
    document.getElementById("book_id").value = "";
    document.getElementById("author_id").value = "";

    delete document.getElementById("book_id").dataset.editingBookId;
    delete document.getElementById("book_id").dataset.editingAuthorId;

    document.getElementById("btn-save").innerText = "Save";
    document.getElementById("form-title").innerText = "Add Book Author";
    document.getElementById("alert-box").innerHTML = "";
};

const escapeHtml = (value) => String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const apiMessage = (error, fallback) =>
    (error.response && error.response.data && error.response.data.message) || fallback;

const showAlert = (msg, type) => {
    const box = document.getElementById("alert-box");
    box.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert"><span></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
    box.querySelector("span").textContent = msg; // plain text, never HTML
};

const loadRecords = async () => {
    try {
        await loadRecordsRaw();
    } catch (error) {
        const tb = document.getElementById("table-body");
        if (tb) tb.innerHTML = `<tr><td colspan="9" class="text-center text-danger">${escapeHtml(apiMessage(error, "Failed to load the list."))}</td></tr>`;
    }
};

const loadDropdowns = async () => {
    try { await loadDropdownsRaw(); } catch (error) { showAlert(apiMessage(error, "Failed to load the dropdown lists."), "danger"); }
};

const saveRecord = async () => {
    try { await saveRecordRaw(); } catch (error) { showAlert(apiMessage(error, "Failed to save."), "danger"); }
};

const deleteRecord = async (id) => {
    try { await deleteRecordRaw(id); } catch (error) { showAlert(apiMessage(error, "Failed to delete."), "danger"); }
};

window.editRecord = editRecord;
window.deleteRecord = deleteRecord;