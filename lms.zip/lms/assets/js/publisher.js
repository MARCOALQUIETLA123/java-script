const baseApiUrl = "api"; // relative to the page, so it works from any folder

let editingId = null;

document.addEventListener("DOMContentLoaded", () => {
    loadRecords();

    document.getElementById("btn-save").addEventListener("click", saveRecord);
    document.getElementById("btn-clear").addEventListener("click", clearForm);
});

const loadRecordsRaw = async () => {
    const response = await axios.get(`${baseApiUrl}/publisher.php`, {
        params: { operation: "getAll" }
    });

    const tbody = document.getElementById("table-body");
    tbody.innerHTML = "";
    window._publisherData = response.data;

    if (response.data.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="2" class="text-center text-muted">No records found.</td>
            </tr>
        `;
        return;
    }

    response.data.forEach((row) => {
        tbody.innerHTML += `
            <tr>
                <td>${escapeHtml(row.publisher_name)}</td>
                <td>
                    <button class="btn btn-success btn-sm me-1" onclick="editRecord(${row.publisher_id})">Edit</button>
                    <button class="btn btn-danger btn-sm" onclick="deleteRecord(${row.publisher_id})">Delete</button>
                </td>
            </tr>
        `;
    });
};

const isValidName = (value) => {
    if (!value || value.trim() === "") return false;
    if (/^[\d\s]+$/.test(value.trim())) return false;
    return true;
};

const saveRecordRaw = async () => {
    const publisher_name = document.getElementById("publisher_name").value.trim();

    if (!publisher_name) {
        showAlert("Publisher name is required.", "danger");
        return;
    }

    if (!isValidName(publisher_name)) {
        showAlert("Invalid input. Publisher name must contain letters, not numbers only.", "danger");
        return;
    }

    const jsonData = { publisher_name };
    let operation = "add";

    if (editingId !== null) {
        jsonData.publisher_id = editingId;
        operation = "update";
    }

    const formData = new FormData();
    formData.append("operation", operation);
    formData.append("json", JSON.stringify(jsonData));

    const response = await axios({
        url: `${baseApiUrl}/publisher.php`,
        method: "POST",
        data: formData
    });

    if (response.data.status === "success") {
        showAlert(response.data.message, "success");
        clearForm();
        loadRecords();
    } else {
        showAlert(response.data.message, "danger");
    }
};

const editRecord = (id) => {
    const row = window._publisherData.find((publisher) => publisher.publisher_id == id);

    if (!row) return;

    editingId = id;

    document.getElementById("publisher_name").value = row.publisher_name;
    document.getElementById("btn-save").innerText = "Update";
    document.getElementById("form-title").innerText = "Edit Publisher";
};

const deleteRecordRaw = async (id) => {
    if (!await lmsConfirm("Are you sure you want to delete this publisher?")) {
        return;
    }

    const formData = new FormData();
    formData.append("operation", "delete");
    formData.append("json", JSON.stringify({ publisher_id: id }));

    const response = await axios({
        url: `${baseApiUrl}/publisher.php`,
        method: "POST",
        data: formData
    });

    if (response.data.status === "success") {
        showAlert(response.data.message, "success");
        loadRecords();
    } else {
        showAlert(response.data.message, "danger");
    }
};

const clearForm = () => {
    editingId = null;

    document.getElementById("publisher_name").value = "";
    document.getElementById("btn-save").innerText = "Save";
    document.getElementById("form-title").innerText = "Add Publisher";
    document.getElementById("alert-box").innerHTML = "";
};

const escapeHtml = (value) => String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const apiMessage = (error, fallback) =>
    (error.response && error.response.data && error.response.data.message) || fallback;

const showAlert = (msg, type) => {
    const box = document.getElementById("alert-box");
    box.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert"><span></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
    box.querySelector("span").textContent = msg; // plain text, never HTML
};

const loadRecords = async () => {
    try {
        await loadRecordsRaw();
    } catch (error) {
        const tb = document.getElementById("table-body");
        if (tb) tb.innerHTML = `<tr><td colspan="9" class="text-center text-danger">${escapeHtml(apiMessage(error, "Failed to load the list."))}</td></tr>`;
    }
};

const saveRecord = async () => {
    try { await saveRecordRaw(); } catch (error) { showAlert(apiMessage(error, "Failed to save."), "danger"); }
};

const deleteRecord = async (id) => {
    try { await deleteRecordRaw(id); } catch (error) { showAlert(apiMessage(error, "Failed to delete."), "danger"); }
};

window.editRecord = editRecord;
window.deleteRecord = deleteRecord;