const baseApiUrl = "api"; // relative to the page, so it works from any folder

const REFRESH_MS = 5 * 60 * 1000; // safety refresh (overdue counts change at midnight even if nobody edits anything)
const RANGE_KEY = "lms_dashboard_days";

const $ = (id) => document.getElementById(id);

const escapeHtml = (value) => String(value ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const fmt = (n) => Number(n || 0).toLocaleString();
const plural = (n, one, many) => `${fmt(n)} ${Number(n) === 1 ? one : (many || one + "s")}`;
const sum = (list) => list.reduce((a, b) => a + b, 0);

let days = (() => {
    try {
        const v = parseInt(localStorage.getItem(RANGE_KEY), 10);
        return [7, 14, 30].includes(v) ? v : 14;
    } catch (e) {
        return 14;
    }
})();

let hasData = false;   // true once the first response has been drawn
let requestSeq = 0;    // lets a newer request win over a slower, older one
const charts = { trend: null, status: null };

/* ---------------------------------------------------------------- start-up */

document.addEventListener("DOMContentLoaded", () => {
    if (window.Chart) {
        Chart.defaults.font.family = '"Figtree", system-ui, -apple-system, "Segoe UI", sans-serif';
        Chart.defaults.font.size = 12;
        Chart.defaults.color = "#6b7280";
    }

    syncRangeButtons();
    document.querySelectorAll("#range [data-days]").forEach((btn) => {
        btn.addEventListener("click", () => {
            days = Number(btn.dataset.days);
            try { localStorage.setItem(RANGE_KEY, String(days)); } catch (e) { /* storage unavailable */ }
            syncRangeButtons();
            loadDashboard();
        });
    });

    loadDashboard();

    // Only the Technical Services Librarian can see or act on pending accounts (the server enforces this too).
    if (window.authReady) {
        window.authReady.then((me) => {
            if (me && me.role === "admin") loadPending();
        }).catch(() => {});
    }

    setInterval(() => { if (!document.hidden) loadDashboard(); }, REFRESH_MS);
});

const syncRangeButtons = () => {
    document.querySelectorAll("#range [data-days]").forEach((btn) => {
        btn.classList.toggle("active", Number(btn.dataset.days) === days);
    });
};

/* ----------------------------------------------------------------- loading */

const loadDashboard = async () => {
    const mine = ++requestSeq;

    try {
        const res = await axios.get(`${baseApiUrl}/dashboard.php`, {
            params: { operation: "getCounts", days }
        });

        if (mine !== requestSeq) return; // a newer request is already on its way

        const d = res.data;
        if (!d || typeof d !== "object" || !("loans" in d)) throw new Error("Unexpected response");

        render(d);
        markUpdated(true);

        if (Array.isArray(d.errors) && d.errors.length) {
            console.warn("Dashboard sections unavailable:", d.errors.join(", "));
        }
    } catch (error) {
        if (mine !== requestSeq) return;
        if (error.response && error.response.status === 403) return;   // no "reports" permission: auth.js shows a notice instead
        markUpdated(false);

        if (!hasData) {
            ["top-titles", "top-categories", "attention-list", "activity-list"].forEach((id) => {
                $(id).innerHTML = '<div class="empty-note">Couldn\'t load this section.</div>';
            });
        }
    }
};

// live.js calls this name when another device saves something.
const loadCounts = loadDashboard;

const markUpdated = (ok) => {
    const el = $("updated");
    el.classList.toggle("is-stale", !ok);

    if (ok) {
        el.textContent = "Updated " + new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit", second: "2-digit" });
    } else {
        el.textContent = hasData ? "Couldn't refresh · showing last data" : "Couldn't load data";
    }
};

/* --------------------------------------------------------------- rendering */

const render = (d) => {
    hasData = true;

    renderKpis(d);
    renderTrend(d);
    renderStatus(d);
    renderRank("top-titles", d.top_titles, "");
    renderRank("top-categories", d.categories, "alt");
    renderAttention(d.attention);
    renderActivity(d.activity, d.today);

    document.querySelectorAll(".range-label").forEach((el) => { el.textContent = `${d.days} days`; });
};

// Writes HTML only when it changed, so a refresh with identical data doesn't flicker.
const setHtml = (el, html) => {
    if (el._html === html) return;
    el._html = html;
    el.innerHTML = html;
};

const setKpi = (key, value, note, alert = false) => {
    $(`kpi-${key}-value`).textContent = value;
    $(`kpi-${key}-note`).textContent = note;
    $(`kpi-${key}`).classList.toggle("is-alert", alert);
};

const renderKpis = (d) => {
    const l = d.loans;
    const c = d.copies;
    const r = d.reservations;

    if (l) {
        setKpi("borrowed", fmt(l.borrowed_now),
            l.due_soon ? `${fmt(l.due_soon)} due in the next 3 days` : "None due in the next 3 days");
        setKpi("overdue", fmt(l.overdue),
            l.overdue ? `Oldest is ${plural(l.oldest_overdue, "day")} late` : "Nothing is overdue",
            l.overdue > 0);
    } else {
        setKpi("borrowed", "—", "Unavailable");
        setKpi("overdue", "—", "Unavailable");
    }

    if (c) {
        const pct = c.total ? Math.round((c.available / c.total) * 100) : 0;
        setKpi("available", fmt(c.available), c.total ? `of ${fmt(c.total)} copies · ${pct}%` : "No copies added yet");
    } else {
        setKpi("available", "—", "Unavailable");
    }

    // Borrowers with overdue books (fines piling up) or blacklisted.
    const acc = d.accounts;
    const accBanner = $("accounts-banner");
    if (accBanner) {
        const total = acc ? acc.overdue + acc.blacklisted + (acc.proofs || 0) : 0;
        accBanner.classList.toggle("d-none", total === 0);
        if (total > 0) {
            const parts = [];
            if (acc.overdue) parts.push(`${plural(acc.overdue, "borrower")} with overdue books`);
            if (acc.blacklisted) parts.push(`${plural(acc.blacklisted, "borrower")} blacklisted`);
            if (acc.proofs) parts.push(`${plural(acc.proofs, "proof of payment", "proofs of payment")} to check`);
            $("accounts-banner-text").textContent = parts.join(" · ");
        }
    }

    const banner = $("resv-banner");
    if (r) {
        const active = r.ready + r.waiting;
        const note = active ? `${fmt(r.ready)} ready for pick-up · ${fmt(r.waiting)} waiting` : "No active reservations";
        setKpi("reserved", fmt(active), r.pending ? `${note} · ${fmt(r.pending)} need approval` : note, r.pending > 0);

        // Student requests wait here until staff approve or reject them.
        if (banner) {
            banner.classList.toggle("d-none", !(r.pending > 0));
            $("resv-banner-text").textContent = r.pending > 0
                ? `${plural(r.pending, "reservation request")} from students ${r.pending === 1 ? "is" : "are"} waiting for approval.`
                : "";
        }
    } else {
        setKpi("reserved", "—", "Unavailable");
    }
};

/* ---- trend (line chart) ---- */

// Last n calendar days ending on the server's "today" (built from the server date, not the browser's).
const buildDates = (todayIso, n) => {
    const [y, m, day] = todayIso.split("-").map(Number);
    const base = Date.UTC(y, m - 1, day);
    const out = [];
    for (let i = n - 1; i >= 0; i--) out.push(new Date(base - i * 86400000).toISOString().slice(0, 10));
    return out;
};

const dayLabel = (iso) => new Date(iso + "T00:00:00Z")
    .toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone: "UTC" });

const setEmpty = (boxId, emptyId, empty, message) => {
    $(boxId).classList.toggle("is-empty", empty);
    if (message) $(emptyId).textContent = message;
};

const renderTrend = (d) => {
    const t = d.trend;

    if (!t) {
        setEmpty("trend-box", "trend-empty", true, "Activity data is unavailable.");
        return;
    }

    const dates = buildDates(d.today, d.days);
    const borrowed = dates.map((x) => t.borrowed[x] || 0);
    const returned = dates.map((x) => t.returned[x] || 0);
    const totalBorrowed = sum(borrowed);
    const totalReturned = sum(returned);

    $("trend-sub").textContent = `${fmt(totalBorrowed)} borrowed · ${fmt(totalReturned)} returned in the last ${d.days} days`;

    if (!window.Chart) {
        setEmpty("trend-box", "trend-empty", true, "Charts need an internet connection to load.");
        return;
    }

    setEmpty("trend-box", "trend-empty", totalBorrowed + totalReturned === 0, "No borrowing activity in this period.");

    const labels = dates.map(dayLabel);

    if (!charts.trend) {
        charts.trend = new Chart($("trend-chart"), {
            type: "line",
            data: {
                labels,
                datasets: [
                    {
                        label: "Borrowed", data: borrowed,
                        borderColor: "#198754", backgroundColor: "rgba(25,135,84,.10)", fill: true,
                        tension: 0.35, borderWidth: 2, pointRadius: 0, pointHoverRadius: 4,
                        pointHoverBackgroundColor: "#198754"
                    },
                    {
                        label: "Returned", data: returned,
                        borderColor: "#4c78a8", backgroundColor: "#4c78a8", fill: false,
                        tension: 0.35, borderWidth: 2, pointRadius: 0, pointHoverRadius: 4,
                        pointHoverBackgroundColor: "#4c78a8"
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: { mode: "index", intersect: false },
                plugins: {
                    legend: {
                        position: "top", align: "end",
                        labels: { usePointStyle: true, pointStyle: "circle", boxWidth: 8, boxHeight: 8, padding: 16 }
                    },
                    tooltip: {
                        backgroundColor: "#111827", padding: 10, cornerRadius: 8,
                        titleFont: { weight: "600" }, boxPadding: 4, usePointStyle: true
                    }
                },
                scales: {
                    x: { grid: { display: false }, border: { display: false }, ticks: { maxRotation: 0, autoSkip: true, maxTicksLimit: 7 } },
                    y: { beginAtZero: true, suggestedMax: 4, border: { display: false }, grid: { color: "#eef1f5" }, ticks: { precision: 0, padding: 8 } }
                }
            }
        });
    } else {
        const chart = charts.trend;
        chart.data.labels = labels;
        chart.data.datasets[0].data = borrowed;
        chart.data.datasets[1].data = returned;
        chart.update();
    }
};

/* ---- copy status (doughnut) ---- */

const STATUS_COLORS = [
    ["available", "#198754"], ["borrowed", "#3b82c4"], ["reserved", "#f0a500"],
    ["returned", "#8b95a5"], ["lost", "#dc3545"], ["damaged", "#c2410c"]
];
const FALLBACK_COLORS = ["#7c8db5", "#14b8a6", "#a78bfa", "#94a3b8"];

const statusColor = (label, index) => {
    const l = String(label).toLowerCase();
    const hit = STATUS_COLORS.find(([key]) => l.includes(key));
    return hit ? hit[1] : FALLBACK_COLORS[index % FALLBACK_COLORS.length];
};

// Writes the total in the middle of the ring.
const centerText = {
    id: "centerText",
    afterDraw(chart) {
        if (chart.$total == null || !chart.chartArea) return;

        const { ctx, chartArea: a } = chart;
        const x = (a.left + a.right) / 2;
        const y = (a.top + a.bottom) / 2;
        const family = Chart.defaults.font.family;

        ctx.save();
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillStyle = "#111827";
        ctx.font = `700 26px ${family}`;
        ctx.fillText(fmt(chart.$total), x, y - 8);
        ctx.fillStyle = "#6b7280";
        ctx.font = `500 12px ${family}`;
        ctx.fillText(chart.$total === 1 ? "copy" : "copies", x, y + 14);
        ctx.restore();
    }
};

const renderStatus = (d) => {
    const c = d.copies;
    const legend = $("status-legend");

    if (!c || !c.total) {
        setEmpty("status-box", "status-empty", true, c ? "No book copies yet." : "Copy data is unavailable.");
        setHtml(legend, "");
        return;
    }

    const rows = c.status;
    const colors = rows.map((r, i) => statusColor(r.label, i));

    setHtml(legend, rows.map((r, i) => `
        <li><span class="dot" style="background:${colors[i]}"></span>
            <span class="name">${escapeHtml(r.label)}</span>
            <span class="n">${fmt(r.count)}</span></li>`).join(""));

    if (!window.Chart) {
        setEmpty("status-box", "status-empty", true, "Charts need an internet connection to load.");
        return;
    }

    setEmpty("status-box", "status-empty", false);

    const labels = rows.map((r) => r.label);
    const values = rows.map((r) => r.count);

    if (!charts.status) {
        charts.status = new Chart($("status-chart"), {
            type: "doughnut",
            data: {
                labels,
                datasets: [{ data: values, backgroundColor: colors, borderColor: "#ffffff", borderWidth: 2, hoverOffset: 4 }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: "72%",
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: "#111827", padding: 10, cornerRadius: 8,
                        callbacks: {
                            label: (ctx) => {
                                const total = ctx.dataset.data.reduce((a, b) => a + b, 0);
                                return ` ${ctx.label}: ${fmt(ctx.parsed)} (${Math.round((ctx.parsed / total) * 100)}%)`;
                            }
                        }
                    }
                }
            },
            plugins: [centerText]
        });
        charts.status.$total = c.total;
        charts.status.update("none");
    } else {
        const chart = charts.status;
        chart.$total = c.total;
        chart.data.labels = labels;
        chart.data.datasets[0].data = values;
        chart.data.datasets[0].backgroundColor = colors;
        chart.update();
    }
};

/* ---- ranking lists ---- */

const renderRank = (id, rows, variant) => {
    const el = $(id);

    if (!rows) {
        setHtml(el, '<div class="empty-note">Unavailable.</div>');
        return;
    }
    if (rows.length === 0) {
        setHtml(el, '<div class="empty-note">No borrowing in this period.</div>');
        return;
    }

    const max = Math.max(...rows.map((r) => r.count));

    setHtml(el, rows.map((r) => `
        <div class="rank-row">
            <div class="rank-top">
                <span class="rank-name" title="${escapeHtml(r.label)}">${escapeHtml(r.label)}</span>
                <span class="rank-val">${fmt(r.count)}</span>
            </div>
            <div class="rank-bar ${variant}"><span style="width:${Math.max(4, Math.round((r.count / max) * 100))}%"></span></div>
        </div>`).join(""));
};

/* ---- needs attention ---- */

const duePill = (late) => {
    if (late > 0) return ["pill-late", `${plural(late, "day")} late`];
    if (late === 0) return ["pill-today", "Due today"];
    return ["pill-soon", `Due in ${plural(-late, "day")}`];
};

const renderAttention = (rows) => {
    const el = $("attention-list");

    if (!rows) {
        setHtml(el, '<div class="empty-note">Unavailable.</div>');
        return;
    }
    if (rows.length === 0) {
        setHtml(el, '<div class="empty-note">All clear. Nothing is overdue or due soon.</div>');
        return;
    }

    setHtml(el, rows.map((r) => {
        const [cls, text] = duePill(r.days_late);
        const sub = `${r.borrower || "Unknown borrower"}${r.accession_number ? " · ACC-" + r.accession_number : ""}`;
        return `
        <div class="list-row">
            <div class="list-main">
                <div class="list-title" title="${escapeHtml(r.title)}">${escapeHtml(r.title || "Untitled")}</div>
                <div class="list-sub">${escapeHtml(sub)}</div>
            </div>
            <span class="pill ${cls}">${escapeHtml(text)}</span>
        </div>`;
    }).join(""));
};

/* ---- recent activity ---- */

const ACTIVITY = {
    borrow:  { color: "#198754", verb: "borrowed" },
    return:  { color: "#4c78a8", verb: "returned" },
    reserve: { color: "#f0a500", verb: "reserved" }
};

const clock12 = (hhmm) => {
    const [h, m] = hhmm.split(":").map(Number);
    return `${((h + 11) % 12) + 1}:${String(m).padStart(2, "0")} ${h < 12 ? "AM" : "PM"}`;
};

const whenLabel = (ts, today) => {
    if (!ts) return "";

    const date = String(ts).slice(0, 10);
    const time = String(ts).length > 10 ? String(ts).slice(11, 16) : "";
    const yesterday = buildDates(today, 2)[0];

    let day = dayLabel(date);
    if (date === today) day = "Today";
    else if (date === yesterday) day = "Yesterday";

    return time && time !== "00:00" ? `${day}, ${clock12(time)}` : day;
};

const renderActivity = (rows, today) => {
    const el = $("activity-list");

    if (!rows) {
        setHtml(el, '<div class="empty-note">Unavailable.</div>');
        return;
    }
    if (rows.length === 0) {
        setHtml(el, '<div class="empty-note">Nothing has been borrowed, returned or reserved yet.</div>');
        return;
    }

    setHtml(el, rows.map((r) => {
        const a = ACTIVITY[r.type] || ACTIVITY.borrow;
        const more = r.n > 1 ? ` and ${plural(r.n - 1, "other book")}` : "";
        const by = r.by_user ? `<span class="by">Processed by ${escapeHtml(r.by_user)}</span>` : "";

        return `
        <div class="feed-row">
            <span class="feed-dot" style="background:${a.color}"></span>
            <div class="feed-text">
                <strong>${escapeHtml(r.who || "Someone")}</strong> ${a.verb} ${escapeHtml(r.title || "a book")}${more}
                ${by}
            </div>
            <span class="feed-time">${escapeHtml(whenLabel(r.ts, today))}</span>
        </div>`;
    }).join(""));
};

/* ------------------------------------------------ pending staff approvals */

const showAlert = (msg, type) => {
    const box = $("alert-box");
    box.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert"></div>`;
    box.firstChild.textContent = msg; // plain text
    const close = document.createElement("button");
    close.type = "button";
    close.className = "btn-close";
    close.setAttribute("data-bs-dismiss", "alert");
    box.firstChild.appendChild(close);
};

const loadPending = async () => {
    const panel = $("pending-panel");

    try {
        const res = await axios.get(`${baseApiUrl}/users.php`, { params: { operation: "getPending" } });
        const rows = res.data;

        $("pending-count").innerText = rows.length;
        panel.classList.toggle("d-none", rows.length === 0);

        $("pending-body").innerHTML = rows.map((r) => `
            <tr>
                <td>${escapeHtml(r.first_name)} ${escapeHtml(r.last_name)}</td>
                <td><span class="badge ${/student assistant|^sa$/i.test(r.role_name || "") ? "bg-info text-dark" : "bg-light text-success border"}">${escapeHtml(r.role_name || "")}</span></td>
                <td>${escapeHtml(r.username)}</td>
                <td>${escapeHtml(r.department_name)}</td>
                <td>${escapeHtml(r.email)}</td>
                <td>${escapeHtml(r.contact_number)}</td>
                <td>${escapeHtml(r.created_at)}</td>
                <td class="text-nowrap">
                    <button class="btn btn-success btn-sm me-1" onclick="approveAccount(${Number(r.user_id)})">Approve</button>
                    <button class="btn btn-outline-danger btn-sm" onclick="rejectAccount(${Number(r.user_id)})">Reject</button>
                </td>
            </tr>`).join("");
    } catch (error) {
        showAlert("Failed to load pending accounts.", "danger");
    }
};

const sendUserAction = async (operation, payload, failMessage) => {
    const formData = new FormData();
    formData.append("operation", operation);
    formData.append("json", JSON.stringify(payload));

    try {
        const res = await axios({ url: `${baseApiUrl}/users.php`, method: "POST", data: formData });
        showAlert(res.data.message, res.data.status === "success" ? "success" : "danger");
    } catch (error) {
        showAlert(failMessage, "danger");
    }

    loadPending();
};

const approveAccount = async (id) => {
    if (!await lmsConfirm("Approve this account? They will be able to log in with the role they signed up for (Library Staff or Student Assistant).")) return;
    sendUserAction("setStatus", { user_id: id, account_status: "active" }, "Failed to approve the account.");
};

const rejectAccount = async (id) => {
    if (!await lmsConfirm("Reject this sign-up? The account will be deleted.")) return;
    sendUserAction("delete", { user_id: id }, "Failed to reject the account.");
};

window.approveAccount = approveAccount;
window.rejectAccount = rejectAccount;