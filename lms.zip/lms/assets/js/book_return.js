const baseApiUrl = "api"; // relative to the page, so it works from any folder
const API = `${baseApiUrl}/book_return.php`;

const BORROWER_PAGE_SIZE = 8;
const HISTORY_PAGE_SIZE = 15;
const CONDITIONS = ["Good", "Fair", "Poor", "Damaged", "Lost"];
const EDIT_CONDITIONS = ["Good", "Fair", "Poor"]; // a damaged or lost book is reported when it comes back, not edited later
const DEFAULT_CONDITION = "Good";

/* ---------------- State ---------------- */

const state = {
    borrowers: { search: "", type: "all", overdue: false, category: "", sort: "overdue", page: 1, pages: 1, total: 0, rows: [] },
    selected: null,        // borrower currently open on the right
    items: [],             // that borrower's unreturned books
    today: "",             // server's "today" (Asia/Manila), used for overdue wording
    picked: new Set(),     // item_ids ticked for return
    conditions: {},        // item_id -> condition text
    settlements: {},       // item_id -> "Paid" | "Replaced" (only for Damaged / Lost books)
    fees: { fine_per_day: 5, processing_fee: 100 },
    history: { search: "", from: "", to: "", late: false, category: "", sort: "newest", page: 1, pages: 1, total: 0, rows: [] }
};

let borrowerRequest = 0;
let historyRequest = 0;
const openHistory = new Set(); // borrowers expanded in Return history
let confirmModal = null;
let editModal = null;
let receiptModal = null;

/* ---------------- Helpers ---------------- */

const $ = (id) => document.getElementById(id);

const escapeHtml = (value) => {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
};

const todayString = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const fmtDate = (value) => {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(value || "");
    if (!m) return "—";
    return `${MONTHS[Number(m[2]) - 1]} ${Number(m[3])}, ${m[1]}`;
};

const debounce = (fn, wait = 300) => {
    let timer;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => fn(...args), wait);
    };
};

const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

const toast = (message, type = "success") => {
    const area = $("toast-area");
    const el = document.createElement("div");
    el.className = `toast align-items-center text-bg-${type} border-0`;
    el.setAttribute("role", type === "danger" ? "alert" : "status");
    el.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${escapeHtml(message)}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>`;
    area.appendChild(el);

    const t = new bootstrap.Toast(el, { delay: type === "danger" ? 8000 : 4000 });
    el.addEventListener("hidden.bs.toast", () => el.remove());
    t.show();
};

const apiGet = async (operation, params = {}) => {
    const response = await axios.get(API, { params: { operation, ...params } });
    return response.data;
};

const apiPost = async (operation, payload) => {
    const formData = new FormData();
    formData.append("operation", operation);
    formData.append("json", JSON.stringify(payload));

    const response = await axios({ url: API, method: "POST", data: formData });
    return response.data;
};

const peso = (n) => "₱" + Number(n || 0).toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const isRetired = (id) => ["Damaged", "Lost"].includes(state.conditions[id]);

// Whole days past the due date on the chosen return date (0 when on time).
const daysLateFor = (item, date) =>
    date && item.due_date && date > item.due_date ? Math.round((Date.parse(date) - Date.parse(item.due_date)) / 86400000) : 0;

const CLEARANCE_WARNING = "Warning: a lost or damaged book will be reflected on the borrower's clearance, and the borrower will not get their clearance signed.";

// Everything the borrower owes for one book on the chosen return date.
const chargesFor = (item) => {
    const date = ($("return-date") && $("return-date").value) || state.today;
    const days = daysLateFor(item, date);
    const out = { days, fine: days * state.fees.fine_per_day, price: null, fee: 0, needsPrice: false, total: 0 };
    out.total = out.fine;

    return out;
};

const conditionOptions = (selected, options = CONDITIONS) => {
    const list = options.includes(selected) || !selected ? options : [...options, selected];
    return list
        .map((c) => `<option value="${escapeHtml(c)}" ${c === (selected || DEFAULT_CONDITION) ? "selected" : ""}>${escapeHtml(c)}</option>`)
        .join("");
};

const dueBadge = (days) => {
    if (days === null || days === undefined) return `<span class="badge bg-secondary">No due date</span>`;
    if (days > 0) return `<span class="badge bg-danger">Overdue ${days} ${days === 1 ? "day" : "days"}</span>`;
    if (days === 0) return `<span class="badge bg-warning text-dark">Due today</span>`;
    return `<span class="badge bg-light text-dark border">${-days} ${-days === 1 ? "day" : "days"} left</span>`;
};

const typeBadge = (isFaculty) =>
    Number(isFaculty) === 1
        ? `<span class="badge bg-primary">Faculty</span>`
        : `<span class="badge bg-secondary">Student</span>`;

/* ---------------- Boot ---------------- */

document.addEventListener("DOMContentLoaded", () => {
    confirmModal = new bootstrap.Modal($("confirmModal"));
    editModal = new bootstrap.Modal($("editModal"));

    wireBorrowerFilters();
    wireHistoryFilters();
    wireKeyboard();
    loadCategories();
    loadCaseCount();

    $("btn-confirm-return").addEventListener("click", submitReturn);
    receiptModal = new bootstrap.Modal($("receiptModal"));
    $("btn-print-receipt").addEventListener("click", printReceipt);
    $("btn-save-edit").addEventListener("click", saveEdit);
    $("tab-history-btn").addEventListener("shown.bs.tab", loadHistory);

    renderPanel();

    // Deep link: book_return.html?student=12 opens that borrower straight away.
    const linked = new URLSearchParams(window.location.search).get("student");

    loadBorrowers().then(() => {
        if (linked) selectBorrower(linked, false);
    });
});

/* ---------------- Step 1: borrower list ---------------- */

const wireBorrowerFilters = () => {
    const search = debounce(() => {
        state.borrowers.search = $("borrower-search").value.trim();
        state.borrowers.page = 1;
        loadBorrowers();
    });

    $("borrower-search").addEventListener("input", search);

    $("btn-search-clear").addEventListener("click", () => {
        $("borrower-search").value = "";
        state.borrowers.search = "";
        state.borrowers.page = 1;
        loadBorrowers();
        $("borrower-search").focus();
    });

    document.querySelectorAll("input[name='type-filter']").forEach((radio) => {
        radio.addEventListener("change", () => {
            state.borrowers.type = radio.value;
            state.borrowers.page = 1;
            loadBorrowers();
        });
    });

    $("filter-overdue").addEventListener("change", (e) => {
        state.borrowers.overdue = e.target.checked;
        state.borrowers.page = 1;
        loadBorrowers();
    });

    $("card-overdue").addEventListener("click", () => {
        const box = $("filter-overdue");
        box.checked = !box.checked;
        box.dispatchEvent(new Event("change"));
    });

    $("borrower-category").addEventListener("change", (e) => {
        state.borrowers.category = e.target.value;
        state.borrowers.page = 1;
        loadBorrowers();
    });

    $("borrower-sort").addEventListener("change", (e) => {
        state.borrowers.sort = e.target.value;
        state.borrowers.page = 1;
        loadBorrowers();
    });

    $("borrower-prev").addEventListener("click", () => {
        if (state.borrowers.page > 1) {
            state.borrowers.page--;
            loadBorrowers();
        }
    });

    $("borrower-next").addEventListener("click", () => {
        if (state.borrowers.page < state.borrowers.pages) {
            state.borrowers.page++;
            loadBorrowers();
        }
    });

    $("borrower-list").addEventListener("click", (e) => {
        const row = e.target.closest(".borrower-item");
        if (row) selectBorrower(row.dataset.id, true);
    });
};

const wireKeyboard = () => {
    document.addEventListener("keydown", (e) => {
        const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName);

        if (e.key === "/" && !typing && !e.ctrlKey && !e.metaKey) {
            e.preventDefault();
            $("tab-process-btn").click();
            $("borrower-search").focus();
            $("borrower-search").select();
        }
    });

    $("borrower-search").addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
            e.preventDefault();
            // Enter opens the first match, so a scan or quick typing is enough.
            state.borrowers.search = $("borrower-search").value.trim();
            state.borrowers.page = 1;
            loadBorrowers().then(() => {
                if (state.borrowers.rows.length > 0) {
                    selectBorrower(state.borrowers.rows[0].student_id, true);
                }
            });
        } else if (e.key === "Escape") {
            $("btn-search-clear").click();
        }
    });
};

// Fills both category dropdowns (borrower list and return history).
const loadCategories = async () => {
    try {
        const response = await axios.get(`${baseApiUrl}/categories.php`, { params: { operation: "getAll" } });
        const rows = Array.isArray(response.data) ? response.data : [];
        const options = rows.map((c) => `<option value="${escapeHtml(c.category_id)}">${escapeHtml(c.category_type)}</option>`).join("");

        ["borrower-category", "history-category"].forEach((id) => {
            $(id).insertAdjacentHTML("beforeend", options);
        });
    } catch (error) {
        toast("Could not load the categories.", "danger");
    }
};

// Number of lost / damaged cases still open, shown on the dashboard button.
const loadCaseCount = async () => {
    try {
        const data = await apiGet("getCases", { status: "open", limit: 1 });
        const open = data && data.summary ? Number(data.summary.open) : 0;
        $("ld-count").textContent = open;
        $("ld-count").classList.toggle("d-none", open === 0);
    } catch (error) { /* the button still works without the count */ }
};

const loadBorrowers = async () => {
    const b = state.borrowers;
    const request = ++borrowerRequest;

    $("borrower-list").innerHTML = `<div class="list-group-item text-center text-muted py-4">Loading...</div>`;

    try {
        const data = await apiGet("getBorrowers", {
            search: b.search,
            type: b.type,
            overdue: b.overdue ? 1 : 0,
            category: b.category,
            sort: b.sort,
            page: b.page,
            limit: BORROWER_PAGE_SIZE
        });

        if (request !== borrowerRequest) return; // a newer search is already on its way

        if (!data || !Array.isArray(data.rows)) {
            throw new Error((data && data.message) || "Unexpected response");
        }

        if (data.rows.length === 0 && data.total > 0 && b.page > 1) {
            b.page = data.pages;
            return loadBorrowers();
        }

        b.rows = data.rows;
        b.total = data.total;
        b.pages = data.pages;
        b.page = data.page;

        renderSummary(data.summary);
        renderBorrowers();
    } catch (error) {
        if (request !== borrowerRequest) return;
        $("borrower-list").innerHTML = `<div class="list-group-item text-center text-danger py-4">Could not load borrowers.</div>`;
        toast("Failed to load borrowers.", "danger");
    }
};

const renderSummary = (summary) => {
    if (!summary) return;
    $("sum-borrowers").innerText = summary.borrowers;
    $("sum-books").innerText = summary.books_out;
    $("sum-overdue").innerText = summary.overdue_books;
};

const renderBorrowers = () => {
    const b = state.borrowers;
    const list = $("borrower-list");
    const filtering = b.search || b.type !== "all" || b.overdue;

    $("borrower-count").innerText = b.total === 0
        ? ""
        : `${plural(b.total, "borrower", "borrowers")} with books out${filtering ? " match your filters" : ""}`;

    $("borrower-page").innerText = `Page ${b.page} of ${b.pages}`;
    $("borrower-prev").disabled = b.page <= 1;
    $("borrower-next").disabled = b.page >= b.pages;

    if (b.rows.length === 0) {
        list.innerHTML = `
            <div class="list-group-item text-center text-muted py-4">
                ${filtering
                    ? "No borrower with books out matches these filters.<br><span class='small'>Try fewer words, or clear the filters.</span>"
                    : "Nobody has books out right now."}
            </div>`;
        return;
    }

    const activeId = state.selected ? String(state.selected.student_id) : "";

    list.innerHTML = b.rows.map((row) => {
        const detail = Number(row.is_faculty) === 1
            ? (row.department_name || "")
            : (row.course || "");
        const line = [detail, row.email].filter(Boolean).join(" · ");
        const overdue = Number(row.overdue_count);

        return `
            <button type="button" class="list-group-item list-group-item-action borrower-item ${String(row.student_id) === activeId ? "active" : ""}"
                    data-id="${row.student_id}">
                <div class="d-flex justify-content-between align-items-start gap-2">
                    <div class="min-w-0">
                        <div class="fw-semibold">${escapeHtml(row.first_name)} ${escapeHtml(row.last_name)} ${typeBadge(row.is_faculty)}</div>
                        <div class="small text-muted text-truncate">${escapeHtml(line) || "&nbsp;"}</div>
                        ${row.phone ? `<div class="small text-muted">${escapeHtml(row.phone)}</div>` : ""}
                    </div>
                    <div class="text-end flex-shrink-0">
                        <div><span class="badge bg-dark">${plural(Number(row.books_out), "book", "books")}</span></div>
                        ${overdue > 0 ? `<div class="mt-1"><span class="badge bg-danger">${overdue} overdue</span></div>` : ""}
                    </div>
                </div>
            </button>`;
    }).join("");
};

/* ---------------- Step 2: the borrower's books ---------------- */

const selectBorrower = async (studentId, scroll) => {
    try {
        const data = await apiGet("getBorrowerItems", { student_id: studentId });

        if (data.status !== "success") {
            toast(data.message || "Could not open this borrower.", "danger");
            return;
        }

        state.selected = data.borrower;
        state.items = data.items;
        state.today = data.today;
        state.picked = new Set();
        state.conditions = {};
        state.settlements = {};
        if (data.fees) state.fees = data.fees;
        state.items.forEach((item) => { state.conditions[item.item_id] = DEFAULT_CONDITION; });

        const url = new URL(window.location);
        url.searchParams.set("student", data.borrower.student_id);
        window.history.replaceState({}, "", url);

        renderBorrowers();
        renderPanel();

        if (scroll && window.innerWidth < 992) {
            $("return-panel").scrollIntoView({ behavior: "smooth", block: "start" });
        }
    } catch (error) {
        toast("Failed to load this borrower's books.", "danger");
    }
};

const closeBorrower = () => {
    state.selected = null;
    state.items = [];
    state.picked = new Set();

    const url = new URL(window.location);
    url.searchParams.delete("student");
    window.history.replaceState({}, "", url);

    renderBorrowers();
    renderPanel();
    $("borrower-search").focus();
};

const renderPanel = () => {
    const body = $("panel-body");
    const b = state.selected;

    if (!b) {
        body.innerHTML = `
            <div class="panel-empty">
                <div class="fs-5 mb-1">No borrower selected</div>
                <div>Pick someone from the list to see the books they have out.</div>
            </div>`;
        return;
    }

    const detail = Number(b.is_faculty) === 1 ? b.department_name : b.course;
    const contact = [detail, b.email, b.phone].filter(Boolean).join(" · ");

    if (state.items.length === 0) {
        body.innerHTML = `
            <div class="card-body">
                ${panelHeader(b, contact)}
                <div class="alert alert-success mt-3 mb-3">All of ${escapeHtml(b.first_name)}'s books have been returned.</div>
                <button class="btn btn-success" id="btn-next-borrower" type="button">Find the next borrower</button>
            </div>`;
        $("btn-next-borrower").addEventListener("click", closeBorrower);
        $("panel-close").addEventListener("click", closeBorrower);
        return;
    }

    const overdueCount = state.items.filter((i) => i.days_overdue > 0).length;

    body.innerHTML = `
        <div class="card-body pb-2">
            ${panelHeader(b, contact)}

            <div class="d-flex flex-wrap align-items-center gap-2 mt-3">
                <label class="form-label fw-semibold mb-0 me-2">2. Choose the books coming back</label>
                <button class="btn btn-sm btn-outline-success" id="btn-pick-all" type="button">Select all</button>
                ${overdueCount > 0 ? `<button class="btn btn-sm btn-outline-danger" id="btn-pick-overdue" type="button">Select overdue (${overdueCount})</button>` : ""}
                <button class="btn btn-sm btn-outline-secondary" id="btn-pick-none" type="button">Clear</button>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" id="items-table">
                <thead class="table-light">
                    <tr>
                        <th style="width: 40px;"><input type="checkbox" class="form-check-input" id="pick-header" aria-label="Select all books"></th>
                        <th>Book</th>
                        <th>Borrowed</th>
                        <th>Due</th>
                        <th style="width: 130px;">Condition</th>
                        <th class="text-end" style="width: 110px;">Fine</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemRowsHtml()}
                </tbody>
            </table>
        </div>

        <div class="card-footer">
            <div class="small text-muted mb-2">Overdue books are fined ${peso(state.fees.fine_per_day)} for every day past the due date. A lost or damaged book must be reported and settled in person at the library.</div>
            <div id="charge-summary" class="mb-2"></div>
            <div class="row g-2 align-items-end">
                <div class="col-sm-5">
                    <label class="form-label fw-semibold mb-1" for="return-date">Return date</label>
                    <input type="date" id="return-date" class="form-control">
                </div>
                <div class="col-sm-7 text-sm-end">
                    <button class="btn btn-success" id="btn-return" type="button" disabled>Return selected (0)</button>
                </div>
            </div>
            <div class="form-text" id="return-date-hint"></div>
        </div>`;

    $("panel-close").addEventListener("click", closeBorrower);
    $("btn-pick-all").addEventListener("click", () => setPicked(state.items.map((i) => i.item_id)));
    $("btn-pick-none").addEventListener("click", () => setPicked([]));
    $("pick-header").addEventListener("change", (e) => setPicked(e.target.checked ? state.items.map((i) => i.item_id) : []));
    $("btn-return").addEventListener("click", openConfirm);
    $("return-date").addEventListener("change", checkReturnDate);

    if ($("btn-pick-overdue")) {
        $("btn-pick-overdue").addEventListener("click", () => setPicked(state.items.filter((i) => i.days_overdue > 0).map((i) => i.item_id)));
    }

    const tbody = document.querySelector("#items-table tbody");

    tbody.addEventListener("change", (e) => {
        if (e.target.classList.contains("item-check")) {
            togglePicked(e.target.dataset.item, e.target.checked);
        } else if (e.target.classList.contains("item-condition")) {
            const id = e.target.dataset.item;
            state.conditions[id] = e.target.value;
            if (!isRetired(id)) delete state.settlements[id];
            else state.picked.add(String(id));          // reporting it means it is being handled now
            redrawItemRows();
        }
    });

    // Clicking anywhere on a row ticks it, which is faster than aiming at the checkbox.
    tbody.addEventListener("click", (e) => {
        if (e.target.closest("select, input, button, a")) return;
        const tr = e.target.closest("tr");
        if (!tr || tr.classList.contains("settle-row") || e.target.closest(".form-check")) return;
        const box = tr.querySelector(".item-check");
        if (!box) return;
        box.checked = !box.checked;
        togglePicked(box.dataset.item, box.checked);
    });

    $("return-date").value = todayString();
    updateSelectionUI();
};

// One table row per book, plus a settlement row under any book reported Damaged or Lost.
const itemRowsHtml = () => state.items.map((item) => `
    <tr data-item="${item.item_id}" class="${item.days_overdue > 0 ? "overdue-row" : ""}">
        <td><input type="checkbox" class="form-check-input item-check" data-item="${item.item_id}" aria-label="Return ${escapeHtml(item.title)}"></td>
        <td>
            <div class="fw-semibold">${escapeHtml(item.title)}</div>
            <div class="small text-muted">ACC-${escapeHtml(item.accession_number)}${item.book_type ? " · " + escapeHtml(item.book_type) : ""}</div>
        </td>
        <td class="text-nowrap">${escapeHtml(fmtDate(item.borrow_date))}</td>
        <td class="text-nowrap">${escapeHtml(fmtDate(item.due_date))}<div>${dueBadge(item.days_overdue)}</div></td>
        <td>
            <select class="form-select form-select-sm item-condition" data-item="${item.item_id}" aria-label="Condition of ${escapeHtml(item.title)}">
                ${conditionOptions(state.conditions[item.item_id])}
            </select>
        </td>
        <td class="text-end text-nowrap fine-cell" data-item="${item.item_id}"></td>
    </tr>${isRetired(item.item_id) ? settleRowHtml(item) : ""}`).join("");

// Shown under a book reported Lost or Damaged: the price and receipt are handled on the Lost & Damaged dashboard.
const settleRowHtml = (item) => {
    const cond = state.conditions[item.item_id];

    return `
    <tr class="settle-row" data-settle="${item.item_id}">
        <td></td>
        <td colspan="5">
            <div class="border rounded p-2 bg-light">
                <div class="fw-semibold mb-1">${escapeHtml(cond)} book: it will be sent to the Lost &amp; Damaged dashboard.</div>
                <div class="small">There the Technical Services Librarian sets the price, the receipt is printed for Assessment, and you can follow the payment.</div>
            </div>
        </td>
    </tr>`;
};

// Redraws the rows (after a condition change) and keeps the ticked books ticked.
const redrawItemRows = () => {
    document.querySelector("#items-table tbody").innerHTML = itemRowsHtml();
    updateSelectionUI();
};

// How the overdue fines of the ticked books are paid. A fine alone is collected at the library desk (after any advance
// payment the borrower already made); the fine of a lost or damaged book goes with its case to Assessment.
const DESK_FINE_LIMIT = 60;   // overdue fines up to this are paid at the library desk, above it at Assessment

const feeSplit = (items) => {
    let desk = 0, assessment = 0;
    items.forEach((item) => {
        const c = chargesFor(item);
        if (isRetired(item.item_id)) assessment += c.fine; else desk += c.fine;
    });

    // An overdue fine above the limit is not collected here: the borrower takes the receipt to Assessment.
    if (desk > DESK_FINE_LIMIT) {
        return { desk: 0, assessment, overdueAssessment: desk, creditUsed: 0, deskDue: 0 };
    }

    const credit = Number((state.selected && state.selected.credit) || 0);
    const creditUsed = Math.min(credit, desk);
    return { desk, assessment, overdueAssessment: 0, creditUsed, deskDue: Math.round((desk - creditUsed) * 100) / 100 };
};

// Fine column and the "to collect" summary above the Return button.
const refreshCharges = () => {
    let fines = 0, retired = 0;

    state.items.forEach((item) => {
        const c = chargesFor(item);
        const cell = document.querySelector(`.fine-cell[data-item="${item.item_id}"]`);
        if (cell) {
            cell.innerHTML = c.fine > 0
                ? `<span class="text-danger fw-semibold">${peso(c.fine)}</span><div class="small text-muted">${c.days} ${c.days === 1 ? "day" : "days"} × ${peso(state.fees.fine_per_day)}</div>`
                : '<span class="text-muted">—</span>';
        }
    });

    pickedItems().forEach((item) => {
        const c = chargesFor(item);
        fines += c.fine;
        if (isRetired(item.item_id)) retired++;
    });

    const box = $("charge-summary");
    if (!box) return;

    const split = feeSplit(pickedItems());
    if (fines === 0 && retired === 0) { box.innerHTML = ""; return; }

    box.innerHTML = `
        <div class="alert alert-warning py-2 mb-0">
            ${fines > 0 ? `Overdue fines: <strong>${peso(fines)}</strong>` : ""}
            ${retired > 0 ? `${fines > 0 ? " · " : ""}${plural(retired, "lost or damaged book", "lost or damaged books")} will go to the Lost &amp; Damaged dashboard` : ""}
            ${split.creditUsed > 0 ? `<div class="text-success">Already paid in advance: −${peso(split.creditUsed)}</div>` : ""}
            ${split.deskDue > 0 ? `<div class="fw-semibold">To collect at the library desk: ${peso(split.deskDue)}</div>` : ""}
            ${split.desk > 0 && split.deskDue === 0 ? `<div class="fw-semibold">Fine already paid: nothing to collect</div>` : ""}
            ${split.overdueAssessment > 0 ? `<div class="fw-semibold">Overdue fine is more than ${peso(DESK_FINE_LIMIT)}: the borrower takes the receipt and pays ${peso(split.overdueAssessment)} at Assessment</div>` : ""}
            ${split.assessment > 0 ? `<div class="fw-semibold">Late fine on the lost or damaged book, to pay at Assessment: ${peso(split.assessment)}</div>` : ""}
        </div>`;
};

const panelHeader = (b, contact) => `
    <div class="d-flex justify-content-between align-items-start gap-2">
        <div>
            <div class="fs-5 fw-semibold">${escapeHtml(b.first_name)} ${escapeHtml(b.last_name)} ${typeBadge(b.is_faculty)}</div>
            <div class="small text-muted">${escapeHtml(contact)}</div>
            <div class="small mt-1">Currently borrowing <strong>${state.items.length}</strong> of ${b.limit} allowed books</div>
        </div>
        <button class="btn btn-sm btn-outline-secondary" id="panel-close" type="button">Change borrower</button>
    </div>`;

const togglePicked = (itemId, on) => {
    const id = String(itemId);
    if (on) state.picked.add(id); else state.picked.delete(id);
    updateSelectionUI();
};

const setPicked = (ids) => {
    state.picked = new Set(ids.map(String));
    updateSelectionUI();
};

const pickedItems = () => state.items.filter((i) => state.picked.has(String(i.item_id)));

const updateSelectionUI = () => {
    document.querySelectorAll("#items-table tbody tr[data-item]").forEach((tr) => {
        const on = state.picked.has(tr.dataset.item);
        tr.classList.toggle("picked", on);
        tr.querySelector(".item-check").checked = on;
    });

    const header = $("pick-header");
    if (header) {
        header.checked = state.items.length > 0 && state.picked.size === state.items.length;
        header.indeterminate = state.picked.size > 0 && state.picked.size < state.items.length;
    }

    const btn = $("btn-return");
    if (btn) {
        btn.innerText = `Return selected (${state.picked.size})`;
        btn.disabled = state.picked.size === 0;
    }

    applyReturnDateLimits();
    refreshCharges();
};

// A book can't come back before it was borrowed or on a day that hasn't happened yet.
const applyReturnDateLimits = () => {
    const input = $("return-date");
    if (!input) return;

    const relevant = pickedItems().length > 0 ? pickedItems() : state.items;
    const earliest = relevant.reduce((max, i) => (i.borrow_date && i.borrow_date > max ? i.borrow_date : max), "");

    input.max = todayString();
    input.min = earliest;

    if (earliest && input.value && input.value < earliest) {
        input.value = earliest;
    }

    $("return-date-hint").innerText = earliest ? `Earliest possible date for this selection: ${fmtDate(earliest)}.` : "";
};

const checkReturnDate = () => {
    const input = $("return-date");

    if (input.value > todayString()) {
        input.value = todayString();
        toast("Return date can't be in the future.", "danger");
    }

    applyReturnDateLimits();
    refreshCharges();
};

/* ---------------- Confirm and save ---------------- */

const openConfirm = () => {
    const items = pickedItems();
    const date = $("return-date").value;

    if (items.length === 0) {
        toast("Select at least one book to return.", "danger");
        return;
    }

    if (!date) {
        toast("Choose the return date.", "danger");
        return;
    }

    const rows = items.map((i) => ({ i, c: chargesFor(i), cond: state.conditions[i.item_id], how: null }));
    const split = feeSplit(items);
    const total = split.deskDue + split.assessment + split.overdueAssessment;
    const replacements = rows.filter((r) => r.how === "Replaced").length;
    const retired = rows.filter((r) => isRetired(r.i.item_id)).length;
    const late = rows.filter((r) => r.c.days > 0).length;

    const detail = (r) => {
        const parts = [];
        if (r.c.fine > 0) parts.push(`Overdue ${r.c.days} ${r.c.days === 1 ? "day" : "days"}: ${peso(r.c.fine)}`);
        if (isRetired(r.i.item_id)) parts.push("Price and receipt: Lost &amp; Damaged dashboard");
        return parts.length ? parts.join("<br>") : '<span class="text-muted">—</span>';
    };

    $("confirm-body").innerHTML = `
        <p class="mb-2">
            ${plural(items.length, "book", "books")} from <strong>${escapeHtml(state.selected.first_name)} ${escapeHtml(state.selected.last_name)}</strong>,
            returned on <strong>${escapeHtml(fmtDate(date))}</strong>.
        </p>
        ${late > 0 ? `<div class="alert alert-warning py-2">${plural(late, "book is", "books are")} past the due date and will be fined ${peso(state.fees.fine_per_day)} per day.</div>` : ""}
        ${retired > 0 ? `<div class="alert alert-info py-2">${plural(retired, "lost or damaged copy", "lost or damaged copies")} will be taken off the shelf, archived, and sent to the Lost &amp; Damaged dashboard.</div>` : ""}
        <div class="table-responsive">
            <table class="table table-sm align-middle mb-0">
                <thead><tr><th>Book</th><th>Due</th><th>Condition</th><th>Charges</th></tr></thead>
                <tbody>
                    ${rows.map((r) => `
                        <tr>
                            <td>${escapeHtml(r.i.title)} <span class="text-muted small">[ACC-${escapeHtml(r.i.accession_number)}]</span></td>
                            <td class="text-nowrap">${escapeHtml(fmtDate(r.i.due_date))}</td>
                            <td>${escapeHtml(r.cond)}</td>
                            <td class="small">${detail(r)}</td>
                        </tr>`).join("")}
                </tbody>
            </table>
        </div>
        ${split.creditUsed > 0 ? `<div class="alert alert-success py-2 mt-2 mb-0">The borrower already paid ${peso(split.creditUsed)} in advance. It is used up against this fine.</div>` : ""}
        ${total > 0 || replacements > 0 ? `
        <div class="border rounded p-2 mt-3">
            ${split.deskDue > 0 ? `<div class="fs-5 fw-semibold mb-1">To collect at the library desk: ${peso(split.deskDue)}</div>` : ""}
            ${split.overdueAssessment > 0 ? `<div class="fs-5 fw-semibold mb-1">To pay at Assessment (overdue fine above ${peso(DESK_FINE_LIMIT)}): ${peso(split.overdueAssessment)}</div>` : ""}
            ${split.assessment > 0 ? `<div class="fw-semibold mb-1">To pay at Assessment (lost or damaged book): ${peso(split.assessment)}</div>` : ""}
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="confirm-received">
                <label class="form-check-label" for="confirm-received">
                    ${[
                        split.deskDue > 0 ? `I have collected ${peso(split.deskDue)} from the borrower at the library desk.` : "",
                        split.overdueAssessment > 0 ? `I will give the borrower the receipt for ${peso(split.overdueAssessment)} to pay at Assessment.` : "",
                        split.assessment > 0 ? `I will give the borrower the slip for ${peso(split.assessment)} to pay at Assessment.` : "",
                        replacements > 0 ? `I have received the replacement ${replacements === 1 ? "copy" : "copies"}.` : ""
                    ].filter(Boolean).join(" ")}
                </label>
            </div>
        </div>` : ""}`;

    const confirmBtn = $("btn-confirm-return");
    const received = $("confirm-received");
    confirmBtn.disabled = !!received;                       // nothing owed means nothing to confirm
    if (received) received.addEventListener("change", () => { confirmBtn.disabled = !received.checked; });

    confirmModal.show();
};

const submitReturn = async () => {
    const items = pickedItems();
    const date = $("return-date").value;
    const btn = $("btn-confirm-return");

    btn.disabled = true;

    try {
        const received = $("confirm-received");
        const result = await apiPost("addMultiple", {
            return_date: date,
            payment_confirmed: !!(received && received.checked),
            items: items.map((i) => ({
                item_id: i.item_id,
                condition_on_return: state.conditions[i.item_id],
            }))
        });

        confirmModal.hide();

        if (result.status === "success") {
            toast(result.message, "success");
            if (Array.isArray(result.return_ids) && result.return_ids.length) {
                await showReceipt(result.return_ids);
            }
        } else {
            toast(result.message, "danger");
        }

        loadCaseCount();

        // Always refresh: on a failure the list may be out of date, which is why it failed.
        await Promise.all([
            reloadSelectedBorrower(),
            loadBorrowers()
        ]);
    } catch (error) {
        confirmModal.hide();
        toast("Failed to save the return.", "danger");
    } finally {
        btn.disabled = false;
    }
};

const reloadSelectedBorrower = async () => {
    if (!state.selected) return;

    const keepPicked = new Set(state.picked);

    try {
        const data = await apiGet("getBorrowerItems", { student_id: state.selected.student_id });
        if (data.status !== "success") return;

        state.selected = data.borrower;
        state.items = data.items;
        if (data.fees) state.fees = data.fees;
        state.today = data.today;

        const stillOut = new Set(data.items.map((i) => String(i.item_id)));
        state.picked = new Set([...keepPicked].filter((id) => stillOut.has(id)));
        // Items that were just returned are gone; a failed attempt keeps its ticks.
        data.items.forEach((i) => {
            if (!(i.item_id in state.conditions)) state.conditions[i.item_id] = DEFAULT_CONDITION;
        });

        renderPanel();
        updateSelectionUI();
    } catch (error) {
        toast("Could not refresh this borrower's books.", "danger");
    }
};

/* ---------------- Return history ---------------- */

const wireHistoryFilters = () => {
    const reload = () => {
        state.history.page = 1;
        loadHistory();
    };

    const search = debounce(() => {
        state.history.search = $("history-search").value.trim();
        reload();
    });

    $("history-search").addEventListener("input", search);

    $("history-from").addEventListener("change", (e) => { state.history.from = e.target.value; reload(); });
    $("history-to").addEventListener("change", (e) => { state.history.to = e.target.value; reload(); });
    $("history-late").addEventListener("change", (e) => { state.history.late = e.target.checked; reload(); });
    $("history-category").addEventListener("change", (e) => { state.history.category = e.target.value; reload(); });
    $("history-sort").addEventListener("change", (e) => { state.history.sort = e.target.value; reload(); });

    $("history-reset").addEventListener("click", () => {
        $("history-search").value = "";
        $("history-from").value = "";
        $("history-to").value = "";
        $("history-late").checked = false;
        $("history-category").value = "";
        $("history-sort").value = "newest";
        Object.assign(state.history, { search: "", from: "", to: "", late: false, category: "", sort: "newest", page: 1 });
        loadHistory();
    });

    $("history-prev").addEventListener("click", () => {
        if (state.history.page > 1) { state.history.page--; loadHistory(); }
    });

    $("history-next").addEventListener("click", () => {
        if (state.history.page < state.history.pages) { state.history.page++; loadHistory(); }
    });

    $("history-body").addEventListener("click", (e) => {
        const btn = e.target.closest("button[data-action]");
        if (!btn) {
            const head = e.target.closest("tr.group-row");
            if (head) toggleHistoryGroup(head);
            return;
        }
        if (btn.dataset.action === "receipt") showReceipt(btn.dataset.ids.split(","));
        if (btn.dataset.action === "assess-pay") recordAssessmentPayment(btn.dataset.ids.split(","));
        if (btn.dataset.action === "edit") openEdit(btn.dataset.id);
        if (btn.dataset.action === "delete") deleteReturn(btn.dataset.id);
    });
};

const loadHistory = async () => {
    const h = state.history;
    const request = ++historyRequest;

    try {
        const data = await apiGet("getHistory", {
            search: h.search,
            from: h.from,
            to: h.to,
            late: h.late ? 1 : 0,
            category: h.category,
            sort: h.sort,
            page: h.page,
            limit: HISTORY_PAGE_SIZE
        });

        if (request !== historyRequest) return;

        if (!data || !Array.isArray(data.rows)) {
            throw new Error((data && data.message) || "Unexpected response");
        }

        if (data.rows.length === 0 && data.total > 0 && h.page > 1) {
            h.page = data.pages;
            return loadHistory();
        }

        Object.assign(h, { rows: data.rows, total: data.total, pages: data.pages, page: data.page });
        renderHistory();
    } catch (error) {
        if (request !== historyRequest) return;
        $("history-body").innerHTML = `<tr><td colspan="9" class="text-center text-danger">Could not load return history.</td></tr>`;
        toast("Failed to load return history.", "danger");
    }
};

const renderHistory = () => {
    const h = state.history;
    const tbody = $("history-body");

    $("history-page").innerText = h.total === 0
        ? "No records"
        : `Page ${h.page} of ${h.pages} · ${plural(h.total, "return", "returns")}`;
    $("history-prev").disabled = h.page <= 1;
    $("history-next").disabled = h.page >= h.pages;

    if (h.rows.length === 0) {
        tbody.innerHTML = `<tr><td colspan="9" class="text-center text-muted">No returns match these filters.</td></tr>`;
        return;
    }

    // One row per borrower; click the name to show the books they returned.
    const groups = new Map();
    h.rows.forEach((row) => {
        const name = row.student_name || "Unknown";
        if (!groups.has(name)) groups.set(name, []);
        groups.get(name).push(row);
    });

    const searching = h.search !== "";

    tbody.innerHTML = [...groups.entries()].map(([name, rows]) => {
        const open = searching || openHistory.has(name);
        const lateCount = rows.filter((r) => Number(r.days_late) > 0).length;

        const details = rows.map((row) => {
            const late = Number(row.days_late);

            return `
            <tr class="detail-row ${open ? "" : "d-none"}" data-group="${escapeHtml(name)}">
                <td></td>
                <td>${escapeHtml(row.title) || `Item ${escapeHtml(row.item_id)}`} <span class="text-muted small">[ACC-${escapeHtml(row.accession_number || "?")}]</span></td>
                <td class="text-nowrap">${escapeHtml(fmtDate(row.borrow_date))}</td>
                <td class="text-nowrap">${escapeHtml(fmtDate(row.due_date))}</td>
                <td class="text-nowrap">
                    ${escapeHtml(fmtDate(row.return_date))}
                    ${late > 0 ? `<div><span class="badge bg-danger">${late} ${late === 1 ? "day" : "days"} late</span></div>` : ""}
                </td>
                <td>${conditionBadge(row.condition_on_return)}</td>
                <td class="small">${chargesText(row)}</td>
                <td>${escapeHtml(row.processed_by) || "—"}</td>
                <td class="admin-only">
                    ${row.settlement || ["Damaged", "Lost"].includes(row.condition_on_return)
                        ? '<span class="text-muted small">Locked</span>'
                        : `<button class="btn btn-success btn-sm me-1" data-action="edit" data-id="${row.return_id}">Edit</button>
                           <button class="btn btn-danger btn-sm" data-action="delete" data-id="${row.return_id}">Delete</button>`}
                </td>
            </tr>`;
        }).join("");

        return `
            <tr class="group-row" data-group="${escapeHtml(name)}" tabindex="0" role="button" aria-expanded="${open}" style="cursor: pointer;">
                <td class="fw-semibold"><span class="caret me-1">${open ? "▼" : "▶"}</span>${escapeHtml(name)}</td>
                <td colspan="8" class="text-muted">
                    ${plural(rows.length, "book", "books")} returned
                    ${lateCount > 0 ? `<span class="badge bg-danger ms-1">${lateCount} late</span>` : ""}
                    ${receiptIds(rows).length ? `<button class="btn btn-outline-success btn-sm ms-2" type="button" data-action="receipt" data-ids="${receiptIds(rows).join(",")}">Receipt</button>` : ""}
                    ${rows.some((r) => assessmentOwed(r) > 0) ? `<button class="btn btn-warning btn-sm ms-2" type="button" data-action="assess-pay" data-ids="${rows.filter((r) => assessmentOwed(r) > 0).map((r) => r.return_id).join(",")}">Record Assessment payment</button>` : ""}
                </td>
            </tr>${details}`;
    }).join("");
};

/* ---------------- Assessment receipt ---------------- */

// An overdue fine above the desk limit that nobody has paid yet: it is paid at Assessment.
const assessmentOwed = (r) => {
    if (["Lost", "Damaged"].includes(r.condition_on_return)) return 0;
    const owed = Number(r.fine_amount || 0) - Number(r.fine_cash || 0) - Number(r.fine_credit || 0);
    return Number(r.assessment_flag || 0) > 0 && owed > 0.005 ? Math.round(owed * 100) / 100 : 0;
};

// Returns that owe money or were lost / damaged: these are the ones that go on a receipt.
const receiptIds = (rows) => rows
    .filter((r) => Number(r.charges_total) > 0 || ["Lost", "Damaged"].includes(r.condition_on_return))
    .map((r) => r.return_id);

const receiptHtml = (rows) => {
    const first = rows[0];
    const isRetiredRow = (r) => ["Lost", "Damaged"].includes(r.condition_on_return);
    const retired = rows.some(isRetiredRow);
    const deskRows = rows.filter((r) => !isRetiredRow(r));
    const deskCollected = deskRows.reduce((sum, r) => sum + Number(r.fine_cash || 0), 0);
    const creditUsed = deskRows.reduce((sum, r) => sum + Number(r.fine_credit || 0), 0);
    const overdueAssessment = deskRows.reduce((sum, r) => sum + assessmentOwed(r), 0);
    const toAssessment = retired || overdueAssessment > 0;
    const assessmentTotal = rows.filter(isRetiredRow).reduce((sum, r) => sum + Number(r.charges_total || 0), 0) + overdueAssessment;
    const no = "R-" + String(first.return_id).padStart(6, "0");

    const lines = (r) => {
        const out = [];
        if (Number(r.fine_amount) > 0) out.push(`<tr><td>Overdue fine (${Number(r.days_late)} ${Number(r.days_late) === 1 ? "day" : "days"})</td><td class="r">${peso(r.fine_amount)}</td></tr>`);
        if (Number(r.fine_credit) > 0) out.push(`<tr><td>Less: advance payment used</td><td class="r">-${peso(r.fine_credit)}</td></tr>`);
        if (r.settlement === "Paid") {
            out.push(`<tr><td>${escapeHtml(r.condition_on_return)} book: price</td><td class="r">${peso(r.book_price)}</td></tr>`);
            out.push(`<tr><td>Processing fee</td><td class="r">${peso(r.processing_fee)}</td></tr>`);
        }
        if (r.settlement === "Pending") out.push(`<tr><td>${escapeHtml(r.condition_on_return)} book: price will be set at the Lost &amp; Damaged desk</td><td class="r">Pending</td></tr>`);
        if (r.settlement === "Replaced") out.push(`<tr><td>${escapeHtml(r.condition_on_return)} book: replaced with a new copy</td><td class="r">No charge</td></tr>`);
        return out.join("");
    };

    const status = !toAssessment
        ? (deskCollected > 0 ? "PAID: received at the library desk" : (creditUsed > 0 ? "PAID: covered by the advance payment" : "NOTHING TO PAY"))
        : `${deskRows.some((r) => Number(r.fine_amount) > 0 && !assessmentOwed(r)) ? "Desk part PAID. " : ""}Assessment part UNPAID until stamped by Assessment`;

    return `
    <div class="receipt">
        <h2>Library Management System</h2>
        <div class="center">${toAssessment ? "Receipt and payment slip for Assessment" : "Official receipt: overdue fine"}</div>
        <div class="meta">
            <div><strong>Receipt no.:</strong> ${escapeHtml(no)}</div>
            <div><strong>Date:</strong> ${escapeHtml(fmtDate(first.return_date))}</div>
            <div><strong>Borrower:</strong> ${escapeHtml(first.student_name || "Unknown")}</div>
            <div><strong>Processed by:</strong> ${escapeHtml(first.processed_by || "—")}</div>
        </div>
        ${rows.map((r) => `
        <table>
            <tr class="book"><td colspan="2">${escapeHtml(r.title || "Book")} <span class="small">[ACC-${escapeHtml(r.accession_number || "?")}]</span>
                <div class="small">Condition: ${escapeHtml(r.condition_on_return)} · Due ${escapeHtml(fmtDate(r.due_date))} · Returned ${escapeHtml(fmtDate(r.return_date))}</div></td></tr>
            ${lines(r)}
        </table>`).join("")}
        ${deskRows.some((r) => Number(r.fine_amount) > 0) ? `<table><tr class="total"><td>COLLECTED AT THE LIBRARY DESK</td><td class="r">${peso(deskCollected)}</td></tr></table>` : ""}
        ${toAssessment ? `<table><tr class="total"><td>TO PAY AT ASSESSMENT</td><td class="r">${peso(assessmentTotal)}</td></tr></table>` : ""}
        <div class="status">${escapeHtml(status)}</div>
        ${retired ? `<div class="warn">${escapeHtml(CLEARANCE_WARNING)}</div>` : ""}
    </div>`;
};

const RECEIPT_CSS = `
    body { font-family: Arial, Helvetica, sans-serif; color: #000; margin: 0; padding: 16px; }
    .receipt { max-width: 420px; margin: 0 auto; font-size: 14px; }
    .receipt h2 { text-align: center; margin: 0 0 2px; font-size: 18px; }
    .center { text-align: center; margin-bottom: 10px; }
    .meta { border-top: 1px dashed #000; border-bottom: 1px dashed #000; padding: 6px 0; margin-bottom: 8px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 6px; }
    td { padding: 2px 0; vertical-align: top; }
    td.r { text-align: right; white-space: nowrap; }
    tr.book td { font-weight: bold; padding-top: 6px; border-top: 1px solid #ccc; }
    .small { font-size: 12px; font-weight: normal; }
    tr.total td { font-size: 16px; font-weight: bold; border-top: 2px solid #000; padding-top: 6px; }
    .status { text-align: center; font-weight: bold; border: 1px solid #000; padding: 4px; margin: 8px 0; }
    .warn { border: 1px solid #000; padding: 6px; font-size: 12px; }`;

const showReceipt = async (ids) => {
    try {
        const data = await apiGet("getReceipt", { ids: ids.join(",") });
        if (data.status !== "success" || !data.rows.length) throw new Error(data.message || "No rows");

        $("receipt-body").innerHTML = `<style>${RECEIPT_CSS.replace(/body \{[^}]*\}/, "")}</style>${receiptHtml(data.rows)}`;
        receiptModal.show();
    } catch (error) {
        toast("Could not build the receipt.", "danger");
    }
};

// The borrower paid an overdue fine above the desk limit at Assessment: record the Assessment receipt number.
const recordAssessmentPayment = async (ids) => {
    const or = (window.prompt("Enter the Assessment receipt number the borrower paid with:") || "").trim();
    if (!or) return;

    try {
        const result = await apiPost("payAssessmentFine", { return_ids: ids.map(Number), or_number: or });
        toast(result.message, result.status === "success" ? "success" : "danger");
        if (result.status === "success") await loadHistory();
    } catch (error) {
        toast("Could not record the payment.", "danger");
    }
};

const printReceipt = () => {
    const frame = document.createElement("iframe");
    frame.style.cssText = "position: fixed; width: 0; height: 0; border: 0;";
    document.body.appendChild(frame);

    const doc = frame.contentWindow.document;
    doc.open();
    doc.write(`<!DOCTYPE html><html><head><title>Receipt</title><style>${RECEIPT_CSS}</style></head><body>${$("receipt-body").querySelector(".receipt").outerHTML}</body></html>`);
    doc.close();

    frame.contentWindow.focus();
    frame.contentWindow.print();
    setTimeout(() => frame.remove(), 1000);
};

const conditionBadge = (c) => {
    if (c === "Lost") return '<span class="badge bg-danger">Lost</span>';
    if (c === "Damaged") return '<span class="badge bg-warning text-dark">Damaged</span>';
    return escapeHtml(c);
};

// What was collected for one returned book: overdue fine and/or lost or damaged settlement.
const chargesText = (row) => {
    const lines = [];
    if (Number(row.fine_amount) > 0) lines.push(`Fine ${peso(row.fine_amount)}`);
    let paidNote = "";
    if (Number(row.fine_amount) > 0 && !["Lost", "Damaged"].includes(row.condition_on_return)) {
        const paid = Number(row.fine_cash || 0) + Number(row.fine_credit || 0);
        paidNote = paid >= Number(row.fine_amount) - 0.005 ? `<div><span class="badge bg-success">Paid</span>${row.fine_receipt ? ` <span class="small text-muted">${escapeHtml(row.fine_receipt)}</span>` : ""}</div>`
            : paid > 0 ? `<div><span class="badge bg-warning text-dark">Part paid ${peso(paid)}</span></div>`
            : (Number(row.assessment_flag || 0) > 0
                ? '<div><span class="badge bg-danger">Unpaid</span> <span class="small text-muted">pay at Assessment</span></div>'
                : '<div class="small text-muted">No payment record</div>');
    }
    if (row.settlement === "Paid") lines.push(`Book ${peso(row.book_price)} + fee ${peso(row.processing_fee)}`);
    if (row.settlement === "Replaced") lines.push("Replaced with a new copy");
    if (lines.length === 0) return '<span class="text-muted">—</span>';
    const total = Number(row.charges_total) > 0 ? `<div class="fw-semibold">${peso(row.charges_total)}</div>` : "";
    return lines.map(escapeHtml).join("<br>") + total + paidNote;
};

const toggleHistoryGroup = (head) => {
    const name = head.dataset.group;
    const open = !openHistory.has(name);
    if (open) openHistory.add(name); else openHistory.delete(name);

    head.setAttribute("aria-expanded", String(open));
    head.querySelector(".caret").textContent = open ? "▼" : "▶";
    $("history-body").querySelectorAll("tr.detail-row").forEach((r) => {
        if (r.dataset.group === name) r.classList.toggle("d-none", !open);
    });
};

const openEdit = (id) => {
    const row = state.history.rows.find((r) => String(r.return_id) === String(id));
    if (!row) return;

    $("edit-return-id").value = row.return_id;
    $("edit-item-id").value = row.item_id;
    $("edit-book").innerText = `${row.title || "Item " + row.item_id} [ACC-${row.accession_number || "?"}]`;
    $("edit-borrower").innerText = `Borrower: ${row.student_name || "Unknown"} · Borrowed ${fmtDate(row.borrow_date)}`;

    const date = $("edit-date");
    date.min = row.borrow_date || "";
    date.max = todayString();
    date.value = row.return_date;

    $("edit-condition").innerHTML = conditionOptions(row.condition_on_return, EDIT_CONDITIONS);

    editModal.show();
};

const saveEdit = async () => {
    const return_id = $("edit-return-id").value;
    const item_id = $("edit-item-id").value;
    const return_date = $("edit-date").value;
    const condition_on_return = $("edit-condition").value;

    if (!return_date || !condition_on_return) {
        toast("All fields are required.", "danger");
        return;
    }

    if (return_date > todayString()) {
        toast("Return date can't be in the future.", "danger");
        return;
    }

    try {
        const result = await apiPost("update", { return_id, item_id, return_date, condition_on_return });

        if (result.status === "success") {
            editModal.hide();
            toast(result.message, "success");
            loadHistory();
        } else {
            toast(result.message, "danger");
        }
    } catch (error) {
        toast("Failed to update the return.", "danger");
    }
};

const deleteReturn = async (id) => {
    if (!await lmsConfirm("Delete this return? The book will be marked as borrowed again.")) return;

    try {
        const result = await apiPost("delete", { return_id: id });

        if (result.status === "success") {
            toast(result.message, "success");
            await Promise.all([loadHistory(), loadBorrowers(), reloadSelectedBorrower()]);
        } else {
            toast(result.message, "danger");
        }
    } catch (error) {
        toast("Failed to delete the return.", "danger");
    }
};