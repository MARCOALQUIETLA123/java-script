// Loaded on every page except login.html, right after axios and before the page's own script.
// - sends signed-out visitors to the login page
// - keeps Library Staff and Student Assistants (SA) out of Technical Services Librarian pages and hides admin-only menu items and buttons
// - shows who is signed in, with a Log out button
// - exposes window.authReady: a promise for the signed-in user ({ user_id, first_name, ... })
// The server enforces all of this independently; this only keeps the screens tidy.

(() => {
    const api = "api/auth.php";

    // Pages only the Technical Services Librarian can open. Library Staff never get these, whatever is granted.
    const ADMIN_PAGES = [
        "roles.html", "loan_rules.html", "department.html", "categories.html", "publisher.html",
        "users.html", "author.html", "book_author.html"
    ];

    // Pages Library Staff / Student Assistants open only when the matching permission was granted.
    // Keep in step with Auth::PERMISSIONS in config/auth.php (the server enforces it; this only keeps the screens tidy).
    const PAGE_PERMISSION = {
        "book.html": "catalog", "book_copies.html": "catalog",
        "borrow_transaction.html": "borrowing",
        "book_return.html": "returns",
        "reservation.html": "reservations",
        "lost_damaged.html": "fines", "account_holds.html": "fines",
        "borrow_report.html": "reports", "transaction_history.html": "reports"
    };

    // Can this user open that page? (the dashboard is always open; its numbers need the "reports" permission)
    const mayOpen = (me, target) => {
        if (me.role === "admin") return true;
        if (me.role === "borrower") return target === "portal.html";
        if (ADMIN_PAGES.includes(target)) return false;
        const need = PAGE_PERMISSION[target];
        return !need || (me.permissions || []).includes(need);
    };

    const page = (location.pathname.split("/").pop() || "dashboard.html").toLowerCase();

    // Pages that were removed from the system. If an old copy is still on the server, send people away from it,
    // and strip links to them from any menu (even a page that still has an old copy of the menu).
    const REMOVED_PAGES = ["status.html", "loan_policy.html"];
    const dropDeadLinks = () => {
        document.querySelectorAll("a[href]").forEach((a) => {
            const target = (a.getAttribute("href") || "").toLowerCase();
            if (REMOVED_PAGES.includes(target)) (a.closest("li") || a).remove();
        });
    };

    if (REMOVED_PAGES.includes(page)) {
        location.replace("dashboard.html");
        return;
    }

    // Loop breaker: if this page keeps getting bounced to the login page (and login keeps
    // bouncing back), stop after 3 rounds in 10 seconds and say which request was refused.
    let leaving = false;
    const loopedTooMuch = () => {
        try {
            const now = Date.now();
            const hits = JSON.parse(sessionStorage.getItem("lms_login_bounces") || "[]").filter((t) => now - t < 10000);
            hits.push(now);
            sessionStorage.setItem("lms_login_bounces", JSON.stringify(hits));
            return hits.length >= 3;
        } catch (e) {
            return false;
        }
    };

    const showLoopNotice = (what) => {
        document.documentElement.classList.remove("auth-pending");
        const show = () => {
            const box = document.createElement("div");
            box.className = "alert alert-danger m-3";
            box.textContent = `Stopped a login loop: ${what} was refused as "not signed in" even though login accepted you. ` +
                `Press F12, open the Network tab and look at that request's Response.`;
            document.body.prepend(box);
        };
        if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", show); else show();
    };

    const toLogin = (what) => {
        if (leaving) return; // several requests can fail at once: count the page only once
        leaving = true;

        if (loopedTooMuch()) {
            console.error("Login loop stopped. Refused request:", what);
            showLoopNotice(what || "a request");
            return;
        }

        const next = /^[a-z_]+\.html$/i.test(page) && page !== "login.html" ? `?next=${page}` : "";
        location.replace(`login.html${next}`);
    };

    // Hide the page until we know who is looking at it, so admin screens never flash up.
    const style = document.createElement("style");
    style.textContent = "html.auth-pending body { visibility: hidden; } html.role-staff .admin-only, html.role-sa .admin-only { display: none !important; }" + `
        /* Table action buttons: always on one line, with the same gap on every page */
        .row-actions { display: flex; flex-wrap: nowrap; align-items: center; gap: .5rem; white-space: nowrap; }
        td > .btn-sm:not(.btn-link), td > span > .btn-sm:not(.btn-link) { margin: 0 .5rem 0 0 !important; }
        td > .btn-sm:last-child, td > span > .btn-sm:last-child { margin-right: 0 !important; }
        td:has(> .btn-sm:not(.btn-link)), td:has(> .row-actions), td > span:has(> .btn-sm) { white-space: nowrap; }
        th.actions-col { min-width: 9rem; }
        /* Navigation bar: wide, never wraps a link, generous gaps */
        @media (min-width: 992px) {
            .app-nav > .container-xl { max-width: 1760px !important; padding-left: 2rem !important; padding-right: 2rem !important; }
            .app-nav .navbar-brand { white-space: nowrap !important; margin-right: 2.25rem !important; }
            .app-nav .navbar-collapse { align-items: center; }
            .app-nav .navbar-nav { flex-wrap: wrap; align-items: center; column-gap: .5rem !important; row-gap: .25rem !important; }
            .app-nav .navbar-nav .nav-link { white-space: nowrap !important; padding: .65rem 1rem !important; }
            .app-nav .nav-user { flex-shrink: 0; white-space: nowrap !important; gap: 1rem !important; margin-left: auto; padding-left: 2rem; }
            .app-nav .nav-user .btn { white-space: nowrap !important; padding: .35rem 1rem !important; }
        }
        @media (max-width: 991.98px) {
            .app-nav .nav-user { padding: .75rem 0; flex-wrap: wrap; }
        }
    `;
    document.head.appendChild(style);
    document.documentElement.classList.add("auth-pending");

    axios.interceptors.response.use(
        (res) => res,
        (err) => {
            const status = err.response && err.response.status;
            if (status === 401) toLogin((err.config && err.config.url) || "a request");
            return Promise.reject(err);
        }
    );

    window.logout = async () => {
        try {
            const fd = new FormData();
            fd.append("operation", "logout");
            await axios.post(api, fd);
        } catch (e) { /* leave anyway */ }
        location.replace("login.html");
    };

    const decorate = (me) => {
        dropDeadLinks();
        const staff = me.role === "staff" || me.role === "sa";   // Library Staff and Student Assistant share the desk-only view
        document.documentElement.classList.add(`role-${me.role}`);

        if (staff) {
            // Remove menu entries and dashboard cards for pages this account may not open.
            document.querySelectorAll("nav a[href], .card-footer a[href]").forEach((a) => {
                const target = (a.getAttribute("href") || "").toLowerCase();
                if (!/^[a-z_]+\.html$/.test(target) || mayOpen(me, target)) return;
                const holder = a.closest("li") || a.closest(".col-md-3");
                if (holder) holder.remove();
            });

            // Drop menus left empty (e.g. "Lookup Tables").
            document.querySelectorAll("nav .dropdown").forEach((d) => {
                if (!d.querySelector(".dropdown-menu li")) d.remove();
            });

            // The dashboard is open to everyone, but its numbers need the "reports" permission.
            if (page === "dashboard.html" && !(me.permissions || []).includes("reports")) {
                const holder = document.querySelector(".app-page");
                if (holder) {
                    holder.innerHTML = '<div class="dash-card"><div class="card-pad"><h5 class="mb-1">Welcome</h5>' +
                        '<p class="text-muted mb-0">Your account can only open the pages the Technical Services Librarian has switched on for you' +
                        ((me.permissions || []).length ? "." : ", and none are switched on yet. Ask the Technical Services Librarian for access.") +
                        "</p></div></div>";
                }
            }
        }

        const menu = document.getElementById("navMenu");
        if (menu) {
            const box = document.createElement("div");
            box.className = "nav-user d-flex align-items-center gap-2 ms-lg-auto text-white";

            // Role title first, then the person's own name. The old built-in "System Administrator" /
            // "Admin" account name is never shown: that account just shows its role title.
            const roleTitle = me.role === "admin" ? "Technical Services Librarian"
                : me.role === "staff" ? "Library Staff"
                : me.role === "sa" ? "Student Assistant"
                : (me.role_name || "");
            const personal = `${me.first_name || ""} ${me.last_name || ""}`.trim();
            const generic = /\badmin(istrator)?\b/i.test(personal) || personal.toLowerCase() === roleTitle.toLowerCase();

            const badge = document.createElement("span");
            badge.className = `badge ${me.role === "admin" ? "bg-warning text-dark" : me.role === "sa" ? "bg-info text-dark" : "bg-light text-success"}`;
            badge.textContent = roleTitle;

            const name = document.createElement("span");
            name.textContent = generic ? "" : personal;

            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "btn btn-outline-light btn-sm";
            btn.textContent = "Log out";
            btn.addEventListener("click", window.logout);

            box.append(badge, name, btn);
            menu.appendChild(box);
        }
    };

    window.authReady = axios.get(api, { params: { operation: "me" } })
        .then((res) => {
            const me = res.data.user;
            window.currentUser = me;

            if (me.role === "borrower" && page !== "portal.html") {
                location.replace("portal.html");
                return new Promise(() => {}); // stay hidden while we leave
            }
            if (me.role !== "borrower" && page === "portal.html") {
                location.replace("dashboard.html");
                return new Promise(() => {});
            }

            if ((me.role === "staff" || me.role === "sa") && !mayOpen(me, page)) {
                location.replace("dashboard.html");
                return new Promise(() => {}); // stay hidden while we leave
            }

            const run = () => {
                decorate(me);
                document.documentElement.classList.remove("auth-pending");

                // Live updates from other devices (see live.js).
                const live = document.createElement("script");
                live.src = "assets/js/live.js";
                document.body.appendChild(live);
            };

            if (document.readyState === "loading") {
                document.addEventListener("DOMContentLoaded", run);
            } else {
                run();
            }

            return me;
        });

    window.authReady.catch((err) => {
        if (err && err.response && err.response.status === 401) return; // interceptor is redirecting

        // Server or database problem: show the page with a clear message rather than a blank screen.
        const show = () => {
            document.documentElement.classList.remove("auth-pending");
            const box = document.createElement("div");
            box.className = "alert alert-danger m-3";
            box.textContent = "Could not verify your login. Check that the web server and database are running.";
            document.body.prepend(box);
        };
        if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", show); else show();
    });
})();