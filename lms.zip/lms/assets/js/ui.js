// Shared page extras. Load it at the bottom of a page, after the page's own script tag is fine.
//
// 1. KPI strip: if the page has <div id="kpi-strip">, it is filled with summary tiles (same look as the
//    dashboard). The numbers are read from the list the page already loads (and re-read on every live
//    refresh), so there is no extra setup. A few pages also read a second list for a richer summary.
// 2. Table search: <input data-filter-body="table-body"> filters the rows of that table body as you type.
//
// Nothing here changes the page's own logic, and any failure is ignored so the page keeps working.

(() => {
    const page = (location.pathname.split("/").pop() || "dashboard.html").toLowerCase();

    /* ---------------- helpers ---------------- */

    const esc = (v) => String(v ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    const num = (v) => Number(v) || 0;
    const fmt = (n) => num(n).toLocaleString();
    const plural = (n, one, many) => `${fmt(n)} ${n === 1 ? one : many}`;
    const lower = (v) => String(v ?? "").trim().toLowerCase();
    const STAFF_ROLES = ["technical services librarian", "library staff", "student assistant", "student assistant (sa)", "sa", "admin", "staff"]; // the old names still count
    const distinct = (rows, key) => new Set(rows.map((r) => r[key]).filter((v) => v !== null && v !== undefined && v !== "")).size;

    // A separate axios instance, so these extra reads never trigger the page's own interceptors.
    const http = axios.create({ timeout: 10000 });
    const getAll = async (file) => {
        const res = await http.get(`api/${file}`, { params: { operation: "getAll" } });
        return Array.isArray(res.data) ? res.data : [];
    };
    const optional = async (file) => { try { return await getAll(file); } catch (e) { return null; } };

    /* ---------------- KPI strip ---------------- */

    const render = (cards) => {
        const el = document.getElementById("kpi-strip");
        if (!el || !cards.length) return;

        const col = { 1: "col-6 col-lg-3", 2: "col-6 col-lg-6", 3: "col-12 col-sm-4", 4: "col-6 col-lg-3" }[cards.length] || "col-6 col-lg-3";

        el.innerHTML = cards.map((c) => `
            <div class="${col}">
                <div class="dash-card kpi${c.alert ? " is-alert" : ""}">
                    <div class="label">${esc(c.label)}</div>
                    <div class="value">${esc(c.value)}</div>
                    <div class="note">${esc(c.note || "")}</div>
                </div>
            </div>`).join("");
    };

    // What each page shows. `file` is the endpoint the page already loads; `build` gets that list.
    const PAGES = {
        "users.html": {
            file: "users.php",
            build: (rows) => {
                const isStaff = (r) => STAFF_ROLES.includes(lower(r.role_name));
                const staff = rows.filter(isStaff).length;
                const pending = rows.filter((r) => r.account_status === "pending").length;
                return [
                    { label: "People", value: fmt(rows.length), note: "accounts and borrowers" },
                    { label: "Librarian and staff", value: fmt(staff), note: "run the library" },
                    { label: "Borrowers", value: fmt(rows.length - staff), note: "students, faculty and deans" },
                    { label: "Pending approval", value: fmt(pending), note: pending ? "waiting for approval" : "nothing waiting", alert: pending > 0 }
                ];
            }
        },

        "book.html": {
            file: "book.php",
            build: (rows) => {
                const total = rows.reduce((s, r) => s + num(r.total_copies), 0);
                const available = rows.reduce((s, r) => s + num(r.available_copies), 0);
                const borrowed = rows.reduce((s, r) => s + num(r.borrowed_copies), 0);
                return [
                    { label: "Book titles", value: fmt(rows.length), note: `${plural(distinct(rows, "category_id"), "category", "categories")} in use` },
                    { label: "Total copies", value: fmt(total), note: rows.length ? `about ${(total / rows.length).toFixed(1)} per title` : "" },
                    { label: "Available", value: fmt(available), note: total ? `${Math.round(available / total * 100)}% on the shelf` : "" },
                    { label: "Borrowed", value: fmt(borrowed), note: total ? `${Math.round(borrowed / total * 100)}% out right now` : "" }
                ];
            }
        },

        "book_copies.html": {
            file: "book_copies.php",
            build: (rows) => {
                const by = (s) => rows.filter((r) => lower(r.status_desc) === s).length;
                const available = by("available");
                const borrowed = by("borrowed");
                return [
                    { label: "Total copies", value: fmt(rows.length), note: plural(distinct(rows, "book_id"), "title", "titles") },
                    { label: "Available", value: fmt(available), note: rows.length ? `${Math.round(available / rows.length * 100)}% on the shelf` : "" },
                    { label: "Borrowed", value: fmt(borrowed), note: "out with borrowers" },
                    { label: "Reserved / other", value: fmt(rows.length - available - borrowed), note: "held or not lendable" }
                ];
            }
        },

        "author.html": {
            file: "author.php",
            build: async (rows) => {
                const links = await optional("book_author.php");
                const withBio = rows.filter((r) => String(r.bio ?? "").trim() !== "").length;
                const cards = [
                    { label: "Authors", value: fmt(rows.length), note: "in the catalogue" },
                    { label: "With a biography", value: fmt(withBio), note: `${fmt(rows.length - withBio)} without` }
                ];
                if (links) {
                    const credited = distinct(links, "author_id");
                    cards.push({ label: "Linked to books", value: fmt(credited), note: `${fmt(rows.length - credited)} not linked yet` });
                }
                return cards;
            }
        },

        "publisher.html": {
            file: "publisher.php",
            build: async (rows) => {
                const books = await optional("book.php");
                const cards = [{ label: "Publishers", value: fmt(rows.length), note: "in the catalogue" }];
                if (books) {
                    const used = distinct(books, "publisher_id");
                    cards.push({ label: "Publishers in use", value: fmt(used), note: `${fmt(rows.length - used)} with no books yet` });
                    cards.push({ label: "Titles published", value: fmt(books.length), note: "across all publishers" });
                }
                return cards;
            }
        },

        "categories.html": {
            file: "categories.php",
            build: async (rows) => {
                const books = await optional("book.php");
                const cards = [{ label: "Categories", value: fmt(rows.length), note: "group the collection" }];
                if (books) {
                    const used = distinct(books, "category_id");
                    cards.push({ label: "Categories in use", value: fmt(used), note: `${fmt(rows.length - used)} with no books yet` });
                    cards.push({ label: "Titles categorised", value: fmt(books.length), note: "in the library" });
                }
                return cards;
            }
        },

        "department.html": {
            file: "department.php",
            build: async (rows) => {
                const users = await optional("users.php");
                const cards = [{ label: "Departments", value: fmt(rows.length), note: "staff and faculty belong to" }];
                if (users) {
                    const used = distinct(users, "department_id");
                    cards.push({ label: "Departments in use", value: fmt(used), note: `${fmt(rows.length - used)} with no people yet` });
                    cards.push({ label: "People assigned", value: fmt(users.length), note: "across all departments" });
                }
                return cards;
            }
        },

        "book_author.html": {
            file: "book_author.php",
            build: (rows) => [
                { label: "Author links", value: fmt(rows.length), note: "book and author pairs" },
                { label: "Books with authors", value: fmt(distinct(rows, "book_id")), note: "titles credited" },
                { label: "Authors credited", value: fmt(distinct(rows, "author_id")), note: "linked to at least one book" }
            ]
        },

        "roles.html": {
            file: "roles.php",
            build: (rows) => {
                const accounts = rows.reduce((s, r) => s + num(r.user_count), 0);
                const staff = rows.filter((r) => STAFF_ROLES.includes(lower(r.role_name))).reduce((s, r) => s + num(r.user_count), 0);
                return [
                    { label: "Roles", value: fmt(rows.length), note: "in the library system" },
                    { label: "Accounts", value: fmt(accounts), note: "across every role" },
                    { label: "Librarian and staff", value: fmt(staff), note: "run the library" },
                    { label: "Borrowers", value: fmt(accounts - staff), note: "students, faculty and deans" }
                ];
            }
        },

        "portal.html": {
            file: "portal.php",
            op: "getMyLoans",
            list: false,
            build: (data) => {
                const s = data && data.summary;
                if (!s) return [];
                const overdue = (data.loans || []).filter((l) => l.status === "Overdue").length;
                const left = Math.max(0, num(s.limit) - num(s.active) - num(s.reserved));
                return [
                    { label: "Borrowed now", value: fmt(s.active), note: "books you have" },
                    { label: "Overdue", value: fmt(overdue), note: overdue ? "please return them" : "nothing late", alert: overdue > 0 },
                    { label: "Reserved", value: fmt(s.reserved), note: "held or waiting for you" },
                    { label: "Books you can add", value: fmt(left), note: `of ${fmt(s.limit)} at a time` }
                ];
            }
        }
    };

    const cfg = PAGES[page];
    let latest = 0;

    if (cfg && typeof axios !== "undefined") {
        axios.interceptors.response.use((res) => {
            try {
                const url = String((res.config && res.config.url) || "").split("?")[0];
                const op = ((res.config && res.config.params) || {}).operation || "";
                const okShape = cfg.list === false ? res.data && typeof res.data === "object" : Array.isArray(res.data);

                if (url.split("/").pop() === cfg.file && op === (cfg.op || "getAll") && okShape) {
                    const mine = ++latest;
                    Promise.resolve(cfg.build(res.data))
                        .then((cards) => { if (mine === latest) render(cards || []); })
                        .catch(() => { /* keep the page working without the summary */ });
                }
            } catch (e) { /* ignore */ }
            return res;
        });
    }

    /* ---------------- table search ---------------- */

    const wireSearch = (input) => {
        const body = document.getElementById(input.dataset.filterBody);
        if (!body) return;

        let timer = null;
        const apply = () => {
            const q = input.value.trim().toLowerCase();
            [...body.rows].forEach((tr) => {
                // "Loading..." and "No records" rows span the whole table: leave them alone.
                if (tr.cells.length === 1 && tr.cells[0].colSpan > 1) { tr.hidden = false; return; }
                tr.hidden = q !== "" && !tr.textContent.toLowerCase().includes(q);
            });
        };

        input.addEventListener("input", apply);
        new MutationObserver(() => { clearTimeout(timer); timer = setTimeout(apply, 0); }).observe(body, { childList: true });
    };

    const start = () => document.querySelectorAll("input[data-filter-body]").forEach(wireSearch);
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
