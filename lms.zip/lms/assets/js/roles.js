const baseApiUrl = "api"; // relative to the page, so it works from any folder

const escapeHtml = (value) => String(value ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

// What each role means in this library.
const ROLE_INFO = {
    "technical services librarian": "Runs the system. Full access to every page, including users, roles and loan rules.",
    "library staff": "Assists the librarian with desk work: borrowing, returns, reservations, reports and viewing stock.",
    "student assistant": "Temporary helper (SA). Same desk access as Library Staff. Needs the Technical Services Librarian's approval, who can deactivate or activate the account at any time.",
    student: "Uses the borrower portal to browse, borrow, reserve and view their own loans. Follows the student loan rules.",
    faculty: "Uses the borrower portal like a student, but follows the faculty loan rules.",
    dean: "Uses the borrower portal and follows the faculty loan rules."
};

document.addEventListener("DOMContentLoaded", () => {
    loadRoles();
});

// live.js calls loadRoles() when another device changes data.
const loadRoles = async () => {
    const tbody = document.getElementById("roleTableBody");

    try {
        const response = await axios.get(`${baseApiUrl}/roles.php`, { params: { operation: "getAll" } });
        const roles = response.data;

        if (!Array.isArray(roles) || roles.length === 0) {
            tbody.innerHTML = `<tr><td colspan="3" class="text-center text-muted">No roles found.</td></tr>`;
            return;
        }

        tbody.innerHTML = roles.map((role) => {
            const access = ROLE_INFO[String(role.role_name).trim().toLowerCase()] || "Borrower account.";

            return `
                <tr>
                    <td class="fw-semibold">${escapeHtml(role.role_name)}</td>
                    <td>${escapeHtml(access)}</td>
                    <td>${escapeHtml(role.user_count)}</td>
                </tr>`;
        }).join("");
    } catch (error) {
        tbody.innerHTML = `<tr><td colspan="3" class="text-center text-danger">Failed to load roles.</td></tr>`;
        showAlert("Failed to load roles.", "danger");
    }
};

const showAlert = (msg, type) => {
    const box = document.getElementById("alert-box");
    box.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert"><span></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
    box.querySelector("span").textContent = msg; // plain text, never HTML
};
