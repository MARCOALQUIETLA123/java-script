// Adds a Show / Hide button to every password box on the page.
// The input keeps its id and value, so the page's own scripts are unaffected.
(() => {
    const wire = () => {
        document.querySelectorAll('input[type="password"]').forEach((input) => {
            if (input.dataset.toggleReady) return;
            input.dataset.toggleReady = "1";

            const group = document.createElement("div");
            group.className = "input-group";
            input.parentNode.insertBefore(group, input);
            group.appendChild(input);

            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "btn btn-outline-secondary";
            btn.textContent = "Show";
            btn.setAttribute("aria-pressed", "false");
            btn.setAttribute("aria-label", "Show password");
            btn.addEventListener("click", () => {
                const reveal = input.type === "password";
                input.type = reveal ? "text" : "password";
                btn.textContent = reveal ? "Hide" : "Show";
                btn.setAttribute("aria-pressed", String(reveal));
                btn.setAttribute("aria-label", reveal ? "Hide password" : "Show password");
            });
            group.appendChild(btn);

            // Always go back to hidden when the form is cleared or submitted.
            const form = input.closest("form");
            const hide = () => {
                input.type = "password";
                btn.textContent = "Show";
                btn.setAttribute("aria-pressed", "false");
                btn.setAttribute("aria-label", "Show password");
            };
            if (form) {
                form.addEventListener("reset", hide);
                form.addEventListener("submit", hide);
            }
            document.addEventListener("click", (e) => {
                // Clear / Save buttons on pages that don't use <form> also re-hide it.
                if (e.target.closest && e.target.closest("#btn-clear, #btn-save")) hide();
            });
        });
    };

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", wire);
    else wire();
})();
