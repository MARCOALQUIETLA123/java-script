const baseApiUrl = "api"; // relative to the page, so it works from any folder
const holdsApi = `${baseApiUrl}/account_holds.php`;

const $ = (id) => document.getElementById(id);

const escapeHtml = (value) => String(value ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const peso = (n) => "₱" + Number(n || 0).toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const plural = (n, one, many) => `${n} ${Number(n) === 1 ? one : (many || one + "s")}`;

let rows = [];
let everyone = [];

// Ready-made messages. {name} becomes the borrower's first name.
const TEMPLATES = [
    { id: "", label: "Write my own", subject: "", body: "" },
    {
        id: "overdue", label: "Overdue book reminder", subject: "Overdue book reminder",
        body: "Hello {name},\n\nYou have a book that is overdue. A fine is added for every day it stays overdue, and your account can't reserve or borrow until it is returned and the fine is paid.\n\nPlease bring the book to the library desk as soon as you can. A fine of ₱60 or less is paid at the library desk; a fine above ₱60 is paid at Assessment with the receipt the library gives you."
    },
    {
        id: "visit", label: "Please visit the library", subject: "Please come to the library",
        body: "Hello {name},\n\nPlease come to the library desk and see the librarian about your account.\n\nThank you."
    },
    {
        id: "lost", label: "Lost or missing book", subject: "Missing book: please come in person",
        body: "Hello {name},\n\nOur records show a book that has not been returned. If it is lost, missing or damaged, you must come to the library in person to settle it. You can pay the full price of the book plus the processing fee, or bring a replacement copy. If a newer edition exists, the replacement must be the newest edition.\n\nPlease visit the library desk as soon as possible to avoid your account being blacklisted."
    },
    {
        id: "cleared", label: "Account cleared", subject: "Thank you: your account is clear",
        body: "Hello {name},\n\nThank you for returning your book and settling your fine. Your account is clear and you can reserve books again."
    }
];

const showAlert = (msg, type) => {
    const box = $("alert-box");
    box.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert"><span></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
    box.querySelector("span").textContent = msg; // plain text, never HTML
};

const apiPost = async (operation, payload) => {
    const fd = new FormData();
    fd.append("operation", operation);
    fd.append("json", JSON.stringify(payload));
    const res = await axios.post(holdsApi, fd);
    return res.data;
};

document.addEventListener("DOMContentLoaded", () => {
    loadHolds();

    $("btn-new-message").addEventListener("click", () => openMessage(null));
    $("btn-record-payment").addEventListener("click", () => openPayment({}));
    $("btn-save-payment").addEventListener("click", savePayment);
    $("pay-student").addEventListener("change", () => refreshBalance());
    $("btn-print-pay-receipt").addEventListener("click", printPayReceipt);
    $("proof-pay").addEventListener("click", () => {
        const p = proofRows.find((x) => Number(x.message_id) === proofMessageId);
        bootstrap.Modal.getOrCreateInstance($("proofModal")).hide();
        if (p) openPayment({ studentId: Number(p.student_id), messageId: Number(p.message_id), amount: p.proof_amount, reference: p.proof_ref, sent: p.created_at });
    });
    $("btn-send-message").addEventListener("click", sendMessage);
    $("msg-student").addEventListener("change", () => loadHistory($("msg-student").value));
    $("msg-template").addEventListener("change", applyTemplate);

    $("proofs-list").addEventListener("click", async (e) => {
        const btn = e.target.closest("button[data-action]");
        if (!btn) return;
        const id = Number(btn.dataset.id);
        if (btn.dataset.action === "reply") openMessage(id);
        if (btn.dataset.action === "pay-proof") {
            const p = proofRows.find((x) => Number(x.message_id) === Number(btn.dataset.message));
            if (p) openPayment({ studentId: id, messageId: Number(p.message_id), amount: p.proof_amount, reference: p.proof_ref, sent: p.created_at });
        }
        if (btn.dataset.action === "lift") lift(id);
        if (btn.dataset.action === "seen") {
            try { await apiPost("markSeen", { message_id: Number(btn.dataset.message) }); loadHolds(); } catch (err) { showAlert("Could not mark it as seen.", "danger"); }
        }
    });

    // A proof listed in a borrower's message history opens in the same viewer.
    $("msg-history").addEventListener("click", (e) => {
        const btn = e.target.closest("button[data-action='view-proof']");
        if (!btn) return;
        bootstrap.Modal.getOrCreateInstance($("messageModal")).hide();
        openProofs(Number(btn.dataset.id), Number(btn.dataset.message));
    });

    $("table-body").addEventListener("click", (e) => {
        const btn = e.target.closest("button[data-action]");
        if (!btn) return;
        const id = Number(btn.dataset.id);
        if (btn.dataset.action === "message") openMessage(id);
        if (btn.dataset.action === "pay") openPayment({ studentId: id });
        if (btn.dataset.action === "proof") openProofs(id);
        if (btn.dataset.action === "blacklist") blacklist(id);
        if (btn.dataset.action === "lift") lift(id);
    });
});

// live.js calls this when another device changes data.
const loadHolds = async () => {
    try {
        const res = await axios.get(holdsApi, { params: { operation: "getAll" } });
        rows = Array.isArray(res.data.borrowers) ? res.data.borrowers : [];
        $("limit-days").textContent = res.data.blacklist_after ?? 30;
        render();
        loadProofs();
        loadPayments();
    } catch (error) {
        $("table-body").innerHTML = '<tr><td colspan="6" class="text-center text-danger">Could not load the list.</td></tr>';
    }
};

const render = () => {
    const hold = rows.filter((r) => r.state === "overdue").length;
    const black = rows.filter((r) => r.state === "blacklisted").length;
    const books = rows.reduce((s, r) => s + r.overdue_count, 0);
    const fines = rows.reduce((s, r) => s + Number(r.fine_due ?? r.fine_total), 0);

    $("sum-hold").textContent = hold;
    $("sum-black").textContent = black;
    $("sum-books").textContent = books;
    $("sum-fines").textContent = peso(fines);
    $("sum-fines-note").textContent = books ? "grows every day, after payments" : "nothing overdue";
    $("kpi-black").classList.toggle("is-alert", black > 0);

    const body = $("table-body");
    if (rows.length === 0) {
        body.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No borrower is overdue or blacklisted.</td></tr>';
        return;
    }

    body.innerHTML = rows.map((r) => {
        const books = r.overdue.map((o) =>
            `<div class="small">${escapeHtml(o.title)} <span class="text-muted">(${o.days_overdue} ${o.days_overdue === 1 ? "day" : "days"} late)</span></div>`).join("")
            || '<span class="text-muted small">None overdue</span>';

        const status = r.state === "blacklisted"
            ? `<span class="badge bg-danger">Blacklisted</span>${r.blacklist_reason ? `<div class="small text-muted mt-1">${escapeHtml(r.blacklist_reason)}</div>` : ""}`
            : `<span class="badge bg-warning text-dark">Overdue</span>${r.days_until_blacklist !== null ? `<div class="small text-muted mt-1">Blacklisted in ${plural(r.days_until_blacklist, "day")}</div>` : ""}`;

        const last = r.last_message_at ? escapeHtml(String(r.last_message_at).slice(0, 16)) : '<span class="text-muted">Never</span>';

        return `
            <tr>
                <td class="fw-semibold">${escapeHtml(r.name)} <span class="badge bg-secondary">${escapeHtml(r.borrower_type)}</span></td>
                <td>${status}</td>
                <td>${books}</td>
                <td class="text-nowrap">${Number(r.fine_due ?? r.fine_total) > 0 ? `<span class="text-danger fw-semibold">${peso(r.fine_due ?? r.fine_total)}</span>` : "—"}${Number(r.credit) > 0 ? `<div class="small text-success">${peso(r.credit)} already paid</div>` : ""}</td>
                <td class="text-nowrap small">${last}${r.unread ? ` <span class="badge bg-secondary">${r.unread} unread</span>` : ""}</td>
                <td class="no-print text-nowrap">
                    ${r.proofs_total ? `<button class="btn ${r.proofs_new ? "btn-warning" : "btn-outline-secondary"} btn-sm me-1" data-action="proof" data-id="${r.student_id}">Proof of payment${r.proofs_new ? ` <span class="badge bg-danger">${r.proofs_new} new</span>` : ""}</button>` : ""}
                    <button class="btn btn-outline-success btn-sm me-1" data-action="pay" data-id="${r.student_id}">Record payment</button>
                    <button class="btn btn-success btn-sm me-1" data-action="message" data-id="${r.student_id}">Message</button>
                    ${r.state === "blacklisted"
                        ? `<button class="btn btn-outline-secondary btn-sm admin-only" data-action="lift" data-id="${r.student_id}">Lift blacklist</button>`
                        : `<button class="btn btn-outline-danger btn-sm admin-only" data-action="blacklist" data-id="${r.student_id}">Blacklist</button>`}
                </td>
            </tr>`;
    }).join("");
};

/* ---------------- Messages ---------------- */

const loadEveryone = async () => {
    if (everyone.length) return;
    try {
        const res = await axios.get(holdsApi, { params: { operation: "getBorrowers" } });
        everyone = Array.isArray(res.data) ? res.data : [];
    } catch (error) { everyone = []; }
};

const openMessage = async (studentId) => {
    await loadEveryone();

    $("msg-student").innerHTML = '<option value="">Choose a borrower...</option>' +
        everyone.map((p) => `<option value="${p.student_id}">${escapeHtml(p.name)} (${escapeHtml(p.borrower_type)})</option>`).join("");
    $("msg-template").innerHTML = TEMPLATES.map((t) => `<option value="${t.id}">${escapeHtml(t.label)}</option>`).join("");

    $("msg-student").value = studentId ? String(studentId) : "";
    $("msg-subject").value = "";
    $("msg-body").value = "";

    // An overdue borrower gets the overdue reminder ready to edit.
    const person = rows.find((r) => r.student_id === studentId);
    if (person) {
        $("msg-template").value = person.state === "blacklisted" ? "lost" : "overdue";
        applyTemplate();
    }

    loadHistory($("msg-student").value);
    bootstrap.Modal.getOrCreateInstance($("messageModal")).show();
};

const firstNameOf = () => {
    const opt = $("msg-student").selectedOptions[0];
    return opt && opt.value ? opt.textContent.split(" (")[0].split(" ")[0] : "";
};

const applyTemplate = () => {
    const t = TEMPLATES.find((x) => x.id === $("msg-template").value);
    if (!t || !t.id) return;
    $("msg-subject").value = t.subject;
    $("msg-body").value = t.body.replace("{name}", firstNameOf() || "there");
};

const loadHistory = async (studentId) => {
    const box = $("msg-history");
    if (!studentId) { box.textContent = "Choose a borrower."; return; }

    try {
        const res = await axios.get(holdsApi, { params: { operation: "getMessages", student_id: studentId } });
        const list = Array.isArray(res.data) ? res.data : [];
        box.innerHTML = list.length === 0 ? "Nothing sent yet." : list.slice(0, 10).map((m) => {
            const proof = Number(m.from_borrower) && Number(m.has_file);
            return `
            <div class="border-bottom py-1 d-flex flex-wrap justify-content-between align-items-center gap-2">
                <div>
                    <strong>${escapeHtml(m.subject)}</strong>
                    <span class="text-muted">· ${Number(m.from_borrower) ? "from the borrower" : escapeHtml(m.sender)} · ${escapeHtml(String(m.created_at).slice(0, 16))} · ${m.read_at ? (Number(m.from_borrower) ? "seen" : "read") : (Number(m.from_borrower) ? "new" : "not read yet")}</span>
                    ${proof ? `<div class="text-dark">${m.proof_amount !== null ? peso(m.proof_amount) : "Amount not given"}${m.proof_ref ? ` · Ref. ${escapeHtml(m.proof_ref)}` : ""}</div>` : ""}
                </div>
                ${proof ? `<button type="button" class="btn btn-outline-success btn-sm" data-action="view-proof" data-id="${Number(studentId)}" data-message="${Number(m.message_id)}">View proof</button>` : ""}
            </div>`;
        }).join("");
    } catch (error) { box.textContent = "Could not load earlier messages."; }
};

const sendMessage = async () => {
    const student_id = Number($("msg-student").value);
    const subject = $("msg-subject").value.trim();
    const body = $("msg-body").value.trim();

    if (!student_id) { showAlert("Choose who the message is for.", "danger"); return; }
    if (!subject || !body) { showAlert("Write a subject and a message.", "danger"); return; }

    const btn = $("btn-send-message");
    btn.disabled = true;
    try {
        const result = await apiPost("sendMessage", { student_id, subject, body });
        if (result.status === "success") {
            bootstrap.Modal.getOrCreateInstance($("messageModal")).hide();
            showAlert(result.message, "success");
            loadHolds();
        } else {
            showAlert(result.message, "danger");
        }
    } catch (error) {
        showAlert("Could not send the message.", "danger");
    } finally {
        btn.disabled = false;
    }
};

/* ---------------- Proof of payment ---------------- */

let proofStudentId = null;
let proofMessageId = 0;

const proofFileUrl = (id) => `${baseApiUrl}/proof_file.php?operation=view&id=${Number(id)}`;

// All proofs a borrower sent, or just one of them when messageId is given.
const openProofs = async (studentId, messageId = 0) => {
    proofStudentId = studentId;
    proofMessageId = messageId;
    const person = rows.find((r) => r.student_id === studentId);
    const known = proofRows.find((p) => Number(p.student_id) === studentId);
    const name = person ? person.name : (known ? known.name : "");
    const blacklisted = person ? person.state === "blacklisted" : !!(known && Number(known.blacklisted));

    $("proof-title").textContent = `Proof of payment${name ? " - " + name : ""}`;
    $("proof-list").textContent = "Loading...";
    // Only the Technical Services Librarian can lift a blacklist (the server checks this too).
    $("proof-lift").classList.toggle("d-none", !blacklisted);
    const thisProof = messageId ? proofRows.find((x) => Number(x.message_id) === messageId) : null;
    $("proof-pay").classList.toggle("d-none", !(thisProof && (thisProof.recorded_amount === null || thisProof.recorded_amount === undefined)));
    bootstrap.Modal.getOrCreateInstance($("proofModal")).show();

    try {
        const res = await axios.get(holdsApi, { params: { operation: "getMessages", student_id: studentId } });
        let proofs = (Array.isArray(res.data) ? res.data : []).filter((m) => Number(m.from_borrower) === 1 && Number(m.has_file));
        if (messageId) proofs = proofs.filter((m) => Number(m.message_id) === messageId);

        $("proof-list").innerHTML = proofs.length === 0 ? "No proof has been sent." : proofs.map((m) => {
            const isPdf = m.attachment_mime === "application/pdf";
            const preview = isPdf
                ? `<a class="btn btn-outline-secondary btn-sm" href="${proofFileUrl(m.message_id)}" target="_blank" rel="noopener">Open PDF</a>`
                : `<a href="${proofFileUrl(m.message_id)}" target="_blank" rel="noopener" title="Open full size">
                       <img src="${proofFileUrl(m.message_id)}" alt="Receipt" class="img-thumbnail" style="max-height: 260px; max-width: 100%;"></a>`;

            return `
            <div class="card mb-3 ${m.read_at ? "" : "border-warning"}">
                <div class="card-body">
                    <div class="d-flex flex-wrap justify-content-between gap-2 mb-2">
                        <div>
                            <strong>${m.proof_amount !== null ? peso(m.proof_amount) : "Amount not given"}</strong>
                            ${m.proof_ref ? `<span class="text-muted">· Ref. ${escapeHtml(m.proof_ref)}</span>` : ""}
                            ${m.read_at ? "" : '<span class="badge bg-warning text-dark ms-1">New</span>'}
                        </div>
                        <div class="text-muted">${escapeHtml(String(m.created_at).slice(0, 16))}</div>
                    </div>
                    <div style="white-space: pre-line;" class="mb-2">${escapeHtml(m.body)}</div>
                    ${preview}
                    ${m.attachment_name ? `<div class="text-muted mt-1">${escapeHtml(m.attachment_name)}</div>` : ""}
                </div>
            </div>`;
        }).join("");

        // Looking at them counts as seen.
        const fresh = proofs.filter((m) => !m.read_at);
        if (fresh.length) {
            try {
                for (const m of fresh) await apiPost("markSeen", { message_id: Number(m.message_id) });
                loadHolds();
            } catch (e) { /* stays "new" */ }
        }
    } catch (error) {
        $("proof-list").textContent = "Could not load the proof of payment.";
    }
};

/* ---------------- Proofs inbox (every borrower, not only overdue ones) ---------------- */

let proofRows = [];

const loadProofs = async () => {
    const list = $("proofs-list");
    try {
        const res = await axios.get(holdsApi, { params: { operation: "getProofs" } });
        if (!Array.isArray(res.data)) throw new Error("bad response");
        proofRows = res.data;
    } catch (error) {
        list.innerHTML = '<div class="alert alert-danger mb-0">Could not load the proofs of payment.</div>';
        return;
    }

    const fresh = proofRows.filter((p) => !p.read_at).length;
    const badge = $("proofs-new-badge");
    badge.textContent = `${fresh} new`;
    badge.classList.toggle("d-none", fresh === 0);

    if (proofRows.length === 0) {
        list.innerHTML = '<div class="text-center text-muted py-3">No borrower has sent a proof of payment yet.</div>';
        return;
    }

    // Laid out like the message the borrower sees, plus the receipt itself.
    list.innerHTML = proofRows.map((p) => {
        const url = proofFileUrl(p.message_id);
        const isPdf = p.attachment_mime === "application/pdf";
        const file = isPdf
            ? `<a class="btn btn-outline-secondary btn-sm" href="${url}" target="_blank" rel="noopener">Open attached PDF${p.attachment_name ? ` (${escapeHtml(p.attachment_name)})` : ""}</a>`
            : `<a href="${url}" target="_blank" rel="noopener" title="Open full size">
                   <img src="${url}" alt="Receipt" class="img-thumbnail" style="max-height: 280px; max-width: 100%;" loading="lazy"></a>
               <div class="mt-1"><a href="${url}" target="_blank" rel="noopener">View attached file${p.attachment_name ? ` (${escapeHtml(p.attachment_name)})` : ""}</a></div>`;

        return `
        <div class="card mb-2 ${p.read_at ? "border-info" : "border-warning"}">
            <div class="card-body py-2">
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <div>
                        <span class="badge bg-info text-dark me-1">Proof of payment</span>
                        <strong>${escapeHtml(p.name)}</strong>
                        <span class="badge bg-secondary">${escapeHtml(p.borrower_type)}</span>
                        ${Number(p.blacklisted) ? '<span class="badge bg-danger">Blacklisted</span>' : ""}
                        ${p.read_at ? '<span class="badge bg-success ms-1">Seen</span>' : '<span class="badge bg-warning text-dark ms-1">New</span>'}
                    </div>
                    <div class="small text-muted">${escapeHtml(String(p.created_at).slice(0, 16))}</div>
                </div>
                <div class="mt-2" style="white-space: pre-line;">${escapeHtml(p.body)}</div>
                <div class="mt-2">${file}</div>
                <div class="mt-2 d-flex flex-wrap gap-2 no-print">
                    ${p.recorded_amount !== null && p.recorded_amount !== undefined
                        ? `<span class="badge bg-success align-self-center">Payment recorded: ${peso(p.recorded_amount)} · Receipt ${escapeHtml(p.recorded_receipt || "")}</span>`
                        : `<button class="btn btn-success btn-sm" data-action="pay-proof" data-id="${Number(p.student_id)}" data-message="${Number(p.message_id)}">Record payment</button>`}
                    <button class="btn btn-outline-success btn-sm" data-action="reply" data-id="${Number(p.student_id)}">Reply to borrower</button>
                    ${Number(p.blacklisted) ? `<button class="btn btn-success btn-sm admin-only" data-action="lift" data-id="${Number(p.student_id)}">Lift blacklist</button>` : ""}
                    ${p.read_at ? "" : `<button class="btn btn-outline-secondary btn-sm" data-action="seen" data-id="${Number(p.student_id)}" data-message="${Number(p.message_id)}">Mark as seen</button>`}
                </div>
            </div>
        </div>`;
    }).join("");
};


/* ---------------- Fine payments (collected at the library desk) ---------------- */

const SOURCE_LABEL = { desk: "At the desk", proof: "From a proof of payment", return: "When the book was returned" };

const loadPayments = async () => {
    const body = $("payments-body");
    try {
        const res = await axios.get(holdsApi, { params: { operation: "getPayments" } });
        const t = res.data.totals || { today: 0, month: 0, total: 0 };
        $("pay-sum-today").textContent = peso(t.today);
        $("pay-sum-month").textContent = peso(t.month);
        $("pay-sum-total").textContent = peso(t.total);

        const list = Array.isArray(res.data.rows) ? res.data.rows : [];
        body.innerHTML = list.length === 0
            ? '<tr><td colspan="6" class="text-center text-muted">No fine payment has been recorded yet.</td></tr>'
            : list.map((p) => `
                <tr>
                    <td class="text-nowrap small">${escapeHtml(String(p.paid_at).slice(0, 16))}</td>
                    <td class="fw-semibold">${escapeHtml(p.name)}</td>
                    <td class="text-nowrap">${peso(p.amount)}</td>
                    <td class="small">${escapeHtml(p.receipt_no || "—")}${p.reference ? `<div class="text-muted">Ref. ${escapeHtml(p.reference)}</div>` : ""}</td>
                    <td class="small">${escapeHtml(SOURCE_LABEL[p.kind] || p.kind)}${p.note ? `<div class="text-muted">${escapeHtml(p.note)}</div>` : ""}</td>
                    <td class="small">${escapeHtml(p.received_by || "—")}</td>
                </tr>`).join("");
    } catch (error) {
        body.innerHTML = '<tr><td colspan="6" class="text-center text-danger">Could not load the payments.</td></tr>';
    }
};

let payContext = { messageId: 0 };

const refreshBalance = async () => {
    const box = $("pay-balance");
    const id = Number($("pay-student").value);
    if (!id) { box.textContent = "Choose a borrower."; return; }

    box.textContent = "Loading...";
    try {
        const res = await axios.get(holdsApi, { params: { operation: "getBalance", student_id: id } });
        const lines = Array.isArray(res.data.lines) ? res.data.lines : [];
        box.innerHTML = `<div class="fw-semibold text-dark">${Number(res.data.total) > 0 ? "Owes " + peso(res.data.total) + " right now" : "Owes nothing right now"}</div>`
            + lines.map((l) => `<div>${escapeHtml(l.label)}${Number(l.amount) !== 0 ? ` <span class="float-end">${Number(l.amount) < 0 ? "−" : ""}${peso(Math.abs(l.amount))}</span>` : ""}</div>`).join("")
            + (Number(res.data.credit) > 0 ? `<div class="text-success">Paid in advance so far: ${peso(res.data.credit)}</div>` : "");
    } catch (error) { box.textContent = "Could not load what this borrower owes."; }

    // Only a blacklisted borrower can have the blacklist lifted.
    const person = rows.find((r) => r.student_id === id);
    $("pay-lift-wrap").classList.toggle("d-none", !(person && person.state === "blacklisted"));
    $("pay-lift").checked = false;
};

const openPayment = async ({ studentId = null, messageId = 0, amount = null, reference = "", sent = "" }) => {
    await loadEveryone();
    payContext = { messageId };

    $("pay-student").innerHTML = '<option value="">Choose a borrower...</option>' +
        everyone.map((p) => `<option value="${p.student_id}">${escapeHtml(p.name)} (${escapeHtml(p.borrower_type)})</option>`).join("");
    $("pay-student").value = studentId ? String(studentId) : "";
    $("pay-student").disabled = !!messageId;   // a proof belongs to the borrower who sent it

    $("pay-amount").value = amount !== null && amount !== undefined && Number(amount) > 0 ? Number(amount).toFixed(2) : "";
    $("pay-ref").value = reference || "";
    $("pay-note").value = "";

    const info = $("pay-proof-info");
    info.classList.toggle("d-none", !messageId);
    if (messageId) info.textContent = `From the proof of payment sent ${String(sent).slice(0, 16)}. Check the amount and reference against the receipt first.`;

    await refreshBalance();
    bootstrap.Modal.getOrCreateInstance($("payModal")).show();
};

const savePayment = async () => {
    const student_id = Number($("pay-student").value);
    const amount = Number($("pay-amount").value);

    if (!student_id) { showAlert("Choose the borrower.", "danger"); return; }
    if (!(amount > 0)) { showAlert("Enter the amount received.", "danger"); return; }

    const btn = $("btn-save-payment");
    btn.disabled = true;
    try {
        const result = await apiPost("recordPayment", {
            student_id, amount,
            message_id: payContext.messageId || 0,
            reference: $("pay-ref").value.trim(),
            note: $("pay-note").value.trim(),
            lift: $("pay-lift").checked
        });
        if (result.status === "success") {
            const person = everyone.find((p) => Number(p.student_id) === student_id);
            bootstrap.Modal.getOrCreateInstance($("payModal")).hide();
            showAlert(result.message, "success");
            showPayReceipt({ name: person ? person.name : "", amount, receipt: result.receipt_no, reference: $("pay-ref").value.trim(), balance: result.balance });
            loadHolds();
        } else {
            showAlert(result.message, "danger");
        }
    } catch (error) {
        showAlert("Could not record the payment.", "danger");
    } finally {
        btn.disabled = false;
    }
};

const showPayReceipt = ({ name, amount, receipt, reference, balance }) => {
    const now = new Date();
    $("pay-receipt-body").innerHTML = `
        <div class="receipt" style="font-size: 14px;">
            <h2 style="text-align:center; font-size: 18px; margin: 0 0 2px;">Library Management System</h2>
            <div style="text-align:center; margin-bottom: 8px;">Official receipt: overdue fine</div>
            <div style="border-top: 1px dashed #000; border-bottom: 1px dashed #000; padding: 6px 0; margin-bottom: 8px;">
                <div><strong>Receipt no.:</strong> ${escapeHtml(receipt)}</div>
                <div><strong>Date:</strong> ${escapeHtml(now.toLocaleString("en-PH"))}</div>
                <div><strong>Borrower:</strong> ${escapeHtml(name)}</div>
                ${reference ? `<div><strong>Reference no.:</strong> ${escapeHtml(reference)}</div>` : ""}
            </div>
            <div style="display:flex; justify-content:space-between; font-size: 16px; font-weight: bold;"><span>AMOUNT RECEIVED</span><span>${peso(amount)}</span></div>
            <div style="text-align:center; font-weight:bold; border: 1px solid #000; padding: 4px; margin: 8px 0;">PAID: received at the library desk</div>
            <div style="font-size: 12px;">${Number(balance) > 0 ? `Balance still owed: ${peso(balance)}` : "Nothing left to pay right now."} A fine on a book that is still overdue keeps growing until it is returned.</div>
        </div>`;
    bootstrap.Modal.getOrCreateInstance($("payReceiptModal")).show();
};

const printPayReceipt = () => {
    const frame = document.createElement("iframe");
    frame.style.cssText = "position: fixed; width: 0; height: 0; border: 0;";
    document.body.appendChild(frame);
    const doc = frame.contentWindow.document;
    doc.open();
    doc.write(`<!DOCTYPE html><html><head><title>Receipt</title><style>body { font-family: Arial, Helvetica, sans-serif; margin: 16px; } .receipt { max-width: 420px; margin: 0 auto; }</style></head><body>${$("pay-receipt-body").innerHTML}</body></html>`);
    doc.close();
    frame.contentWindow.focus();
    frame.contentWindow.print();
    setTimeout(() => frame.remove(), 1000);
};

/* ---------------- Blacklist (Technical Services Librarian only) ---------------- */

const blacklist = async (id) => {
    const person = rows.find((r) => r.student_id === id);
    const reason = await lmsPrompt(`Blacklist ${person ? person.name : "this borrower"}? They won't be able to reserve or borrow until you lift it. Add a reason (optional).`, {
        title: "Blacklist this account",
        confirmText: "Blacklist",
        placeholder: "e.g. Did not return the book after several reminders",
        danger: true
    });
    if (reason === null) return;

    try {
        const result = await apiPost("blacklist", { student_id: id, reason });
        showAlert(result.message, result.status === "success" ? "success" : "danger");
        loadHolds();
    } catch (error) {
        showAlert("Could not blacklist the account.", "danger");
    }
};

const lift = async (id) => {
    const person = rows.find((r) => r.student_id === id);
    const note = await lmsPrompt(`Lift the blacklist on ${person ? person.name : "this borrower"}? Do this once the books are returned and everything is paid. Add a note for them (optional).`, {
        title: "Lift the blacklist",
        confirmText: "Lift blacklist",
        placeholder: "e.g. Fine paid on the library desk"
    });
    if (note === null) return;

    try {
        const result = await apiPost("lift", { student_id: id, note });
        showAlert(result.message, result.status === "success" ? "success" : "danger");
        loadHolds();
    } catch (error) {
        showAlert("Could not lift the blacklist.", "danger");
    }
};
