const baseApiUrl = "api"; // relative to the page, so it works from any folder

document.addEventListener("DOMContentLoaded", () => {
    loadRecords();
    document.getElementById("btn-save").addEventListener("click", saveRecord);
    document.getElementById("btn-clear").addEventListener("click", clearForm);
});

const loadRecords = async () => {
    try {
        const response = await axios.get(`${baseApiUrl}/loan_policy.php`, {
            params: { operation: "getAll" }
        });

        const tbody = document.getElementById("table-body");
        tbody.innerHTML = "";
        window._loanPolicyData = response.data;

        if (response.data.length === 0) {
            tbody.innerHTML = `<tr><td colspan="4" class="text-center text-muted">No records found.</td></tr>`;
            return;
        }

        response.data.forEach((row, index) => {
            tbody.innerHTML += `
                <tr>
                    <td>${index + 1}</td>
                    <td>${row.policy_name}</td>
                    <td>${row.borrow_days}</td>
                    <td>
                        <button class="btn btn-success btn-sm me-1" onclick="editRecord(${row.policy_id})">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deleteRecord(${row.policy_id})">Delete</button>
                    </td>
                </tr>`;
        });
    } catch (error) {
        const reason = error.response && error.response.data && error.response.data.message;
        showAlert(reason ? `Failed to load loan policies. ${String(reason).replace(/</g, "&lt;")}` : "Failed to load loan policies.", "danger");
    }
};

const saveRecord = async () => {
    const editingId = document.getElementById("editing-id").value.trim();
    const policy_name = document.getElementById("policy_name").value.trim();
    const borrow_days = document.getElementById("borrow_days").value.trim();

    if (!policy_name || borrow_days === "") {
        showAlert("All fields are required.", "danger");
        return;
    }

    if (policy_name.length < 2 || /^\d+$/.test(policy_name)) {
        showAlert("Please enter a valid policy name.", "danger");
        return;
    }

    if (!Number.isInteger(Number(borrow_days)) || Number(borrow_days) < 1) {
        showAlert("Borrow days must be a whole number of at least 1.", "danger");
        return;
    }

    const jsonData = {
        policy_name,
        borrow_days
    };

    let operation = "add";

    if (editingId !== "") {
        jsonData.policy_id = editingId;
        operation = "update";
    }

    try {
        const formData = new FormData();
        formData.append("operation", operation);
        formData.append("json", JSON.stringify(jsonData));

        const response = await axios({
            url: `${baseApiUrl}/loan_policy.php`,
            method: "POST",
            data: formData
        });

        if (response.data.status === "success") {
            showAlert(response.data.message, "success");
            clearForm();
            loadRecords();
        } else {
            showAlert(response.data.message, "danger");
        }
    } catch (error) {
        showAlert("Failed to save loan policy.", "danger");
    }
};

const editRecord = id => {
    const row = window._loanPolicyData.find(r => r.policy_id == id);
    if (!row) return;

    document.getElementById("editing-id").value = id;
    document.getElementById("policy_name").value = row.policy_name;
    document.getElementById("borrow_days").value = row.borrow_days;

    document.getElementById("btn-save").innerText = "Update";
    document.getElementById("form-title").innerText = "Edit Loan Policy";
    window.scrollTo(0, 0);
};

const deleteRecord = async id => {
    if (!confirm("Are you sure you want to delete this loan policy?")) return;

    try {
        const formData = new FormData();
        formData.append("operation", "delete");
        formData.append("json", JSON.stringify({ policy_id: id }));

        const response = await axios({
            url: `${baseApiUrl}/loan_policy.php`,
            method: "POST",
            data: formData
        });

        if (response.data.status === "success") {
            showAlert(response.data.message, "success");
            loadRecords();
        } else {
            showAlert(response.data.message, "danger");
        }
    } catch (error) {
        showAlert("Failed to delete loan policy.", "danger");
    }
};

const clearForm = () => {
    document.getElementById("editing-id").value = "";
    document.getElementById("policy_name").value = "";
    document.getElementById("borrow_days").value = "";

    document.getElementById("btn-save").innerText = "Save";
    document.getElementById("form-title").innerText = "Add Loan Policy";
    document.getElementById("alert-box").innerHTML = "";
};

const showAlert = (msg, type) => {
    document.getElementById("alert-box").innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${msg}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>`;
};

window.editRecord = editRecord;
window.deleteRecord = deleteRecord;