const baseApiUrl = "api";
const portal = `${baseApiUrl}/portal.php`;

let books = [];
let loanRows = [];   // one row per borrowed copy, as sent by the server
let resRows = [];    // one row per reservation
let reserveBookId = null;

const openLoans = new Set(); // expanded books, kept across refreshes
const openRes = new Set();

const $ = (id) => document.getElementById(id);

const escapeHtml = (value) => String(value ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const showAlert = (msg, type) => {
    const box = $("alert-box");
    box.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert"><span></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
    box.querySelector("span").textContent = msg; // plain text, never HTML
    window.scrollTo(0, 0);
};

const apiError = (error, fallback) =>
    (error.response && error.response.data && error.response.data.message) || fallback;

const post = async (operation, payload) => {
    const fd = new FormData();
    fd.append("operation", operation);
    fd.append("json", JSON.stringify(payload));
    const res = await axios.post(portal, fd);
    return res.data;
};

const isoDate = (days) => {
    const d = new Date();
    d.setDate(d.getDate() + days);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

const val = (id) => $(id).value.trim();
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

document.addEventListener("DOMContentLoaded", () => {
    loadAll();

    const msgTab = $("tab-msgs-btn");
    if (msgTab) msgTab.addEventListener("shown.bs.tab", () => { loadMessages().then(markMessagesRead); });
    bindFilters();
    bindToggle("loans-list", openLoans);
    bindToggle("res-list", openRes);
    const rs = $("rs-confirm");
    if (rs) rs.addEventListener("click", confirmReserve);
});

const loadAll = () => Promise.allSettled([loadBooks(), loadLoans(), loadReservations(), loadMessages()]);

/* ---------- filters ---------- */

const FILTERS = [
    { render: () => renderBooks(), reset: "book-reset",
      ids: ["book-search", "book-category", "book-type", "book-avail", "book-mine", "book-year-from", "book-year-to"] },
    { render: () => renderLoans(), reset: "loan-reset",
      ids: ["loan-search", "loan-status", "loan-from", "loan-to"] },
    { render: () => renderReservations(), reset: "res-reset",
      ids: ["res-search", "res-status", "res-from", "res-to"] }
];

const bindFilters = () => {
    FILTERS.forEach(({ ids, render, reset }) => {
        // A missing element must never stop the other filters from working.
        ids.forEach((id) => {
            const el = $(id);
            if (!el) { console.warn(`portal: #${id} not found in portal.html`); return; }
            el.addEventListener("input", render);
            el.addEventListener("change", render);
        });
        const resetBtn = $(reset);
        if (resetBtn) resetBtn.addEventListener("click", () => {
            ids.forEach((id) => { const el = $(id); if (el) el.value = ""; });
            render();
        });
    });
};

// Click on a book's header opens or closes it. The page itself is the source of truth,
// so it also works while a search is auto-opening every book.
const bindToggle = (listId, openSet) => {
    const listEl = $(listId);
    if (!listEl) return;
    listEl.addEventListener("click", (e) => {
        const head = e.target.closest(".group-head");
        if (!head) return;

        const card = head.closest(".book-group");
        const body = card.querySelector(".group-body");
        const open = body.classList.contains("d-none"); // hidden now, so this click opens it

        if (open) openSet.add(card.dataset.key); else openSet.delete(card.dataset.key);

        body.classList.toggle("d-none", !open);
        head.setAttribute("aria-expanded", String(open));
        head.querySelector(".caret").textContent = open ? "▼" : "▶";
    });
};

// One entry per book, in the order the server sent them.
const groupRows = (rows, keyOf, titleOf) => {
    const groups = new Map();
    rows.forEach((row) => {
        const key = keyOf(row);
        if (!groups.has(key)) groups.set(key, { key, title: titleOf(row), rows: [] });
        groups.get(key).rows.push(row);
    });
    return [...groups.values()];
};

const groupCard = (group, open, subHtml, badgesHtml, bodyHtml) => `
    <div class="card book-group mb-2" data-key="${escapeHtml(group.key)}">
        <button type="button" class="group-head" aria-expanded="${open}">
            <span class="caret">${open ? "▼" : "▶"}</span>
            <span class="group-title">${escapeHtml(group.title)}${subHtml ? `<span class="group-sub">${subHtml}</span>` : ""}</span>
            <span class="group-badges">${badgesHtml}</span>
        </button>
        <div class="group-body ${open ? "" : "d-none"}">${bodyHtml}</div>
    </div>`;

const countBadge = (n, label, cls) => n > 0 ? `<span class="badge ${cls}">${n} ${escapeHtml(label)}</span>` : "";

/* ---------- books ---------- */
const loadBooks = async () => {
    try {
        const res = await axios.get(portal, { params: { operation: "getBooks" } });
        books = Array.isArray(res.data) ? res.data : [];
        fillCategories();
        renderBooks();
    } catch (error) {
        $("books-body").innerHTML = `<tr><td colspan="5" class="text-center text-danger">${escapeHtml(apiError(error, "Failed to load books."))}</td></tr>`;
    }
};

// Category list comes from the books themselves, so it never shows an empty category.
const fillCategories = () => {
    const select = $("book-category");
    const keep = select.value;
    const names = [...new Set(books.map((b) => b.category_type).filter(Boolean))].sort((a, b) => a.localeCompare(b));

    select.innerHTML = '<option value="">All</option>' +
        names.map((n) => `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`).join("");
    select.value = names.includes(keep) ? keep : "";
};

const filteredBooks = () => {
    const q = val("book-search").toLowerCase();
    const category = $("book-category").value;
    const type = $("book-type").value;
    const copies = $("book-avail").value;
    const mine = $("book-mine").value;
    const from = parseInt($("book-year-from").value, 10);
    const to = parseInt($("book-year-to").value, 10);

    return books.filter((b) => {
        if (q && !`${b.title} ${b.authors || ""} ${b.publisher_name || ""} ${b.category_type || ""}`.toLowerCase().includes(q)) return false;
        if (category && b.category_type !== category) return false;
        if (type && b.book_type !== type) return false;
        if (copies === "free" && !(b.available > 0)) return false;
        if (copies === "none" && b.available > 0) return false;
        if (mine === "borrowed" && !b.i_have) return false;
        if (mine === "reserved" && !b.my_reservation) return false;

        const year = parseInt(b.published_year, 10);
        if (!Number.isNaN(from) && !(year >= from)) return false;
        if (!Number.isNaN(to) && !(year <= to)) return false;

        return true;
    });
};

const bookActions = (b) => {
    if (b.i_have) return '<span class="badge bg-primary">You have this</span>';
    if (b.my_reservation === "Ready") return '<span class="badge bg-info text-dark">Held for you. Pick it up at the desk</span>';
    if (b.my_reservation === "Pending") return '<span class="badge bg-secondary">Awaiting approval</span>';
    if (b.my_reservation === "Waiting") return '<span class="badge bg-warning text-dark">On waiting list</span>';
    if (b.total_copies === 0) return b.library_only > 0
        ? '<span class="badge bg-info text-dark" title="This book stays in the library">Library use only</span>'
        : '<span class="text-muted small">No copies yet</span>';
    if (standing && standing.state === "blacklisted") {
        return '<button class="btn btn-secondary btn-sm" disabled title="Your account is blacklisted">Blacklisted</button>';
    }
    return `<button class="btn btn-success btn-sm" onclick="openReserve(${b.book_id})">Reserve</button>`;
};

const renderBooks = () => {
    const rows = filteredBooks();
    const tbody = $("books-body");

    $("book-count").textContent = books.length === 0 ? "" : `Showing ${rows.length} of ${plural(books.length, "book", "books")}`;

    if (rows.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" class="text-center text-muted">${books.length === 0 ? "No books found." : "No books match your filters."}</td></tr>`;
        return;
    }

    tbody.innerHTML = rows.map((b) => {
        const published = [b.publisher_name, b.published_year].filter(Boolean).join(", ");
        return `
        <tr>
            <td data-label="Title"><span class="d-block"><span class="d-block fw-semibold">${escapeHtml(b.title)}</span>
                <span class="d-block text-muted small">${escapeHtml(b.authors || "")}</span>
                ${published ? `<span class="d-block text-muted small">${escapeHtml(published)}</span>` : ""}</span></td>
            <td data-label="Category"><span>${escapeHtml(b.category_type || "")}</span></td>
            <td data-label="Free copies"><span>${b.available} of ${b.total_copies}</span></td>
            <td data-label="Keep it for"><span>${escapeHtml(b.period)}</span></td>
            <td data-label=""><span>${bookActions(b)}</span></td>
        </tr>`;
    }).join("");
};

/* ---------- reserve ---------- */
window.openReserve = (id) => {
    const b = books.find((x) => x.book_id == id);
    if (!b) return;
    reserveBookId = id;

    $("rs-title").textContent = b.title;
    $("rs-period").textContent = (b.available > 0
        ? `A copy is free. It will be held for you once the library approves your request.`
        : `No copy is free, so once approved you'll join the waiting list.`)
        + ` After approval, pick it up at the library desk by your chosen date. Once borrowed you can keep it for ${b.period}.`;

    const date = $("rs-date");
    date.min = isoDate(0);
    date.max = isoDate(14);
    date.value = isoDate(7);

    bootstrap.Modal.getOrCreateInstance($("reserveModal")).show();
};

const confirmReserve = async () => {
    const modal = bootstrap.Modal.getOrCreateInstance($("reserveModal"));

    try {
        const data = await post("reserve", { book_id: reserveBookId, expires_on: $("rs-date").value });
        modal.hide();
        showAlert(data.message, data.status === "success" ? "success" : "danger");
    } catch (error) {
        modal.hide();
        showAlert(apiError(error, "Failed to reserve the book."), "danger");
    }
    loadAll();
};

/* ---------- my borrowed books: one card per book, click to see each copy ---------- */
const dueText = (l) => {
    if (l.status === "Returned") return `Returned ${l.return_date ? l.return_date.slice(0, 10) : ""}`;
    if (l.days_left < 0) return `${-l.days_left} day${l.days_left === -1 ? "" : "s"} overdue`;
    if (l.days_left === 0) return "Due today";
    return `${l.days_left} day${l.days_left === 1 ? "" : "s"} left`;
};

const LOAN_BADGE = { Borrowed: "bg-primary", Overdue: "bg-danger", Returned: "bg-success" };

/* ---------- account hold, reminders and messages ---------- */
let standing = null;

const peso = (n) => "₱" + Number(n || 0).toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// Shown at the top every day the account has a problem: what is owed, that it grows daily, and what to do.
const renderStanding = () => {
    const box = $("standing-banner");
    if (!standing || standing.state === "good") { box.className = "d-none"; box.innerHTML = ""; return; }

    const blacklisted = standing.state === "blacklisted";
    const overdue = (standing.overdue || []).map((o) =>
        `<li>${escapeHtml(o.title)}: due ${escapeHtml(o.due_date)}, ${o.days_overdue} ${o.days_overdue === 1 ? "day" : "days"} late, fine ${peso(o.fine)}</li>`).join("");

    box.className = `alert ${blacklisted ? "alert-danger" : "alert-warning"}`;
    box.innerHTML = `
        <div class="fw-bold mb-1">${blacklisted ? "Your account is blacklisted" : "You have overdue books"}</div>
        ${blacklisted && standing.blacklist_reason ? `<div class="mb-2">${escapeHtml(standing.blacklist_reason)}</div>` : ""}
        ${overdue ? `<ul class="mb-2">${overdue}</ul>` : ""}
        ${standing.overdue && standing.overdue.length ? `<div class="mb-2"><strong>A fine of ${peso(standing.fine_per_day)} is added every day</strong> a book is overdue. Total so far: <strong>${peso(standing.fine_total)}</strong>.${Number(standing.credit) > 0 ? ` You already paid <strong>${peso(standing.credit)}</strong>, so you still owe <strong>${peso(standing.fine_due)}</strong> so far.` : ""}</div>` : ""}
        <div class="mb-2">${blacklisted ? "You can't reserve or borrow until the librarian lifts the blacklist. Please come to the library desk." : "Please return the overdue books. A fine of ₱60 or less is paid at the library desk; a fine above ₱60 is paid at Assessment with the receipt the library gives you."}</div>
        ${blacklisted ? `<div class="mb-2">Already paid? <button type="button" class="btn btn-sm btn-light border" data-proof-open>Send proof of payment</button> to speed things up.</div>` : ""}
        <div class="small">Lost, missing or damaged a book? You must come to the library <strong>in person</strong> to settle it: pay its full price plus the processing fee, or bring a replacement copy.</div>
        ${!blacklisted && standing.days_until_blacklist !== null ? `<div class="small mt-2 fw-semibold">If a book stays overdue, your account will be blacklisted in ${standing.days_until_blacklist} ${standing.days_until_blacklist === 1 ? "day" : "days"}. You will not be able to reserve or borrow after that.</div>` : ""}`;
};

// Lost or damaged books that are not settled: what the borrower must do, and the clearance warning.
// Clearance only applies to students. A dean's lost or damaged book is deducted from his or her salary instead,
// and a faculty member is only asked to settle it with the library (no clearance wording at all).
const borrowerKindOf = (type) => {
    const t = String(type || "").toLowerCase();
    if (t.indexOf("dean") !== -1) return "dean";
    if (t.indexOf("faculty") !== -1) return "faculty";
    return "student";
};

// The permanent note under "My borrowed books" also mentions clearance: show it to students only.
const renderClearanceNote = (kind) => {
    const note = $("clearance-note");
    if (!note) return;
    if (kind === "dean") {
        note.innerHTML = "<strong>Salary deduction:</strong> a lost or damaged book is deducted from your salary (book price plus the processing fee).";
    } else if (kind === "faculty") {
        note.innerHTML = "";
    } else {
        note.innerHTML = "<strong>Clearance:</strong> a lost or damaged book is reflected on your clearance, and you will not get your clearance signed until it is settled.";
    }
};

const renderClearance = (cases, type) => {
    const box = $("clearance-banner");
    const kind = borrowerKindOf(type);
    renderClearanceNote(kind);
    if (!cases || cases.length === 0) { box.className = "d-none"; box.innerHTML = ""; return; }

    const rep = (c) => c.replacement
        ? `<strong>${escapeHtml(c.replacement.title)}</strong>${c.replacement.year ? ` (${escapeHtml(c.replacement.year)})` : ""}${c.replacement.authors ? ` by ${escapeHtml(c.replacement.authors)}` : ""}`
        : "the same book";

    const what = (c) => {
        const total = Number(c.book_price || 0) + Number(c.processing_fee || 0);

        if (c.case_status === "Awaiting payment") {
            return `Pay <strong>${peso(total)}</strong> (${peso(c.book_price)} book price + ${peso(c.processing_fee)} processing fee) at Assessment. Receipt no. <strong>${escapeHtml(c.receipt_no || "")}</strong>.`;
        }
        if (c.case_status === "Awaiting replacement") {
            return `Bring a replacement: ${rep(c)}. It must be the newest edition, with the same title and author.`;
        }
        return `Come to the library to settle it: pay the price of the book plus the processing fee, or bring a replacement (${rep(c)}, the newest edition with the same title and author).`;
    };

    if (kind === "dean") {
        const owed = (c) => {
            const total = Number(c.book_price || 0) + Number(c.processing_fee || 0);
            return total > 0
                ? `<strong>${peso(total)}</strong> (${peso(c.book_price)} book price + ${peso(c.processing_fee)} processing fee) will be deducted from your salary.`
                : `the book price plus the processing fee will be deducted from your salary once the library confirms the price.`;
        };
        box.className = "alert alert-warning";
        box.innerHTML = `
            <div class="fw-bold mb-1">Notice: salary deduction</div>
            <div class="mb-2">A lost or damaged book is <strong>deducted from your salary</strong>. You do not need to pay at Assessment.</div>
            <ul class="mb-0">${cases.map((c) => `<li><strong>${escapeHtml(c.title || "Book")}</strong> (${escapeHtml(c.condition_on_return)}): ${owed(c)}</li>`).join("")}</ul>`;
        return;
    }

    if (kind === "faculty") {
        box.className = "alert alert-warning";
        box.innerHTML = `
            <div class="fw-bold mb-1">Lost or damaged book</div>
            <ul class="mb-0">${cases.map((c) => `<li><strong>${escapeHtml(c.title || "Book")}</strong> (${escapeHtml(c.condition_on_return)}): ${what(c)}</li>`).join("")}</ul>`;
        return;
    }

    box.className = "alert alert-danger";
    box.innerHTML = `
        <div class="fw-bold mb-1">Warning: your clearance is affected</div>
        <div class="mb-2">A lost or damaged book is reflected on your clearance, and you will <strong>not get your clearance signed</strong> until it is settled.</div>
        <ul class="mb-0">${cases.map((c) => `<li><strong>${escapeHtml(c.title || "Book")}</strong> (${escapeHtml(c.condition_on_return)}): ${what(c)}</li>`).join("")}</ul>`;
};

const setUnread = (n) => {
    const badge = $("msg-badge");
    badge.textContent = n;
    badge.classList.toggle("d-none", !(n > 0));
};

const KIND_BADGE = { reminder: "bg-warning text-dark", warning: "bg-danger", notice: "bg-success", message: "bg-primary", proof: "bg-info text-dark", statement: "bg-dark" };
const KIND_LABEL = { reminder: "Reminder", warning: "Warning", notice: "Notice", message: "Message", proof: "Proof of payment", statement: "Statement" };

// A link that opens the receipt the borrower sent (served only to its owner and the library staff).
const fileLink = (m) => Number(m.has_file)
    ? `<div class="mt-2"><a href="${baseApiUrl}/proof_file.php?operation=view&id=${Number(m.message_id)}" target="_blank" rel="noopener">View attached file${m.attachment_name ? ` (${escapeHtml(m.attachment_name)})` : ""}</a></div>`
    : "";

const loadMessages = async () => {
    const list = $("msgs-list");
    try {
        const res = await axios.get(portal, { params: { operation: "getMessages" } });
        const rows = Array.isArray(res.data) ? res.data : [];

        if (rows.length === 0) {
            list.innerHTML = '<div class="text-center text-muted py-3">No messages yet.</div>';
            return;
        }

        list.innerHTML = rows.map((m) => {
            const mine = Number(m.from_borrower) === 1;   // sent by this borrower
            const flag = mine
                ? (m.read_at ? '<span class="badge bg-success ms-1">Seen by the library</span>' : '<span class="badge bg-secondary ms-1">Waiting for the librarian</span>')
                : (m.read_at ? "" : '<span class="badge bg-primary ms-1">New</span>');

            return `
            <div class="card mb-2 ${mine ? "border-info" : (m.read_at ? "" : "border-primary")}">
                <div class="card-body py-2">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                        <div>
                            <span class="badge ${KIND_BADGE[m.kind] || "bg-secondary"} me-1">${escapeHtml(KIND_LABEL[m.kind] || m.kind)}</span>
                            <strong>${escapeHtml(m.subject)}</strong>
                            ${flag}
                        </div>
                        <div class="small text-muted">${escapeHtml(m.sender)} · ${escapeHtml(String(m.created_at).slice(0, 16))}</div>
                    </div>
                    <div class="mt-2" style="white-space: pre-line;">${escapeHtml(m.body)}</div>
                    ${fileLink(m)}
                </div>
            </div>`;
        }).join("");
    } catch (error) {
        list.innerHTML = `<div class="alert alert-danger">${escapeHtml(apiError(error, "Failed to load your messages."))}</div>`;
    }
};

/* ---------- proof of payment ---------- */

const MAX_UPLOAD_BYTES = 1.8 * 1024 * 1024;   // stay under PHP's usual 2 MB upload limit

// Phone photos are often several MB. Shrink images in the browser first (long side 1600 px, JPEG) so they upload quickly.
const shrinkImage = (file) => new Promise((resolve) => {
    if (!/^image\/(jpeg|png|webp)$/.test(file.type)) { resolve(file); return; }

    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
        const scale = Math.min(1, 1600 / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext("2d");
        ctx.fillStyle = "#fff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        URL.revokeObjectURL(url);
        canvas.toBlob((blob) => {
            if (!blob || blob.size >= file.size) { resolve(file); return; }
            resolve(new File([blob], file.name.replace(/\.[^.]+$/, "") + ".jpg", { type: "image/jpeg" }));
        }, "image/jpeg", 0.82);
    };
    img.onerror = () => { URL.revokeObjectURL(url); resolve(file); };
    img.src = url;
});

const resetProofForm = () => {
    $("proof-form").reset();
    $("proof-preview").classList.add("d-none");
    $("proof-form").classList.add("d-none");
};

const openProofForm = () => {
    // Make sure the person is looking at the Messages tab, where the form lives.
    const tabBtn = $("tab-msgs-btn");
    if (tabBtn && window.bootstrap) bootstrap.Tab.getOrCreateInstance(tabBtn).show();
    $("proof-form").classList.remove("d-none");
    $("proof-amount").focus();
};

const sendProof = async (e) => {
    e.preventDefault();

    const amount = $("proof-amount").value.trim();
    const file = $("proof-file").files[0];

    if (!amount || Number(amount) <= 0) { showAlert("Enter the amount you paid.", "danger"); return; }
    if (!file) { showAlert("Attach a photo or PDF of your receipt.", "danger"); return; }

    const btn = $("proof-send");
    btn.disabled = true;
    btn.textContent = "Sending...";

    try {
        const upload = await shrinkImage(file);
        if (upload.size > MAX_UPLOAD_BYTES) {
            showAlert("That file is too big. Send a smaller photo (under 2 MB) or a screenshot.", "danger");
            return;
        }

        const fd = new FormData();
        fd.append("operation", "sendProof");
        fd.append("amount", amount);
        fd.append("reference", $("proof-ref").value.trim());
        fd.append("note", $("proof-note").value.trim());
        fd.append("proof", upload, upload.name);

        const res = await axios.post(portal, fd);
        const ok = res.data.status === "success";
        showAlert(res.data.message, ok ? "success" : "danger");
        if (ok) { resetProofForm(); loadMessages(); }
    } catch (error) {
        showAlert(apiError(error, "Could not send your proof. Please try again."), "danger");
    } finally {
        btn.disabled = false;
        btn.textContent = "Send proof";
    }
};

document.addEventListener("DOMContentLoaded", () => {
    if (!$("proof-form")) return;

    $("proof-toggle").addEventListener("click", openProofForm);
    $("proof-cancel").addEventListener("click", resetProofForm);
    $("proof-form").addEventListener("submit", sendProof);
    $("proof-file").addEventListener("change", () => {
        const f = $("proof-file").files[0];
        const img = $("proof-preview");
        if (f && /^image\//.test(f.type)) { img.src = URL.createObjectURL(f); img.classList.remove("d-none"); }
        else img.classList.add("d-none");
    });

    // The "Send proof of payment" button in the blacklist banner.
    document.addEventListener("click", (ev) => {
        if (ev.target.closest("[data-proof-open]")) openProofForm();
    });
});

// Opening the Messages tab marks everything as read.
const markMessagesRead = async () => {
    try {
        const fd = new FormData();
        fd.append("operation", "markRead");
        await axios.post(portal, fd);
        setUnread(0);
    } catch (error) { /* the badge simply stays */ }
};

const loadLoans = async () => {
    const list = $("loans-list");
    try {
        const res = await axios.get(portal, { params: { operation: "getMyLoans" } });
        const { summary, loans } = res.data;
        standing = res.data.standing || null;
        setUnread(res.data.unread_messages || 0);
        renderStanding();
        renderClearance(res.data.clearance || [], summary.borrower_type);
        if (typeof renderBooks === "function" && books.length) renderBooks();

        $("limit-note").textContent =
            `${summary.borrower_type} limit: ${summary.active} borrowed and ${summary.reserved} reserved of ${summary.limit} books at a time.`;

        if ($("fine-per-day") && summary.fine_per_day != null) $("fine-per-day").textContent = "₱" + summary.fine_per_day;
        if ($("processing-fee") && summary.processing_fee != null) $("processing-fee").textContent = "₱" + summary.processing_fee;

        loanRows = Array.isArray(loans) ? loans : [];
        renderLoans();
    } catch (error) {
        list.innerHTML = `<div class="alert alert-danger">${escapeHtml(apiError(error, "Failed to load your loans."))}</div>`;
    }
};

const filteredLoans = () => {
    const q = val("loan-search").toLowerCase();
    const status = $("loan-status").value;
    const from = $("loan-from").value;
    const to = $("loan-to").value;

    return loanRows.filter((l) => {
        if (status && l.status !== status) return false;
        if (from && !(l.borrow_date >= from)) return false;
        if (to && !(l.borrow_date <= to)) return false;
        if (q && !`${l.title} ${l.accession_number}`.toLowerCase().includes(q)) return false;
        return true;
    });
};

const renderLoans = () => {
    const list = $("loans-list");
    const rows = filteredLoans();
    const searching = val("loan-search") !== "";

    if (loanRows.length === 0) {
        $("loan-count").textContent = "";
        list.innerHTML = '<div class="text-center text-muted py-3">You haven\'t borrowed any books yet.</div>';
        return;
    }

    const groups = groupRows(rows, (l) => l.title || "Unknown book", (l) => l.title || "Unknown book");

    $("loan-count").textContent = rows.length === 0
        ? "Nothing matches your filters."
        : `${plural(groups.length, "book", "books")}, ${plural(rows.length, "copy", "copies")}. Click a book to see your copies.`;

    if (rows.length === 0) {
        list.innerHTML = '<div class="text-center text-muted py-3">No borrowed books match your filters.</div>';
        return;
    }

    list.innerHTML = groups.map((g) => {
        const count = (status) => g.rows.filter((r) => r.status === status).length;
        const open = searching || openLoans.has(g.key);

        // The copy that is due first, among the ones still out.
        const active = g.rows.filter((r) => r.status !== "Returned").sort((a, b) => a.days_left - b.days_left);
        const sub = active.length > 0 ? `Next due ${escapeHtml(active[0].due_date)}, ${escapeHtml(dueText(active[0]))}` : "";

        const badges =
            `<span class="badge bg-secondary">${plural(g.rows.length, "copy", "copies")}</span>` +
            countBadge(count("Borrowed"), "Borrowed", LOAN_BADGE.Borrowed) +
            countBadge(count("Overdue"), "Overdue", LOAN_BADGE.Overdue) +
            countBadge(count("Returned"), "Returned", LOAN_BADGE.Returned);

        const copies = g.rows.map((l) => `
            <tr>
                <td data-label="Copy"><span>ACC-${escapeHtml(l.accession_number)}</span></td>
                <td data-label="Borrowed"><span>${escapeHtml(l.borrow_date)}</span></td>
                <td data-label="Due date"><span>${escapeHtml(l.due_date)} <span class="text-muted small">${escapeHtml(dueText(l))}</span></span></td>
                <td data-label="Status"><span class="badge ${LOAN_BADGE[l.status] || "bg-secondary"}">${escapeHtml(l.status)}</span></td>
            </tr>`).join("");

        const table = `
            <div class="table-responsive">
                <table class="table table-sm align-middle mb-0 table-stack">
                    <thead><tr><th>Copy</th><th>Borrowed</th><th>Due date</th><th>Status</th></tr></thead>
                    <tbody>${copies}</tbody>
                </table>
            </div>`;

        return groupCard(g, open, sub, badges, table);
    }).join("");
};

/* ---------- my reservations: one card per book ---------- */
const RES_BADGE = { Pending: "bg-info text-dark", Ready: "bg-success", Waiting: "bg-warning text-dark", Fulfilled: "bg-primary", Rejected: "bg-danger", Cancelled: "bg-secondary", Expired: "bg-secondary" };

// Plain-words status for the student ("Pending" means the library has not answered yet).
const RES_LABEL = { Pending: "Awaiting approval" };

const loadReservations = async () => {
    const list = $("res-list");
    try {
        const res = await axios.get(portal, { params: { operation: "getMyReservations" } });
        resRows = Array.isArray(res.data) ? res.data : [];
        renderReservations();
    } catch (error) {
        list.innerHTML = `<div class="alert alert-danger">${escapeHtml(apiError(error, "Failed to load your reservations."))}</div>`;
    }
};

const filteredReservations = () => {
    const q = val("res-search").toLowerCase();
    const status = $("res-status").value;
    const from = $("res-from").value;
    const to = $("res-to").value;

    return resRows.filter((r) => {
        if (status && r.status !== status) return false;
        if (from && !(r.expires_on >= from)) return false;
        if (to && !(r.expires_on <= to)) return false;
        if (q && !`${r.title} ${r.accession_number || ""}`.toLowerCase().includes(q)) return false;
        return true;
    });
};

const renderReservations = () => {
    const list = $("res-list");
    const rows = filteredReservations();
    const searching = val("res-search") !== "";

    if (resRows.length === 0) {
        $("res-count").textContent = "";
        list.innerHTML = '<div class="text-center text-muted py-3">You have no reservations.</div>';
        return;
    }

    const groups = groupRows(rows, (r) => `b${r.book_id}`, (r) => r.title || "Unknown book");

    $("res-count").textContent = rows.length === 0
        ? "Nothing matches your filters."
        : `${plural(groups.length, "book", "books")}, ${plural(rows.length, "reservation", "reservations")}. Click a book to see its reservations.`;

    if (rows.length === 0) {
        list.innerHTML = '<div class="text-center text-muted py-3">No reservations match your filters.</div>';
        return;
    }

    list.innerHTML = groups.map((g) => {
        const count = (status) => g.rows.filter((r) => r.status === status).length;
        const open = searching || openRes.has(g.key);

        const live = g.rows.filter((r) => ["Pending", "Ready", "Waiting"].includes(r.status))
            .sort((a, b) => String(a.expires_on).localeCompare(String(b.expires_on)));
        const sub = live.length > 0 ? `Pick up by ${escapeHtml(live[0].expires_on)}` : "";

        const badges =
            `<span class="badge bg-secondary">${plural(g.rows.length, "reservation", "reservations")}</span>` +
            ["Pending", "Ready", "Waiting", "Fulfilled", "Rejected", "Cancelled", "Expired"].map((s) => countBadge(count(s), RES_LABEL[s] || s, RES_BADGE[s])).join("");

        const items = g.rows.map((r) => `
            <tr>
                <td data-label="Copy held"><span>${r.accession_number ? `ACC-${escapeHtml(r.accession_number)}` : "—"}</span></td>
                <td data-label="Pick up by"><span>${escapeHtml(r.expires_on)}</span></td>
                <td data-label="Status"><span class="badge ${RES_BADGE[r.status] || "bg-secondary"}">${escapeHtml(RES_LABEL[r.status] || r.status)}</span>${r.status === "Rejected" && r.reject_reason ? `<div class="small text-muted mt-1">${escapeHtml(r.reject_reason)}</div>` : ""}</td>
                <td data-label="Loan period"><span>${escapeHtml(r.period)}</span></td>
                <td data-label=""><span>${["Pending", "Ready", "Waiting"].includes(r.status)
                    ? `<button class="btn btn-outline-danger btn-sm" onclick="cancelRes(${Number(r.reservation_id)})">Cancel</button>` : ""}</span></td>
            </tr>`).join("");

        const table = `
            <div class="table-responsive">
                <table class="table table-sm align-middle mb-0 table-stack">
                    <thead><tr><th>Copy held</th><th>Pick up by</th><th>Status</th><th>Loan period</th><th></th></tr></thead>
                    <tbody>${items}</tbody>
                </table>
            </div>`;

        return groupCard(g, open, sub, badges, table);
    }).join("");
};

window.cancelRes = async (id) => {
    if (!confirm("Cancel this reservation?")) return;

    try {
        const data = await post("cancelReservation", { reservation_id: id });
        showAlert(data.message, data.status === "success" ? "success" : "danger");
    } catch (error) {
        showAlert(apiError(error, "Failed to cancel the reservation."), "danger");
    }
    loadAll();
};