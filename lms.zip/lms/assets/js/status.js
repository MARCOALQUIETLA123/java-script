const baseApiUrl = "api"; // relative to the page, so it works from any folder

let editingId = null;

document.addEventListener("DOMContentLoaded", () => {
    loadRecords();

    document.getElementById("btn-save").addEventListener("click", saveRecord);
    document.getElementById("btn-clear").addEventListener("click", clearForm);
});

const loadRecords = async () => {
    const response = await axios.get(`${baseApiUrl}/status.php`, {
        params: { operation: "getAll" }
    });

    const tbody = document.getElementById("table-body");
    tbody.innerHTML = "";
    window._statusData = response.data;

    if (response.data.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="2" class="text-center text-muted">No records found.</td>
            </tr>
        `;
        return;
    }

    response.data.forEach((row) => {
        tbody.innerHTML += `
            <tr>
                <td>${row.status_desc}</td>
                <td>
                    <button class="btn btn-success btn-sm me-1" onclick="editRecord(${row.status_id})">Edit</button>
                    <button class="btn btn-danger btn-sm" onclick="deleteRecord(${row.status_id})">Delete</button>
                </td>
            </tr>
        `;
    });
};

const isValidName = (value) => {
    if (!value || value.trim() === "") return false;
    if (/^[\d\s]+$/.test(value.trim())) return false;
    return true;
};

const saveRecord = async () => {
    const status_desc = document.getElementById("status_desc").value.trim();

    if (!status_desc) {
        showAlert("Status description is required.", "danger");
        return;
    }

    if (!isValidName(status_desc)) {
        showAlert("Invalid input. Status description must contain letters, not numbers only.", "danger");
        return;
    }

    const jsonData = { status_desc };
    let operation = "add";

    if (editingId !== null) {
        jsonData.status_id = editingId;
        operation = "update";
    }

    const formData = new FormData();
    formData.append("operation", operation);
    formData.append("json", JSON.stringify(jsonData));

    const response = await axios({
        url: `${baseApiUrl}/status.php`,
        method: "POST",
        data: formData
    });

    if (response.data.status === "success") {
        showAlert(response.data.message, "success");
        clearForm();
        loadRecords();
    } else {
        showAlert(response.data.message, "danger");
    }
};

const editRecord = (id) => {
    const row = window._statusData.find((status) => status.status_id == id);

    if (!row) return;

    editingId = id;

    document.getElementById("status_desc").value = row.status_desc;
    document.getElementById("btn-save").innerText = "Update";
    document.getElementById("form-title").innerText = "Edit Status";
};

const deleteRecord = async (id) => {
    if (!confirm("Are you sure you want to delete this status?")) {
        return;
    }

    const formData = new FormData();
    formData.append("operation", "delete");
    formData.append("json", JSON.stringify({ status_id: id }));

    const response = await axios({
        url: `${baseApiUrl}/status.php`,
        method: "POST",
        data: formData
    });

    if (response.data.status === "success") {
        showAlert(response.data.message, "success");
        loadRecords();
    } else {
        showAlert(response.data.message, "danger");
    }
};

const clearForm = () => {
    editingId = null;

    document.getElementById("status_desc").value = "";
    document.getElementById("btn-save").innerText = "Save";
    document.getElementById("form-title").innerText = "Add Status";
    document.getElementById("alert-box").innerHTML = "";
};

const showAlert = (msg, type) => {
    document.getElementById("alert-box").innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${msg}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
};

window.editRecord = editRecord;
window.deleteRecord = deleteRecord;