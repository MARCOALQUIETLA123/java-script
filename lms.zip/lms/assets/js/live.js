// Live updates between devices. auth.js loads this on every page once the user is signed in.
//
// Every few seconds it asks api/sync.php for the "change counter". When another device has
// saved something, the counter goes up and this reloads the data on the current page.
// It never touches the forms, so nothing you are typing is lost.

(() => {
    const api = "api/sync.php";
    const POLL_MS = 5000;

    const page = (location.pathname.split("/").pop() || "dashboard.html").toLowerCase();

    // Remembers every dropdown's choice around a reload, so a refreshed list doesn't reset it.
    const keepSelections = async (fn) => {
        const saved = [...document.querySelectorAll("select[id]")].map((s) => [s.id, s.value]);
        try {
            await fn();
        } finally {
            saved.forEach(([id, value]) => {
                const el = document.getElementById(id);
                if (el && value !== "" && [...el.options].some((o) => o.value === value)) el.value = value;
            });
        }
    };

    // What to reload on each page. These are the same functions the pages already use after a save.
    const simple = (fn) => () => fn();
    const REFRESH = {
        "dashboard.html": () => {
            loadCounts();
            if (window.currentUser && window.currentUser.role === "admin") loadPending();
        },
        "roles.html": simple(() => loadRoles()),
        "department.html": simple(() => loadRecords()),
        "categories.html": simple(() => loadRecords()),
        "publisher.html": simple(() => loadRecords()),
        "author.html": simple(() => loadRecords()),
        "users.html": () => keepSelections(async () => { await loadRecords(); }),
        "book.html": () => keepSelections(async () => { await Promise.all([loadDropdowns(), loadRecords()]); }),
        "book_author.html": () => keepSelections(async () => { await Promise.all([loadDropdowns(), loadRecords()]); }),
        "book_copies.html": () => keepSelections(async () => { await Promise.all([loadDropdowns(), loadRecords()]); }),
        "borrow_report.html": simple(() => loadReport()),
        "transaction_history.html": simple(() => loadHistory()),
        "account_holds.html": simple(() => loadHolds()),
        "reservation.html": () => keepSelections(async () => { await Promise.all([loadRecords(), loadBooks()]); }),
        "borrow_transaction.html": () => refreshAfterChange(),
        "book_return.html": async () => {
            await loadBorrowers();
            await reloadSelectedBorrower();
            const history = document.getElementById("tab-history-btn");
            if (history && history.classList.contains("active")) await loadHistory();
        }
    };

    const refresh = REFRESH[page];
    if (!refresh) return; // login page and anything else without data to reload

    /* ---- small "Live" indicator, bottom-left ---- */
    const pill = document.createElement("div");
    pill.setAttribute("role", "status");
    pill.style.cssText = "position:fixed;left:12px;bottom:12px;z-index:1080;padding:.25rem .65rem;" +
        "border-radius:999px;font-size:.78rem;font-weight:600;background:#fff;border:1px solid #dee2e6;" +
        "box-shadow:0 1px 4px rgba(0,0,0,.12);color:#198754;pointer-events:none;";
    document.body.appendChild(pill);

    let flashTimer = null;
    const show = (text, color) => {
        pill.textContent = `● ${text}`;
        pill.style.color = color;
    };
    const live = () => show("Live", "#198754");
    live();

    const flash = () => {
        show("Live · updated", "#0d6efd");
        clearTimeout(flashTimer);
        flashTimer = setTimeout(live, 2000);
    };

    /* ---- polling ---- */
    let known = null;
    let busy = false;
    let again = false;

    const reload = async () => {
        try {
            await refresh();
            flash();
        } catch (e) {
            console.warn("Live refresh failed:", e);
        }
    };

    const check = async () => {
        if (busy) { again = true; return; }
        if (document.hidden) return;
        busy = true;

        try {
            const res = await axios.get(api, { params: { operation: "version" }, timeout: 8000 });
            const version = Number(res.data && res.data.version);

            if (!Number.isFinite(version)) throw new Error("bad response");

            if (known === null) {
                known = version;
            } else if (version !== known) {
                known = version;
                await reload();
            }

            if (pill.style.color === "rgb(255, 193, 7)" || pill.textContent === "● Reconnecting…") live();
        } catch (e) {
            // A 401 is handled by auth.js (back to the login page); anything else is a network blip.
            show("Reconnecting…", "#ffc107");
        } finally {
            busy = false;
            if (again) { again = false; check(); }
        }
    };

    setInterval(check, POLL_MS);
    document.addEventListener("visibilitychange", () => { if (!document.hidden) check(); });
    window.addEventListener("online", check);
    check();
})();
