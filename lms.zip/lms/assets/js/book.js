const baseApiUrl = "api"; // relative to the page, so it works from any folder

let selectedAuthorIds = new Set();

// Loan periods come from the Loan Rules page (api/loan_settings.php), so they are never out of date.
let loanRules = null;

const periodText = (rule) => {
    const n = Number(rule.value);
    return `${n} ${rule.unit}${n === 1 ? "" : "s"}`;
};

const loadLoanRules = async () => {
    try {
        const response = await axios.get(`${baseApiUrl}/loan_settings.php`, { params: { operation: "getRules" } });
        if (response.data && response.data.rules) {
            loanRules = response.data.rules;
            if (typeof renderRecords === "function" && window._bookData) renderRecords();
        }
    } catch (error) { /* the column just shows a dash */ }
};

const escapeHtml = (value) => {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
};

const TYPE_BADGE = {
    Educational: "bg-primary",
    Fictional: "bg-info text-dark"
};

const LIST_HIDDEN_KEY = "booksListHidden";

// One line per borrower type, e.g. "Student 3 days" and "Faculty 7 days".
const loanLines = (bookType) => {
    const kind = { Educational: "educational", Fictional: "fictional" }[bookType];
    if (!kind || !loanRules) return "—";
    return [`Student ${periodText(loanRules["student_" + kind])}`, `Faculty ${periodText(loanRules["faculty_" + kind])}`]
        .map(line => `<div class="small">${escapeHtml(line)}</div>`).join("");
};

document.addEventListener("DOMContentLoaded", () => {
    loadDropdowns();
    loadAuthors();
    loadRecords();
    loadLoanRules();

    document.getElementById("btn-save").addEventListener("click", saveRecord);
    document.getElementById("btn-clear").addEventListener("click", clearForm);
    document.getElementById("author-search").addEventListener("input", (e) => {
        renderAuthorsTable(e.target.value);
    });
    document.getElementById("btn-save-new-author").addEventListener("click", saveNewAuthor);
    document.getElementById("book-search").addEventListener("input", renderRecords);
    ["filter-availability", "filter-type", "filter-category"].forEach(id => {
        document.getElementById(id).addEventListener("change", renderRecords);
    });
    document.getElementById("btn-cond-all").addEventListener("click", applyConditionToAll);
    document.getElementById("btn-clear-filters").addEventListener("click", () => {
        ["book-search", "filter-availability", "filter-type", "filter-category"].forEach(id => {
            document.getElementById(id).value = "";
        });
        renderRecords();
    });

    setupListToggle();
});

/* ---------------- Hide / show the books list ---------------- */

const setupListToggle = () => {
    const wrapper = document.getElementById("books-list-wrapper");
    const button = document.getElementById("btn-toggle-list");

    const remember = (hidden) => {
        try {
            localStorage.setItem(LIST_HIDDEN_KEY, hidden ? "1" : "0");
        } catch (e) { /* storage unavailable, the toggle still works */ }
    };

    // Restore the last choice without playing the animation.
    let startHidden = false;
    try {
        startHidden = localStorage.getItem(LIST_HIDDEN_KEY) === "1";
    } catch (e) { /* ignore */ }

    if (startHidden) {
        wrapper.classList.remove("show");
        button.setAttribute("aria-expanded", "false");
        button.innerText = "Show List";
    }

    wrapper.addEventListener("shown.bs.collapse", () => {
        button.innerText = "Hide List";
        remember(false);
    });

    wrapper.addEventListener("hidden.bs.collapse", () => {
        button.innerText = "Show List";
        remember(true);
    });
};

// Turns a failed API reply into readable text, including raw PHP errors if the server sent one.
const describeReply = (res) => {
    if (res.data && res.data.message) return res.data.message;
    const raw = typeof res.data === "string" ? res.data : JSON.stringify(res.data);
    return "server said: " + String(raw).replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim().slice(0, 300);
};

/* ---------------- Dropdowns (publisher / category / status) ---------------- */

// New copies are always Available, so the status field is locked to it.
let availableStatusId = "";

const loadDropdowns = async () => {
    const fill = async (file, selectId, placeholder, valueKey, labelKey) => {
        const select = document.getElementById(selectId);
        select.innerHTML = `<option value="">${placeholder}</option>`;

        const response = await axios.get(`${baseApiUrl}/${file}`, { params: { operation: "getAll" } });

        if (!Array.isArray(response.data)) {
            throw new Error("unexpected response");
        }

        response.data.forEach(r => {
            select.innerHTML += `<option value="${r[valueKey]}">${escapeHtml(r[labelKey])}</option>`;
        });

        return response.data;
    };

    // Each dropdown loads on its own, so one broken endpoint doesn't blank the others.
    const jobs = [
        ["publisher.php", fill("publisher.php", "publisher_id", "Select Publisher", "publisher_id", "publisher_name")],
        ["categories.php", fill("categories.php", "category_id", "Select Category", "category_id", "category_type")],
        ["status.php", fill("status.php", "status_id", "Select Status", "status_id", "status_desc")]
    ];

    const results = await Promise.allSettled(jobs.map(j => j[1]));
    const failed = [];

    results.forEach((res, i) => {
        if (res.status === "rejected") {
            const reason = res.reason && res.reason.response
                ? `HTTP ${res.reason.response.status}`
                : (res.reason && res.reason.message) || "error";
            failed.push(`${jobs[i][0]} (${reason})`);
        }
    });

    if (failed.length > 0) {
        showAlert(`Failed to load: ${failed.join(", ")}. Open ${baseApiUrl}/<file>?operation=getAll in your browser to see the error.`, "danger");
    }

    // Category filter above the books list (keeps the current choice when refreshed).
    if (results[1].status === "fulfilled") {
        const catFilter = document.getElementById("filter-category");
        const keep = catFilter.value;
        catFilter.innerHTML = '<option value="">All categories</option>' +
            results[1].value.map(r => `<option value="${r.category_id}">${escapeHtml(r.category_type)}</option>`).join("");
        catFilter.value = keep;
    }

    const statusResult = results[2];
    if (statusResult.status === "fulfilled") {
        const statuses = statusResult.value;

        if (statuses.length === 0) {
            showAlert("No statuses found in the database. Ask the Technical Services Librarian to restore them.", "danger");
        } else {
            // New copies start as Available, so preselect it.
            const available = statuses.find(r => String(r.status_desc).toLowerCase() === "available");
            if (available) {
                availableStatusId = available.status_id;
                const statusSelect = document.getElementById("status_id");
                statusSelect.value = availableStatusId;
                statusSelect.disabled = true;
            } else {
                showAlert("The 'Available' status is missing from the database. Ask the Technical Services Librarian to restore it.", "danger");
            }
        }
    }
};

/* ---------------- Author picker ---------------- */

const loadAuthors = async () => {
    try {
        const response = await axios.get(`${baseApiUrl}/author.php`, {
            params: { operation: "getAll" }
        });
        window._allAuthors = response.data;
        renderAuthorsTable(document.getElementById("author-search").value);
    } catch (error) {
        document.getElementById("authors-table-body").innerHTML =
            `<tr><td colspan="4" class="text-center text-danger">Failed to load authors.</td></tr>`;
    }
};

const renderAuthorsTable = (filter = "") => {
    const tbody = document.getElementById("authors-table-body");
    const term = filter.trim().toLowerCase();
    const authors = (window._allAuthors || []).filter(a => {
        if (!term) return true;
        const full = `${a.first_name} ${a.last_name}`.toLowerCase();
        return full.includes(term);
    });

    if (authors.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" class="text-center text-muted">No authors found.</td></tr>`;
        return;
    }

    tbody.innerHTML = "";
    authors.forEach(a => {
        const isSelected = selectedAuthorIds.has(String(a.author_id));
        const bio = a.bio ? a.bio : "";
        const bioShort = bio.length > 40 ? bio.slice(0, 40) + "…" : bio;

        tbody.innerHTML += `
            <tr class="${isSelected ? "selected-row" : ""}">
                <td>
                    <input type="checkbox" class="form-check-input" ${isSelected ? "checked" : ""}
                           onchange="toggleAuthor(${a.author_id})">
                </td>
                <td>${a.first_name} ${a.last_name}</td>
                <td><span class="bio-truncate" title="${bio.replace(/"/g, "&quot;")}">${bioShort || "—"}</span></td>
                <td>
                    <button type="button" class="btn btn-sm ${isSelected ? "btn-outline-secondary" : "btn-success"}"
                            onclick="toggleAuthor(${a.author_id})">
                        ${isSelected ? "Remove" : "+ Add"}
                    </button>
                </td>
            </tr>
        `;
    });
};

const toggleAuthor = (authorId) => {
    const key = String(authorId);
    if (selectedAuthorIds.has(key)) {
        selectedAuthorIds.delete(key);
    } else {
        selectedAuthorIds.add(key);
    }
    renderAuthorsTable(document.getElementById("author-search").value);
    renderSelectedChips();
};

const renderSelectedChips = () => {
    const container = document.getElementById("selected-authors-chips");
    const authors = window._allAuthors || [];

    if (selectedAuthorIds.size === 0) {
        container.innerHTML = `<span class="text-muted small">None selected.</span>`;
        return;
    }

    container.innerHTML = "";
    selectedAuthorIds.forEach(id => {
        const a = authors.find(x => String(x.author_id) === id);
        if (!a) return;
        container.innerHTML += `
            <span class="author-chip">
                ${a.first_name} ${a.last_name}
                <span class="chip-remove" onclick="toggleAuthor(${a.author_id})">&times;</span>
            </span>
        `;
    });
};

const saveNewAuthor = async () => {
    const first_name = document.getElementById("new-author-first").value.trim();
    const last_name = document.getElementById("new-author-last").value.trim();
    const bio = document.getElementById("new-author-bio").value.trim();
    const modalAlert = document.getElementById("author-modal-alert");

    if (!first_name || !last_name) {
        modalAlert.innerHTML = `<div class="alert alert-danger py-2">First name and last name are required.</div>`;
        return;
    }

    try {
        const formData = new FormData();
        formData.append("operation", "add");
        formData.append("json", JSON.stringify({ first_name, last_name, bio }));

        const response = await axios({
            url: `${baseApiUrl}/author.php`,
            method: "POST",
            data: formData
        });

        if (response.data.status === "success") {
            document.getElementById("new-author-first").value = "";
            document.getElementById("new-author-last").value = "";
            document.getElementById("new-author-bio").value = "";
            modalAlert.innerHTML = "";

            await loadAuthors();

            const modalEl = document.getElementById("addAuthorModal");
            const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
            modal.hide();

            showAlert("Author added. You can now select them from the list.", "success");
        } else {
            modalAlert.innerHTML = `<div class="alert alert-danger py-2">${response.data.message}</div>`;
        }
    } catch (error) {
        modalAlert.innerHTML = `<div class="alert alert-danger py-2">Failed to add author.</div>`;
    }
};

/* ---------------- Save confirmation modal ---------------- */

// Snapshot of the form/selection at the moment of a successful save —
// captured before clearForm() resets everything, then shown in a modal.
const buildPreviewData = () => {
    const title = document.getElementById("title").value.trim();
    const year = document.getElementById("published_year").value.trim();
    const numCopies = document.getElementById("num_copies").value.trim();

    const publisherSelect = document.getElementById("publisher_id");
    const categorySelect = document.getElementById("category_id");

    const publisherText = publisherSelect.value ? publisherSelect.options[publisherSelect.selectedIndex].text : "—";
    const categoryText = categorySelect.value ? categorySelect.options[categorySelect.selectedIndex].text : "—";

    const authors = window._allAuthors || [];
    const authorNames = [...selectedAuthorIds]
        .map(id => authors.find(a => String(a.author_id) === id))
        .filter(Boolean)
        .map(a => `${a.first_name} ${a.last_name}`);

    return {
        title: title || "—",
        authors: authorNames.length ? authorNames.join(", ") : "—",
        publisher: publisherText || "—",
        category: categoryText || "—",
        type: document.getElementById("book_type").value || "—",
        year: year || "—",
        copies: numCopies || "—"
    };
};

const showPreviewModal = (data) => {
    document.getElementById("modal-prev-title").innerText = data.title;
    document.getElementById("modal-prev-authors").innerText = data.authors;
    document.getElementById("modal-prev-publisher").innerText = data.publisher;
    document.getElementById("modal-prev-category").innerText = data.category;
    document.getElementById("modal-prev-type").innerText = data.type;
    document.getElementById("modal-prev-year").innerText = data.year;
    document.getElementById("modal-prev-copies").innerText = data.copies;

    const modalEl = document.getElementById("bookSavedModal");
    const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
    modal.show();
};

/* ---------------- Books list (existing table below the form) ---------------- */

const loadRecords = async () => {
    try {
        const response = await axios.get(`${baseApiUrl}/book.php`, {
            params: { operation: "getAll" }
        });

        window._bookData = Array.isArray(response.data) ? response.data : [];
        renderRecords();

    } catch (error) {
        showAlert("Failed to load books.", "danger");
    }
};

// "2 available, 1 borrowed" badges for one book.
const copiesCell = (row) => {
    const total = Number(row.total_copies) || 0;
    if (total === 0) return '<span class="text-muted small">No copies</span>';

    const free = Number(row.available_copies) || 0;
    const out = Number(row.borrowed_copies) || 0;
    const lib = Number(row.library_copies) || 0;
    return `<span class="badge ${free > 0 ? "bg-success" : "bg-secondary"}">${free} available</span> ` +
           `<span class="badge ${out > 0 ? "bg-primary" : "bg-secondary"}">${out} borrowed</span> ` +
           `<span class="badge bg-info text-dark" title="Kept in the library. Can't be borrowed.">${lib} library use</span> ` +
           `<span class="text-muted small">of ${total}</span>`;
};

// Draws the table from window._bookData, narrowed by the search box and the filters.
const renderRecords = () => {
    const tbody = document.getElementById("table-body");
    const term = document.getElementById("book-search").value.trim().toLowerCase();
    const all = window._bookData || [];

    const availability = document.getElementById("filter-availability").value;
    const type = document.getElementById("filter-type").value;
    const category = document.getElementById("filter-category").value;
    const filtering = Boolean(term || availability || type || category);

    const rows = all.filter(row => {
        if (type && row.book_type !== type) return false;
        if (category && String(row.category_id) !== category) return false;
        if (availability === "available" && Number(row.available_copies) < 1) return false;
        if (availability === "borrowed" && Number(row.borrowed_copies) < 1) return false;

        if (!term) return true;
        const text = [row.title, row.publisher_name, row.category_type, row.book_type, row.published_year]
            .join(" ")
            .toLowerCase();
        return text.includes(term);
    });

    document.getElementById("book-count").innerText = filtering ? `${rows.length} of ${all.length}` : all.length;

    if (all.length === 0) {
        tbody.innerHTML = `<tr><td colspan="10" class="text-center text-muted py-4">No records found.</td></tr>`;
        return;
    }

    if (rows.length === 0) {
        tbody.innerHTML = `<tr><td colspan="10" class="text-center text-muted py-4">No books match your search or filters.</td></tr>`;
        return;
    }

    tbody.innerHTML = rows.map((row, index) => {
        const typeBadge = row.book_type
            ? `<span class="badge ${TYPE_BADGE[row.book_type] || "bg-secondary"}">${escapeHtml(row.book_type)}</span>`
            : '<span class="badge bg-danger">Not set</span>';

        return `
            <tr>
                <td class="text-muted">${index + 1}</td>
                <td class="fw-semibold">${escapeHtml(row.title)}</td>
                <td>${escapeHtml(row.publisher_name) || "—"}</td>
                <td>${escapeHtml(row.category_type) || "—"}</td>
                <td>${typeBadge}</td>
                <td>${loanLines(row.book_type)}</td>
                <td>${escapeHtml(row.published_year)}</td>
                <td class="text-nowrap">${row.price != null && row.price !== "" ? "₱" + Number(row.price).toLocaleString("en-PH", { minimumFractionDigits: 2 }) : '<span class="text-muted">Not set</span>'}</td>
                <td>${copiesCell(row)}</td>
                <td>
                    <div class="row-actions">
                        <button class="btn btn-outline-success btn-sm" onclick="openCopies(${row.book_id})">Condition</button>
                        <button class="btn btn-success btn-sm" onclick="editRecord(${row.book_id})">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deleteRecord(${row.book_id})">Delete</button>
                    </div>
                </td>
            </tr>
        `;
    }).join("");
};

const isValidBookTitle = value => {
    const trimmed = value.trim();
    if (trimmed.length < 2) return false;

    const isPureDigits = /^\d+$/.test(trimmed);
    if (!isPureDigits) return true;

    const num = parseInt(trimmed, 10);
    return trimmed.length === 4 && num >= 1000 && num <= 2099;
};

/* ---------------- Save (add = book + authors + copies, update = book fields only) ---------------- */

const saveRecord = async () => {
    const editingId = document.getElementById("editing-id").value.trim();
    const publisher_id = document.getElementById("publisher_id").value;
    const category_id = document.getElementById("category_id").value;
    const book_type = document.getElementById("book_type").value;
    const title = document.getElementById("title").value.trim();
    const published_year = document.getElementById("published_year").value.trim();
    const price = document.getElementById("price").value.trim();

    if (!publisher_id || !category_id || !book_type || !title || !published_year) {
        showAlert("Please fill in all required book fields.", "danger");
        return;
    }

    if (!isValidBookTitle(title)) {
        showAlert("Please enter a valid book title.", "danger");
        return;
    }

    if (!/^\d{4}$/.test(published_year)) {
        showAlert("A valid 4-digit published year is required.", "danger");
        return;
    }

    const bookJson = {
        publisher_id,
        category_id,
        book_type,
        title,
        published_year,
        price
    };

    if (editingId !== "") {
        // EDIT MODE: just update the book's own fields.
        try {
            bookJson.book_id = editingId;

            const formData = new FormData();
            formData.append("operation", "update");
            formData.append("json", JSON.stringify(bookJson));

            const response = await axios({
                url: `${baseApiUrl}/book.php`,
                method: "POST",
                data: formData
            });

            if (response.data.status === "success") {
                showAlert(response.data.message, "success");
                clearForm();
                loadRecords();
            } else {
                showAlert(response.data.message, "danger");
            }
        } catch (error) {
            showAlert("Failed to update book.", "danger");
        }
        return;
    }

    // ADD MODE: needs at least one author and valid copy settings too.
    const num_copies = parseInt(document.getElementById("num_copies").value, 10);
    const condition = document.getElementById("condition").value;
    const status_id = document.getElementById("status_id").value;

    if (selectedAuthorIds.size === 0) {
        showAlert("Please select at least one author.", "danger");
        return;
    }

    if (!num_copies || num_copies < 1) {
        showAlert("Number of copies must be at least 1.", "danger");
        return;
    }

    if (!condition || !status_id) {
        showAlert("Please select a condition and status for the book copies.", "danger");
        return;
    }

    const saveButton = document.getElementById("btn-save");
    saveButton.disabled = true;
    saveButton.innerText = "Saving...";

    // Snapshot form/selection now, before clearForm() wipes it.
    const previewData = buildPreviewData();

    try {
        // 1) Create the book
        const bookFormData = new FormData();
        bookFormData.append("operation", "add");
        bookFormData.append("json", JSON.stringify(bookJson));

        const bookResponse = await axios({
            url: `${baseApiUrl}/book.php`,
            method: "POST",
            data: bookFormData
        });

        if (bookResponse.data.status !== "success") {
            showAlert(bookResponse.data.message, "danger");
            return;
        }

        const newBookId = bookResponse.data.book_id;
        const errors = [];

        // 2) Link each selected author
        for (const authorId of selectedAuthorIds) {
            const formData = new FormData();
            formData.append("operation", "add");
            formData.append("json", JSON.stringify({ book_id: newBookId, author_id: authorId }));

            const res = await axios({ url: `${baseApiUrl}/book_author.php`, method: "POST", data: formData });
            if (res.data.status !== "success") {
                errors.push(`Author link: ${describeReply(res)}`);
            }
        }

        // 3) Create the requested number of copies (accession numbers auto-generated server-side)
        for (let i = 0; i < num_copies; i++) {
            const formData = new FormData();
            formData.append("operation", "add");
            formData.append("json", JSON.stringify({ book_id: newBookId, status_id, condition }));

            const res = await axios({ url: `${baseApiUrl}/book_copies.php`, method: "POST", data: formData });
            if (res.data.status !== "success") {
                errors.push(`Copy ${i + 1}: ${describeReply(res)}`);
            }
        }

        clearForm();
        loadRecords();

        if (errors.length === 0) {
            showPreviewModal(previewData);
        } else {
            showAlert(`Book saved, but some steps had issues: ${errors.join(" | ")}`, "danger");
        }

    } catch (error) {
        showAlert("Failed to save book.", "danger");
    } finally {
        saveButton.disabled = false;
        saveButton.innerText = "Save Book";
    }
};

/* ---------------- Edit / delete existing books ---------------- */

const editRecord = id => {
    const row = window._bookData.find(r => r.book_id == id);
    if (!row) return;

    document.getElementById("editing-id").value = id;
    document.getElementById("publisher_id").value = row.publisher_id;
    document.getElementById("category_id").value = row.category_id;
    document.getElementById("book_type").value = row.book_type || "";
    document.getElementById("title").value = row.title;
    document.getElementById("published_year").value = row.published_year;
    document.getElementById("price").value = row.price ?? "";

    // Editing only touches the book's own fields — hide the author/copy pickers,
    // which only apply when creating a brand new book.
    document.getElementById("add-mode-only-1").classList.add("d-none");
    document.getElementById("add-mode-only-2").classList.add("d-none");
    document.getElementById("copies-section").classList.add("d-none");

    document.getElementById("btn-save").innerText = "Update Book";
    document.getElementById("form-title").innerText = "Edit Book";

    window.scrollTo(0, 0);
};

const deleteRecord = async id => {
    if (!await lmsConfirm("Are you sure you want to delete this book?")) return;

    try {
        const formData = new FormData();
        formData.append("operation", "delete");
        formData.append("json", JSON.stringify({ book_id: id }));

        const response = await axios({
            url: `${baseApiUrl}/book.php`,
            method: "POST",
            data: formData
        });

        if (response.data.status === "success") {
            showAlert(response.data.message, "success");
            loadRecords();
        } else {
            showAlert(response.data.message, "danger");
        }

    } catch (error) {
        showAlert("Failed to delete book.", "danger");
    }
};

/* ---------------- Reset ---------------- */

const clearForm = () => {
    document.getElementById("editing-id").value = "";

    ["publisher_id", "category_id", "book_type", "condition"].forEach(id => {
        document.getElementById(id).value = "";
    });
    document.getElementById("status_id").value = availableStatusId;

    document.getElementById("title").value = "";
    document.getElementById("published_year").value = "";
    document.getElementById("price").value = "";
    document.getElementById("num_copies").value = "1";

    selectedAuthorIds = new Set();
    renderAuthorsTable(document.getElementById("author-search").value);
    renderSelectedChips();

    document.getElementById("add-mode-only-1").classList.remove("d-none");
    document.getElementById("add-mode-only-2").classList.remove("d-none");
    document.getElementById("copies-section").classList.remove("d-none");

    document.getElementById("btn-save").innerText = "Save Book";
    document.getElementById("form-title").innerText = "Add Book & Authors";
    document.getElementById("alert-box").innerHTML = "";
};

const apiMessage = (error, fallback) =>
    (error.response && error.response.data && error.response.data.message) || fallback;

const showAlert = (msg, type) => {
    const box = document.getElementById("alert-box");
    box.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert"><span></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
    box.querySelector("span").textContent = msg; // plain text, never HTML
};

window.editRecord = editRecord;
window.deleteRecord = deleteRecord;
window.toggleAuthor = toggleAuthor;

/* ---------------- Update the condition of a book's copies ---------------- */

const CONDITIONS = ["New", "Good", "Fair", "Poor"];
let modalCopies = [];

const copiesAlert = (msg, type) => {
    const box = document.getElementById("copies-alert");
    box.innerHTML = `<div class="alert alert-${type} py-2"></div>`;
    box.firstChild.textContent = msg; // plain text, never HTML
};

const renderCopiesModal = () => {
    const tbody = document.getElementById("copies-body");

    if (modalCopies.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">This book has no copies yet.</td></tr>';
        return;
    }

    tbody.innerHTML = modalCopies.map(c => {
        // Keep an unusual existing value selectable instead of silently changing it.
        const options = CONDITIONS.includes(c.condition) ? CONDITIONS : [c.condition, ...CONDITIONS];
        const select = options.map(o => `<option value="${escapeHtml(o)}" ${o === c.condition ? "selected" : ""}>${escapeHtml(o)}</option>`).join("");

        return `
            <tr>
                <td>ACC-${escapeHtml(c.accession_number)}</td>
                <td>${escapeHtml(c.status_desc)}</td>
                <td><select id="cond-${c.copy_id}" class="form-select form-select-sm">${select}</select></td>
                <td><button class="btn btn-success btn-sm" onclick="saveCopyCondition(${c.copy_id})">Save</button></td>
            </tr>`;
    }).join("");
};

// The copy API needs the whole record, so the unchanged fields are sent back as they are.
const sendCopyUpdate = async (copy, condition) => {
    const formData = new FormData();
    formData.append("operation", "update");
    formData.append("json", JSON.stringify({
        copy_id: copy.copy_id,
        book_id: copy.book_id,
        status_id: copy.status_id,
        accession_number: copy.accession_number,
        condition
    }));

    const res = await axios({ url: `${baseApiUrl}/book_copies.php`, method: "POST", data: formData });
    if (res.data.status === "success") copy.condition = condition;
    return res.data;
};

window.openCopies = async (bookId) => {
    const book = (window._bookData || []).find(b => b.book_id == bookId);
    document.getElementById("copies-book-title").textContent = book ? book.title : "";
    document.getElementById("copies-alert").innerHTML = "";
    document.getElementById("copies-body").innerHTML = '<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>';
    bootstrap.Modal.getOrCreateInstance(document.getElementById("copiesModal")).show();

    try {
        const res = await axios.get(`${baseApiUrl}/book_copies.php`, { params: { operation: "getAll" } });
        modalCopies = (Array.isArray(res.data) ? res.data : []).filter(c => c.book_id == bookId);
        renderCopiesModal();
    } catch (error) {
        document.getElementById("copies-body").innerHTML = '<tr><td colspan="4" class="text-center text-danger">Failed to load the copies.</td></tr>';
    }
};

window.saveCopyCondition = async (copyId) => {
    const copy = modalCopies.find(c => c.copy_id == copyId);
    if (!copy) return;

    try {
        const data = await sendCopyUpdate(copy, document.getElementById(`cond-${copyId}`).value);
        copiesAlert(data.status === "success" ? `ACC-${copy.accession_number} is now ${copy.condition}.` : data.message,
                    data.status === "success" ? "success" : "danger");
    } catch (error) {
        copiesAlert("Failed to update the condition.", "danger");
    }
};

const applyConditionToAll = async () => {
    if (modalCopies.length === 0) return;

    const condition = document.getElementById("cond-all").value;
    if (!await lmsConfirm(`Set all ${modalCopies.length} cop${modalCopies.length === 1 ? "y" : "ies"} to ${condition}?`)) return;

    let done = 0;
    for (const copy of modalCopies) {
        try {
            const data = await sendCopyUpdate(copy, condition);
            if (data.status === "success") done++;
        } catch (error) { /* counted as not updated */ }
    }

    renderCopiesModal();
    copiesAlert(`${done} of ${modalCopies.length} copies set to ${condition}.`, done === modalCopies.length ? "success" : "danger");
};