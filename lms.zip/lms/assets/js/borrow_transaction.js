const baseApiUrl = "api"; // relative to the page, so it works from any folder
const API = `${baseApiUrl}/borrow_transaction.php`;

const BORROWER_PAGE_SIZE = 8;
const COPY_PAGE_SIZE = 10;
const TX_PAGE_SIZE = 10;
const LAST_USER_KEY = "lms_last_processed_by";

/* ---------------- State ---------------- */

const state = {
    borrowers: { search: "", type: "all", available: false, sort: "name", page: 1, pages: 1, total: 0, rows: [] },
    selected: null,         // borrower open on the right (from getBorrower)
    out: [],                // books that borrower already has out
    copies: { search: "", type: "all", page: 1, pages: 1, total: 0, totalCopies: 0, rows: [] },
    picked: new Map(),      // copy_id -> copy, kept across searches and pages
    openBooks: new Set(),   // book_ids whose copies are shown in the picker
    plan: null,             // latest answer from the "preview" operation
    editMax: {},            // copy_id -> {due_date, period, ...} allowed while editing a transaction
    editRow: null,          // the transaction row open in the edit dialog
    users: [],
    statuses: [],
    tx: { search: "", state: "", from: "", to: "", page: 1, pages: 1, total: 0, rows: [], loaded: false }
};

let borrowerRequest = 0;
let copyRequest = 0;
let planRequest = 0;
let txRequest = 0;
let confirmModal = null;
let editModal = null;

/* ---------------- Helpers ---------------- */

const $ = (id) => document.getElementById(id);

const escapeHtml = (value) => {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
};

const todayString = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const fmtDate = (value) => {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(value || "");
    if (!m) return "—";
    return `${MONTHS[Number(m[2]) - 1]} ${Number(m[3])}, ${m[1]}`;
};

const debounce = (fn, wait = 300) => {
    let timer;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => fn(...args), wait);
    };
};

const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

const toast = (message, type = "success") => {
    const area = $("toast-area");
    const el = document.createElement("div");
    el.className = `toast align-items-center text-bg-${type} border-0`;
    el.setAttribute("role", type === "danger" ? "alert" : "status");
    el.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${escapeHtml(message)}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>`;
    area.appendChild(el);

    const t = new bootstrap.Toast(el, { delay: type === "danger" ? 8000 : 4000 });
    el.addEventListener("hidden.bs.toast", () => el.remove());
    t.show();
};

const apiGet = async (operation, params = {}, url = API) => {
    const response = await axios.get(url, { params: { operation, ...params } });
    return response.data;
};

const apiPost = async (operation, payload, url = API) => {
    const formData = new FormData();
    formData.append("operation", operation);
    formData.append("json", JSON.stringify(payload));

    const response = await axios({ url, method: "POST", data: formData });
    return response.data;
};

const typeBadge = (isFaculty) =>
    Number(isFaculty) === 1
        ? `<span class="badge bg-primary">Faculty</span>`
        : `<span class="badge bg-secondary">Student</span>`;

const bookTypeBadge = (t) =>
    t ? ` <span class="badge bg-light text-dark border">${escapeHtml(t)}</span>` : "";

const dueBadge = (days) => {
    if (days === null || days === undefined) return `<span class="badge bg-secondary">No due date</span>`;
    if (days > 0) return `<span class="badge bg-danger">Overdue ${days} ${days === 1 ? "day" : "days"}</span>`;
    if (days === 0) return `<span class="badge bg-warning text-dark">Due today</span>`;
    return `<span class="badge bg-light text-dark border">${-days} ${-days === 1 ? "day" : "days"} left</span>`;
};

const txBadge = (s) => ({
    open: `<span class="badge bg-primary">Books out</span>`,
    overdue: `<span class="badge bg-danger">Overdue</span>`,
    completed: `<span class="badge bg-success">All returned</span>`,
    empty: `<span class="badge bg-secondary">No books</span>`
}[s] || `<span class="badge bg-secondary">${escapeHtml(s)}</span>`);

// Slots this borrower can still fill: allowed limit minus books out minus books already picked.
const slotsLeft = () => {
    if (!state.selected) return 0;
    return state.selected.borrow_limit - state.selected.books_out - state.picked.size;
};

/* ---------------- Boot ---------------- */

document.addEventListener("DOMContentLoaded", () => {
    confirmModal = new bootstrap.Modal($("confirmModal"));
    editModal = new bootstrap.Modal($("editModal"));


    wireBorrowerFilters();
    wireCopyFilters();
    wireTransactionFilters();
    wireKeyboard();

    $("btn-borrow").addEventListener("click", openConfirm);
    $("btn-confirm-borrow").addEventListener("click", submitBorrow);
    $("btn-pick-none").addEventListener("click", () => { state.picked.clear(); onPicksChanged(); });
    $("panel-close").addEventListener("click", closeBorrower);
    $("btn-save-edit").addEventListener("click", saveEdit);
    $("tab-history-btn").addEventListener("shown.bs.tab", loadTransactions);

    $("edit-borrow").addEventListener("change", refreshEditPlan);
    $("edit-items").addEventListener("change", (e) => {
        const input = e.target.closest(".edit-item-due");
        if (input) onEditDueChange(input);
    });
    $("processed-by").addEventListener("change", (e) => {
        try { localStorage.setItem(LAST_USER_KEY, e.target.value); } catch (err) { /* storage unavailable */ }
    });

    $("card-overdue").addEventListener("click", () => {
        $("tx-state").value = "overdue";
        state.tx.state = "overdue";
        state.tx.page = 1;
        $("tab-history-btn").click();
        if (state.tx.loaded) loadTransactions();
    });

    loadUsersAndStatuses();

    // Deep link: borrow_transaction.html?student=12 (or f5 for faculty) opens that borrower.
    const linked = new URLSearchParams(window.location.search).get("student");

    loadBorrowers().then(() => {
        if (linked) selectBorrower(linked, false);
    });
});

const loadUsersAndStatuses = async () => {
    try {
        const [users, statuses] = await Promise.all([
            window.authReady.then((me) => [me]),
            apiGet("getAll", {}, `${baseApiUrl}/status.php`)
        ]);

        state.users = Array.isArray(users) ? users : [];
        state.statuses = Array.isArray(statuses) ? statuses : [];

        const userOptions = state.users
            .map((u) => `<option value="${u.user_id}">${escapeHtml(u.first_name)} ${escapeHtml(u.last_name)}</option>`)
            .join("");

        // Processed-by is always the signed-in user; the server fills it in from the session.
        $("processed-by").innerHTML = userOptions;
        $("processed-by").disabled = true;
        $("edit-processed").innerHTML = userOptions;
        $("edit-processed").disabled = true;
        $("edit-status").innerHTML = state.statuses
            .map((s) => `<option value="${s.status_id}">${escapeHtml(s.status_desc)}</option>`)
            .join("");

        try {
            const last = localStorage.getItem(LAST_USER_KEY);
            if (last && state.users.some((u) => String(u.user_id) === last)) {
                $("processed-by").value = last;
            }
        } catch (err) { /* storage unavailable */ }
    } catch (error) {
        toast("Failed to load users and statuses.", "danger");
    }
};

/* ---------------- Step 1: borrower list ---------------- */

const wireBorrowerFilters = () => {
    const search = debounce(() => {
        state.borrowers.search = $("borrower-search").value.trim();
        state.borrowers.page = 1;
        loadBorrowers();
    });

    $("borrower-search").addEventListener("input", search);

    $("btn-search-clear").addEventListener("click", () => {
        $("borrower-search").value = "";
        state.borrowers.search = "";
        state.borrowers.page = 1;
        loadBorrowers();
        $("borrower-search").focus();
    });

    document.querySelectorAll("input[name='type-filter']").forEach((radio) => {
        radio.addEventListener("change", () => {
            state.borrowers.type = radio.value;
            state.borrowers.page = 1;
            loadBorrowers();
        });
    });

    $("filter-available").addEventListener("change", (e) => {
        state.borrowers.available = e.target.checked;
        state.borrowers.page = 1;
        loadBorrowers();
    });

    $("borrower-sort").addEventListener("change", (e) => {
        state.borrowers.sort = e.target.value;
        state.borrowers.page = 1;
        loadBorrowers();
    });

    $("borrower-prev").addEventListener("click", () => {
        if (state.borrowers.page > 1) { state.borrowers.page--; loadBorrowers(); }
    });

    $("borrower-next").addEventListener("click", () => {
        if (state.borrowers.page < state.borrowers.pages) { state.borrowers.page++; loadBorrowers(); }
    });

    $("borrower-list").addEventListener("click", (e) => {
        const row = e.target.closest(".borrower-item");
        if (row) selectBorrower(row.dataset.key, true);
    });
};

const wireKeyboard = () => {
    document.addEventListener("keydown", (e) => {
        const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName);

        if (e.key === "/" && !typing && !e.ctrlKey && !e.metaKey) {
            e.preventDefault();
            $("tab-borrow-btn").click();
            $("borrower-search").focus();
            $("borrower-search").select();
        }
    });

    $("borrower-search").addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
            e.preventDefault();
            // Enter opens the first match, so quick typing is enough.
            state.borrowers.search = $("borrower-search").value.trim();
            state.borrowers.page = 1;
            loadBorrowers().then(() => {
                if (state.borrowers.rows.length > 0) {
                    selectBorrower(state.borrowers.rows[0].borrower_key, true);
                }
            });
        } else if (e.key === "Escape") {
            $("btn-search-clear").click();
        }
    });
};

const loadBorrowers = async () => {
    const b = state.borrowers;
    const request = ++borrowerRequest;

    $("borrower-list").innerHTML = `<div class="list-group-item text-center text-muted py-4">Loading...</div>`;

    try {
        const data = await apiGet("getBorrowers", {
            search: b.search,
            type: b.type,
            available: b.available ? 1 : 0,
            sort: b.sort,
            page: b.page,
            limit: BORROWER_PAGE_SIZE
        });

        if (request !== borrowerRequest) return; // a newer search is already on its way

        if (!data || !Array.isArray(data.rows)) {
            throw new Error((data && data.message) || "Unexpected response");
        }

        if (data.rows.length === 0 && data.total > 0 && b.page > 1) {
            b.page = data.pages;
            return loadBorrowers();
        }

        b.rows = data.rows;
        b.total = data.total;
        b.pages = data.pages;
        b.page = data.page;

        renderSummary(data.summary);
        renderBorrowers();
    } catch (error) {
        if (request !== borrowerRequest) return;
        $("borrower-list").innerHTML = `<div class="list-group-item text-center text-danger py-4">Could not load borrowers.</div>`;
        toast("Failed to load borrowers.", "danger");
    }
};

const renderSummary = (summary) => {
    if (!summary) return;
    $("sum-borrowers").innerText = summary.borrowers;
    $("sum-books").innerText = summary.books_out;
    $("sum-overdue").innerText = summary.overdue_books;
    $("sum-available").innerText = summary.available_copies;
};

const renderBorrowers = () => {
    const b = state.borrowers;
    const list = $("borrower-list");
    const filtering = b.search || b.type !== "all" || b.available;

    $("borrower-count").innerText = b.total === 0
        ? ""
        : `${plural(b.total, "borrower", "borrowers")}${filtering ? " match your filters" : ""}`;

    $("borrower-page").innerText = `Page ${b.page} of ${b.pages}`;
    $("borrower-prev").disabled = b.page <= 1;
    $("borrower-next").disabled = b.page >= b.pages;

    if (b.rows.length === 0) {
        list.innerHTML = `
            <div class="list-group-item text-center text-muted py-4">
                ${filtering
                    ? "No borrower matches these filters.<br><span class='small'>Try fewer words, or clear the filters.</span>"
                    : "No borrowers yet. Add students or faculty first."}
            </div>`;
        return;
    }

    const activeKey = state.selected ? String(state.selected.borrower_key) : "";

    list.innerHTML = b.rows.map((row) => {
        const detail = Number(row.is_faculty) === 1 ? (row.department_name || "") : (row.course || "");
        const line = [detail, row.email].filter(Boolean).join(" · ");
        const out = Number(row.books_out);
        const limit = Number(row.borrow_limit);
        const overdue = Number(row.overdue_count);
        const full = out >= limit;

        return `
            <button type="button" class="list-group-item list-group-item-action borrower-item ${String(row.borrower_key) === activeKey ? "active" : ""}"
                    data-key="${escapeHtml(row.borrower_key)}">
                <div class="d-flex justify-content-between align-items-start gap-2">
                    <div class="min-w-0">
                        <div class="fw-semibold">${escapeHtml(row.first_name)} ${escapeHtml(row.last_name)} ${typeBadge(row.is_faculty)}</div>
                        <div class="small text-muted text-truncate">${escapeHtml(line) || "&nbsp;"}</div>
                        ${row.phone ? `<div class="small text-muted">${escapeHtml(row.phone)}</div>` : ""}
                    </div>
                    <div class="text-end flex-shrink-0">
                        <div><span class="badge ${full ? "bg-danger" : "bg-dark"}">${out} / ${limit} out</span></div>
                        ${overdue > 0 ? `<div class="mt-1"><span class="badge bg-danger">${overdue} overdue</span></div>` : ""}
                    </div>
                </div>
            </button>`;
    }).join("");
};

/* ---------------- Step 2: borrower panel ---------------- */

const normalizeBorrower = (b) => {
    b.books_out = Number(b.books_out);
    b.borrow_limit = Number(b.borrow_limit);
    b.overdue_count = Number(b.overdue_count);
    return b;
};

const selectBorrower = async (key, scroll) => {
    try {
        const data = await apiGet("getBorrower", { key });

        if (data.status !== "success") {
            toast(data.message || "Could not open this borrower.", "danger");
            return;
        }

        const changed = !state.selected || state.selected.borrower_key !== data.borrower.borrower_key;

        state.selected = normalizeBorrower(data.borrower);
        state.out = data.items;

        const url = new URL(window.location);
        url.searchParams.set("student", state.selected.borrower_key);
        window.history.replaceState({}, "", url);

        renderBorrowers();
        renderPanel();

        // Load the shelf the first time a borrower is opened.
        if (state.copies.rows.length === 0) loadCopies();

        refreshPlan();

        if (scroll && window.innerWidth < 992) {
            $("borrow-panel").scrollIntoView({ behavior: "smooth", block: "start" });
        }
    } catch (error) {
        toast("Failed to load this borrower.", "danger");
    }
};

const closeBorrower = () => {
    state.selected = null;
    state.out = [];
    state.picked.clear();
    state.plan = null;

    const url = new URL(window.location);
    url.searchParams.delete("student");
    window.history.replaceState({}, "", url);

    renderBorrowers();
    renderPanel();
    $("borrower-search").focus();
};

const renderPanel = () => {
    const b = state.selected;

    $("panel-empty").classList.toggle("d-none", !!b);
    $("panel-main").classList.toggle("d-none", !b);

    if (!b) return;

    const detail = Number(b.is_faculty) === 1 ? b.department_name : b.course;
    $("b-name").innerHTML = `${escapeHtml(b.first_name)} ${escapeHtml(b.last_name)} ${typeBadge(b.is_faculty)}`;
    $("b-contact").innerText = [detail, b.email, b.phone].filter(Boolean).join(" · ");

    const wrap = $("b-out-wrap");
    wrap.classList.toggle("d-none", state.out.length === 0);
    $("b-out").innerHTML = state.out.map((i) => `
        <li class="list-group-item d-flex justify-content-between align-items-center gap-2">
            <span>${escapeHtml(i.title)} <span class="text-muted">[ACC-${escapeHtml(i.accession_number)}]</span></span>
            <span class="text-nowrap">${escapeHtml(fmtDate(i.due_date))} ${dueBadge(i.days_overdue)}</span>
        </li>`).join("");

    renderLimit();
    renderCopies();
    renderTray();
};

const renderLimit = () => {
    const b = state.selected;
    if (!b) return;

    const left = slotsLeft();
    const over = left < 0;
    const cls = over ? "danger" : (left === 0 ? "warning" : "success");

    $("b-limit").innerHTML = `
        <span class="badge text-bg-${cls}">
            ${b.books_out} out${state.picked.size ? ` + ${state.picked.size} selected` : ""} of ${b.borrow_limit} allowed
        </span>
        <span class="small text-muted ms-1">
            ${over
                ? `Too many books selected. Remove ${-left}.`
                : (left === 0 ? "No more books can be added." : `${plural(left, "more book", "more books")} can be added.`)}
        </span>
        ${b.overdue_count > 0 ? `<span class="badge bg-danger ms-1">${b.overdue_count} overdue</span>` : ""}`;
};

/* ---------------- Book picker ---------------- */

const wireCopyFilters = () => {
    const search = debounce(() => {
        state.copies.search = $("copy-search").value.trim();
        state.copies.page = 1;
        loadCopies();
    });

    $("copy-search").addEventListener("input", search);

    $("copy-type").addEventListener("change", (e) => {
        state.copies.type = e.target.value;
        state.copies.page = 1;
        loadCopies();
    });

    $("copy-prev").addEventListener("click", () => {
        if (state.copies.page > 1) { state.copies.page--; loadCopies(); }
    });

    $("copy-next").addEventListener("click", () => {
        if (state.copies.page < state.copies.pages) { state.copies.page++; loadCopies(); }
    });

    $("copy-search").addEventListener("keydown", async (e) => {
        if (e.key === "Escape") {
            $("copy-search").value = "";
            state.copies.search = "";
            state.copies.page = 1;
            loadCopies();
            return;
        }

        if (e.key !== "Enter") return;
        e.preventDefault();

        // Make sure the list matches what was typed (the search is debounced).
        state.copies.search = $("copy-search").value.trim();
        state.copies.page = 1;
        await loadCopies();

        const term = state.copies.search.toLowerCase();
        const rows = state.copies.rows;
        const exact = rows.find((c) => String(c.accession_number).toLowerCase() === term);
        const target = exact || (rows.length === 1 ? rows[0] : null);

        if (!target) {
            if (rows.length > 1) toast("More than one copy matches. Tick the one you want, or type its full accession number.", "warning");
            return;
        }

        if (!state.picked.has(String(target.copy_id))) {
            togglePick(target);
        }

        // Ready for the next scan.
        $("copy-search").value = "";
        state.copies.search = "";
        loadCopies();
        $("copy-search").focus();
    });

    $("copies-body").addEventListener("click", (e) => {
        if (e.target.closest("a, button")) return;

        // A copy row: tick or untick that exact copy.
        const copyRow = e.target.closest("tr[data-copy]");
        if (copyRow) {
            const copy = state.copies.rows.find((c) => String(c.copy_id) === copyRow.dataset.copy);
            if (copy) togglePick(copy);
            return;
        }

        const bookRow = e.target.closest("tr[data-book]");
        if (!bookRow) return;
        const id = bookRow.dataset.book;
        const copies = copiesOfBook(id);

        // The book's own tick box: borrow one copy, or put every picked copy of it back.
        if (e.target.closest(".book-check")) {
            e.stopPropagation();
            const mine = copies.filter((c) => state.picked.has(String(c.copy_id)));
            if (mine.length > 0) {
                mine.forEach((c) => state.picked.delete(String(c.copy_id)));
                onPicksChanged();
            } else if (copies[0]) {
                togglePick(copies[0]);
            }
            return;
        }

        // Anywhere else on the book row: open or close its copies.
        if (state.openBooks.has(id)) state.openBooks.delete(id); else state.openBooks.add(id);
        renderCopies();
    });

    $("pick-header").addEventListener("change", (e) => {
        // One copy of every book on this page (open a book to choose a specific copy).
        const groups = groupCopies(state.copies.rows);
        if (e.target.checked) {
            let skipped = 0;
            groups.forEach((g) => {
                if (g.copies.some((c) => state.picked.has(String(c.copy_id)))) return;
                if (slotsLeft() <= 0) { skipped++; return; }
                state.picked.set(String(g.copies[0].copy_id), g.copies[0]);
            });
            if (skipped > 0) toast(`Only ${plural(groups.length - skipped, "book", "books")} could be added: the borrowing limit was reached.`, "warning");
        } else {
            state.copies.rows.forEach((c) => state.picked.delete(String(c.copy_id)));
        }
        onPicksChanged();
    });

    $("tray").addEventListener("click", (e) => {
        const btn = e.target.closest("button[data-remove]");
        if (!btn) return;
        state.picked.delete(btn.dataset.remove);
        onPicksChanged();
    });
};

const loadCopies = async () => {
    const c = state.copies;
    const request = ++copyRequest;

    try {
        const data = await apiGet("getAvailableCopies", {
            search: c.search,
            type: c.type,
            page: c.page,
            limit: COPY_PAGE_SIZE
        });

        if (request !== copyRequest) return;

        if (!data || !Array.isArray(data.rows)) {
            throw new Error((data && data.message) || "Unexpected response");
        }

        if (data.rows.length === 0 && data.total > 0 && c.page > 1) {
            c.page = data.pages;
            return loadCopies();
        }

        Object.assign(c, { rows: data.rows, total: data.total, totalCopies: data.total_copies ?? data.rows.length, pages: data.pages, page: data.page });
        renderCopies();
    } catch (error) {
        if (request !== copyRequest) return;
        $("copies-body").innerHTML = `<tr><td colspan="4" class="text-center text-danger">Could not load available books.</td></tr>`;
        toast("Failed to load available books.", "danger");
    }
};

// One entry per book, in the order the server sent them.
const groupCopies = (rows) => {
    const groups = new Map();
    rows.forEach((row) => {
        const key = String(row.book_id);
        if (!groups.has(key)) groups.set(key, { key, first: row, copies: [] });
        groups.get(key).copies.push(row);
    });
    return [...groups.values()];
};

const copiesOfBook = (bookId) => state.copies.rows.filter((c) => String(c.book_id) === String(bookId));

const renderCopies = () => {
    const c = state.copies;
    const tbody = $("copies-body");
    const filtering = c.search || c.type !== "all";

    $("copy-count").innerText = c.total === 0
        ? ""
        : `${plural(c.total, "book", "books")} (${plural(c.totalCopies, "copy", "copies")}) on the shelf${filtering ? " match your search" : ""}. Click a book to see its copies.`;

    $("copy-page").innerText = `Page ${c.page} of ${c.pages}`;
    $("copy-prev").disabled = c.page <= 1;
    $("copy-next").disabled = c.page >= c.pages;

    if (c.rows.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" class="text-center text-muted py-4">${filtering ? "No available copy matches your search." : "No copies are available right now."}</td></tr>`;
        updatePickHeader();
        return;
    }

    tbody.innerHTML = groupCopies(c.rows).map((g) => {
        const row = g.first;
        const sub = [row.authors, row.category_type].filter(Boolean).join(" · ");
        const pickedHere = g.copies.filter((x) => state.picked.has(String(x.copy_id))).length;
        const open = Boolean(c.search) || state.openBooks.has(g.key);

        const head = `
            <tr data-book="${escapeHtml(g.key)}" class="book-row ${pickedHere ? "picked" : ""}" aria-expanded="${open}">
                <td><input type="checkbox" class="form-check-input book-check" ${pickedHere ? "checked" : ""}
                           aria-label="Borrow one copy of ${escapeHtml(row.title)}"></td>
                <td>
                    <div class="fw-semibold"><span class="caret me-2">${open ? "▼" : "▶"}</span>${escapeHtml(row.title)}${bookTypeBadge(row.book_type)}</div>
                    ${sub ? `<div class="small text-muted ms-4">${escapeHtml(sub)}</div>` : ""}
                </td>
                <td class="text-nowrap"><span class="badge bg-secondary">${plural(g.copies.length, "copy", "copies")}</span></td>
                <td class="text-nowrap">${pickedHere ? `<span class="badge bg-success">${pickedHere} selected</span>` : ""}</td>
            </tr>`;

        const copies = g.copies.map((copy) => {
            const on = state.picked.has(String(copy.copy_id));
            return `
            <tr data-copy="${copy.copy_id}" data-of="${escapeHtml(g.key)}" class="copy-row ${on ? "picked" : ""} ${open ? "" : "d-none"}">
                <td><input type="checkbox" class="form-check-input copy-check" ${on ? "checked" : ""} aria-label="Select copy ACC-${escapeHtml(copy.accession_number)}"></td>
                <td class="ps-5 text-muted small">Copy</td>
                <td class="text-nowrap">ACC-${escapeHtml(copy.accession_number)}</td>
                <td>${escapeHtml(copy.condition)}</td>
            </tr>`;
        }).join("");

        return head + copies;
    }).join("");

    updatePickHeader();
};

const updatePickHeader = () => {
    const groups = groupCopies(state.copies.rows);
    const header = $("pick-header");
    const picked = groups.filter((g) => g.copies.some((c) => state.picked.has(String(c.copy_id)))).length;

    header.checked = groups.length > 0 && picked === groups.length;
    header.indeterminate = picked > 0 && picked < groups.length;
};

const togglePick = (copy) => {
    const key = String(copy.copy_id);

    if (state.picked.has(key)) {
        state.picked.delete(key);
    } else {
        if (!state.selected) {
            toast("Select a borrower first so the borrowing limit can be checked.", "danger");
            return;
        }

        if (slotsLeft() <= 0) {
            toast(`${Number(state.selected.is_faculty) === 1 ? "Faculty" : "Student"} limit is ${state.selected.borrow_limit} books at a time (${state.selected.books_out} already out). You can't add more.`, "danger");
            renderCopies();
            return;
        }

        state.picked.set(key, copy);
    }

    onPicksChanged();
};

const onPicksChanged = () => {
    renderCopies();
    renderTray();
    renderLimit();
    refreshPlan();
};

/* ---------------- Selected books, due date and plan ---------------- */

// The latest due date allowed for one picked book (from the loan rules), or null while unknown.
const planBook = (copyId) => (state.plan ? state.plan.books.find((b) => String(b.copy_id) === String(copyId)) : null) || null;

// The due date that will be saved for a picked book: always the longest loan allowed for THAT book.
const effectiveDue = (copyId) => {
    const p = planBook(copyId);
    return p ? p.due_date : "";
};

const renderTray = () => {
    $("tray-count").innerText = state.picked.size;

    const tray = $("tray");

    if (state.picked.size === 0) {
        tray.innerHTML = `<div class="list-group-item text-muted small">None selected yet. Tick books above.</div>`;
    } else {
        tray.innerHTML = [...state.picked.values()].map((c) => {
            const p = planBook(c.copy_id);

            const dueField = p
                ? `<span class="text-muted">Due</span> <span class="fw-semibold">${escapeHtml(fmtDate(effectiveDue(c.copy_id)))}</span>`
                : `<span class="text-muted">Checking the due date...</span>`;

            return `
                <div class="list-group-item tray-item">
                    <div class="d-flex justify-content-between align-items-start gap-2">
                        <div class="min-w-0">
                            <div class="fw-semibold">${escapeHtml(c.title)}${bookTypeBadge(c.book_type)}</div>
                            <div class="small text-muted">ACC-${escapeHtml(c.accession_number)}</div>
                        </div>
                        <button class="btn btn-sm btn-outline-secondary flex-shrink-0" type="button" data-remove="${c.copy_id}">Remove</button>
                    </div>
                    <div class="d-flex flex-wrap align-items-center gap-2 mt-1 small">${dueField}</div>
                </div>`;
        }).join("");
    }

    updateBorrowButton();
};

const updateBorrowButton = () => {
    const btn = $("btn-borrow");
    btn.innerText = `Borrow selected (${state.picked.size})`;
    btn.disabled = !state.selected || state.picked.size === 0 || slotsLeft() < 0;
};

const refreshPlan = async () => {
    const request = ++planRequest;

    if (!state.selected || state.picked.size === 0) {
        state.plan = null;
        renderPlan();
        return;
    }

    try {
        const data = await apiPost("preview", {
            student_id: state.selected.borrower_key,
            copy_ids: [...state.picked.keys()].map(Number)
        });

        if (request !== planRequest) return;

        if (data.status !== "success") {
            state.plan = null;
            renderPlan(data.message);
            return;
        }

        state.plan = data.plan;
        renderPlan();
        renderTray();
    } catch (error) {
        if (request !== planRequest) return;
        state.plan = null;
        renderPlan("Failed to check the borrowing rules.");
    }
};

const renderPlan = (errorMessage) => {
    const box = $("plan-box");
    const p = state.plan;

    if (errorMessage) {
        box.className = "alert alert-danger py-2 mb-3";
        box.innerText = errorMessage;
    } else if (!p) {
        box.className = "alert alert-secondary py-2 mb-3";
        box.innerText = state.picked.size === 0
            ? "Select at least one book to see the due dates."
            : "Checking the borrowing rules...";
    } else {
        // One line per book type, so a mixed loan shows both periods side by side.
        const periods = {};
        p.books.forEach((b) => { periods[b.book_type || "Other"] = b.period; });
        const parts = Object.entries(periods).map(([type, period]) => `${escapeHtml(type)}: up to ${escapeHtml(period)}`);
        const mixed = parts.length > 1;

        box.className = "alert alert-info py-2 mb-3";
        box.innerHTML = `
            <strong>${escapeHtml(p.borrower_type)}</strong> &middot; ${parts.join(" &middot; ")}.
            ${mixed ? "<strong>Each book keeps its own due date.</strong>" : ""}`;
    }

    updateBorrowButton();
};

/* ---------------- Confirm and save ---------------- */

const openConfirm = () => {
    const b = state.selected;
    const userId = $("processed-by").value;

    if (!b || state.picked.size === 0) {
        toast("Select at least one book to borrow.", "danger");
        return;
    }

    if (!userId) {
        toast("Could not tell who is processing this borrow. Please sign in again.", "danger");
        return;
    }

    if (!state.plan) {
        toast("Still checking the borrowing rules. Try again in a moment.", "danger");
        return;
    }

    if (slotsLeft() < 0) {
        toast("Too many books selected for this borrower.", "danger");
        return;
    }

    const user = state.users.find((u) => String(u.user_id) === String(userId));
    const books = [...state.picked.values()];
    const dues = books.map((c) => effectiveDue(c.copy_id));
    const differ = new Set(dues).size > 1;

    $("confirm-body").innerHTML = `
        <p class="mb-2">
            ${plural(books.length, "book", "books")} for <strong>${escapeHtml(b.first_name)} ${escapeHtml(b.last_name)}</strong>
            ${typeBadge(b.is_faculty)}, borrowed today.
            ${differ ? "Each book has its own due date." : `All due <strong>${escapeHtml(fmtDate(dues[0]))}</strong>.`}
        </p>
        <p class="small text-muted">Processed by ${escapeHtml(user ? `${user.first_name} ${user.last_name}` : "")}.
            After this ${escapeHtml(b.first_name)} will have ${b.books_out + books.length} of ${b.borrow_limit} books out.</p>
        <div class="table-responsive">
            <table class="table table-sm align-middle mb-0">
                <thead><tr><th>Book</th><th>Accession No.</th><th>Condition</th><th>Due date</th></tr></thead>
                <tbody>
                    ${books.map((c) => `
                        <tr>
                            <td>${escapeHtml(c.title)}${bookTypeBadge(c.book_type)}</td>
                            <td class="text-nowrap">ACC-${escapeHtml(c.accession_number)}</td>
                            <td>${escapeHtml(c.condition)}</td>
                            <td class="text-nowrap fw-semibold">${escapeHtml(fmtDate(effectiveDue(c.copy_id)))}</td>
                        </tr>`).join("")}
                </tbody>
            </table>
        </div>`;

    confirmModal.show();
};

const submitBorrow = async () => {
    const btn = $("btn-confirm-borrow");
    btn.disabled = true;

    try {
        const due_dates = {};
        [...state.picked.keys()].forEach((k) => {
            const d = effectiveDue(k);
            if (d) due_dates[k] = d;
        });

        const result = await apiPost("borrow", {
            student_id: state.selected.borrower_key,
            processed_by_user_id: $("processed-by").value,
            due_dates,
            copy_ids: [...state.picked.keys()].map(Number)
        });

        confirmModal.hide();

        if (result.status === "success") {
            toast(result.message, "success");
            state.picked.clear();
            state.plan = null;
                } else {
            toast(result.message, "danger");
        }

        // Always refresh: on a failure the shelf may have changed, which is often why it failed.
        await refreshAfterChange();
    } catch (error) {
        confirmModal.hide();
        toast("Failed to save the borrow transaction.", "danger");
    } finally {
        btn.disabled = false;
    }
};

const refreshAfterChange = async () => {
    const jobs = [loadBorrowers(), loadCopies()];

    if (state.selected) {
        jobs.push(selectBorrower(state.selected.borrower_key, false));
    }

    if (state.tx.loaded) jobs.push(loadTransactions());

    await Promise.all(jobs);
    onPicksChanged();
};

/* ---------------- Transactions tab ---------------- */

const wireTransactionFilters = () => {
    const reload = () => {
        state.tx.page = 1;
        loadTransactions();
    };

    const search = debounce(() => {
        state.tx.search = $("tx-search").value.trim();
        reload();
    });

    $("tx-search").addEventListener("input", search);
    $("tx-state").addEventListener("change", (e) => { state.tx.state = e.target.value; reload(); });
    $("tx-from").addEventListener("change", (e) => { state.tx.from = e.target.value; reload(); });
    $("tx-to").addEventListener("change", (e) => { state.tx.to = e.target.value; reload(); });

    $("tx-reset").addEventListener("click", () => {
        $("tx-search").value = "";
        $("tx-state").value = "";
        $("tx-from").value = "";
        $("tx-to").value = "";
        Object.assign(state.tx, { search: "", state: "", from: "", to: "", page: 1 });
        loadTransactions();
    });

    $("tx-prev").addEventListener("click", () => {
        if (state.tx.page > 1) { state.tx.page--; loadTransactions(); }
    });

    $("tx-next").addEventListener("click", () => {
        if (state.tx.page < state.tx.pages) { state.tx.page++; loadTransactions(); }
    });

    $("tx-body").addEventListener("click", (e) => {
        const btn = e.target.closest("[data-action]");
        if (!btn) return;

        if (btn.dataset.action === "edit") openEdit(btn.dataset.id);
        if (btn.dataset.action === "delete") deleteTransaction(btn.dataset.id);
        if (btn.dataset.action === "more") {
            const extra = btn.parentElement.querySelector(".more-items");
            const open = extra.classList.toggle("d-none") === false;
            btn.innerText = open ? "Show less" : btn.dataset.label;
        }
        if (btn.dataset.action === "borrower") {
            $("tab-borrow-btn").click();
            selectBorrower(btn.dataset.key, true);
        }
    });
};

const loadTransactions = async () => {
    const t = state.tx;
    const request = ++txRequest;

    try {
        const data = await apiGet("getTransactions", {
            search: t.search,
            state: t.state,
            from: t.from,
            to: t.to,
            page: t.page,
            limit: TX_PAGE_SIZE
        });

        if (request !== txRequest) return;

        if (!data || !Array.isArray(data.rows)) {
            throw new Error((data && data.message) || "Unexpected response");
        }

        if (data.rows.length === 0 && data.total > 0 && t.page > 1) {
            t.page = data.pages;
            return loadTransactions();
        }

        Object.assign(t, { rows: data.rows, total: data.total, pages: data.pages, page: data.page, loaded: true });
        renderTransactions();
    } catch (error) {
        if (request !== txRequest) return;
        $("tx-body").innerHTML = `<tr><td colspan="8" class="text-center text-danger">Could not load transactions.</td></tr>`;
        toast("Failed to load transactions.", "danger");
    }
};

const renderTransactions = () => {
    const t = state.tx;
    const tbody = $("tx-body");

    $("tx-page").innerText = t.total === 0
        ? "No records"
        : `Page ${t.page} of ${t.pages} · ${plural(t.total, "transaction", "transactions")}`;
    $("tx-prev").disabled = t.page <= 1;
    $("tx-next").disabled = t.page >= t.pages;

    if (t.rows.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" class="text-center text-muted">No transactions match these filters.</td></tr>`;
        return;
    }

    const SHOW = 3;

    tbody.innerHTML = t.rows.map((row) => {
        const items = row.items || [];
        const today = todayString();
        const line = (i) => {
            const back = Number(i.is_returned) === 1;
            const late = !back && i.due_date && i.due_date < today;
            const due = back
                ? ' <span class="badge bg-success">returned</span>'
                : ` <span class="small ${late ? "text-danger fw-semibold" : "text-muted"}">due ${escapeHtml(fmtDate(i.due_date))}</span>`;

            return `<li>${escapeHtml(i.title || "Unknown title")}${bookTypeBadge(i.book_type)} <span class="text-muted small">[ACC-${escapeHtml(i.accession_number || "?")}]</span>${due}</li>`;
        };
        const shown = items.slice(0, SHOW).map(line).join("");
        const rest = items.slice(SHOW).map(line).join("");
        const label = `+ ${items.length - SHOW} more`;

        const books = items.length === 0
            ? `<span class="text-muted">No books</span>`
            : `<ul class="list-unstyled mb-0">${shown}</ul>
               ${rest ? `<ul class="list-unstyled mb-0 more-items d-none">${rest}</ul>
                         <button type="button" class="btn btn-link btn-sm p-0" data-action="more" data-label="${label}">${label}</button>` : ""}
               <div class="small text-muted mt-1">${row.returned_count} of ${row.item_count} returned</div>`;

        return `
            <tr>
                <td>${row.transaction_id}</td>
                <td>
                    <button type="button" class="btn btn-link p-0 text-start" data-action="borrower" data-key="${row.student_id}" title="Open this borrower on the New borrow tab">${escapeHtml(row.student_name) || "—"}</button>
                </td>
                <td>${books}</td>
                <td class="text-nowrap">${escapeHtml(fmtDate(row.borrow_date))}</td>
                <td class="text-nowrap">${escapeHtml(fmtDate(row.next_due || row.due_date))}</td>
                <td>${txBadge(row.state)}</td>
                <td>${escapeHtml(row.processed_by) || "—"}</td>
                <td class="admin-only">
                    <button class="btn btn-success btn-sm me-1" data-action="edit" data-id="${row.transaction_id}">Edit</button>
                    <button class="btn btn-danger btn-sm" data-action="delete" data-id="${row.transaction_id}"
                            ${items.length > 0 ? 'disabled title="This transaction has books. Returned or not, its history is kept."' : ""}>Delete</button>
                </td>
            </tr>`;
    }).join("");
};

/* ---------------- Edit / delete a transaction ---------------- */

const openEdit = async (id) => {
    const row = state.tx.rows.find((r) => String(r.transaction_id) === String(id));
    if (!row) return;

    state.editRow = row;
    state.editMax = {};

    $("edit-id").value = row.transaction_id;
    $("edit-student").value = row.student_id;
    $("edit-borrower").innerText = `Transaction #${row.transaction_id} · ${row.student_name || "Unknown borrower"}`;
    $("edit-books").innerText = row.items.length
        ? `${plural(row.items.length, "book", "books")} on this transaction.`
        : "No books on this transaction.";
    $("edit-borrow").value = row.borrow_date;
    // Shows who originally processed it; editing a transaction never changes that.
    $("edit-processed").innerHTML = `<option value="${escapeHtml(row.processed_by_user_id ?? "")}">${escapeHtml(row.processed_by || "Unknown")}</option>`;
    $("edit-processed").disabled = true;
    $("edit-status").value = row.status_id;
    $("edit-hint").innerText = "";

    // One due date per book. Returned books are shown but can't be changed.
    $("edit-items").innerHTML = row.items.length === 0
        ? `<div class="list-group-item text-muted small">No books.</div>`
        : row.items.map((i) => {
            const back = Number(i.is_returned) === 1;

            return `
                <div class="list-group-item d-flex justify-content-between align-items-center gap-2 flex-wrap">
                    <div class="min-w-0">
                        <div class="fw-semibold">${escapeHtml(i.title || "Unknown title")}${bookTypeBadge(i.book_type)}</div>
                        <div class="small text-muted">ACC-${escapeHtml(i.accession_number || "?")}</div>
                    </div>
                    ${back
                        ? `<div class="small text-muted"><span class="badge bg-success">returned</span> was due ${escapeHtml(fmtDate(i.due_date))}</div>`
                        : `<input type="date" class="form-control form-control-sm edit-item-due" style="width: auto;"
                                  data-item="${i.item_id}" data-copy="${i.copy_id}" value="${escapeHtml(i.due_date || "")}"
                                  aria-label="Due date for ${escapeHtml(i.title || "this book")}">`}
                </div>`;
        }).join("");

    editModal.show();
    refreshEditPlan();
};

// Each book's due date is capped by the borrower type, that book's type and the borrow date.
const refreshEditPlan = async () => {
    const row = state.editRow;
    const borrow = $("edit-borrow").value;
    if (!row || row.items.length === 0 || !borrow) return;

    try {
        const data = await apiPost("preview", {
            student_id: row.student_id,
            transaction_id: row.transaction_id,
            borrow_date: borrow
        });

        if (data.status !== "success") return;

        state.editMax = {};
        data.plan.books.forEach((b) => { state.editMax[b.copy_id] = b; });

        document.querySelectorAll(".edit-item-due").forEach((input) => {
            const b = state.editMax[input.dataset.copy];
            input.min = borrow > todayString() ? borrow : todayString();
            if (b) input.max = b.due_date;
        });

        const periods = {};
        data.plan.books.forEach((b) => { periods[b.book_type || "Other"] = b.period; });
        $("edit-hint").innerText = "Longest loan allowed: " +
            Object.entries(periods).map(([t, per]) => `${t} up to ${per}`).join(" · ") + ".";
    } catch (error) { /* the server checks the limit again on save */ }
};

const onEditDueChange = (input) => {
    const b = state.editMax[input.dataset.copy];
    const borrow = $("edit-borrow").value;

    if (b && input.value > b.due_date) {
        input.value = b.due_date;
        toast(`Due date can't be later than ${fmtDate(b.due_date)} for this book.`, "danger");
    } else if (input.value && input.value < todayString()) {
        input.value = todayString();
        toast("Due date can't be in the past.", "danger");
    } else if (borrow && input.value && input.value < borrow) {
        input.value = borrow;
        toast("Due date cannot be earlier than borrow date.", "danger");
    }
};

const saveEdit = async () => {
    const row = state.editRow;
    const borrow_date = $("edit-borrow").value;

    if (!borrow_date || !$("edit-processed").value || !$("edit-status").value) {
        toast("All fields are required.", "danger");
        return;
    }

    const inputs = [...document.querySelectorAll(".edit-item-due")];

    if (inputs.some((i) => !i.value)) {
        toast("Every book needs a due date.", "danger");
        return;
    }

    if (inputs.some((i) => i.value < borrow_date)) {
        toast("Due date cannot be earlier than borrow date.", "danger");
        return;
    }

    const btn = $("btn-save-edit");
    btn.disabled = true;

    try {
        const result = await apiPost("update", {
            transaction_id: $("edit-id").value,
            student_id: $("edit-student").value,
            processed_by_user_id: $("edit-processed").value,
            borrow_date,
            due_date: row ? row.due_date : "",
            items: inputs.map((i) => ({ item_id: i.dataset.item, due_date: i.value })),
            status_id: $("edit-status").value
        });

        if (result.status === "success") {
            editModal.hide();
            toast(result.message, "success");
            await Promise.all([loadTransactions(), loadBorrowers()]);
            if (state.selected) selectBorrower(state.selected.borrower_key, false);
        } else {
            toast(result.message, "danger");
        }
    } catch (error) {
        toast("Failed to update the transaction.", "danger");
    } finally {
        btn.disabled = false;
    }
};

const deleteTransaction = async (id) => {
    if (!await lmsConfirm("Delete this borrow transaction?")) return;

    try {
        const result = await apiPost("delete", { transaction_id: id });
        toast(result.message, result.status === "success" ? "success" : "danger");
        loadTransactions();
        loadBorrowers();
    } catch (error) {
        toast("Failed to delete the transaction.", "danger");
    }
};