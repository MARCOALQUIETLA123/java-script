const baseApiUrl = "api"; // relative to the page, so it works from any folder
const usersApi = `${baseApiUrl}/users.php`;

let roleNames = {}; // role_id -> role name, to know which roles are borrowers

const escapeHtml = (value) => String(value ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const apiMessage = (error, fallback) =>
    (error.response && error.response.data && error.response.data.message) || fallback;

const showAlert = (msg, type) => {
    const box = document.getElementById("alert-box");
    box.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert"><span></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
    box.querySelector("span").textContent = msg; // plain text, never HTML
};

const $ = (id) => document.getElementById(id);

document.addEventListener("DOMContentLoaded", () => {
    loadDropdowns();
    loadRecords();
    loadPermissions();
    $("perm-user").addEventListener("change", renderPermBoxes);
    $("btn-save-perms").addEventListener("click", savePermissions);
    $("btn-save").addEventListener("click", saveRecord);
    $("btn-clear").addEventListener("click", clearForm);
    $("role_id").addEventListener("change", toggleBorrowerFields);
    $("group-filter").addEventListener("change", renderRows);
    $("stmt-send").addEventListener("click", sendStatement);
});

/* ---------- role-dependent fields ---------- */

// student | faculty | dean for a borrower role, otherwise null.
const kindOf = (roleId) => {
    const name = String(roleNames[roleId] || "").trim().toLowerCase();
    if (name.includes("faculty")) return "faculty";
    if (name === "dean") return "dean";
    if (name === "student") return "student";
    return null;
};

const toggleBorrowerFields = () => {
    const kind = kindOf($("role_id").value);
    $("borrower-fields").classList.toggle("d-none", !kind);
    $("course-wrapper").classList.toggle("d-none", kind !== "student");

    // Borrowers must pick a department. Librarian, Library Staff and Student Assistant accounts may leave it empty.
    const noDept = $("role_id").value !== "" && !kind;
    const first = $("department_id").options[0];
    if (first) first.textContent = noDept ? "No department (optional)" : "Select Department";
};

const loadDropdowns = async () => {
    try {
        const [rolesRes, deptRes] = await Promise.all([
            axios.get(`${baseApiUrl}/roles.php`, { params: { operation: "getAll" } }),
            axios.get(`${baseApiUrl}/department.php`, { params: { operation: "getAll" } })
        ]);

        const keepRole = $("role_id").value;
        const keepDept = $("department_id").value;

        roleNames = {};
        $("role_id").innerHTML = '<option value="">Select Role</option>' + rolesRes.data.map((role) => {
            roleNames[role.role_id] = role.role_name;
            return `<option value="${role.role_id}">${escapeHtml(role.role_name)}</option>`;
        }).join("");

        $("department_id").innerHTML = '<option value="">Select Department</option>' + deptRes.data.map((d) =>
            `<option value="${d.department_id}">${escapeHtml(d.department_name)}</option>`).join("");

        $("role_id").value = keepRole;
        $("department_id").value = keepDept;
        toggleBorrowerFields();
    } catch (error) {
        showAlert(apiMessage(error, "Failed to load the role and department lists."), "danger");
    }
};

/* ---------- list ---------- */

const STATUS = {
    active: '<span class="badge bg-success">Active</span>',
    deactivated: '<span class="badge bg-secondary">Deactivated</span>',
    pending: '<span class="badge bg-warning text-dark">Pending</span>',
    disabled: '<span class="badge bg-secondary">Deactivated</span>',   // stored as "disabled", shown as "Deactivated"
    no_login: '<span class="badge bg-light text-dark border">No login</span>'
};

const isSA = (row) => /^(student assistant|sa)( \(sa\))?$/i.test(String(row.role_name || "").trim());

const detailsOf = (row) => {
    if (!row.student_id) return "";
    const course = String(row.role_name || "").toLowerCase() === "student" && row.course ? ` · ${escapeHtml(row.course)}` : "";
    return `<span class="small">${escapeHtml(row.address)}${course}</span>`;
};

const balanceCell = (row) => {
    if (groupOf(row) !== "borrower") return "";
    return Number(row.fine_balance) > 0 ? `<strong class="text-danger">${peso(row.fine_balance)}</strong>` : '<span class="text-muted">—</span>';
};

const groupOf = (row) => {
    const r = String(row.role_name || "").trim().toLowerCase();
    if (r === "technical services librarian" || r === "admin") return "admin";
    if (r === "library staff" || r === "staff") return "staff";
    if (isSA(row)) return "sa";
    return "borrower";
};

const peso = (n) => "₱" + Number(n || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const renderRows = () => {
    const tbody = $("table-body");
    const group = $("group-filter").value;
    const rows = (window._usersData || []).filter((r) => group === "all" || groupOf(r) === group);

    if (rows.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">No records found.</td></tr>';
        return;
    }

        tbody.innerHTML = rows.map((row) => {
            const noLogin = row.user_id === null;
            let extra = "";
            let edit;
            let del;

            if (noLogin) {
                edit = `onclick="editBorrower(${row.student_id})"`;
                del = `onclick="deleteBorrower(${row.student_id})"`;
            } else {
                edit = `onclick="editRecord(${row.user_id})"`;
                del = `onclick="deleteRecord(${row.user_id})"`;

                const sa = isSA(row);
                if (row.account_status === "pending") {
                    extra = `<button class="btn btn-primary btn-sm me-1" onclick="setStatus(${row.user_id}, 'active')">Approve</button>`;
                } else if (row.account_status === "disabled") {
                    extra = `<button class="btn btn-outline-primary btn-sm me-1" onclick="setStatus(${row.user_id}, 'active')">Activate</button>`;
                } else {
                    extra = `<button class="btn btn-outline-secondary btn-sm me-1" onclick="setStatus(${row.user_id}, 'disabled')">Deactivate</button>`;
                }
                if (groupOf(row) === "borrower" && Number(row.fine_balance) > 0) {
                    extra += `<button class="btn btn-outline-danger btn-sm me-1" onclick="openStatement(${row.user_id})">Send statement</button>`;
                }
            }

            return `
            <tr>
                <td>${escapeHtml(row.first_name)} ${escapeHtml(row.last_name)}</td>
                <td>${escapeHtml(row.role_name)}</td>
                <td>${escapeHtml(row.department_name)}</td>
                <td>${escapeHtml(row.contact_number)}</td>
                <td>${escapeHtml(row.email)}</td>
                <td>${escapeHtml(row.username)}</td>
                <td>${detailsOf(row)}</td>
                <td class="text-nowrap">${balanceCell(row)}</td>
                <td>${STATUS[row.account_status] || escapeHtml(row.account_status)}</td>
                <td class="text-nowrap">
                    ${extra}
                    <button class="btn btn-success btn-sm me-1" ${edit}>Edit</button>
                    <button class="btn btn-danger btn-sm" ${del}>${row.account_status === "pending" ? "Reject" : "Delete"}</button>
                </td>
            </tr>`;
        }).join("");
};

const loadRecords = async () => {
    const tbody = $("table-body");

    try {
        const response = await axios.get(usersApi, { params: { operation: "getAll" } });
        const rows = response.data;

        window._usersData = rows;

        // The "waiting for approval" banner follows the list, even when the list is empty.
        const pending = rows.filter((r) => r.account_status === "pending").length;
        $("pending-note").innerHTML = pending > 0
            ? `<div class="alert alert-warning">${pending} new ${pending === 1 ? "account is" : "accounts are"} waiting for your approval. Approve or reject ${pending === 1 ? "it" : "them"} in the list below.</div>`
            : "";

        renderRows();
    } catch (error) {
        tbody.innerHTML = `<tr><td colspan="10" class="text-center text-danger">${escapeHtml(apiMessage(error, "Failed to load the list."))}</td></tr>`;
    }
};

const setStatus = async (id, account_status) => {
    const row = (window._usersData || []).find((u) => u.user_id == id);
    const sa = row && isSA(row);
    const verb = account_status === "active" ? "activate" : "deactivate";
    if (!await lmsConfirm(`Are you sure you want to ${verb} this account?`)) return;

    await send("setStatus", { user_id: id, account_status }, "Failed to update the account.");
};

/* ---------- save ---------- */

const send = async (operation, payload, failMessage, afterSuccess) => {
    const formData = new FormData();
    formData.append("operation", operation);
    formData.append("json", JSON.stringify(payload));

    try {
        const response = await axios({ url: usersApi, method: "POST", data: formData });
        const ok = response.data.status === "success";
        if (ok && afterSuccess) afterSuccess(); // clears the form (and any old message) first
        showAlert(response.data.message, ok ? "success" : "danger");
        loadRecords();
    } catch (error) {
        showAlert(apiMessage(error, failMessage), "danger");
    }
};

const saveRecord = async () => {
    const editingId = $("editing-id").value.trim();
    const studentId = $("editing-student-id").value.trim();
    const role_id = $("role_id").value;
    const department_id = $("department_id").value;
    const first_name = $("first_name").value.trim();
    const last_name = $("last_name").value.trim();
    const contact_number = $("contact_number").value.trim();
    const email = $("email").value.trim();
    const username = $("username").value.trim();
    const password = $("password").value.trim();
    const address = $("address").value.trim();
    const course = $("course").value.trim();
    const kind = kindOf(role_id);

    // A borrower without a login can be edited without a username or password.
    const loginOptional = studentId !== "" && username === "" && password === "";

    if (!first_name || !last_name || !contact_number || !email) {
        showAlert("All fields are required.", "danger");
        return;
    }

    if (!loginOptional && (!role_id || !username)) {
        showAlert("All fields are required.", "danger");
        return;
    }

    // Department is only compulsory for borrowers (Student, Faculty, Dean).
    if (!loginOptional && kind && !department_id) {
        showAlert("Department is required for students, faculty and deans.", "danger");
        return;
    }

    if (!editingId && !loginOptional && !password) {
        showAlert("Password is required.", "danger");
        return;
    }

    if (!/[A-Za-z]/.test(first_name)) { showAlert("First name must contain letters, not numbers only.", "danger"); return; }
    if (!/[A-Za-z]/.test(last_name)) { showAlert("Last name must contain letters, not numbers only.", "danger"); return; }

    if (!/^0\d{10}$/.test(contact_number) && !/^[1-9]\d{9}$/.test(contact_number)) {
        showAlert("Contact number must be 11 digits (e.g. 09171234567) or 10 digits without leading 0 (e.g. 9171234567).", "danger");
        return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showAlert("Please enter a valid email address.", "danger"); return; }

    if (password && password.length < 8) { showAlert("Password must be at least 8 characters.", "danger"); return; }

    if (kind || studentId) {
        if (!/[A-Za-z]/.test(address)) { showAlert("Address is required for students, faculty and deans.", "danger"); return; }
        if ((kind === "student" || (studentId && !kind)) && !/[A-Za-z]/.test(course)) {
            showAlert("Course is required for students (e.g. BSIT).", "danger");
            return;
        }
    }

    const payload = { role_id, department_id, first_name, last_name, contact_number, email, username, password, address, course };

    if (studentId) {
        payload.student_id = studentId;
        await send("updateBorrower", payload, "Failed to save the borrower.", clearForm);
    } else if (editingId) {
        payload.user_id = editingId;
        await send("update", payload, "Failed to save the user.", clearForm);
    } else {
        await send("add", payload, "Failed to save the user.", clearForm);
    }
};

/* ---------- edit / delete ---------- */

const fillForm = (row) => {
    $("role_id").value = row.role_id || "";
    $("department_id").value = row.department_id || "";
    $("first_name").value = row.first_name || "";
    $("last_name").value = row.last_name || "";
    $("contact_number").value = row.contact_number || "";
    $("email").value = row.email || "";
    $("username").value = row.username || "";
    $("password").value = "";
    $("address").value = row.address || "";
    $("course").value = row.course || "";
    toggleBorrowerFields();
    window.scrollTo(0, 0);
};

const editRecord = (id) => {
    const row = (window._usersData || []).find((user) => user.user_id == id);
    if (!row) return;

    clearForm();
    $("editing-id").value = id;
    fillForm(row);
    $("password").placeholder = "Leave blank to keep current password";
    $("btn-save").innerText = "Update";
    $("form-title").innerText = "Edit User";
};

// A borrower with no login: edit their details, or fill in a username and password to give them one.
const editBorrower = (studentId) => {
    const row = (window._usersData || []).find((r) => r.user_id === null && r.student_id == studentId);
    if (!row) return;

    clearForm();
    $("editing-student-id").value = studentId;
    fillForm(row);
    $("borrower-fields").classList.remove("d-none");
    $("course-wrapper").classList.remove("d-none");
    $("password").placeholder = "Set a password to give them a login";
    $("btn-save").innerText = "Update";
    $("form-title").innerText = "Edit Borrower (no login yet)";
};

const deleteRecord = async (id) => {
    if (!await lmsConfirm("Are you sure you want to delete this user? If they are a borrower, their borrower record is deleted too.")) return;
    await send("delete", { user_id: id }, "Failed to delete the user.");
};

const deleteBorrower = async (studentId) => {
    if (!await lmsConfirm("Are you sure you want to delete this borrower?")) return;
    await send("deleteBorrower", { student_id: studentId }, "Failed to delete the borrower.");
};

const clearForm = () => {
    $("editing-id").value = "";
    $("editing-student-id").value = "";

    ["role_id", "department_id", "first_name", "last_name", "contact_number", "email", "username", "password", "address", "course"].forEach((id) => {
        $(id).value = "";
    });

    $("password").placeholder = "Password";
    $("btn-save").innerText = "Save";
    $("form-title").innerText = "Add User";
    $("alert-box").innerHTML = "";
    toggleBorrowerFields();
};

// The buttons in the list call these from inline onclick handlers.
window.editRecord = editRecord;
window.editBorrower = editBorrower;
window.deleteRecord = deleteRecord;
window.deleteBorrower = deleteBorrower;
window.setStatus = setStatus;

/* ---------- Library Staff permissions (one account at a time) ---------- */

const permApi = `${baseApiUrl}/staff_permissions.php`;
let permDefs = [];
let permUsers = [];

const renderPermBoxes = () => {
    const user = permUsers.find((u) => String(u.user_id) === $("perm-user").value);
    $("btn-save-perms").disabled = !user;

    $("perm-list").innerHTML = !user ? "" : permDefs.map((p) => `
        <div class="col-md-6">
            <label class="d-flex gap-2 align-items-start border rounded p-2 h-100 bg-white" style="cursor:pointer">
                <input type="checkbox" class="form-check-input mt-1 perm-box" data-key="${escapeHtml(p.key)}" ${user.granted.includes(p.key) ? "checked" : ""}>
                <span><span class="fw-semibold d-block">${escapeHtml(p.label)}</span>
                <span class="text-muted small">${escapeHtml(p.desc)}</span></span>
            </label>
        </div>`).join("");
};

const loadPermissions = async (keepUserId) => {
    try {
        const res = await axios.get(permApi, { params: { operation: "getAll" } });
        permDefs = res.data.permissions || [];
        permUsers = res.data.users || [];

        $("perm-accounts").textContent = `${permUsers.length} account(s) available for supervision and access control.`;
        $("perm-user").innerHTML = '<option value="">Select an account</option>' + permUsers.map((u) =>
            `<option value="${u.user_id}">${escapeHtml(`${u.first_name} ${u.last_name}`)} (${escapeHtml(u.username)}) - ${u.is_sa ? "Student Assistant" : "Library Staff"}${u.account_status === "disabled" ? " - deactivated" : ""}</option>`).join("");
        if (keepUserId) $("perm-user").value = String(keepUserId);
        renderPermBoxes();
    } catch (error) {
        $("perm-accounts").textContent = "Couldn't load the permissions.";
        showAlert(apiMessage(error, "Couldn't load the Library Staff permissions."), "danger");
    }
};

const savePermissions = async () => {
    const user_id = Number($("perm-user").value);
    if (!user_id) return;
    const granted = [...document.querySelectorAll(".perm-box:checked")].map((b) => b.dataset.key);

    const fd = new FormData();
    fd.append("operation", "save");
    fd.append("json", JSON.stringify({ user_id, granted }));

    try {
        const res = await axios.post(permApi, fd);
        showAlert(res.data.message, res.data.status === "success" ? "success" : "danger");
        if (res.data.status === "success") loadPermissions(user_id);
    } catch (error) {
        showAlert(apiMessage(error, "Failed to save the permissions."), "danger");
    }
};

/* ---------- send a borrower their fines statement ---------- */

let statementFor = null;

const openStatement = (userId) => {
    const row = (window._usersData || []).find((u) => u.user_id == userId);
    if (!row) return;
    statementFor = row;
    $("stmt-name").textContent = `${row.first_name} ${row.last_name}`;
    $("stmt-total").textContent = peso(row.fine_balance);
    $("stmt-note").value = "";
    $("stmt-file").value = "";
    bootstrap.Modal.getOrCreateInstance($("statementModal")).show();
};

const sendStatement = async () => {
    if (!statementFor) return;
    const btn = $("stmt-send");
    const fd = new FormData();
    fd.append("operation", "sendStatement");
    fd.append("json", JSON.stringify({ student_id: statementFor.student_id, note: $("stmt-note").value.trim() }));
    const file = $("stmt-file").files[0];
    if (file) fd.append("receipt", file, file.name);

    btn.disabled = true;
    try {
        const res = await axios.post(usersApi, fd);
        const ok = res.data.status === "success";
        if (ok) bootstrap.Modal.getOrCreateInstance($("statementModal")).hide();
        showAlert(res.data.message, ok ? "success" : "danger");
    } catch (error) {
        showAlert(apiMessage(error, "Failed to send the statement."), "danger");
    } finally {
        btn.disabled = false;
    }
};
