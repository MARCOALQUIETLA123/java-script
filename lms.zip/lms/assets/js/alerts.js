// SweetAlert2 look for every message in the system.
//
// 1. Confirm boxes: pages call `await lmsConfirm("Are you sure ...?")` instead of the browser's confirm().
// 2. Messages: anything a page puts into #alert-box (inline alerts) or #toast-area / #toast-container
//    (Bootstrap toasts) is shown as a SweetAlert toast instead, so every page looks the same and
//    nothing needs to change in the page scripts' showAlert / toast helpers.
//
// Needs sweetalert2 loaded first. If it can't load (offline), pages fall back to the plain browser
// confirm and the original inline alerts, so nothing breaks.

(() => {
    const ready = () => typeof Swal !== "undefined";

    /* ---------------- confirm ---------------- */

    // Picks wording and colour from the question, so the page scripts only pass the message.
    const guess = (text) => {
        if (/\b(delete|reject|remove)\b/i.test(text)) return { icon: "warning", ok: "Yes, delete", cancel: "Cancel", danger: true };
        if (/\bcancel\b/i.test(text)) return { icon: "warning", ok: "Yes, cancel it", cancel: "Keep it", danger: true };
        if (/\bdisable\b/i.test(text)) return { icon: "warning", ok: "Yes, disable", cancel: "Cancel", danger: true };
        if (/\b(approve|activate)\b/i.test(text)) return { icon: "question", ok: "Yes, approve", cancel: "Cancel", danger: false };
        if (/\bborrow\b/i.test(text)) return { icon: "question", ok: "Yes, borrow", cancel: "Cancel", danger: false };
        return { icon: "question", ok: "Yes, continue", cancel: "Cancel", danger: false };
    };

    // opts: { title, confirmText, cancelText, danger }
    window.lmsConfirm = async (message, opts = {}) => {
        const text = String(message ?? "");
        if (!ready()) return window.confirm(text);

        const g = guess(text);
        const danger = opts.danger !== undefined ? opts.danger : g.danger;

        const res = await Swal.fire({
            icon: g.icon,
            title: opts.title || "Are you sure?",
            text,
            showCancelButton: true,
            confirmButtonText: opts.confirmText || g.ok,
            cancelButtonText: opts.cancelText || g.cancel,
            reverseButtons: true,
            focusCancel: danger,
            buttonsStyling: false,
            // Inside an open Bootstrap modal the box must live in that modal, or its focus trap fights it.
            target: document.querySelector(".modal.show") || "body",
            customClass: {
                popup: "lms-swal",
                confirmButton: danger ? "btn btn-danger px-4" : "btn btn-success px-4",
                cancelButton: "btn btn-outline-secondary px-4"
            }
        });

        return res.isConfirmed;
    };

    // Asks for a short piece of text (e.g. a reason). Resolves to the text, or null if cancelled.
    // opts: { title, confirmText, placeholder, danger, maxLength }
    window.lmsPrompt = async (message, opts = {}) => {
        const text = String(message ?? "");
        if (!ready()) {
            const answer = window.prompt(text, "");
            return answer === null ? null : answer.trim();
        }

        const res = await Swal.fire({
            icon: "question",
            title: opts.title || "Add a note",
            text,
            input: "text",
            inputPlaceholder: opts.placeholder || "",
            inputAttributes: { maxlength: String(opts.maxLength || 200) },
            showCancelButton: true,
            confirmButtonText: opts.confirmText || "OK",
            cancelButtonText: "Cancel",
            reverseButtons: true,
            buttonsStyling: false,
            target: document.querySelector(".modal.show") || "body",
            customClass: {
                popup: "lms-swal",
                confirmButton: opts.danger ? "btn btn-danger px-4" : "btn btn-success px-4",
                cancelButton: "btn btn-outline-secondary px-4"
            }
        });

        return res.isConfirmed ? String(res.value || "").trim() : null;
    };

    /* ---------------- toasts ---------------- */

    const ICON = { success: "success", danger: "error", error: "error", warning: "warning", info: "info" };
    const TIME = { success: 3500, error: 6000, warning: 5000, info: 4500 };

    window.lmsToast = (message, type = "success") => {
        const text = String(message ?? "").trim();
        if (!text || !ready()) return;

        const icon = ICON[type] || "info";

        Swal.fire({
            toast: true,
            position: "top-end",
            icon,
            title: text,
            showConfirmButton: false,
            showCloseButton: true,
            timer: TIME[icon],
            timerProgressBar: true,
            customClass: { popup: `lms-toast lms-toast-${icon}` },
            didOpen: (el) => {
                el.addEventListener("mouseenter", Swal.stopTimer);   // hover to keep it open
                el.addEventListener("mouseleave", Swal.resumeTimer);
            }
        });
    };

    const typeOf = (el) => {
        const m = String(el.className).match(/(?:alert|text-bg)-(success|danger|warning|info|primary|secondary|light|dark)/);
        return m ? m[1] : "info";
    };

    const textOf = (el) => {
        const clone = el.cloneNode(true);
        clone.querySelectorAll(".btn-close").forEach((b) => b.remove());
        return clone.textContent.replace(/\s+/g, " ").trim();
    };

    // An inline alert or a Bootstrap toast has just been added: show it as a SweetAlert toast and drop it.
    const take = (node) => {
        if (node.nodeType !== 1) return;

        if (node.classList.contains("alert")) {
            window.lmsToast(textOf(node), typeOf(node));
            node.remove();
        } else if (node.classList.contains("toast")) {
            const body = node.querySelector(".toast-body");
            window.lmsToast(body ? textOf(body) : textOf(node), typeOf(node));
            node.remove();
        }
    };

    const start = () => {
        if (!ready()) return; // keep the original inline messages

        ["alert-box", "toast-area", "toast-container"].forEach((id) => {
            const box = document.getElementById(id);
            if (!box) return;

            // The callback sees nodes a page added and cleared in the same moment too (a "saved" message
            // followed straight away by a form reset), so those messages are no longer lost.
            new MutationObserver((records) => {
                records.forEach((r) => r.addedNodes.forEach(take));
            }).observe(box, { childList: true });
        });
    };

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
