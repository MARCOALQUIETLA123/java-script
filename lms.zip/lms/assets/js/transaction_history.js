const baseApiUrl = "api"; // relative to the page, so it works from any folder

const escapeHtml = (value) => {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
};

const PAGE_SIZE = 25;
let currentPage = 1;
let printing = false;

document.addEventListener("DOMContentLoaded", () => {
    loadHistory();

    ["filter-search", "filter-status", "filter-staff", "filter-from", "filter-to"].forEach((id) => {
        const el = document.getElementById(id);
        el.addEventListener("input", () => { currentPage = 1; renderHistory(); });
        el.addEventListener("change", () => { currentPage = 1; renderHistory(); });
    });

    document.getElementById("btn-reset").addEventListener("click", resetFilters);
    document.getElementById("btn-print").addEventListener("click", () => window.print());
    document.getElementById("pager-prev").addEventListener("click", () => { currentPage--; renderHistory(); });
    document.getElementById("pager-next").addEventListener("click", () => { currentPage++; renderHistory(); });

    // A printout shows every matching row, not just the current page.
    window.addEventListener("beforeprint", () => { printing = true; renderHistory(); });
    window.addEventListener("afterprint", () => { printing = false; renderHistory(); });
});

// live.js calls loadHistory() when another device changes data.
const loadHistory = async () => {
    try {
        const response = await axios.get(`${baseApiUrl}/borrow_report.php`, {
            params: { operation: "getHistory" }
        });

        if (response.status == 200 && Array.isArray(response.data)) {
            window._historyData = response.data;
            fillStaffFilter();
            renderHistory();
            loadFinesCollected();
        } else {
            showAlert("Failed to load the transaction history.", "danger");
        }
    } catch (error) {
        showAlert("Failed to load the transaction history.", "danger");
    }
};

// Money collected for overdue fines at the library desk (see Holds & Messages for each payment).
const loadFinesCollected = async () => {
    try {
        const res = await axios.get(`${baseApiUrl}/borrow_report.php`, { params: { operation: "getFinesCollected" } });
        const t = res.data || {};
        document.getElementById("sum-fines").textContent = peso(t.total || 0);
        document.getElementById("sum-fines-note").textContent = `${peso(t.month || 0)} this month · ${peso(t.today || 0)} today`;
    } catch (error) { /* the card keeps its zero */ }
};

// Everyone who handled at least one borrow or return, for the "Processed By" filter.
const fillStaffFilter = () => {
    const select = document.getElementById("filter-staff");
    const keep = select.value;
    const names = new Set();

    (window._historyData || []).forEach((r) => {
        if (r.borrow_processed_by) names.add(r.borrow_processed_by);
        if (r.return_processed_by) names.add(r.return_processed_by);
    });

    select.innerHTML = '<option value="">All</option>' +
        [...names].sort().map((n) => `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`).join("");
    select.value = names.has(keep) ? keep : "";
};

const getFilteredRows = () => {
    const search = document.getElementById("filter-search").value.trim().toLowerCase();
    const status = document.getElementById("filter-status").value;
    const from = document.getElementById("filter-from").value;
    const to = document.getElementById("filter-to").value;
    const staff = document.getElementById("filter-staff").value;

    return (window._historyData || []).filter((row) => {
        if (status && row.status !== status) return false;
        if (from && (!row.return_date || row.return_date < from)) return false;
        if (to && (!row.return_date || row.return_date > to)) return false;
        if (staff && row.borrow_processed_by !== staff && row.return_processed_by !== staff) return false;

        if (search) {
            const text = `${row.borrower} ${row.borrower_role} ${row.title} ${row.accession_number} ${row.condition_on_return} ${row.borrow_processed_by} ${row.return_processed_by}`.toLowerCase();
            if (!text.includes(search)) return false;
        }

        return true;
    });
};

const ROLE_BADGE = { student: "bg-secondary", faculty: "bg-primary", dean: "bg-dark" };

const roleBadge = (role) => role
    ? ` <span class="badge ${ROLE_BADGE[String(role).trim().toLowerCase()] || "bg-light text-dark border"}">${escapeHtml(role)}</span>`
    : "";

// "On time" or "Late · 3 days".
const resultBadge = (row) => {
    if (row.status !== "Late") return '<span class="badge bg-success">On time</span>';
    const days = Number(row.days_late) || 0;
    return `<span class="badge bg-danger">Late${days > 0 ? ` · ${days} day${days === 1 ? "" : "s"}` : ""}</span>`;
};

const dash = (v) => (v ? escapeHtml(v) : "—");

const peso = (n) => "₱" + Number(n || 0).toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const conditionBadge = (c) => {
    if (c === "Lost") return '<span class="badge bg-danger">Lost</span>';
    if (c === "Damaged") return '<span class="badge bg-warning text-dark">Damaged</span>';
    return dash(c);
};

// Overdue fine and/or lost or damaged settlement collected for this book.
const chargesText = (row) => {
    const lines = [];
    if (Number(row.fine_amount) > 0) lines.push(`Fine ${peso(row.fine_amount)}`);
    if (row.settlement === "Paid") lines.push(`Book ${peso(row.book_price)} + fee ${peso(row.processing_fee)}`);
    if (row.settlement === "Replaced") lines.push("Replaced with a new copy");
    if (lines.length === 0) return '<span class="text-muted">—</span>';
    const total = Number(row.charges_total) > 0 ? `<div class="fw-semibold">${peso(row.charges_total)}</div>` : "";

    // Was the overdue fine collected? (Lost or damaged books are settled with their case.)
    let paidNote = "";
    if (Number(row.fine_amount) > 0 && !["Lost", "Damaged"].includes(row.condition_on_return)) {
        const paid = Number(row.fine_cash || 0) + Number(row.fine_credit || 0);
        paidNote = paid >= Number(row.fine_amount) - 0.005 ? '<div><span class="badge bg-success">Fine paid</span></div>'
            : paid > 0 ? `<div><span class="badge bg-warning text-dark">Part paid ${peso(paid)}</span></div>`
            : '<div class="small text-muted">No payment record</div>';
    }
    return lines.map(escapeHtml).join("<br>") + total + paidNote;
};

const renderHistory = () => {
    const rows = getFilteredRows();
    const tbody = document.getElementById("table-body");

    const late = rows.filter((r) => r.status === "Late").length;
    const onTime = rows.length - late;
    const monthPrefix = new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Manila" }).slice(0, 7); // YYYY-MM
    const thisMonth = rows.filter((r) => String(r.return_date || "").startsWith(monthPrefix)).length;

    document.getElementById("sum-total").innerText = rows.length;
    document.getElementById("sum-ontime").innerText = onTime;
    document.getElementById("sum-ontime-note").innerText = rows.length ? `${Math.round(onTime / rows.length * 100)}% of returns` : "";
    document.getElementById("sum-late").innerText = late;
    document.getElementById("sum-late-note").innerText = late ? `${Math.round(late / rows.length * 100)}% of returns` : "none were late";
    document.getElementById("kpi-late").classList.toggle("is-alert", late > 0);
    document.getElementById("sum-month").innerText = thisMonth;
    document.getElementById("sum-month-note").innerText = "books back on the shelf";

    const pager = document.getElementById("pager");

    if (rows.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="11" class="text-center text-muted">No returned books found.</td>
            </tr>
        `;
        pager.classList.add("d-none");
        return;
    }

    const pages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
    currentPage = Math.min(Math.max(1, currentPage), pages);
    const start = printing ? 0 : (currentPage - 1) * PAGE_SIZE;
    const shown = printing ? rows : rows.slice(start, start + PAGE_SIZE);

    tbody.innerHTML = shown.map((row, index) => `
        <tr>
            <td>${start + index + 1}</td>
            <td>${escapeHtml(row.borrower)}${roleBadge(row.borrower_role)}</td>
            <td>${escapeHtml(row.title)} <span class="text-muted small">[ACC-${escapeHtml(row.accession_number)}]</span></td>
            <td>${escapeHtml(row.borrow_date)}</td>
            <td>${escapeHtml(row.due_date)}</td>
            <td>${dash(row.return_date)}</td>
            <td>${resultBadge(row)}</td>
            <td>${conditionBadge(row.condition_on_return)}</td>
            <td class="small">${chargesText(row)}</td>
            <td>${dash(row.borrow_processed_by)}</td>
            <td>${dash(row.return_processed_by)}</td>
        </tr>
    `).join("");

    pager.classList.toggle("d-none", pages === 1);
    document.getElementById("pager-info").innerText =
        `Showing ${start + 1}–${Math.min(start + PAGE_SIZE, rows.length)} of ${rows.length}`;
    document.getElementById("pager-prev").disabled = currentPage <= 1;
    document.getElementById("pager-next").disabled = currentPage >= pages;
};

const resetFilters = () => {
    document.getElementById("filter-search").value = "";
    document.getElementById("filter-status").value = "";
    document.getElementById("filter-staff").value = "";
    document.getElementById("filter-from").value = "";
    document.getElementById("filter-to").value = "";
    currentPage = 1;
    renderHistory();
};

const showAlert = (msg, type) => {
    const box = document.getElementById("alert-box");
    box.innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert"><span></span>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    box.querySelector("span").textContent = msg; // plain text, never HTML
};
