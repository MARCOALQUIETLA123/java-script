const baseApiUrl = "api"; // relative to the page, so it works from any folder

const escapeHtml = (value) => {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
};

const STATUS_BADGE = {
    Borrowed: "bg-primary",
    Overdue: "bg-danger"
};

document.addEventListener("DOMContentLoaded", () => {
    loadReport();

    ["filter-search", "filter-status", "filter-staff", "filter-from", "filter-to"].forEach((id) => {
        const el = document.getElementById(id);
        el.addEventListener("input", renderReport);
        el.addEventListener("change", renderReport);
    });

    document.getElementById("btn-reset").addEventListener("click", resetFilters);
    document.getElementById("btn-print").addEventListener("click", () => window.print());
    document.getElementById("btn-mode").addEventListener("click", () => setDetailed(!detailed));
    setDetailed(detailed);

    const summaryBody = document.getElementById("summary-body");
    summaryBody.addEventListener("click", (e) => {
        const row = e.target.closest("tr.borrower-row");
        if (row) toggleBorrower(row);
    });
    summaryBody.addEventListener("keydown", (e) => {
        const row = e.target.closest("tr.borrower-row");
        if (row && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); toggleBorrower(row); }
    });

    // A printout of the summary shows every borrower's books.
    window.addEventListener("beforeprint", () => { printing = true; renderReport(); });
    window.addEventListener("afterprint", () => { printing = false; renderReport(); });
});

// live.js calls loadReport() when another device changes data.
const loadReport = async () => {
    try {
        const response = await axios.get(`${baseApiUrl}/borrow_report.php`, {
            params: { operation: "getBorrowing" }
        });

        if (response.status == 200 && Array.isArray(response.data)) {
            window._reportData = response.data;
            fillStaffFilter();
            renderReport();
        } else {
            showAlert("Failed to load the borrowing report.", "danger");
        }
    } catch (error) {
        showAlert("Failed to load the borrowing report.", "danger");
    }
};

// Everyone who processed at least one of these loans, for the "Processed By" filter.
const fillStaffFilter = () => {
    const select = document.getElementById("filter-staff");
    const keep = select.value;
    const names = new Set();

    (window._reportData || []).forEach((r) => {
        if (r.borrow_processed_by) names.add(r.borrow_processed_by);
    });

    select.innerHTML = '<option value="">All</option>' +
        [...names].sort().map((n) => `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`).join("");
    select.value = names.has(keep) ? keep : "";
};

const getFilteredRows = () => {
    const search = document.getElementById("filter-search").value.trim().toLowerCase();
    const status = document.getElementById("filter-status").value;
    const from = document.getElementById("filter-from").value;
    const to = document.getElementById("filter-to").value;
    const staff = document.getElementById("filter-staff").value;

    return (window._reportData || []).filter((row) => {
        if (status && row.status !== status) return false;
        if (from && row.borrow_date < from) return false;
        if (to && row.borrow_date > to) return false;
        if (staff && row.borrow_processed_by !== staff) return false;

        if (search) {
            const text = `${row.borrower} ${row.borrower_role} ${row.title} ${row.accession_number} ${row.borrow_processed_by}`.toLowerCase();
            if (!text.includes(search)) return false;
        }

        return true;
    });
};

/* ---------------- Summary (default) and detailed views ---------------- */

let detailed = false;
try { detailed = localStorage.getItem("lms_report_detailed") === "1"; } catch (e) { /* storage unavailable */ }

const openBorrowers = new Set(); // expanded borrowers, kept across live refreshes
let printing = false;

const setDetailed = (on) => {
    detailed = on;
    try { localStorage.setItem("lms_report_detailed", on ? "1" : "0"); } catch (e) { /* ignore */ }

    document.getElementById("summary-wrap").classList.toggle("d-none", on);
    document.getElementById("summary-hint").classList.toggle("d-none", on);
    document.getElementById("detail-wrap").classList.toggle("d-none", !on);

    const btn = document.getElementById("btn-mode");
    btn.classList.toggle("btn-success", on);
    btn.classList.toggle("btn-outline-success", !on);
    btn.setAttribute("aria-pressed", String(on));
};

const ROLE_BADGE = { student: "bg-secondary", faculty: "bg-primary", dean: "bg-dark" };

// Small role label (Student, Faculty, Dean...) shown next to a borrower's name.
const roleBadge = (role) => role
    ? ` <span class="badge ${ROLE_BADGE[String(role).trim().toLowerCase()] || "bg-light text-dark border"}">${escapeHtml(role)}</span>`
    : "";

const countBadge = (n, cls) => n > 0 ? `<span class="badge ${cls}">${n}</span>` : '<span class="text-muted">0</span>';

// "Overdue" plus how late, e.g. "Overdue · 5 days".
const statusBadge = (row) => {
    const days = Number(row.days_overdue) || 0;
    const extra = row.status === "Overdue" && days > 0 ? ` · ${days} day${days === 1 ? "" : "s"}` : "";
    const fine = Number(row.fine_so_far) > 0
        ? `<div class="small text-danger mt-1">Fine so far: ₱${Number(row.fine_so_far).toLocaleString("en-PH", { minimumFractionDigits: 2 })}</div>` : "";
    return `<span class="badge ${STATUS_BADGE[row.status] || "bg-secondary"}">${escapeHtml(row.status)}${extra}</span>${fine}`;
};

const renderSummary = (rows) => {
    const tbody = document.getElementById("summary-body");

    if (rows.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No books are out right now.</td></tr>';
        return;
    }

    const groups = new Map(); // one entry per borrower
    rows.forEach((row) => {
        const key = row.student_id != null ? `s${row.student_id}` : `n${row.borrower}`;
        if (!groups.has(key)) groups.set(key, { key, name: row.borrower, role: row.borrower_role, rows: [] });
        groups.get(key).rows.push(row);
    });

    const searching = document.getElementById("filter-search").value.trim() !== "";

    tbody.innerHTML = [...groups.values()].map((g) => {
        const count = (status) => g.rows.filter((r) => r.status === status).length;
        const open = printing || searching || openBorrowers.has(g.key);

        const books = g.rows.map((row) => `
            <tr>
                <td>${escapeHtml(row.title)} <span class="text-muted small">[ACC-${escapeHtml(row.accession_number)}]</span></td>
                <td>${escapeHtml(row.borrow_date)}</td>
                <td>${escapeHtml(row.due_date)}</td>
                <td>${statusBadge(row)}</td>
                <td>${row.borrow_processed_by ? escapeHtml(row.borrow_processed_by) : "—"}</td>
            </tr>`).join("");

        return `
            <tr class="borrower-row" data-key="${escapeHtml(g.key)}" tabindex="0" role="button" aria-expanded="${open}" style="cursor: pointer;">
                <td class="fw-semibold"><span class="caret me-1">${open ? "▼" : "▶"}</span>${escapeHtml(g.name || "Unknown")}${roleBadge(g.role)}</td>
                <td>${g.rows.length}</td>
                <td>${countBadge(count("Borrowed"), "bg-primary")}</td>
                <td>${countBadge(count("Overdue"), "bg-danger")}</td>
            </tr>
            <tr class="detail-row ${open ? "" : "d-none"}">
                <td colspan="4" class="bg-light p-2">
                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-0">
                            <thead><tr><th>Book</th><th>Date Borrowed</th><th>Due Date</th><th>Status</th><th>Processed By</th></tr></thead>
                            <tbody>${books}</tbody>
                        </table>
                    </div>
                </td>
            </tr>`;
    }).join("");
};

const toggleBorrower = (row) => {
    const key = row.dataset.key;
    const open = !openBorrowers.has(key);
    if (open) openBorrowers.add(key); else openBorrowers.delete(key);

    row.setAttribute("aria-expanded", String(open));
    row.querySelector(".caret").textContent = open ? "▼" : "▶";
    row.nextElementSibling.classList.toggle("d-none", !open);
};

const renderReport = () => {
    const rows = getFilteredRows();
    const tbody = document.getElementById("table-body");

    const overdue = rows.filter((r) => r.status === "Overdue").length;
    // days_overdue is negative while a book is not late yet: -3 means due in 3 days.
    const soon = rows.filter((r) => r.status === "Borrowed" && Number(r.days_overdue) >= -3).length;
    const borrowers = new Set(rows.map((r) => r.student_id != null ? `s${r.student_id}` : `n${r.borrower}`)).size;

    document.getElementById("sum-total").innerText = rows.length;
    document.getElementById("sum-overdue").innerText = overdue;
    document.getElementById("sum-soon").innerText = soon;
    document.getElementById("sum-borrowers").innerText = borrowers;
    document.getElementById("kpi-overdue").classList.toggle("is-alert", overdue > 0);
    document.getElementById("sum-overdue-note").innerText = overdue > 0 ? "please follow up" : "nothing late";

    renderSummary(rows);

    if (rows.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="text-center text-muted">No books are out right now.</td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = rows.map((row, index) => `
        <tr>
            <td>${index + 1}</td>
            <td>${escapeHtml(row.borrower)}${roleBadge(row.borrower_role)}</td>
            <td>${escapeHtml(row.title)} <span class="text-muted small">[ACC-${escapeHtml(row.accession_number)}]</span></td>
            <td>${escapeHtml(row.borrow_date)}</td>
            <td>${escapeHtml(row.due_date)}</td>
            <td>${statusBadge(row)}</td>
            <td>${row.borrow_processed_by ? escapeHtml(row.borrow_processed_by) : "—"}</td>
        </tr>
    `).join("");
};

const resetFilters = () => {
    document.getElementById("filter-search").value = "";
    document.getElementById("filter-status").value = "";
    document.getElementById("filter-staff").value = "";
    document.getElementById("filter-from").value = "";
    document.getElementById("filter-to").value = "";
    renderReport();
};

const showAlert = (msg, type) => {
    const box = document.getElementById("alert-box");
    box.innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert"><span></span>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    box.querySelector("span").textContent = msg; // plain text, never HTML
};
