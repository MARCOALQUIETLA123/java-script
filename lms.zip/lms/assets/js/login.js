const api = "api/auth.php";

const showAlert = (msg, type) => {
    const box = document.getElementById("alert-box");
    box.innerHTML = `<div class="alert alert-${type}" role="alert"></div>`;
    box.firstChild.textContent = msg; // plain text, never HTML
};

const errorMessage = (error) =>
    (error.response && error.response.data && error.response.data.message) || "Could not reach the server.";

// Where to go after logging in: the page that sent us here, if it is one of ours.
const destination = () => {
    const next = new URLSearchParams(location.search).get("next") || "";
    return /^[a-z_]+\.html$/i.test(next) ? next : "dashboard.html";
};

const $ = (id) => document.getElementById(id);

const showForm = (which) => {
    $("login-form").classList.toggle("d-none", which !== "login");
    $("signup-form").classList.toggle("d-none", which !== "signup");
    $("alert-box").innerHTML = "";
};

const loadDepartments = async () => {
    try {
        const res = await axios.get(api, { params: { operation: "departments" } });
        const select = $("su-dept");
        select.innerHTML = '<option value="">No department (optional)</option>';
        res.data.forEach((d) => {
            const opt = document.createElement("option");
            opt.value = d.department_id;
            opt.textContent = d.department_name;
            select.appendChild(opt);
        });
    } catch (e) {
        showAlert("Could not load departments.", "danger");
    }
};

const doLogin = async (e) => {
    e.preventDefault();

    const username = $("username").value.trim();
    const password = $("password").value;

    if (!username || !password) {
        showAlert("Enter your username and password.", "danger");
        return;
    }

    const btn = $("btn-login");
    btn.disabled = true;

    try {
        const formData = new FormData();
        formData.append("operation", "login");
        formData.append("username", username);
        formData.append("password", password);

        const res = await axios.post(api, formData);
        const isBorrower = res.data.user && res.data.user.role === "borrower";
        location.replace(isBorrower ? "portal.html" : destination());
    } catch (error) {
        const code = error.response && error.response.data && error.response.data.code;
        showAlert(errorMessage(error), code === "pending" ? "warning" : "danger");
        $("password").value = "";
        btn.disabled = false;
    }
};

const doSignup = async (e) => {
    e.preventDefault();

    const v = {
        first_name: $("su-first").value.trim(),
        last_name: $("su-last").value.trim(),
        email: $("su-email").value.trim(),
        contact_number: $("su-contact").value.trim(),
        department_id: $("su-dept").value,
        username: $("su-username").value.trim(),
        role: $("su-role").value,
        password: $("su-password").value,
        confirm_password: $("su-confirm").value
    };

    if (Object.entries(v).some(([k, x]) => x === "" && k !== "department_id")) return showAlert("All fields are required.", "danger");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email)) return showAlert("Please enter a valid email address.", "danger");
    if (!/^0\d{10}$/.test(v.contact_number) && !/^[1-9]\d{9}$/.test(v.contact_number)) {
        return showAlert("Contact number must be 11 digits (e.g. 09171234567) or 10 digits without the leading 0.", "danger");
    }
    if (!/^[A-Za-z0-9._-]{3,30}$/.test(v.username)) {
        return showAlert("Username must be 3-30 characters: letters, numbers, dot, dash or underscore.", "danger");
    }
    if (v.password.length < 8) return showAlert("Password must be at least 8 characters.", "danger");
    if (v.password !== v.confirm_password) return showAlert("The two passwords don't match.", "danger");

    const btn = $("btn-signup");
    btn.disabled = true;

    try {
        const formData = new FormData();
        formData.append("operation", "signup");
        Object.entries(v).forEach(([k, val]) => formData.append(k, val));

        const res = await axios.post(api, formData);

        $("signup-form").reset();
        showForm("login");
        showAlert(res.data.message, "success");
    } catch (error) {
        showAlert(errorMessage(error), "danger");
    }

    btn.disabled = false;
};

document.addEventListener("DOMContentLoaded", async () => {
    // Already signed in? Skip the form.
    try {
        await axios.get(api, { params: { operation: "me" } });
        location.replace(destination());
        return;
    } catch (e) { /* not signed in, show the form */ }

    $("login-form").addEventListener("submit", doLogin);
    $("signup-form").addEventListener("submit", doSignup);

    $("show-signup").addEventListener("click", (e) => {
        e.preventDefault();
        showForm("signup");
        if ($("su-dept").options.length <= 1) loadDepartments();
    });
    $("show-login").addEventListener("click", (e) => {
        e.preventDefault();
        showForm("login");
    });
});