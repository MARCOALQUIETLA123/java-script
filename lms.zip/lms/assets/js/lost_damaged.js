const API = "api/book_return.php";
const PAGE_SIZE = 10;

const CLEARANCE_WARNING = "Warning: a lost or damaged book is reflected on the borrower's clearance, and the borrower will not get their clearance signed until this case is settled.";

// Clearance only applies to students. A dean's book is deducted from his or her salary; faculty get no clearance note.
const kindWarning = (r) => r && r.borrower_kind === "dean"
    ? "Notice: the price of the book and the processing fee will be deducted from the borrower's salary."
    : r && r.borrower_kind === "faculty" ? "" : CLEARANCE_WARNING;

const state = {
    search: "", status: "open", condition: "", page: 1, pages: 1, total: 0,
    rows: [], fee: 100
};

let requestId = 0;
let priceModal = null;
let settleModal = null;
let receiptModal = null;

/* ---------------- Helpers ---------------- */

const $ = (id) => document.getElementById(id);

const escapeHtml = (value) => String(value ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const fmtDate = (value) => {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(value || "");
    return m ? `${MONTHS[Number(m[2]) - 1]} ${Number(m[3])}, ${m[1]}` : "—";
};

const peso = (n) => "₱" + Number(n || 0).toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const debounce = (fn, wait = 300) => {
    let timer;
    return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), wait); };
};

const toast = (message, type = "success") => {
    const el = document.createElement("div");
    el.className = `toast align-items-center text-bg-${type} border-0`;
    el.setAttribute("role", type === "danger" ? "alert" : "status");
    el.innerHTML = `<div class="d-flex"><div class="toast-body">${escapeHtml(message)}</div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button></div>`;
    $("toast-area").appendChild(el);

    const t = new bootstrap.Toast(el, { delay: type === "danger" ? 8000 : 4000 });
    el.addEventListener("hidden.bs.toast", () => el.remove());
    t.show();
};

const apiGet = async (operation, params = {}) => (await axios.get(API, { params: { operation, ...params } })).data;

const apiPost = async (operation, payload) => {
    const formData = new FormData();
    formData.append("operation", operation);
    formData.append("json", JSON.stringify(payload));
    return (await axios({ url: API, method: "POST", data: formData })).data;
};

const findCase = (id) => state.rows.find((r) => String(r.return_id) === String(id));

const total = (r) => Number(r.book_price || 0) + Number(r.processing_fee || 0);

/* ---------------- Start ---------------- */

document.addEventListener("DOMContentLoaded", () => {
    priceModal = new bootstrap.Modal($("priceModal"));
    settleModal = new bootstrap.Modal($("settleModal"));
    receiptModal = new bootstrap.Modal($("receiptModal"));

    const search = debounce(() => {
        state.search = $("case-search").value.trim();
        state.page = 1;
        loadCases();
    });

    $("case-search").addEventListener("input", search);
    $("case-status").addEventListener("change", (e) => { state.status = e.target.value; state.page = 1; loadCases(); });
    $("case-condition").addEventListener("change", (e) => { state.condition = e.target.value; state.page = 1; loadCases(); });

    $("case-reset").addEventListener("click", () => {
        $("case-search").value = "";
        $("case-status").value = "open";
        $("case-condition").value = "";
        Object.assign(state, { search: "", status: "open", condition: "", page: 1 });
        loadCases();
    });

    $("case-prev").addEventListener("click", () => { if (state.page > 1) { state.page--; loadCases(); } });
    $("case-next").addEventListener("click", () => { if (state.page < state.pages) { state.page++; loadCases(); } });

    document.querySelectorAll(".stat-card[data-filter]").forEach((card) => {
        card.addEventListener("click", () => {
            const f = card.dataset.filter;
            state.status = f === "closed" ? "Settled" : f;
            $("case-status").value = state.status;
            state.page = 1;
            loadCases();
        });
    });

    $("case-body").addEventListener("click", (e) => {
        const btn = e.target.closest("button[data-action]");
        if (!btn) return;
        const id = btn.dataset.id;

        if (btn.dataset.action === "price") openPrice(id);
        if (btn.dataset.action === "settle") openSettle(id);
        if (btn.dataset.action === "receipt") showReceipt(id);
    });

    $("price-input").addEventListener("input", refreshPriceLines);
    document.querySelectorAll("input[name='choose-method']").forEach((radio) => radio.addEventListener("change", refreshChooseFields));
    $("btn-save-price").addEventListener("click", savePrice);

    document.querySelectorAll("input[name='settle-method']").forEach((radio) => {
        radio.addEventListener("change", refreshSettleFields);
    });
    $("btn-save-settle").addEventListener("click", saveSettle);

    $("btn-print-receipt").addEventListener("click", printReceipt);

    loadCases();
});

/* ---------------- List ---------------- */

const loadCases = async () => {
    const request = ++requestId;
    $("case-body").innerHTML = `<tr><td colspan="6" class="text-center text-muted">Loading...</td></tr>`;

    try {
        const data = await apiGet("getCases", {
            search: state.search,
            status: state.status,
            condition: state.condition,
            page: state.page,
            limit: PAGE_SIZE
        });

        if (request !== requestId) return;
        if (!data || !Array.isArray(data.rows)) throw new Error("Unexpected response");

        if (data.rows.length === 0 && data.total > 0 && state.page > 1) {
            state.page = data.pages;
            return loadCases();
        }

        Object.assign(state, { rows: data.rows, total: data.total, pages: data.pages, page: data.page, fee: data.processing_fee });

        $("sum-pending").textContent = data.summary.pending;
        $("sum-awaiting").textContent = data.summary.awaiting;
        $("sum-replacing").textContent = data.summary.replacing;
        $("sum-closed").textContent = data.summary.closed;
        $("sum-outstanding").textContent = peso(data.summary.outstanding);

        renderCases();
    } catch (error) {
        if (request !== requestId) return;
        $("case-body").innerHTML = `<tr><td colspan="6" class="text-center text-danger">Could not load the cases.</td></tr>`;
        toast("Failed to load the lost and damaged books.", "danger");
    }
};

const statusBadge = (status) => ({
    "Pending": '<span class="badge bg-danger">Not decided yet</span>',
    "Awaiting payment": '<span class="badge bg-warning text-dark">Awaiting payment</span>',
    "Awaiting replacement": '<span class="badge bg-primary">Awaiting replacement</span>',
    "Settled": '<span class="badge bg-success">Settled</span>',
    "Waived": '<span class="badge bg-secondary">Waived</span>'
}[status] || escapeHtml(status));

const renderCases = () => {
    $("case-page").textContent = state.total === 0
        ? "No cases"
        : `Page ${state.page} of ${state.pages} · ${state.total} ${state.total === 1 ? "case" : "cases"}`;
    $("case-prev").disabled = state.page <= 1;
    $("case-next").disabled = state.page >= state.pages;

    if (state.rows.length === 0) {
        $("case-body").innerHTML = `<tr><td colspan="6" class="text-center text-muted">No cases match these filters.</td></tr>`;
        return;
    }

    $("case-body").innerHTML = state.rows.map((r) => {
        const open = ["Pending", "Awaiting payment", "Awaiting replacement"].includes(r.case_status);
        const id = r.return_id;

        const money = r.settlement === "Replaced"
            ? '<span class="text-muted">Replaced with a new copy</span>'
            : r.case_status === "Awaiting replacement"
            ? `<span class="text-muted">Replace with:</span><div class="small fw-semibold">${escapeHtml(r.replacement_title || r.title)}${r.replacement_year ? ` (${escapeHtml(r.replacement_year)})` : ""}</div>`
            : r.book_price === null || r.book_price === undefined
                ? '<span class="text-muted">Not set</span>'
                : `${peso(r.book_price)} + ${peso(r.processing_fee)}<div class="fw-semibold">${peso(total(r))}</div>`;

        const actions = [];
        if (open) {
            actions.push(`<button class="btn btn-success btn-sm admin-only" data-action="price" data-id="${id}">${r.case_status === "Pending" ? "Choose settlement" : "Change"}</button>`);
        }
        if (r.case_status === "Awaiting payment") {
            actions.push(`<button class="btn btn-outline-success btn-sm" data-action="receipt" data-id="${id}">Print receipt</button>`);
        }
        if (open) {
            actions.push(`<button class="btn btn-outline-secondary btn-sm admin-only" data-action="settle" data-id="${id}">Close case</button>`);
        }
        if (r.case_status === "Settled" && r.settlement === "Paid") {
            actions.push(`<button class="btn btn-outline-secondary btn-sm" data-action="receipt" data-id="${id}">Receipt</button>`);
        }

        return `
        <tr>
            <td>
                <div class="fw-semibold">${escapeHtml(r.student_name || "Unknown")}</div>
                <div class="small text-muted">${escapeHtml(r.course || "")}</div>
            </td>
            <td>
                ${escapeHtml(r.title || "Book")}
                <div class="small text-muted">ACC-${escapeHtml(r.accession_number || "?")}
                    <span class="badge ${r.condition_on_return === "Lost" ? "bg-danger" : "bg-warning text-dark"} ms-1">${escapeHtml(r.condition_on_return)}</span></div>
            </td>
            <td class="text-nowrap">${escapeHtml(fmtDate(r.return_date))}</td>
            <td class="text-nowrap">${money}${r.receipt_no ? `<div class="small text-muted">${escapeHtml(r.receipt_no)}</div>` : ""}</td>
            <td>${statusBadge(r.case_status)}${r.or_number ? `<div class="small text-muted">OR ${escapeHtml(r.or_number)}</div>` : ""}${r.settled_at ? `<div class="small text-muted">${escapeHtml(fmtDate(r.settled_at))}</div>` : ""}${r.case_note ? `<div class="small text-muted">${escapeHtml(r.case_note)}</div>` : ""}</td>
            <td class="text-nowrap">${actions.join(" ") || '<span class="text-muted">—</span>'}</td>
        </tr>`;
    }).join("");
};

/* ---------------- Choose how the borrower settles ---------------- */

const replacementText = (r) => `${r.replacement_title || r.title}${r.replacement_year ? ` (${r.replacement_year})` : ""}`;

const openPrice = (id) => {
    const r = findCase(id);
    if (!r) return;

    $("price-id").value = id;
    $("price-book").textContent = `${r.title} (ACC-${r.accession_number}) · ${r.condition_on_return}`;
    $("price-who").textContent = `Borrower: ${r.student_name || "Unknown"}`;

    const current = r.book_price !== null && r.book_price !== undefined ? r.book_price : "";
    $("price-input").value = current !== "" ? current : (r.suggested_price !== null && r.suggested_price !== undefined ? r.suggested_price : "");
    $("price-note").value = r.case_note || "";
    $("price-suggest").textContent = r.suggested_price !== null && r.suggested_price !== undefined
        ? `Price filled in automatically from the Books page (${peso(r.suggested_price)}). You only need to change it if it is wrong.`
        : "This book has no price on the Books page yet. Type the price the borrower must pay.";

    $("replace-title").textContent = replacementText(r);
    $("replace-authors").textContent = r.replacement_authors ? `Author(s): ${r.replacement_authors}` : "Author(s): same as the lost or damaged copy";
    $("replace-note").textContent = r.replacement_is_newer
        ? "A newer edition than the lost or damaged copy exists, so this newest edition is required."
        : "This is already the newest edition.";

    $(r.case_status === "Awaiting replacement" ? "choose-replace" : "choose-pay").checked = true;
    refreshChooseFields();
    refreshPriceLines();
    priceModal.show();
};

const chosenMethod = () => document.querySelector("input[name='choose-method']:checked").value;

const refreshChooseFields = () => {
    const replace = chosenMethod() === "replace";
    $("pay-fields").classList.toggle("d-none", replace);
    $("replace-fields").classList.toggle("d-none", !replace);
    $("btn-save-price").textContent = replace ? "Save: bring the newest edition" : "Save price and create receipt";
};

const refreshPriceLines = () => {
    const price = Number($("price-input").value) > 0 ? Number($("price-input").value) : 0;
    $("price-line-book").textContent = peso(price);
    $("price-line-fee").textContent = peso(state.fee);
    $("price-line-total").textContent = peso(price + state.fee);
};

const savePrice = async () => {
    const id = $("price-id").value;
    const method = chosenMethod();
    const price = $("price-input").value;

    if (method === "pay" && !(Number(price) > 0)) {
        toast("Enter the price of the book.", "danger");
        $("price-input").focus();
        return;
    }

    const btn = $("btn-save-price");
    btn.disabled = true;

    try {
        const before = { ...findCase(id) };
        const result = await apiPost("saveCase", { return_id: id, method, price, note: $("price-note").value });
        if (result.status === "success") priceModal.hide();
        toast(result.message, result.status === "success" ? "success" : "danger");
        loadCases();

        // Paying: straight to the receipt, so it can be handed to the borrower.
        if (result.status === "success" && method === "pay") {
            showReceipt(id, {
                ...before,
                book_price: Number(price),
                processing_fee: state.fee,
                receipt_no: before.receipt_no || "LD-" + String(id).padStart(6, "0"),
                settlement: "Pending"
            });
        }
    } catch (error) {
        toast("Failed to save.", "danger");
    } finally {
        btn.disabled = false;
    }
};

/* ---------------- Close a case ---------------- */

const openSettle = (id) => {
    const r = findCase(id);
    if (!r) return;

    $("settle-id").value = id;
    $("settle-book").textContent = `${r.title} (ACC-${r.accession_number}) · ${r.condition_on_return}`;
    $("settle-who").textContent = `Borrower: ${r.student_name || "Unknown"}`;
    $("settle-total").textContent = r.case_status === "Awaiting payment" ? peso(total(r)) : "";
    $("settle-replacement").textContent = replacementText(r);
    $("settle-authors").textContent = r.replacement_authors ? `Author(s): ${r.replacement_authors}` : "";
    $("settle-or").value = "";
    $("settle-note").value = "";
    $("settle-verified").checked = false;

    // Only the option the Technical Services Librarian chose is offered: pay (needs the price and receipt) or the replacement copy.
    const canPay = r.case_status === "Awaiting payment";
    const canReplace = r.case_status === "Awaiting replacement";
    $("opt-paid-wrap").classList.toggle("d-none", !canPay);
    $("opt-replaced-wrap").classList.toggle("d-none", !canReplace);
    // A dean's lost or damaged book is deducted from his or her salary (no Assessment payment, no clearance).
    $("opt-salary-wrap").classList.toggle("d-none", !(canPay && r.borrower_kind === "dean"));
    $("settle-total").textContent = canPay ? peso(total(r)) : "";

    document.querySelectorAll("input[name='settle-method']").forEach((radio) => { radio.checked = false; });
    refreshSettleFields();
    settleModal.show();
};

const refreshSettleFields = () => {
    const chosen = document.querySelector("input[name='settle-method']:checked");
    $("paid-fields").classList.toggle("d-none", !(chosen && chosen.value === "paid"));
    $("waive-fields").classList.toggle("d-none", !(chosen && chosen.value === "waived"));
    $("replace-verify").classList.toggle("d-none", !(chosen && chosen.value === "replaced"));
};

const saveSettle = async () => {
    const chosen = document.querySelector("input[name='settle-method']:checked");
    if (!chosen) {
        toast("Choose how this case is closed.", "danger");
        return;
    }

    const id = $("settle-id").value;
    const method = chosen.value;
    const r = findCase(id);

    if (method === "paid" && $("settle-or").value.trim() === "") {
        toast("Enter the Assessment receipt number.", "danger");
        $("settle-or").focus();
        return;
    }
    if (method === "replaced" && !$("settle-verified").checked) {
        toast("Check the copy first: newest edition, same title and author(s).", "danger");
        return;
    }
    if (method === "waived" && $("settle-note").value.trim() === "") {
        toast("Write the reason for waiving the charge.", "danger");
        $("settle-note").focus();
        return;
    }

    const text = {
        paid: `Record the payment of ${peso(total(r))} for ${r.student_name}?`,
        replaced: `Confirm that ${r.student_name} brought a replacement copy? It will be added to the library.`,
        waived: `Waive the charge for ${r.student_name}?`,
        salary: `Deduct ${peso(total(r))} from ${r.student_name}'s salary and close the case?`
    }[method];

    const confirmed = await Swal.fire({ title: "Please confirm", text, icon: "question", showCancelButton: true, confirmButtonText: "Yes, close the case" });
    if (!confirmed.isConfirmed) return;

    const btn = $("btn-save-settle");
    btn.disabled = true;

    try {
        const result = await apiPost("settleCase", {
            return_id: id, method, or_number: $("settle-or").value, note: $("settle-note").value,
            verified: $("settle-verified").checked
        });
        if (result.status === "success") settleModal.hide();
        toast(result.message, result.status === "success" ? "success" : "danger");
        loadCases();
    } catch (error) {
        toast("Failed to close the case.", "danger");
    } finally {
        btn.disabled = false;
    }
};

/* ---------------- Receipt ---------------- */

const RECEIPT_CSS = `
    body { font-family: Arial, Helvetica, sans-serif; color: #000; margin: 0; padding: 16px; }
    .receipt { max-width: 420px; margin: 0 auto; font-size: 14px; }
    .receipt h2 { text-align: center; margin: 0 0 2px; font-size: 18px; }
    .center { text-align: center; margin-bottom: 10px; }
    .meta { border-top: 1px dashed #000; border-bottom: 1px dashed #000; padding: 6px 0; margin-bottom: 8px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 6px; }
    td { padding: 2px 0; vertical-align: top; }
    td.r { text-align: right; white-space: nowrap; }
    tr.total td { font-size: 16px; font-weight: bold; border-top: 2px solid #000; padding-top: 6px; }
    .small { font-size: 12px; }
    .status { text-align: center; font-weight: bold; border: 1px solid #000; padding: 4px; margin: 8px 0; }
    .warn { border: 1px solid #000; padding: 6px; font-size: 12px; }`;

const receiptHtml = (r) => {
    const paid = r.settlement === "Paid";

    return `
    <div class="receipt">
        <h2>Library Management System</h2>
        <div class="center">Lost / damaged book: payment slip for Assessment</div>
        <div class="meta">
            <div><strong>Receipt no.:</strong> ${escapeHtml(r.receipt_no || "—")}</div>
            <div><strong>Date reported:</strong> ${escapeHtml(fmtDate(r.return_date))}</div>
            <div><strong>Borrower:</strong> ${escapeHtml(r.student_name || "Unknown")}</div>
            <div><strong>Book:</strong> ${escapeHtml(r.title || "Book")} <span class="small">[ACC-${escapeHtml(r.accession_number || "?")}]</span></div>
            <div><strong>Reason:</strong> ${escapeHtml(r.condition_on_return)} book</div>
            <div><strong>Prepared by:</strong> ${escapeHtml(r.processed_by || "—")}</div>
        </div>
        <table>
            <tr><td>Price of the book</td><td class="r">${peso(r.book_price)}</td></tr>
            <tr><td>Processing fee</td><td class="r">${peso(r.processing_fee)}</td></tr>
            <tr class="total"><td>TOTAL TO PAY</td><td class="r">${peso(total(r))}</td></tr>
        </table>
        <div class="status">${paid ? `PAID · Assessment receipt no. ${escapeHtml(r.or_number || "")}` : "UNPAID until stamped by Assessment"}</div>
        ${kindWarning(r) ? `<div class="warn">${escapeHtml(kindWarning(r))}</div>` : ""}
    </div>`;
};

const showReceipt = (id, row = null) => {
    const r = row || findCase(id);
    if (!r || r.book_price === null || r.book_price === undefined) {
        toast("Set the price first to create the receipt.", "danger");
        return;
    }

    $("receipt-body").innerHTML = `<style>${RECEIPT_CSS.replace(/body \{[^}]*\}/, "")}</style>${receiptHtml(r)}`;
    receiptModal.show();
};

const printReceipt = () => {
    const frame = document.createElement("iframe");
    frame.style.cssText = "position: fixed; width: 0; height: 0; border: 0;";
    document.body.appendChild(frame);

    const doc = frame.contentWindow.document;
    doc.open();
    doc.write(`<!DOCTYPE html><html><head><title>Receipt</title><style>${RECEIPT_CSS}</style></head><body>${$("receipt-body").querySelector(".receipt").outerHTML}</body></html>`);
    doc.close();

    frame.contentWindow.focus();
    frame.contentWindow.print();
    setTimeout(() => frame.remove(), 1000);
};