const baseApiUrl = "api"; // relative to the page, so it works from any folder

let selectedIds = new Set(); // copy_ids ticked for bulk disposal

const escapeHtml = (value) => {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
};

document.addEventListener("DOMContentLoaded", () => {
    loadDropdowns();
    loadRecords();
    document.getElementById("btn-save").addEventListener("click", saveRecord);
    document.getElementById("btn-clear").addEventListener("click", clearForm);
    document.getElementById("quantity").addEventListener("input", setAccessionPreview);
    document.getElementById("btn-delete-selected").addEventListener("click", deleteSelected);
    document.getElementById("select-all").addEventListener("change", (e) => toggleSelectAll(e.target.checked));

    document.getElementById("btn-mode").addEventListener("click", () => setDetailed(!detailed));
    setDetailed(detailed);

    const summaryBody = document.getElementById("summary-body");
    summaryBody.addEventListener("click", (e) => {
        const row = e.target.closest("tr.book-row");
        if (row) toggleBook(row);
    });
    summaryBody.addEventListener("keydown", (e) => {
        const row = e.target.closest("tr.book-row");
        if (row && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); toggleBook(row); }
    });
});

/* ---------------- Summary (default) and detailed views ---------------- */

let detailed = false;
try { detailed = localStorage.getItem("lms_copies_detailed") === "1"; } catch (e) { /* storage unavailable */ }

const openBooks = new Set(); // expanded books, kept across live refreshes

const setDetailed = (on) => {
    detailed = on;
    try { localStorage.setItem("lms_copies_detailed", on ? "1" : "0"); } catch (e) { /* ignore */ }

    document.getElementById("summary-wrap").classList.toggle("d-none", on);
    document.getElementById("summary-hint").classList.toggle("d-none", on);
    document.getElementById("detail-wrap").classList.toggle("d-none", !on);

    const btn = document.getElementById("btn-mode");
    btn.classList.toggle("btn-success", on);
    btn.classList.toggle("btn-outline-success", !on);
    btn.setAttribute("aria-pressed", String(on));
};

const STATUS_BADGE = { available: "bg-success", borrowed: "bg-primary", reserved: "bg-info text-dark", "library use only": "bg-info text-dark" };

const countBadge = (n, cls) => n > 0 ? `<span class="badge ${cls}">${n}</span>` : '<span class="text-muted">0</span>';

const renderSummary = (data) => {
    const tbody = document.getElementById("summary-body");

    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No records found.</td></tr>';
        return;
    }

    const groups = new Map(); // one entry per book
    data.forEach((row) => {
        const key = String(row.book_id);
        if (!groups.has(key)) groups.set(key, { key, title: row.title, copies: [] });
        groups.get(key).copies.push(row);
    });

    tbody.innerHTML = [...groups.values()].map((g) => {
        const is = (row, s) => String(row.status_desc || "").toLowerCase() === s;
        const available = g.copies.filter((c) => is(c, "available")).length;
        const borrowed = g.copies.filter((c) => is(c, "borrowed")).length;
        const other = g.copies.length - available - borrowed;
        const open = openBooks.has(g.key);

        const copies = g.copies.map((row) => `
            <tr>
                <td class="admin-only" style="width: 40px;"><input type="checkbox" class="form-check-input row-select" ${selectedIds.has(String(row.copy_id)) ? "checked" : ""}
                           onchange="toggleSelect(${row.copy_id}, this.checked)"></td>
                <td>${escapeHtml(row.accession_number)}</td>
                <td><span class="badge ${STATUS_BADGE[String(row.status_desc || "").toLowerCase()] || "bg-secondary"}">${escapeHtml(row.status_desc)}</span></td>
                <td>${escapeHtml(row.condition)}</td>
                <td>${escapeHtml(row.added_at)}</td>
                <td class="admin-only text-nowrap">
                    <button class="btn btn-success btn-sm me-1" onclick="editRecord(${row.copy_id})">Edit</button>
                    <button class="btn btn-danger btn-sm" onclick="deleteRecord(${row.copy_id})">Dispose</button>
                </td>
            </tr>`).join("");

        return `
            <tr class="book-row" data-key="${escapeHtml(g.key)}" tabindex="0" role="button" aria-expanded="${open}" style="cursor: pointer;">
                <td class="fw-semibold"><span class="caret me-1">${open ? "▼" : "▶"}</span>${escapeHtml(g.title || "Unknown book")}</td>
                <td>${g.copies.length}</td>
                <td>${countBadge(available, "bg-success")}</td>
                <td>${countBadge(borrowed, "bg-primary")}</td>
                <td>${countBadge(other, "bg-secondary")}</td>
            </tr>
            <tr class="detail-row ${open ? "" : "d-none"}">
                <td colspan="5" class="bg-light p-2">
                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-0">
                            <thead><tr><th class="admin-only"></th><th>Accession No.</th><th>Status</th><th>Condition</th><th>Added At</th><th class="admin-only">Actions</th></tr></thead>
                            <tbody>${copies}</tbody>
                        </table>
                    </div>
                </td>
            </tr>`;
    }).join("");
};

const toggleBook = (row) => {
    const key = row.dataset.key;
    const open = !openBooks.has(key);
    if (open) openBooks.add(key); else openBooks.delete(key);

    row.setAttribute("aria-expanded", String(open));
    row.querySelector(".caret").textContent = open ? "▼" : "▶";
    row.nextElementSibling.classList.toggle("d-none", !open);
};

const loadDropdowns = async () => {
    try {
        const [bookRes, statusRes] = await Promise.all([
            axios.get(`${baseApiUrl}/book.php`, { params: { operation: "getAll" } }),
            axios.get(`${baseApiUrl}/status.php`, { params: { operation: "getAll" } })
        ]);

        const bookSelect = document.getElementById("book_id");
        bookSelect.innerHTML = '<option value="">Select Book</option>';
        bookRes.data.forEach(r => {
            bookSelect.innerHTML += `<option value="${r.book_id}">${escapeHtml(r.title)}</option>`;
        });

        const statusSelect = document.getElementById("status_id");
        statusSelect.innerHTML = '<option value="">Select Status</option>';
        statusRes.data.forEach(r => {
            statusSelect.innerHTML += `<option value="${r.status_id}">${escapeHtml(r.status_desc)}</option>`;
        });
    } catch (error) {
        showAlert("Failed to load dropdown data.", "danger");
    }
};

const isEditing = () => document.getElementById("editing-id").value.trim() !== "";

const getQuantity = () => {
    const n = parseInt(document.getElementById("quantity").value, 10);
    return isNaN(n) || n < 1 ? 1 : n;
};

// Preview only — the real values are generated server-side on save,
// this just shows the Technical Services Librarian what the next number(s) will likely be.
const computeNextAccessionNumber = () => {
    const data = window._bcData || [];
    let max = 1000;

    data.forEach(row => {
        const n = parseInt(row.accession_number, 10);
        if (!isNaN(n) && n > max) {
            max = n;
        }
    });

    return max + 1;
};

const setAccessionPreview = () => {
    // Only overwrite the field when we're in "add" mode, not while editing an existing copy.
    if (isEditing()) return;

    const first = computeNextAccessionNumber();
    const qty = getQuantity();
    document.getElementById("accession_number").value = qty > 1 ? `${first} - ${first + qty - 1}` : String(first);
};

const updateBulkControls = () => {
    const btn = document.getElementById("btn-delete-selected");
    btn.innerText = `Dispose Selected (${selectedIds.size})`;
    btn.disabled = selectedIds.size === 0;

    const all = window._bcData || [];
    const selectAll = document.getElementById("select-all");
    selectAll.checked = all.length > 0 && selectedIds.size === all.length;
    selectAll.indeterminate = selectedIds.size > 0 && selectedIds.size < all.length;
};

const toggleSelect = (id, checked) => {
    if (checked) {
        selectedIds.add(String(id));
    } else {
        selectedIds.delete(String(id));
    }
    updateBulkControls();
};

const toggleSelectAll = (checked) => {
    selectedIds = new Set();
    if (checked) {
        (window._bcData || []).forEach(row => selectedIds.add(String(row.copy_id)));
    }
    document.querySelectorAll(".row-select").forEach(cb => { cb.checked = checked; });
    updateBulkControls();
};

const loadRecords = async () => {
    try {
        const response = await axios.get(`${baseApiUrl}/book_copies.php`, {
            params: { operation: "getAll" }
        });

        const tbody = document.getElementById("table-body");
        tbody.innerHTML = "";
        window._bcData = response.data;

        // Drop selections for rows that no longer exist.
        const existing = new Set(response.data.map(r => String(r.copy_id)));
        selectedIds = new Set([...selectedIds].filter(id => existing.has(id)));

        renderSummary(response.data);
        loadArchive();

        if (response.data.length === 0) {
            tbody.innerHTML = `<tr><td colspan="8" class="text-center text-muted">No records found.</td></tr>`;
        } else {
            response.data.forEach((row, index) => {
                tbody.innerHTML += `
                    <tr>
                        <td class="admin-only"><input type="checkbox" class="form-check-input row-select" ${selectedIds.has(String(row.copy_id)) ? "checked" : ""}
                                   onchange="toggleSelect(${row.copy_id}, this.checked)"></td>
                        <td>${index + 1}</td>
                        <td>${escapeHtml(row.title)}</td>
                        <td>${escapeHtml(row.accession_number)}</td>
                        <td>${escapeHtml(row.status_desc)}</td>
                        <td>${escapeHtml(row.condition)}</td>
                        <td>${escapeHtml(row.added_at)}</td>
                        <td class="admin-only">
                            <button class="btn btn-success btn-sm me-1" onclick="editRecord(${row.copy_id})">Edit</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteRecord(${row.copy_id})">Dispose</button>
                        </td>
                    </tr>`;
            });
        }

        updateBulkControls();
        setAccessionPreview();
    } catch (error) {
        showAlert("Failed to load book copies.", "danger");
    }
};

const isMeaningfulText = value => {
    const trimmed = value.trim();
    return trimmed.length >= 2 && !/^\d+$/.test(trimmed);
};

const saveRecord = async () => {
    const editing = isEditing();
    const editingId = document.getElementById("editing-id").value.trim();
    const book_id = document.getElementById("book_id").value;
    const status_id = document.getElementById("status_id").value;
    const condition = document.getElementById("condition").value.trim();

    if (!book_id || !status_id || !condition) {
        showAlert("All fields are required.", "danger");
        return;
    }

    if (!isMeaningfulText(condition)) {
        showAlert("Condition must be meaningful text (e.g. Good, Fair), not just numbers.", "danger");
        return;
    }

    const jsonData = {
        book_id,
        status_id,
        condition
    };

    let operation = "add";

    if (editing) {
        // Editing keeps whatever accession number the copy already has —
        // it's only auto-generated when new copies are created.
        jsonData.copy_id = editingId;
        jsonData.accession_number = document.getElementById("accession_number").value.trim();
        operation = "update";
    } else {
        const raw = document.getElementById("quantity").value.trim();
        const quantity = Number(raw);

        if (raw === "" || !Number.isInteger(quantity) || quantity < 1 || quantity > 100) {
            showAlert("Number of copies must be a whole number from 1 to 100.", "danger");
            return;
        }

        jsonData.quantity = quantity;
    }

    try {
        const formData = new FormData();
        formData.append("operation", operation);
        formData.append("json", JSON.stringify(jsonData));

        const response = await axios({
            url: `${baseApiUrl}/book_copies.php`,
            method: "POST",
            data: formData
        });

        if (response.data.status === "success") {
            clearForm();
            showAlert(response.data.message, "success");
            loadRecords();
        } else {
            showAlert(response.data.message, "danger");
        }
    } catch (error) {
        showAlert("Failed to save book copy.", "danger");
    }
};

const editRecord = id => {
    const row = window._bcData.find(r => r.copy_id == id);
    if (!row) return;

    document.getElementById("editing-id").value = id;
    document.getElementById("book_id").value = row.book_id;
    document.getElementById("status_id").value = row.status_id;
    document.getElementById("accession_number").value = row.accession_number;
    document.getElementById("condition").value = row.condition;

    // Quantity only applies when adding new copies.
    document.getElementById("quantity-wrapper").classList.add("d-none");

    document.getElementById("btn-save").innerText = "Update";
    document.getElementById("form-title").innerText = "Edit Book Copy";
    window.scrollTo(0, 0);
};

const deleteRecord = async id => {
    if (!await lmsConfirm("Are you sure you want to dispose of this book copy? It moves to the archive, where the Technical Services Librarian can restore it.", { confirmText: "Yes, dispose", danger: true })) return;

    try {
        const formData = new FormData();
        formData.append("operation", "delete");
        formData.append("json", JSON.stringify({ copy_id: id }));

        const response = await axios({
            url: `${baseApiUrl}/book_copies.php`,
            method: "POST",
            data: formData
        });

        if (response.data.status === "success") {
            showAlert(response.data.message, "success");
            loadRecords();
        } else {
            showAlert(response.data.message, "danger");
        }
    } catch (error) {
        showAlert("Failed to dispose of the book copy.", "danger");
    }
};

const deleteSelected = async () => {
    if (selectedIds.size === 0) return;

    if (!await lmsConfirm(`Dispose of ${selectedIds.size} selected book cop${selectedIds.size === 1 ? "y" : "ies"}? They move to the archive, where the Technical Services Librarian can restore them.`, { confirmText: "Yes, dispose", danger: true })) {
        return;
    }

    const btn = document.getElementById("btn-delete-selected");
    btn.disabled = true;

    try {
        const formData = new FormData();
        formData.append("operation", "deleteMultiple");
        formData.append("json", JSON.stringify({ copy_ids: Array.from(selectedIds) }));

        const response = await axios({
            url: `${baseApiUrl}/book_copies.php`,
            method: "POST",
            data: formData
        });

        showAlert(response.data.message, response.data.status === "success" ? "success" : "danger");
        selectedIds = new Set();
        loadRecords();
    } catch (error) {
        showAlert("Failed to dispose of the selected book copies.", "danger");
        updateBulkControls();
    }
};

/* ---------------- Archive of disposed copies ---------------- */

const reasonBadge = (reason) => {
    if (reason === "Lost") return '<span class="badge bg-danger">Lost</span>';
    if (reason === "Damaged") return '<span class="badge bg-warning text-dark">Damaged</span>';
    return '<span class="badge bg-secondary">Disposed</span>';
};

const loadArchive = async () => {
    const body = document.getElementById("archive-body");
    if (!body) return;

    try {
        const response = await axios.get(`${baseApiUrl}/book_copies.php`, { params: { operation: "getArchive" } });
        const rows = Array.isArray(response.data) ? response.data : [];

        document.getElementById("archive-count").textContent = rows.length;

        if (rows.length === 0) {
            body.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Nothing has been archived yet.</td></tr>';
            return;
        }

        body.innerHTML = rows.map((row) => `
            <tr>
                <td class="fw-semibold">${escapeHtml(row.title) || "Unknown book"}</td>
                <td class="text-nowrap">ACC-${escapeHtml(row.accession_number)}</td>
                <td>${escapeHtml(row.condition)}</td>
                <td>${reasonBadge(row.reason)}</td>
                <td class="text-nowrap">${escapeHtml(String(row.disposed_at || "").slice(0, 16))}</td>
                <td>${escapeHtml(row.disposed_by) || "—"}</td>
                <td>
                    <button class="btn btn-outline-success btn-sm" onclick="restoreCopy(${Number(row.archive_id)})">Restore</button>
                </td>
            </tr>`).join("");
    } catch (error) {
        const reason = error.response && error.response.data && error.response.data.message;
        body.innerHTML = `<tr><td colspan="7" class="text-center text-danger">${escapeHtml(reason || "Could not load the archive.")}</td></tr>`;
    }
};

const restoreCopy = async (archiveId) => {
    if (!await lmsConfirm("Restore this copy to the library as an available copy?", { confirmText: "Yes, restore", danger: false })) return;

    try {
        const formData = new FormData();
        formData.append("operation", "restore");
        formData.append("json", JSON.stringify({ archive_id: archiveId }));

        const response = await axios({ url: `${baseApiUrl}/book_copies.php`, method: "POST", data: formData });

        showAlert(response.data.message, response.data.status === "success" ? "success" : "danger");
        loadRecords();
    } catch (error) {
        showAlert("Failed to restore the book copy.", "danger");
    }
};

const clearForm = () => {
    document.getElementById("editing-id").value = "";

    ["book_id", "status_id", "condition"].forEach(id => {
        document.getElementById(id).value = "";
    });

    document.getElementById("quantity").value = 1;
    document.getElementById("quantity-wrapper").classList.remove("d-none");

    document.getElementById("btn-save").innerText = "Save";
    document.getElementById("form-title").innerText = "Add Book Copy";
    document.getElementById("alert-box").innerHTML = "";

    setAccessionPreview();
};

const showAlert = (msg, type) => {
    document.getElementById("alert-box").innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${escapeHtml(msg)}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>`;
};

window.editRecord = editRecord;
window.deleteRecord = deleteRecord;
window.restoreCopy = restoreCopy;
window.toggleSelect = toggleSelect;