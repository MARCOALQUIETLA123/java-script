const baseApiUrl = "api"; // relative to the page, so it works from any folder

const escapeHtml = (value) => String(value ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const UNIT_LABELS = { day: "day", week: "week", month: "month", semester: "semester" };

let loaded = null; // the rules as last read from the server

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("rules-form").addEventListener("submit", (e) => { e.preventDefault(); saveRules(); });
    document.getElementById("btn-discard").addEventListener("click", () => { if (loaded) fillForm(loaded); });
    loadRules();
});

const showAlert = (msg, type) => {
    const box = document.getElementById("alert-box");
    box.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert"><span></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
    box.querySelector("span").textContent = msg; // plain text, never HTML
};

const rows = () => [...document.querySelectorAll(".rule-row")];

// "day" / "days" etc. so "1 days" never shows.
const refreshUnitLabels = (row) => {
    const select = row.querySelector("select");
    const input = row.querySelector("input");
    if (!select) return;
    const one = Number(input.value) === 1;
    [...select.options].forEach((o) => { o.textContent = UNIT_LABELS[o.value] + (one ? "" : "s"); });
};

const buildRow = (row, rule, units) => {
    const key = row.dataset.key;
    const isCount = row.dataset.count === "1";

    const unitControl = isCount
        ? (row.dataset.suffix ? `<span class="rule-suffix">${escapeHtml(row.dataset.suffix)}</span>` : "")
        : `<select class="form-select" id="unit-${key}" aria-label="${escapeHtml(row.dataset.label)} unit">
               ${units.map((u) => `<option value="${u}">${u}</option>`).join("")}
           </select>`;

    row.innerHTML = `
        <label class="rule-label" for="value-${key}">${escapeHtml(row.dataset.label)}</label>
        <div class="rule-inputs">
            <input type="number" class="form-control" id="value-${key}" min="1" step="1" inputmode="numeric" required>
            ${unitControl}
        </div>`;

    row.querySelector("input").addEventListener("input", () => refreshUnitLabels(row));
};

const fillForm = (data) => {
    rows().forEach((row) => {
        const key = row.dataset.key;
        const rule = data.rules[key];
        if (!rule) return;

        if (!row.querySelector("input")) buildRow(row, rule, data.units);

        row.querySelector("input").value = rule.value;
        const select = row.querySelector("select");
        if (select && rule.unit) select.value = rule.unit;
        refreshUnitLabels(row);
    });

    const note = document.getElementById("last-changed");
    if (data.updated_at) {
        const when = new Date(String(data.updated_at).replace(" ", "T"));
        const text = isNaN(when) ? data.updated_at : when.toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
        note.textContent = `Last changed ${data.updated_by ? "by " + data.updated_by + " " : ""}on ${text}.`;
    } else {
        note.textContent = "These are the standard rules. Nothing has been changed yet.";
    }
};

const loadRules = async () => {
    try {
        const response = await axios.get(`${baseApiUrl}/loan_settings.php`, { params: { operation: "getRules" } });
        if (!response.data || !response.data.rules) throw new Error("bad reply");
        loaded = response.data;
        fillForm(loaded);
    } catch (error) {
        const reason = error.response && error.response.data && error.response.data.message;
        showAlert(reason || "Could not load the loan rules.", "danger");
    }
};

const collect = () => {
    const rules = {};
    rows().forEach((row) => {
        const select = row.querySelector("select");
        rules[row.dataset.key] = {
            value: row.querySelector("input").value.trim(),
            unit: select ? select.value : null
        };
    });
    return rules;
};

const saveRules = async () => {
    if (!loaded) return;

    const rules = collect();
    for (const row of rows()) {
        const v = rules[row.dataset.key].value;
        if (!/^\d+$/.test(v) || Number(v) < 1) {
            showAlert(`${row.dataset.label} needs a whole number of 1 or more.`, "danger");
            row.querySelector("input").focus();
            return;
        }
    }

    const btn = document.getElementById("btn-save");
    btn.disabled = true;

    try {
        const fd = new FormData();
        fd.append("operation", "update");
        fd.append("json", JSON.stringify({ rules }));
        const response = await axios.post(`${baseApiUrl}/loan_settings.php`, fd);

        if (response.data && response.data.status === "success") {
            document.getElementById("alert-box").innerHTML = "";
            if (window.lmsToast) lmsToast(response.data.message, "success"); else showAlert(response.data.message, "success");
            await loadRules();
        } else {
            showAlert((response.data && response.data.message) || "Could not save the loan rules.", "danger");
        }
    } catch (error) {
        const reason = error.response && error.response.data && error.response.data.message;
        showAlert(reason || "Could not save the loan rules.", "danger");
    } finally {
        btn.disabled = false;
    }
};
